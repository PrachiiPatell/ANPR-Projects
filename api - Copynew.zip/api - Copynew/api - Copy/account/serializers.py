from rest_framework import serializers
from .models import User,BusinessDetail,BusinessParkingDetail,Roles,Permission,UserRoleMapping,AddUserEmail,UserType,MenuPage,Currency,Sites,OTP  ##UserRolePermission
from rest_framework.validators import UniqueValidator
from django.contrib.auth.password_validation import validate_password

from rest_framework import serializers
from django.contrib.auth.tokens import default_token_generator
from django.utils.encoding import force_bytes
from django.utils.http import urlsafe_base64_encode
from django.template import loader
from django.core.validators import validate_email
from django.core.exceptions import ValidationError
from django.core.mail import send_mail
from myapp.models import Building,BuildingParkingDetail
from django.db.models import Sum

class CurrencySerializer(serializers.ModelSerializer):
    currency_type = serializers.CharField(required=True,validators=[UniqueValidator(queryset=Currency.objects.all())])
    currency_symbol = serializers.CharField(required=True,validators=[UniqueValidator(queryset=Currency.objects.all())])
    class Meta:
        model = Currency
        fields = ['id','currency_type','currency_symbol']

class BusinessDetailSerializer(serializers.ModelSerializer):
    business_name = serializers.CharField(required=True,validators=[UniqueValidator(queryset=BusinessDetail.objects.all())])
    class Meta:
        model = BusinessDetail
        #fields = ['business_name','uses_type','anpr_check_allowed','blacklist_check_allowed','created_datetime','end_datetime','days_to_expire','account_validity']
        fields = ['id','business_name','business_type','business_logo','country','uses_type','anpr_check_allowed','blacklist_check_allowed','total_parking','total_occupied_parking','plan_start_datetime','plan_expire_datetime','days_to_expire','minutes_to_expire','plan_validity','timezones']
        # fields = ['business_name','business_type','plan_expire_datetime','total_number_of_wings','plan_validity','days_to_expire','total_number_of_parking','total_number_of_occupants']
    def create(self, validated_data):
       # building_parking_sum = Building.objects.filter(business_detail_id=validated_data['id']).aggregate(Sum('total_parking'))
        #if building_parking_sum['total_parking__sum'] == None:
         #       building_parking_sum['total_parking__sum'] = 0
        #if building_parking_sum['total_parking__sum'] > validated_data['total_parking']:
         #   raise serializers.ValidationError({"total_parking":"Business Parking are already in use please update building parking count first."})
        return super().create(validated_data)
    def update(self, instance, validated_data):
        building_parking_sum = Building.objects.filter(business_detail_id=instance.pk).aggregate(Sum('total_parking'))
        if building_parking_sum['total_parking__sum'] == None:
                building_parking_sum['total_parking__sum'] = 0
        if building_parking_sum['total_parking__sum'] > validated_data['total_parking']:
            raise serializers.ValidationError({'total_parking':"Business Parking are already in use please update building parking count first."})
        return super().update(instance, validated_data)
    
class BusinessParkingDetailSerializer(serializers.ModelSerializer):
    parking_size_and_type_name = serializers.CharField(source='vehicle_parking_size_and_type_id.parking_size_and_type_name', read_only=True)
    business_name = serializers.CharField(source='business_detail_id.business_name',read_only=True)
    class Meta:
        model = BusinessParkingDetail
        fields = ['id','total_parking','total_occupied_parking','vehicle_parking_size_and_type_id','parking_size_and_type_name','business_detail_id','business_name']
    def create(self, validated_data):
        if BusinessParkingDetail.objects.filter(vehicle_parking_size_and_type_id=validated_data['vehicle_parking_size_and_type_id'],business_detail_id=validated_data['business_detail_id']).exists():
            raise serializers.ValidationError(
                {"vehicle_parking_size_and_type_id":"Business parking size and type already exist."})
        business_total_parking_detail_sum = BusinessParkingDetail.objects.filter(business_detail_id=validated_data['business_detail_id']).aggregate(Sum('total_parking'))
        business_parking_detail = BusinessDetail.objects.filter(id=self.initial_data.get('business_detail_id')).values('total_parking').first()
        if business_total_parking_detail_sum['total_parking__sum'] == None:
            business_total_parking_detail_sum['total_parking__sum'] = 0
        if business_parking_detail != None:
            if business_total_parking_detail_sum['total_parking__sum']+validated_data['total_parking'] > business_parking_detail['total_parking']:
                raise serializers.ValidationError(
                    {"total_parking":"Business parking total "+str(business_total_parking_detail_sum['total_parking__sum']+validated_data['total_parking'])+" are greater than business "+str(business_parking_detail['total_parking'])+"."})
        return super().create(validated_data)
    def update(self, instance, validated_data):
        if BusinessParkingDetail.objects.filter(vehicle_parking_size_and_type_id=validated_data['vehicle_parking_size_and_type_id'],business_detail_id=validated_data['business_detail_id']).exclude(id=instance.pk).exists():
            raise serializers.ValidationError(
                {"vehicle_parking_size_and_type_id":"Business parking size and type already exist."})
        business_total_parking_detail_sum = BusinessParkingDetail.objects.filter(business_detail_id=validated_data['business_detail_id']).exclude(id=instance.pk).aggregate(Sum('total_parking'))
        business_parking_detail = BusinessDetail.objects.filter(id=self.initial_data.get('business_detail_id')).values('total_parking').first()
        if business_total_parking_detail_sum['total_parking__sum'] == None:
            business_total_parking_detail_sum['total_parking__sum'] = 0
        if business_parking_detail != None:
            if business_total_parking_detail_sum['total_parking__sum']+validated_data['total_parking'] > business_parking_detail['total_parking']:
                raise serializers.ValidationError(
                    {"total_parking":"Business parking total "+str(business_total_parking_detail_sum['total_parking__sum']+validated_data['total_parking'])+" are greater than business "+str(business_parking_detail['total_parking'])+"."})
        building_parking_size_type = BuildingParkingDetail.objects.filter(vehicle_parking_size_and_type_id=validated_data['vehicle_parking_size_and_type_id'], business_detail_id=validated_data['business_detail_id']).aggregate(Sum('total_parking'))
        if building_parking_size_type['total_parking__sum'] == None:
           building_parking_size_type['total_parking__sum'] = 0
        if building_parking_size_type['total_parking__sum'] > validated_data['total_parking']:
            raise serializers.ValidationError({"total_parking":'Business Parking size and type total are '+str(validated_data['total_parking'])+' less than building parking count '+str(building_parking_size_type['total_parking__sum'])+'.'})
        return super().update(instance, validated_data)
    def delete(self,instance):
        if BuildingParkingDetail.objects.filter(vehicle_parking_size_and_type_id=instance.vehicle_parking_size_and_type_id,business_detail_id=instance.business_detail_id).exists():
            raise serializers.ValidationError({'submit':'Occupant parking size and type are exist in vehicle parking.'})
        try:
            instance.delete()
        except Exception as e:
            raise serializers.ValidationError({'submit': 'Cannot delete. This object is referenced by other objects.'})
    
class AddUserEmailSerializer(serializers.ModelSerializer):
    email = serializers.EmailField(required=True,validators=[UniqueValidator(queryset=User.objects.all())])
    role_name = serializers.CharField(source='role.role_name', read_only=True)
    class Meta:
        model = AddUserEmail
        fields = ['id','email','role','role_name','business_detail_id']

class RoleSerializer(serializers.ModelSerializer):
    class Meta:
        model = Roles
        fields = ['id','role_name','business_detail_id','created_by','created_datetime']

    def create(self,validated_data):
        role_name = validated_data.get('role_name', '').strip()

        if role_name:
        
            validated_data['role_name'] = role_name.capitalize()
        if Roles.objects.filter(
                business_detail_id = validated_data['business_detail_id'],
                role_name=validated_data['role_name']).exists():
            raise serializers.ValidationError(
                    {'role_name': 'An entry with the same role name of this company already exists.'}
                )
        return Roles.objects.create(**validated_data)
        
 

    def update(self, instance, validated_data):
        role_name = validated_data.get('role_name', '').strip()

        if role_name:
           
            validated_data['role_name'] = role_name.capitalize()
        if Roles.objects.filter(
                business_detail_id = validated_data['business_detail_id'],
                role_name=validated_data['role_name']).exclude(pk=getattr(self.instance, 'pk', None)).exists():
            raise serializers.ValidationError(
                    {'role_name': 'An entry with the same role name of this company already exists.'}
                )
        
        return super().update(instance, validated_data)

class UserTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserType
        fields = ['is_menu_visible']

class MenuPageSerializer(serializers.ModelSerializer):
    class Meta:
        model = MenuPage
        fields = ['menu_name','is_menu_type']


class PermissionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Permission
        fields = ['role','menu_page','action']

    def validate(self, attrs):
        role = attrs.get('role')
        menu_page = attrs.get('menu_page')
        action = attrs.get('action')

        # Check if the combination of role_id, menu_page_id, and action_id already exists
        existing_qs = Permission.objects.filter(role=role, menu_page=menu_page, action=action)

        if self.instance:
            # Exclude the current instance from the queryset for updates
            existing_qs = existing_qs.exclude(pk=self.instance.pk)

        if existing_qs.exists():
            raise serializers.ValidationError({'submit': 'This combination of role, menu_page, and action already exists.'})

        return attrs


class UserRoleMappingSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserRoleMapping
        fields = ['user','role','business_detail_id','created_by','created_datetime']


class UserSerializer(serializers.ModelSerializer):
    email = serializers.EmailField(required=True,validators=[UniqueValidator(queryset=User.objects.all())])
    password = serializers.CharField(write_only=True, required=True, validators=[validate_password])
    password2 = serializers.CharField(write_only=True, required=True)
    #business_detail_id = serializers.IntegerField(required=True)
    business_detail_id = serializers.PrimaryKeyRelatedField(queryset=BusinessDetail.objects.all(), required=False)
    class Meta:
        model = User
        fields = ['id','email','phone_number','password','password2','business_detail_id','user_login_or_not','is_superuser','is_active']
    def validate(self, attrs):
        if attrs['password'] != attrs['password2']:
            raise serializers.ValidationError({"password": "Password fields didn't match."})
        return attrs
    def create(self, validated_data):
        user = User.objects.create(
            email=validated_data['email'],
            phone_number=validated_data['phone_number'],
            # anpr_check_allowed=validated_data['anpr_check_allowed'],
            # blacklist_check_allowed=validated_data['blacklist_check_allowed'],
            business_detail_id=validated_data['business_detail_id'],
            user_login_or_not=validated_data['user_login_or_not'],
            is_superuser=validated_data['is_superuser'],
            is_active=validated_data['is_active'])

        user.set_password(validated_data['password'])
        user.save()
        return user


# class UserProfileSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = UserProfileInformation
#         fields = '__all__'


class UserLoginSerializer(serializers.ModelSerializer):
  email = serializers.EmailField(max_length=255)
  class Meta:
    model = User
    fields = ['email', 'password']



class SitesSerializer(serializers.ModelSerializer):
    # site_name = serializers.CharField(required=True,validators=[UniqueValidator(queryset=Sites.objects.all())])
    user_email = serializers.CharField(source='user.email', read_only=True)
    class Meta:
        model = Sites
        fields = ['id','site_name','user','user_email','anpr_check_allowed','blacklist_check_allowed','business_detail','plan_start_datetime','plan_expire_datetime','days_to_expire','minutes_to_expire','plan_validity','timezones','active','user_login_or_not','skip_frame','delete_previous_data_after_day']
    def create(self, validated_data):
        if Sites.objects.filter(business_detail=validated_data['business_detail'], site_name=validated_data['site_name']).exists():
            raise serializers.ValidationError({"site_name":"site name is unique field."})
        if Sites.objects.filter(business_detail=validated_data['business_detail'], user=validated_data['user']).exists():
            raise serializers.ValidationError({"user":"user email is unique field."})
        return super().create(validated_data)
    
    def update(self, instance, validated_data):
        if Sites.objects.filter(business_detail=validated_data['business_detail'], site_name=validated_data['site_name']).exclude(id=instance.pk).exists():
            raise serializers.ValidationError({"site_name":"site name is unique field."})
        if Sites.objects.filter(business_detail=validated_data['business_detail'], user=validated_data['user']).exclude(id=instance.pk).exists():
            raise serializers.ValidationError({"user":"user email is unique field."})
        return super().update(instance, validated_data)


class UserEmailSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id','email']



class OTPSerializer(serializers.ModelSerializer):
    class Meta:
        model = OTP
        fields = '__all__'