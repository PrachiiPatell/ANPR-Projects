from django.contrib import admin
from .models import *
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin

from .forms import UserCreationForm, UserChangeForm

User = get_user_model()

# class UserAdmin(BaseUserAdmin):
#     # The forms to add and change user instances
#     form = UserChangeForm
#     add_form = UserCreationForm

#     # The fields to be used in displaying the User model.
#     # These override the definitions on the base UserAdmin
#     # that reference specific fields on auth.User.
#     list_display = ['email', 'admin']
#     list_filter = ['admin']
#     fieldsets = (
#         (None, {'fields': ('email', 'password')}),
#         ('Personal info', {'fields': ()}),
#         ('Permissions', {'fields': ('admin',)}),
#     )
#     # add_fieldsets is not a standard ModelAdmin attribute. UserAdmin
#     # overrides get_fieldsets to use this attribute when creating a user.
#     add_fieldsets = (
#         (None, {
#             'classes': ('wide',),
#             'fields': ('email', 'password1', 'password2')}
#         ),
#     )
#     search_fields = ['email']
#     ordering = ['email']
#     filter_horizontal = ()


# admin.site.register(User, UserAdmin)

class AccountAdmin(BaseUserAdmin):
    form = UserChangeForm
    add_form = UserCreationForm



    list_display = ('id','uuid','email', 'phone_number','anpr_check_allowed','blacklist_check_allowed', 'business_detail_id', 'user_login_or_not', 'timezones','is_active', 'is_staff',  'is_superuser')
    list_filter = ('is_superuser',)

    fieldsets = (
        (None, {'fields': ('email','is_active', 'is_staff', 'is_superuser', 'password')}),
        ('Personal info', {'fields': ('phone_number','anpr_check_allowed','blacklist_check_allowed', 'business_detail_id', 'user_login_or_not', 'timezones')}),
        ('Groups', {'fields': ('groups',)}),
        ('Permissions', {'fields': ('user_permissions',)}),
    )
    add_fieldsets = (
        (None, {'fields': ('email','is_active','is_staff', 'is_superuser', 'password1', 'password2')}),
        ('Personal info', {'fields': ('phone_number','anpr_check_allowed','blacklist_check_allowed', 'business_detail_id', 'user_login_or_not', 'timezones')}),
        ('Groups', {'fields': ('groups',)}),
        ('Permissions', {'fields': ('user_permissions',)}),
    )

    search_fields = ('phone_number','anpr_check_allowed','blacklist_check_allowed', 'business_detail_id', 'user_login_or_not', 'timezones')
    ordering = ('email',)
    filter_horizontal = ('groups', 'user_permissions',)

    

# admin.site.unregister(User)
# admin.site.register(User, AccountAdmin)


# from django.contrib.auth.models import User

# class AccountAdmin(admin.ModelAdmin):
#     list_display = ('id', 'uuid', 'phone_number', 'anpr_check_allowed', 'blacklist_check_allowed', 'business_detail', 'user_login_or_not', 'timezones')

#     def uuid(self, obj):
#         return obj.user.uuid

#     def phone_number(self, obj):
#         return obj.user.phone_number

#     def anpr_check_allowed(self, obj):
#         return obj.user.anpr_check_allowed

#     def blacklist_check_allowed(self, obj):
#         return obj.user.blacklist_check_allowed

#     def business_detail(self, obj):
#         return obj.user.business_detail

#     def user_login_or_not(self, obj):
#         return obj.user.user_login_or_not

#     def timezones(self, obj):
#         return obj.user.timezones

#     uuid.short_description = 'UUID'
#     phone_number.short_description = 'Phone Number'
#     anpr_check_allowed.short_description = 'ANPR Check Allowed'
#     blacklist_check_allowed.short_description = 'Blacklist Check Allowed'
#     business_detail.short_description = 'business Detail'
#     user_login_or_not.short_description = 'User Login or Not'
#     timezones.short_description = 'Timezones'


# admin.site.register(Account, AccountAdmin)


# class UserProfileInformationAdmin(admin.ModelAdmin):
#     list_display= ('user', 'Country', 'businessName','UsesType','Speed','LaneChange','StartDateTime','EndDateTime','UserLoginOrNot','timezones')

class PrimaryIndustryOptionAdmin(admin.ModelAdmin):
    list_display= ('Industry',)

class PrimaryUseCaseOptionAdmin(admin.ModelAdmin):
    list_display= ('UseCase',)

class BusinessDetailAdmin(admin.ModelAdmin):
    list_display = ('id','business_name','business_type','plan_validity','plan_expire_datetime','days_to_expire','minutes_to_expire','created_by','created_datetime','modified_by','modified_datetime')

class RolesAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','role_name','business_detail_id','created_by','created_datetime','updated_by','updated_datetime')

class UserTypeAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','is_menu_visible')

class MenuPageAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','menu_name','is_menu_type','created_by','created_datetime','updated_by','updated_datetime')

class ActionAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','action_name')

class MenuActionMapAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','menu_page','action')

class PermissionAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','role','menu_page','action')

class UserRoleMappingAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','user','role','business_detail_id','created_by','created_datetime','updated_by','updated_datetime')

class AddUserEmailAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','email','role','business_detail_id')

class OTPAdmin(admin.ModelAdmin):
    list_display = ('user','email','is_verified','otp','otp_validity')

# Register your models here.
# admin.site.register(UserProfileInformation,UserProfileInformationAdmin)
admin.site.register(BusinessDetail,BusinessDetailAdmin)
admin.site.register(Roles,RolesAdmin)
admin.site.register(UserType,UserTypeAdmin)
admin.site.register(MenuPage,MenuPageAdmin)
admin.site.register(Action,ActionAdmin)
admin.site.register(MenuActionMap,MenuActionMapAdmin)
admin.site.register(Permission,PermissionAdmin)
admin.site.register(UserRoleMapping,UserRoleMappingAdmin)
admin.site.register(AddUserEmail,AddUserEmailAdmin)
admin.site.register(NumberOfWheeler)
admin.site.register(BusinessParkingDetail)
admin.site.register(Sites)
admin.site.register(OTP, OTPAdmin)