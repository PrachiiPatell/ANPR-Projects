from django.db import models
# from django.contrib.auth.models import User
import datetime
import uuid
from django.contrib.postgres.functions import RandomUUID
import pytz
from django.contrib.auth.models import (
    BaseUserManager, AbstractBaseUser,AbstractUser,PermissionsMixin
)
import django
from django.core.validators import RegexValidator

import random
import string
from django.core.mail import send_mail
#from django.utils.encoding import force_bytes, force_text
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.template.loader import render_to_string
from datetime import timedelta, timezone

from django.core.mail import send_mail
from django.urls import reverse
from django.conf import settings

# Create your models here.

class UserManager(BaseUserManager):
    def create_user(self, email, password=None):
        """
        Creates and saves a User with the given email and password.
        """
        if not email:
            raise ValueError('Users must have an email address')

        user = self.model(
            email=self.normalize_email(email),
        )

        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_staffuser(self, email, password):
        """
        Creates and saves a staff user with the given email and password.
        """
        user = self.create_user(
            email,
            password=password,
        )
        user.staff = True
        user.save(using=self._db)
        return user

    def create_superuser(self, email, password):
        """
        Creates and saves a superuser with the given email and password.
        """
        user = self.create_user(
            email,
            password=password,
            
        )
        user.staff = True
        user.admin = True
        user.save(using=self._db)
        return user
    



class AccountManager(BaseUserManager):
    use_in_migrations = True

    def _create_user(self, email, business_detail_id, password, **extra_fields):
        values = [email, business_detail_id]
        field_value_map = dict(zip(self.model.REQUIRED_FIELDS, values))
        for field_name, value in field_value_map.items():
            if not value:
                raise ValueError('The {} value must be set'.format(field_name))

        email = self.normalize_email(email)
        user = self.model(
            email=email,
            business_detail_id_id=business_detail_id,
            **extra_fields
        )
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_user(self, email, business_detail_id, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', False)
        extra_fields.setdefault('is_superuser', False)
        return self._create_user(email, business_detail_id, password, **extra_fields)

    def create_superuser(self, email, business_detail_id, password=None, **extra_fields):
        extra_fields.setdefault('is_active', True)
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)

        if extra_fields.get('is_staff') is not True:
            raise ValueError('Superuser must have is_staff=True.')
        if extra_fields.get('is_superuser') is not True:
            raise ValueError('Superuser must have is_superuser=True.')

        return self._create_user(email, business_detail_id, password, **extra_fields)

# class BusinessDetail(models.Model):
#     uuid = models.UUIDField(default = uuid.uuid4,editable = False)
#     company_name = models.CharField(max_length=50)
#     company_logo = models.TextField(blank=True,null=True)
#     country = models.CharField(max_length=20)
#     uses_type = models.CharField(max_length=100,default='free trail')
#     anpr_check_allowed = models.BooleanField(default=True)
#     blacklist_check_allowed = models.BooleanField(default=True)
#     start_datetime = models.DateTimeField(default=django.utils.timezone.now)
#     end_datetime = models.DateTimeField(default=django.utils.timezone.now)
#     days_to_expire = models.IntegerField(default=15)
#     account_validity = models.BooleanField(default=True)
#     created_by = models.CharField(max_length=50,blank=True, null=True)
#     created_datetime = models.DateTimeField(default=django.utils.timezone.now)
#     updated_by = models.CharField(max_length=50,blank=True, null=True)
#     updated_datetime = models.DateTimeField(default=django.utils.timezone.now)


class Currency(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    currency_type = models.CharField(max_length=20)
    currency_symbol = models.CharField(max_length=10)


class BusinessDetail(models.Model):
    business_name = models.CharField(max_length=50)
    business_type = models.CharField(max_length=50)
    business_logo = models.ImageField(upload_to='parking-management/logo/',blank=True,null=True)
    # business_logo = models.TextField(blank=True,null=True)
    country = models.CharField(max_length=20,default='India')
    uses_type = models.CharField(max_length=100,default='free trail')
    anpr_check_allowed = models.BooleanField(default=True)
    blacklist_check_allowed = models.BooleanField(default=True)
    total_parking = models.IntegerField()
    total_occupied_parking = models.IntegerField(default=0)
    plan_start_datetime = models.DateTimeField()
    plan_expire_datetime = models.DateTimeField()
    days_to_expire = models.IntegerField(default=15)
    minutes_to_expire = models.IntegerField(default=21600)
    delete_previous_data_after_day = models.IntegerField(default=60)
    plan_validity = models.BooleanField(default=False)
    currency = models.ForeignKey(Currency,on_delete=models.PROTECT,null=True)
    timezones = models.CharField(max_length=50,default='Asia/Kolkata')
    created_datetime = models.DateTimeField(auto_now_add=True,blank=True, null=True)
    modified_datetime = models.DateTimeField(auto_now=True,blank=True, null=True)
    created_by = models.CharField(max_length=50,blank=True, null=True)
    modified_by = models.CharField(max_length=50,blank=True, null=True)

class NumberOfWheeler(models.Model):
    wheeler = models.CharField(max_length=20)

class VehicleType(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    vehicle_type = models.CharField(max_length=50)
    number_of_wheeler_id = models.ForeignKey(NumberOfWheeler,on_delete=models.PROTECT)
    business_detail_id = models.ForeignKey(BusinessDetail, on_delete=models.PROTECT)
    created_datetime = models.DateTimeField(auto_now_add=True,blank=True, null=True)
    modified_datetime = models.DateTimeField(auto_now=True,blank=True, null=True)
    created_by = models.CharField(max_length=50,blank=True, null=True)
    modified_by = models.CharField(max_length=50,blank=True, null=True)

class VehicleParkingSizeAndType(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    parking_size_and_type_name = models.CharField(max_length=50)
    parking_size = models.FloatField(default=0.0)
    length = models.FloatField(default=0.0)
    width = models.FloatField(default=0.0)
    vehicle_type_id = models.ForeignKey(VehicleType,on_delete=models.PROTECT)
    business_detail_id = models.ForeignKey(BusinessDetail,on_delete=models.PROTECT)
    created_datetime = models.DateTimeField(auto_now_add=True,blank=True, null=True)
    modified_datetime = models.DateTimeField(auto_now=True,blank=True, null=True)
    created_by = models.CharField(max_length=50,blank=True, null=True)
    modified_by = models.CharField(max_length=50,blank=True, null=True)

class BusinessParkingDetail(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    total_parking = models.IntegerField()
    total_occupied_parking = models.IntegerField(default=0)
    vehicle_parking_size_and_type_id = models.ForeignKey(VehicleParkingSizeAndType,on_delete=models.PROTECT)
    business_detail_id = models.ForeignKey(BusinessDetail, on_delete=models.PROTECT)
    created_datetime = models.DateTimeField(auto_now_add=True,blank=True, null=True)
    modified_datetime = models.DateTimeField(auto_now=True,blank=True, null=True)
    created_by = models.CharField(max_length=50,blank=True, null=True)
    modified_by = models.CharField(max_length=50,blank=True, null=True)

class Roles(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    role_name = models.CharField(max_length=50)
    business_detail_id= models.ForeignKey(BusinessDetail, on_delete=models.PROTECT)
    created_by = models.CharField(max_length=50,blank=True, null=True)
    created_datetime = models.DateTimeField(default=django.utils.timezone.now)
    updated_by = models.CharField(max_length=50,blank=True, null=True)
    updated_datetime = models.DateTimeField(default=django.utils.timezone.now)

class UserType(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    is_menu_visible = models.CharField(max_length=100)

class MenuPage(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    menu_name = models.CharField(max_length=100)
    is_menu_type = models.ForeignKey(UserType, on_delete=models.PROTECT)
    created_by = models.CharField(max_length=50,blank=True, null=True)
    created_datetime = models.DateTimeField(default=django.utils.timezone.now)
    updated_by = models.CharField(max_length=50,blank=True, null=True)
    updated_datetime = models.DateTimeField(default=django.utils.timezone.now)

class Action(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    action_name = models.CharField(max_length=100)

class MenuActionMap(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    menu_page = models.ForeignKey(MenuPage, on_delete=models.PROTECT)
    action = models.ForeignKey(Action, on_delete=models.PROTECT)

class Permission(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    role = models.ForeignKey(Roles, on_delete=models.PROTECT)
    menu_page = models.ForeignKey(MenuPage, on_delete=models.PROTECT)
    action = models.ForeignKey(Action, on_delete=models.PROTECT)

class User(AbstractBaseUser,PermissionsMixin):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    email = models.EmailField(verbose_name='email address',max_length=255,unique=True,)
    phone_regex = RegexValidator(regex=r'^\+?1?\d{11,15}$', message="Phone number must be entered in the format: '+919999999999'. Up to 15 digits allowed.")
    phone_number = models.CharField(validators=[phone_regex], max_length=17, blank=True) # Validators should be a list
    #anpr_check_allowed = models.BooleanField(default=True)
    #blacklist_check_allowed = models.BooleanField(default=True)
    business_detail_id = models.ForeignKey(BusinessDetail, on_delete=models.PROTECT)
    user_login_or_not = models.BooleanField(default=False)
    timezones = models.CharField(max_length=50,default='Asia/Kolkata')
    is_active = models.BooleanField(default=False)
    is_staff = models.BooleanField(default=False) # a admin user; non super-user
    date_joined = models.DateTimeField(default=django.utils.timezone.now)
    last_login = models.DateTimeField(null=True)

    is_verified = models.BooleanField(default=False)
    
    # password_reset_token = models.CharField(max_length=255, blank=True, null=True)
    # password_reset_token_expiry = models.DateTimeField(blank=True, null=True)

    def send_reset_email(self):
        token = self.password_reset_token
        email_body = f"Please click the link below to reset your password: {settings.SITE_URL}{reverse('password_reset_confirm', args=[token])}/"
        send_mail(
            'Password reset request',
            email_body,
            'anprsolutionsllp@gmail.com',
            [self.email],
            fail_silently=False,
        )
    # notice the absence of a "Password field", that is built in.

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['business_detail_id'] # Email & Password are required by default.
    objects = AccountManager()
    def get_full_name(self):
        # The user is identified by their email address
        return self.email

    def get_short_name(self):
        # The user is identified by their email address
        return self.email


class UserRoleMapping(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    user = models.ForeignKey(User, on_delete=models.PROTECT)
    role = models.ForeignKey(Roles, on_delete=models.PROTECT)
    business_detail_id = models.ForeignKey(BusinessDetail, on_delete=models.PROTECT)
    created_by = models.CharField(max_length=50,blank=True, null=True)
    created_datetime = models.DateTimeField(default=django.utils.timezone.now)
    updated_by = models.CharField(max_length=50,blank=True, null=True)
    updated_datetime = models.DateTimeField(default=django.utils.timezone.now)

class AddUserEmail(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    email = models.EmailField(verbose_name='email address',max_length=255,unique=True,)
    role = models.ForeignKey(Roles, on_delete=models.PROTECT)
    business_detail_id = models.ForeignKey(BusinessDetail, on_delete=models.PROTECT)


class Sites(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False) 
    site_name = models.CharField(max_length=30)
    user = models.ForeignKey(User, on_delete=models.PROTECT)
    anpr_check_allowed = models.BooleanField(default=True)
    blacklist_check_allowed = models.BooleanField(default=True)
    business_detail = models.ForeignKey(BusinessDetail, on_delete=models.PROTECT)
    plan_start_datetime = models.DateTimeField(default=django.utils.timezone.now)
    plan_expire_datetime = models.DateTimeField(default=django.utils.timezone.now)
    days_to_expire = models.IntegerField(default=15)
    minutes_to_expire = models.IntegerField(default=21600)
    plan_validity = models.BooleanField(default=True)
    timezones = models.CharField(max_length=50,default='Asia/Kolkata')
    active = models.BooleanField(default=True)
    user_login_or_not = models.BooleanField(default=False)
    skip_frame = models.IntegerField(default=5)
    delete_previous_data_after_day = models.IntegerField(default=30)
    created_by = models.CharField(max_length=50,blank=True, null=True)
    created_datetime = models.DateTimeField(default=django.utils.timezone.now)
    updated_by = models.CharField(max_length=50,blank=True, null=True)
    updated_datetime = models.DateTimeField(default=django.utils.timezone.now)

class WindowsSitesActiveLog(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False) 
    sites = models.ForeignKey(Sites, on_delete=models.PROTECT)
    business_detail = models.ForeignKey(BusinessDetail,on_delete=models.PROTECT)
    last_active_datetime = models.DateTimeField(default=django.utils.timezone.now)
    application_open = models.BooleanField(default=False)
    active = models.BooleanField(default=False)
    login = models.BooleanField(default=False)

class WindowsDeactiveLog(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    sites = models.ForeignKey(Sites, on_delete=models.PROTECT)
    business_detail = models.ForeignKey(BusinessDetail,on_delete=models.PROTECT)
    start_datetime = models.DateTimeField(default=django.utils.timezone.now)
    end_datetime = models.DateTimeField(default=django.utils.timezone.now)

class SiteLoginLog(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    sites = models.ForeignKey(Sites, on_delete=models.PROTECT)
    last_login_datetime = models.DateTimeField(default=django.utils.timezone.now)
    mac_address = models.CharField(max_length=17,blank=True, null=True)

class OTP(models.Model):
    user =models.ForeignKey(User, on_delete=models.PROTECT)
    email = models.EmailField(verbose_name='email address', max_length=255)
    is_verified = models.BooleanField(default=False)
    otp = models.CharField(max_length=6)
    otp_validity = models.DateTimeField()

# class UserProfileInformation(models.Model):
#     Uuid = models.UUIDField(default = uuid.uuid4,editable = False)
#     user=models.OneToOneField(User,on_delete=models.PROTECT)   
#     UserLoginOrNot = models.BooleanField(default=False)
#     timezones = models.CharField(max_length=50,default='Asia/Kolkata')
#     created_by = models.CharField(max_length=50,blank=True, null=True)
#     created_datetime = models.DateTimeField(default=django.utils.timezone.now)
#     updated_by = models.CharField(max_length=50,blank=True, null=True)
#     updated_datetime = models.DateTimeField(default=django.utils.timezone.now)


# class PrimaryIndustryOption(models.Model):
#     Industry = models.CharField(max_length=100)

# class PrimaryUseCaseOption(models.Model):
#     UseCase = models.CharField(max_length=100)
class PasswordResetToken(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    token = models.CharField(max_length=100)
    created_at = models.DateTimeField(auto_now_add=True)
    is_valid = models.BooleanField(default=True)

    # def __str__(self):
    #     return f"{self.user.username} - {self.token}"