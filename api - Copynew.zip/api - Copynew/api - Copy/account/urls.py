#from django.conf.urls import url
from django.urls import path,reverse,reverse_lazy
from account import views
#from views import Register
from django.conf.urls.static import static
from django.conf import settings 
from django.contrib.auth import views as auth_views
from .views import *

app_name = 'account'
urlpatterns = [
    # path('register/', views.register, name='register'),
    path("api/register", Register.as_view()),
    path('api/login',Login.as_view()),
    path('api/windows-login',WindowsLogin.as_view()),
    path('api/windows-logout',WindowsLogout.as_view()),
    path('api/windows-get-user-detail',WindowsGetUserDetail.as_view()),
    path('api/add-new-business',AddBusiness.as_view()),
    path('api/business',BusinessView.as_view()),
    path('api/business/<int:id>',BusinessDetailView.as_view()),
    path('api/business-parking',BusinessParkingView.as_view()),
    path('api/business-parking/<int:id>',BusinessParkingDetailView.as_view()),
    path('api/get-user-detail',GetUserDetail.as_view()),
    # path('api/Login/',views.user_loginApi, name="user_loginApi"),
    # path('api/detail/<int:user_id>', UserProfileDetail,name="UserProfileDetail"),
    # path('api/logout/<int:user_id>', Logout,name="logout"),
    # path("password-reset", auth_views.PasswordResetView.as_view(template_name='reset_password.html',html_email_template_name='emails.html',success_url=reverse_lazy('account:password_reset_done')), name="password_reset"),
    # path("password-reset-done", auth_views.PasswordResetDoneView.as_view(template_name='reset_password_done.html'), name="password_reset_done"),
    # path("password-reset-confirm/<uidb64>/<token>", auth_views.PasswordResetConfirmView.as_view(template_name='password_reset_confirm.html',success_url=reverse_lazy('account:password_reset_complete')), name="password_reset_confirm"),
    # path("password-reset-complete", auth_views.PasswordResetCompleteView.as_view(template_name='password_reset_complete.html'), name="password_reset_complete"),
    #path("password-reset", PasswordResetView.as_view()),
    #path("password-reset-done", auth_views.PasswordResetDoneView.as_view(template_name='reset_password_done.html'), name="password_reset_done"),
    #path("password-reset-confirm/<str:uidb64>/<str:token>", auth_views.PasswordResetConfirmView.as_view(), name="password_reset_confirm"),
    #path("password-reset-complete", auth_views.PasswordResetCompleteView.as_view(template_name='password_reset_complete.html'), name="password_reset_complete"),
    path('api/add-user-email', AddUserEmailView.as_view()),
    path('api/add-user-email/<int:id>', UserEmailDetailView.as_view()),
    path('api/site', SiteView.as_view()),
    path('api/site/<int:id>', SitesDetailView.as_view()),
    path('api/user-email', UserEmailView.as_view()),
    path('api/roles',RoleDropdownView.as_view()),
    path('roles_and_permissions/', RolesAndPermissionView.as_view()),
    path('roles_and_permissions_detail/<int:id>', RolesAndPermissionDetailView.as_view()),

    path('get_roles_and_permissions/',GetRolesAndPermissionView.as_view()),
    path('send_otp/', SendOTP.as_view()),

    path('verify_otp/', VerifyOTP.as_view()),
    path('password-reset/', PasswordResetView.as_view(), name='password_reset'),
    path('password-reset-confirm/<str:token>/', PasswordResetConfirmationView.as_view(), name='password_reset_confirm'),
    path('password-reset-complete/', PasswordResetCompleteView.as_view(), name='password_reset_complete'),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

# + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)