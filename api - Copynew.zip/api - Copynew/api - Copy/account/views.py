from django.shortcuts import render,redirect

# Create your views here.
# from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
# from .forms import UserProfileInformationForm
from .models import User,Roles,MenuPage,MenuActionMap,UserType,BusinessDetail,BusinessParkingDetail,AddUserEmail,Permission,Action,UserRoleMapping,Sites,WindowsSitesActiveLog,WindowsDeactiveLog, OTP #,UserProfileInformation
from django.contrib.auth import authenticate,login,logout
from django.http import HttpResponseRedirect,HttpResponse
from django.http.response import JsonResponse,Http404
from rest_framework.response import Response
from rest_framework.parsers import JSONParser
from rest_framework.decorators import api_view
from rest_framework.views import APIView
from .serializers import UserSerializer,BusinessDetailSerializer,BusinessParkingDetailSerializer,RoleSerializer,PermissionSerializer,UserRoleMappingSerializer,AddUserEmailSerializer,UserLoginSerializer,CurrencySerializer,UserEmailSerializer,SitesSerializer, OTPSerializer  ##UserRolePermissionSerializer
from rest_framework import status
from datetime import datetime,timedelta
from django.utils import timezone
#from django_countries import countries
from django.core.mail import EmailMultiAlternatives,send_mail
from django.conf import settings
from django.template.loader import render_to_string, get_template
from rest_framework_simplejwt.tokens import RefreshToken
from django.db import transaction
from django.db.models import Count
from django.db.models import F
from rest_framework.permissions import AllowAny,IsAuthenticated
from rest_framework_simplejwt.backends import TokenBackend
from django.core.exceptions import ValidationError
from rest_framework.response import Response
#from .serializers import PasswordResetSerializer
from django.contrib.auth import get_user_model
from django.contrib.auth import get_user_model, update_session_auth_hash
from django.utils.http import urlsafe_base64_decode,urlsafe_base64_encode
from django.utils.encoding import force_bytes, force_text
from django.contrib.auth.tokens import default_token_generator
from rest_framework import views
from django.contrib.auth import get_user_model
import uuid
from rest_framework.pagination import LimitOffsetPagination
import pytz
import asyncio
import random
from django.core.exceptions import PermissionDenied
from .utils import generate_and_send_otp, save_token_in_database
from django.shortcuts import render, get_object_or_404
from django.utils import timezone
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_exempt
from .models import PasswordResetToken
from django.contrib import messages
from django.contrib.auth import get_user_model
from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.urls import reverse

# get_menu_action = MenuActionMap.objects.values('id','menu_page','action').all()[2:20]
# print(get_menu_action)

# GetPermissionData = MenuActionMap.objects.filter(action=1).values('menu_page','menu_page__menu_name').distinct('menu_page')
# print(GetPermissionData)


def getUserData(user):
    user_detail = User.objects.filter(id=user).values('id','email','business_detail_id').first()
    if user_detail is None:
        # handle the case where the user is not found
        return None
    #business_details = BusinessDetail.objects.filter(id=user_detail['business_detail_id']).values('id','business_name').first()
    business_details = BusinessDetail.objects.filter(id=user_detail['business_detail_id']).values('id','business_name', 'plan_expire_datetime','plan_validity','timezones').first()
    user_role_maps = UserRoleMapping.objects.filter(user=user_detail['id']).values('id','role').first()
    TimeZoneLoc = pytz.timezone(business_details['timezones'])
    diff = None
    try:
        diff = datetime.strptime(str(business_details['plan_expire_datetime']), '%Y-%m-%d %H:%M:%S.%f+00:00') - datetime.strptime(str(datetime.now()), '%Y-%m-%d %H:%M:%S.%f')
    except Exception as e:
        diff = datetime.strptime(str(business_details['plan_expire_datetime']), '%Y-%m-%d %H:%M:%S+00:00') - datetime.strptime(str(datetime.now()), '%Y-%m-%d %H:%M:%S.%f')
    if int(diff.total_seconds() / 60.0) > 0:
        BusinessDetail.objects.filter(id=user_detail['business_detail_id']).update(plan_validity=True,days_to_expire=diff.days,minutes_to_expire=int(diff.total_seconds() / 60.0))
    else:
        BusinessDetail.objects.filter(id=user_detail['business_detail_id']).update(plan_validity=False,days_to_expire=diff.days,minutes_to_expire=int(diff.total_seconds() / 60.0))
    business_details = BusinessDetail.objects.filter(id=user_detail['business_detail_id']).values('id','business_name','business_type','business_logo','country','uses_type','anpr_check_allowed','blacklist_check_allowed','plan_start_datetime','plan_expire_datetime','days_to_expire','minutes_to_expire','plan_validity','timezones','currency__currency_symbol').first()
    role_detail = Roles.objects.filter(id=user_role_maps['role']).values('id','role_name').last()
    get_menu_data = Permission.objects.filter(role=user_role_maps['role']).values('id','menu_page','menu_page__menu_name').distinct('menu_page')
    permissions = {}
    for get_menu in get_menu_data:
        get_action = Permission.objects.filter(role=user_role_maps['role'],menu_page=get_menu['menu_page']).values('id','menu_page','action','action__action_name').distinct('action')
        permissions[get_menu['menu_page__menu_name']] = []
        for get_action in get_action:
            permissions[get_menu['menu_page__menu_name']].append(get_action.get('action__action_name'))
    data = {'user_detail':user_detail,'business_detail':business_details,'role_detail':role_detail,'permission':permissions}
    return data




# class Register(APIView):
#     permission_classes = (AllowAny,)
#     def post(self, request, format=None):
#         add_user_emails = AddUserEmail.objects.filter(email=request.data['email']).values('email','role','business_detail_id').first()
#         if add_user_emails != None:
#             get_business_detail = BusinessDetail.objects.filter(id=add_user_emails.get('business_detail')).first()
#             serializer = UserSerializer(data={'email':request.data['email'],'phone_number':request.data['phone_number'],'password':request.data['password'],'password2':request.data['password2'],'business_detail': add_user_emails.get('business_detail'),'user_login_or_not':False,'is_superuser':False,'is_active':False})
#             user_id = None
#             if serializer.is_valid():
#                 obj = serializer.save()
#                 user_id = obj.id
#             else:
#                 return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
#             user_role_map_serializer = UserRoleMappingSerializer(data={'user':user_id,'role':add_user_emails.get('role'),'business_detail': add_user_emails.get('business_detail')})
#             if user_role_map_serializer.is_valid():
#                 user_role_map_serializer.save()
#             else:
#                 User.objects.filter(id=user_id).delete()
#                 return Response(user_role_map_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
#             print("serializer:",serializer.data)
#             user_select = User.objects.filter(id=user_id).last()
#             refresh = RefreshToken.for_user(user_select)
#             user_detail = getUserData(user_id)
#             user_detail['refresh'] = str(refresh)
#             user_detail['access'] = str(refresh.access_token)
#             return Response(user_detail, status=status.HTTP_201_CREATED)
#         else:
#             print("Yes")
#             return Response({"result": {},"message": "Business are not register with this email."}, status=status.HTTP_400_BAD_REQUEST)


class Register(APIView):
    permission_classes = (AllowAny,)
    def post(self, request, format=None):
        add_user_emails = AddUserEmail.objects.filter(email=request.data['email']).values('email','role','business_detail_id').first()
        if add_user_emails != None:
            business_detail_id = add_user_emails.get('business_detail_id')
            get_business_detail = BusinessDetail.objects.filter(id=business_detail_id).first()
            print("serializer:", request.data)
            serializer = UserSerializer(data={
                'email': request.data['email'],
                'phone_number': request.data['phone_number'],
                'password': request.data['password'],
                'password2': request.data['password2'],
                'business_detail_id': business_detail_id,
                'user_login_or_not': False,
                'is_superuser': False,
                'is_active': True
            })
            user_id = None
            if serializer.is_valid():
                obj = serializer.save()
                user_id = obj.id
            else:
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            user_role_map_serializer = UserRoleMappingSerializer(data={
                'user': user_id,
                'role': add_user_emails.get('role'),
                'business_detail_id': business_detail_id
            })
            if user_role_map_serializer.is_valid():
                user_role_map_serializer.save()
            else:
                User.objects.filter(id=user_id).delete()
                return Response(user_role_map_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            
            user_select = User.objects.filter(id=user_id).last()
            refresh = RefreshToken.for_user(user_select)
            user_detail = getUserData(user_id)
            user_detail['refresh'] = str(refresh)
            user_detail['access'] = str(refresh.access_token)
            return Response(user_detail, status=status.HTTP_201_CREATED)
        else:
            print("Yes")
            return Response({"submit": "Business are not register with this email."}, status=status.HTTP_400_BAD_REQUEST)




class AddBusiness(APIView):
    permission_classes = (AllowAny,)

    def post(self, request, format=None):
        # currency_detail = {'currency_type':request.data['currency_type'],'currency_symbol':request.data['currency_symbol']}
        # currency_serializer = CurrencySerializer(data=currency_detail)
        # currency_id = None
        # if currency_serializer.is_valid():
        #     obj = currency_serializer.save()
        #     currency_id = obj.id
        TimeZoneLoc = pytz.timezone('Asia/Kolkata')
        business_detail = {'business_name':request.data['business_name'],
        'business_type':request.data['business_type'],
        'business_logo':request.data['business_logo'],
        'country':request.data['country'],
        'uses_type':'free trail',
        'anpr_check_allowed':request.data['anpr_check_allowed'],
        'blacklist_check_allowed':request.data['blacklist_check_allowed'],
        'total_parking':request.data['total_parking'],
        'total_occupied_parking':request.data['total_occupied_parking'],
        'plan_start_datetime':datetime.now(),
        'plan_expire_datetime':datetime.now()+timedelta(days=15),
        'days_to_expire':15,
        'minutes_to_expire':21600,
        'plan_validity':True,
        'currency':request.data['currency']
        }
        business_serializer = BusinessDetailSerializer(data=business_detail)
        business_id = None
        if business_serializer.is_valid():
            obj = business_serializer.save()
            business_id = obj.id
        else:
            return Response(business_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        role_detail = {'role_name': 'Admin', 'business_detail_id': business_id}
        role_serializer = RoleSerializer(data=role_detail)
        role_id = None
        if role_serializer.is_valid():
            obj = role_serializer.save()
            role_id = obj.id
        else:
            BusinessDetail.objects.filter(id=business_id).delete()
            return Response(role_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        email = request.data['email']
        add_user_email_serializer = AddUserEmailSerializer(data={'email': email, 'role': role_id, 'business_detail_id': business_id})
        add_user_emailid = None
        if add_user_email_serializer.is_valid():
            obj = add_user_email_serializer.save()
            add_user_emailid = obj.id
        else:
            BusinessDetail.objects.filter(id=business_id).delete()
            Roles.objects.filter(id=role_id).delete()
            return Response(add_user_email_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        permission_id = []
        get_menu_data = MenuPage.objects.exclude(is_menu_type__is_menu_visible='SuperAdmin').all().values('id', 'menu_name')
        for menus in get_menu_data:
            get_menu_action_data = MenuActionMap.objects.filter(menu_page=menus['id']).values('id', 'menu_page', 'action').all()
            for menu_action in get_menu_action_data:
                permission_serializer = PermissionSerializer(data={'role': role_id, 'menu_page': menu_action['menu_page'], 'action': menu_action['action']})
                if permission_serializer.is_valid():
                    obj = permission_serializer.save()
                    permission_id.append(obj.id)
                else:
                    BusinessDetail.objects.filter(id=business_id).delete()
                    Roles.objects.filter(id=role_id).delete()
                    AddUserEmail.objects.filter(id=add_user_emailid).delete()
                    for perm_id in permission_id:
                        Permission.objects.filter(id=perm_id).delete()
                    return Response(permission_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        return Response({'Success': 'Business created successfully.'}, status.HTTP_201_CREATED)

class BusinessView(APIView):
    permission_classes = (IsAuthenticated,)
    def get(self, request, format=None):
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'business' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['business']:
                    AcessToPage = True
            if AcessToPage == True:
                business_detail = BusinessDetail.objects.filter(id=get_user_data['business_detail']['id']).all()
                business_detail_count = BusinessDetail.objects.filter(id=get_user_data['business_detail']['id']).count()
                serializer = BusinessDetailSerializer(business_detail,many=True)
                return  Response({'count':business_detail_count,'results':serializer.data})
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST) 

class BusinessDetailView(APIView):
    permission_classes = (IsAuthenticated,)
    def get_object(self, id):
        try:
            return BusinessDetail.objects.get(pk=id)
        except BusinessDetail.DoesNotExist:
            return Response(status=status.HTTP_404_NOT_FOUND)
    def patch(self,request,id,format=None):
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'business' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['business']:
                    AcessToPage = True
            if AcessToPage == True:
                business_detail = self.get_object(id)
                get_data = request.data
                get_data['business_detail_id'] = get_user_data['business_detail']['id']
                serializer = BusinessDetailSerializer(business_detail,data=get_data,partial=True)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)  
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
    
    
#Vehicle parking size and type api
class BusinessParkingView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'business_parking_detail' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['business_parking_detail']:
                    AcessToPage = True
            if AcessToPage == True:
                business_parking_detail = BusinessParkingDetail.objects.filter(business_detail_id = get_user_data['business_detail']['id']).all() 
                paginator = LimitOffsetPagination()
                serializer = BusinessParkingDetailSerializer(business_parking_detail, many=True)
                result_page = paginator.paginate_queryset(serializer.data, request,view=paginator)
                return paginator.get_paginated_response(result_page)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
    
    def post(self, request, format=None):
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'business_parking_detail' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['business_parking_detail']:
                    AcessToPage = True
            if AcessToPage == True:
                get_data = request.data
                get_data['business_detail_id'] = get_user_data['business_detail']['id']
                serializer = BusinessParkingDetailSerializer(data=get_data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                else:
                    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
        
class BusinessParkingDetailView(APIView):
    permission_classes = (IsAuthenticated,)
    def get_object(self, id):
        try:
            return BusinessParkingDetail.objects.get(pk=id)
        except BusinessParkingDetail.DoesNotExist:
            return Response(status=status.HTTP_404_NOT_FOUND)
    def get(self, request,id, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'business_parking_detail' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['business_parking_detail']:
                    AcessToPage = True
            if AcessToPage == True:
                business_parking_detail = self.get_object(id)
                serializer = BusinessParkingDetailSerializer(business_parking_detail)
                return Response(serializer.data)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
    def put(self, request, id, format=None): 
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'business_parking_detail' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['business_parking_detail']:
                    AcessToPage = True
            if AcessToPage == True:
                business_parking_detail = self.get_object(id)
                get_data = request.data
                get_data['business_detail_id'] = get_user_data['business_detail']['id']
                serializer = BusinessParkingDetailSerializer(business_parking_detail, data=get_data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)  
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
     
    def delete(self, request,id, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = getUserData(request.user.id)
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'business_parking_detail' in get_user_data['permission'].keys():
                if 'delete' in get_user_data['permission']['business_parking_detail']:
                    AcessToPage = True
            if AcessToPage == True:
                business_parking_detail = self.get_object(id)
                serializers = BusinessParkingDetailSerializer(business_parking_detail)
                serializers.delete(business_parking_detail)
                return Response(status=status.HTTP_204_NO_CONTENT)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


    
class Login(APIView):
    permission_classes = (AllowAny,)
    def post(self, request, format=None):
        try:
            serializer = UserLoginSerializer(data=request.data)
            serializer.is_valid(raise_exception=True)
            email = serializer.data.get('email')
            password = serializer.data.get('password')
            user = authenticate(email=email,password=password)
            if user:
                if user.is_active:
                    if user.is_verified:
                        refresh = RefreshToken.for_user(user)
                        user_detail = getUserData(user.id)
                        user_detail['refresh'] = str(refresh)
                        user_detail['access'] = str(refresh.access_token)
                        print(user_detail)
                        return JsonResponse(user_detail, status=status.HTTP_200_OK)
                    else:
                        return Response({"submit":"Please Verify your email."}, status=status.HTTP_400_BAD_REQUEST)
                else:
                    res = {"submit": "Account was not active."}
                    return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)
            else:
                res = {"submit": "Invalid Username and Password."}
                return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            res = {"message": "Internal Server Error.","error":e}
            return JsonResponse(res)
   
class WindowsLogin(APIView):
    permission_classes = (AllowAny,)
    def post(self, request, format=None):
        serializer = UserLoginSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        email = serializer.data.get('email')
        password = serializer.data.get('password')
        print(email,password)
        user = authenticate(email=email,password=password)
        if user:
            if user.is_active:
                getSites = Sites.objects.filter(user=user.id).values('id','site_name','user','anpr_check_allowed','blacklist_check_allowed','business_detail','plan_start_datetime','plan_expire_datetime','days_to_expire','minutes_to_expire','plan_validity','timezones','active','user_login_or_not','skip_frame','delete_previous_data_after_day').first()
                if getSites != None:
                    if getSites['user_login_or_not'] == False:
                        if getSites['active'] == True:
                            TimeZoneLoc = pytz.timezone('Asia/Kolkata')
                            diff = None
                            try:
                                diff = datetime.strptime(str(getSites['plan_expire_datetime']), '%Y-%m-%d %H:%M:%S.%f+00:00') - datetime.strptime(str(datetime.now()), '%Y-%m-%d %H:%M:%S.%f')
                            except Exception as e:
                                diff = datetime.strptime(str(getSites['plan_expire_datetime']), '%Y-%m-%d %H:%M:%S+00:00') - datetime.strptime(str(datetime.now()), '%Y-%m-%d %H:%M:%S.%f')
                            if int(diff.total_seconds() / 60.0) > 0:
                                Sites.objects.filter(id=getSites['id']).update(plan_validity=True,days_to_expire=diff.days,minutes_to_expire=int(diff.total_seconds() / 60.0),user_login_or_not=True)
                            else:
                                Sites.objects.filter(id=getSites['id']).update(plan_validity=False,days_to_expire=diff.days,minutes_to_expire=int(diff.total_seconds() / 60.0),user_login_or_not=True)
                            update_sites = Sites.objects.filter(user=user.id).values('id','site_name','user','anpr_check_allowed','blacklist_check_allowed','business_detail','plan_start_datetime','plan_expire_datetime','days_to_expire','minutes_to_expire','plan_validity','timezones','active','user_login_or_not','skip_frame','delete_previous_data_after_day').first()
                            refresh = RefreshToken.for_user(user)
                            user_detail = getUserData(user.id)
                            user_detail['refresh'] = str(refresh)
                            user_detail['access'] = str(refresh.access_token)
                            user_detail['sites'] = update_sites
                            # print(user_detail)
                            return JsonResponse(user_detail, status=status.HTTP_200_OK)
                        else:
                            res = {"code": 400, "message": "Your Sites is not active."}
                            return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)
                    else:
                        res = {"code": 400, "message": "Your sites account is already login in other system. Please logout first. "}
                        return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)
                else:
                    res = {"code": 400, "message": "Your account is not valid for windows application."}
                    return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)
            else:
                res = {"code": 400, "message": "Account was not active."}
                return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)
        else:
            res = {"code": 400, "message": "Invalid Username and Password."}
            return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)

   
class WindowsLogout(APIView):
    permission_classes = (IsAuthenticated,)
    def post(self, request, format=None):
        
        getSites = Sites.objects.filter(user=request.user.id).values('id','site_name','user','anpr_check_allowed','blacklist_check_allowed','business_detail','plan_start_datetime','plan_expire_datetime','days_to_expire','minutes_to_expire','plan_validity','timezones','active','user_login_or_not','skip_frame','delete_previous_data_after_day').first()
        if getSites != None:
                updateSites = Sites.objects.filter(user=request.user.id).update(user_login_or_not=False)
                res = {"code": 200, "message": "Your account are logout successfully."}
                return JsonResponse(res, status=status.HTTP_200_OK)
        else:
            res = {"code": 400, "message": "Your account is not valid for windows application."}
            return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)

class WindowsGetUserDetail(APIView):
    permission_classes = (IsAuthenticated,)
    def get(self, request, format=None):
        getSites = Sites.objects.filter(user=request.user.id).values('id','site_name','user','anpr_check_allowed','blacklist_check_allowed','business_detail','plan_start_datetime','plan_expire_datetime','days_to_expire','minutes_to_expire','plan_validity','timezones','active','user_login_or_not','skip_frame','delete_previous_data_after_day').first()
        if getSites != None:
            TimeZoneLoc = pytz.timezone(getSites['timezones'])
            try:
                diff = datetime.strptime(str(getSites['plan_expire_datetime']), '%Y-%m-%d %H:%M:%S.%f+00:00') - datetime.strptime(str(datetime.now()), '%Y-%m-%d %H:%M:%S.%f')
            except Exception as e:
                diff = datetime.strptime(str(getSites['plan_expire_datetime']), '%Y-%m-%d %H:%M:%S+00:00') - datetime.strptime(str(datetime.now()), '%Y-%m-%d %H:%M:%S.%f')
            if int(diff.total_seconds() / 60.0) > 0:
                Sites.objects.filter(id=getSites['id']).update(plan_validity=True,days_to_expire=diff.days,minutes_to_expire=int(diff.total_seconds() / 60.0),user_login_or_not=True)
            else:
                Sites.objects.filter(id=getSites['id']).update(plan_validity=False,days_to_expire=diff.days,minutes_to_expire=int(diff.total_seconds() / 60.0),user_login_or_not=True)
            update_sites = Sites.objects.filter(user=request.user.id).values('id','site_name','user','anpr_check_allowed','blacklist_check_allowed','business_detail','plan_start_datetime','plan_expire_datetime','days_to_expire','minutes_to_expire','plan_validity','timezones','active','user_login_or_not','skip_frame','delete_previous_data_after_day').first()
            application_active = request.GET.get('application_active',None)
            if application_active ==None:
                application_active = False
            if application_active != None:
                if application_active == 'true':
                    application_active = True
                else:
                    application_active=False
            get_active_log = WindowsSitesActiveLog.objects.filter(sites_id=getSites['id']).values('id','sites','last_active_datetime').last()
            if get_active_log == None:
                insert_active_log = WindowsSitesActiveLog.objects.create(sites_id=getSites['id'],business_detail_id=getSites['business_detail'], last_active_datetime=datetime.now(),application_open=application_active,active=True)
                insert_active_log.save()
            else:
                last_active_datetime = get_active_log['last_active_datetime']
                diff = datetime.strptime(str(last_active_datetime), '%Y-%m-%d %H:%M:%S.%f+00:00') - datetime.strptime(str(datetime.now()), '%Y-%m-%d %H:%M:%S.%f')
                if int(diff.total_seconds() / 60.0) >= 15:
                    insert_deactive_log =  WindowsDeactiveLog.objects.create(sites_id=getSites['id'],business_detail_id=getSites['business_detail'],start_datetime=last_active_datetime,end_datetime=timezone.now())
                    insert_deactive_log.save()
                update_active_log = WindowsSitesActiveLog.objects.filter(sites_id=getSites['id']).update(last_active_datetime=timezone.now(),application_open=application_active,active=True)
            get_user_data = getUserData(request.user.id)
            get_user_data['sites'] = update_sites
            return JsonResponse(get_user_data, status=status.HTTP_200_OK)
        else:
            res = {"code": 400, "message": "Your account is not valid for windows application."}
            return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)

class GetUserDetail(APIView):
    permission_classes = (IsAuthenticated,)
    # authentication_classes = (TokenAuthentication,)
    
    def get(self, request, format=None):
        try:
            token = request.META.get('HTTP_AUTHORIZATION', " ").split(' ')[1]
            if token != '':
                data = {'token': token}
                print("data:",data)
                valid_data = TokenBackend(algorithm='HS256').decode(token,verify=False)
                print(valid_data)
                user = valid_data['user_id']
                print("User:",user,request.user.id)
                request.user = user
                print("request.user1:",request.user)
            else:
                Response({"result": {},"message": "Invalid Token."}, status=status.HTTP_201_CREATED)
        except ValidationError as v:
            print("validation error", v)
        get_user_data = getUserData(request.user)
        print(get_user_data)
        return Response(get_user_data)




# @api_view(['POST'])
# def user_loginApi(request):
#     if request.method=='POST':
#         UserData = JSONParser().parse(request)
#         print(UserData,type(UserData))
#         GetUserDetail = {'username':str(UserData.get('username')),'password': str(UserData.get('password'))}
#         # UserData_serializer = UserSerializer(data=GetUserDetail)
#         # if UserData_serializer.is_valid():
#         userdetails = authenticate(username=UserData.get('username'),password=UserData.get('password'))  
#         if userdetails:
#             if userdetails.is_active:
#                 # getData = MacAddress.objects.filter(username=UserData.get('username'),MacAddress=UserData.get('MacAddress')).values()
#                 getIdUser = User.objects.filter(username=UserData.get('username')).values().first()
#                 print(getIdUser,getIdUser.get('id'))
#                 getUserProfile = UserProfileInformation.objects.filter(user_id=getIdUser.get('id')).values().first()
#                 if getUserProfile.get('user_login_or_not') != True:
#                     diff = ''
#                     try:    
#                         diff = datetime.strptime(str(getUserProfile.get('plan_expire_datetime')), '%Y-%m-%d %H:%M:%S+00:00') - datetime.strptime(str(getUserProfile.get('created_datetime')), '%Y-%m-%d %H:%M:%S+00:00')
#                         print(diff)
#                     except:
#                         diff = datetime.strptime(str(getUserProfile.get('plan_expire_datetime')), '%Y-%m-%d %H:%M:%S.%f+00:00') - datetime.strptime(str(getUserProfile.get('created_datetime')), '%Y-%m-%d %H:%M:%S.%f+00:00')
#                         print(diff)
#                     if diff.days == 0:
#                         # createMac = MacAddress(MacAddress = UserData.get('MacAddress'),DateTimeStart = UserData.get('DateTimeStart'),TimeZoneString = UserData.get('TimeZoneString'),username = UserData.get('username'))
#                         # createMac.save()
#                         dt = datetime.strptime(UserData.get('DateTimeStart'),"%Y-%m-%d %H:%M:%S.%f%z")
#                         GetDateTime = datetime.strftime(dt, "%Y-%m-%dT%H:%M:%S.%f%z")
#                     #     if getUserProfile.get('uses_type') == 'free trail':
#                     #         endDate = dt + timedelta(days=14)
#                     #         print(UserData.get('TimeZoneString'))
#                     #         UserProfileInformation.objects.filter(uses_type=getUserProfile.get('uses_type'),user=getIdUser.get('id')).update(created_datetime=GetDateTime,plan_expire_datetime=endDate,timezones=UserData.get('TimeZoneString'),user_login_or_not=True)
#                     #         data = {'user':getUserProfile.get('user'),'created_datetime':GetDateTime,'plan_expire_datetime':endDate,'TimeZoneString':UserData.get('TimeZoneString'),'uses_type':getUserProfile.get('uses_type'':getUserProfile.ge'':getUserProfile.ge')}
#                     #         return JsonResponse(data, status=status.HTTP_201_CREATED)
#                     # elif diff.days > 0:
#                     #     UserProfileInformation.objects.filter(user=getIdUser.get('id')).update(user_login_or_not=True)
#                     #     data = {'user':getUserProfile.get('user'),'created_datetime':getUserProfile.get('created_datetime'),'plan_expire_datetime':getUserProfile.get('plan_expire_datetime'),'TimeZoneString':getUserProfile.get('timezones'),'uses_type':getUserProfile.get('uses_type'':getUserProfile.ge'':getUserProfile.ge')}
#                     #     return JsonResponse(data, status=status.HTTP_201_CREATED)
#                 else:
#                     res = {"code": 400, "message": "Account are already Login in another System. Please Logout First."}
#                     return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)
#             else:
#                 res = {"code": 400, "message": "Account was not active."}
#                 return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)
#         else:
#             res = {"code": 400, "message": "Invalid Username and Password."}
#             return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)       
#         # else:
#         #     print(UserData_serializer.errors)
#         #     return JsonResponse(UserData_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

# @api_view(['GET'])
# def UserProfileDetail(request,user):
#     try:
#         userdetail = UserProfileInformation.objects.get(user=user)
#     except:
#         return JsonResponse({'message':'The user does not exist.'},status=status.HTTP_400_BAD_REQUEST)
#     if request.method == 'GET':
#         user_serializer = UserProfileSerializer(userdetail)
#         return JsonResponse(user_serializer.data)

# @api_view(['PUT'])
# def Logout(request,user):
#     try:
#         userdetail = UserProfileInformation.objects.get(user=user)
#     except:
#         return JsonResponse({'message':'The user does not exist.'},status=status.HTTP_400_BAD_REQUEST)
#     if request.method == 'PUT':
#         UserData = JSONParser().parse(request)
#         UpdataLoginStatus = UserProfileInformation.objects.filter(user=user).update(user_login_or_not=UserData.get('user_login_or_not'))
#         return JsonResponse({'message':'Updated Successfully'},status=status.HTTP_200_OK)

    
#new



class PasswordResetView(views.APIView):
    def post(self, request):
        email = request.data.get('email')
        User = get_user_model()
        try:
            user = User.objects.get(email=email)
        except User.DoesNotExist:
            return Response({"error": "This email is not registered"}, status=status.HTTP_404_NOT_FOUND)
        token = uuid.uuid4().hex
        user.password_reset_token = token
        user.password_reset_token_expiry = timezone.now() + timezone.timedelta(hours=24)
        user.save()
        uidb64 = force_text(urlsafe_base64_encode(force_bytes(user.pk)))
        print(uidb64,user.pk)
        reset_password_url = request.build_absolute_uri('/account/password-reset-confirm/{}/{}'.format(uidb64,token))
        email_body = f"Please click the link below to reset your password: {reset_password_url}"
        context = {'user_email': user.email, 'reset_link': reset_password_url}
        email_html = render_to_string('emails.html', context)
        send_mail(
            'Password reset request',
            '',
            'anprsolutionsllp@gmail.com',
            [email],
            html_message=email_html,
            fail_silently=False,
        )
        return Response({"detail": "Password reset email sent."}, status=status.HTTP_200_OK)




class PasswordResetDoneView(views.APIView):
    def post(self, request):
        email = request.data.get('email')
        User = get_user_model()
        try:
            user = User.objects.get(email=email)
        except User.DoesNotExist:
            return Response({"error": "This email is not registered"}, status=status.HTTP_404_NOT_FOUND)
        user.send_reset_email()
        return Response({"detail": "Password reset email sent."}, status=status.HTTP_200_OK)
    

class PasswordResetConfirmView(views.APIView):
    def post(self, request, uidb64, token):
        User = get_user_model()
        try:
            uid = urlsafe_base64_decode(uidb64).decode()
            user = User.objects.get(pk=uid)
        except (TypeError, ValueError, OverflowError, User.DoesNotExist):
            return Response({"error": "Invalid reset link"}, status=status.HTTP_404_NOT_FOUND)

        if not default_token_generator.check_token(user, token):
            return Response({"error": "Invalid reset link"}, status=status.HTTP_404_NOT_FOUND)

        password = request.data.get('password')
        user.set_password(password)
        user.save()
        update_session_auth_hash(request, user)
        return Response({"detail": "Password reset complete."}, status=status.HTTP_200_OK)
    

class PasswordResetCompleteView(views.APIView):
    def get(self, request):
        return Response({"detail": "Password reset complete."}, status=status.HTTP_200_OK)




    
class AddUserEmailView(APIView):
    permission_classes = (IsAuthenticated,)
    pagination_class = LimitOffsetPagination

    def get(self, request, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = getUserData(request.user.id)
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'add user email' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['add user email']:
                    AcessToPage = True
            if AcessToPage == True:
                limit = int(request.GET.get('limit',10))
                offset = int(request.GET.get('offset',0))
                add_user_email_detail = AddUserEmail.objects.filter(business_detail_id = get_user_data['business_detail']['id']).order_by('-id').all()[offset:limit+offset]  ##.values('id','licence_plate_number','licence_plate_image','confidence_licence_plate','datetime','speed','speed_violation','lane_change','driver_seat_belt','driver_seat_belt_image','confidence_driver_seat_belt','passanger_seat_belt','passanger_seat_belt_image','confidence_passanger_seat_belt','driver_mobile','driver_mobile_image','confidence_driver_mobile','passanger_mobile','passanger_mobile_image','confidence_passanger_mobile','vehicle_type','vehicle_direction','country','camera_name','created_by','created_datetime','updated_by','updated_datetime')
                add_user_email_detail_count = AddUserEmail.objects.filter(business_detail_id = get_user_data['business_detail']['id']).order_by('-id').all().count()
                serializer = AddUserEmailSerializer(add_user_email_detail, many=True)
                return Response({'count':add_user_email_detail_count,'results':serializer.data})
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def post(self, request, format=None):
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'add user email' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['add user email']:
                    AcessToPage = True
            if AcessToPage == True:
                get_data = request.data
                get_data['business_detail_id'] = get_user_data['business_detail']['id']
                print(get_data)
                serializer = AddUserEmailSerializer(data=get_data)
                print(serializer)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

class UserEmailDetailView(APIView):
    permission_classes = (IsAuthenticated,)
    def get_object(self, id):
        try:
            return AddUserEmail.objects.get(pk=id)
        except AddUserEmail.DoesNotExist:
            raise Http404
    def get(self, request,id, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'add user email' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['add user email']:
                    AcessToPage = True
            if AcessToPage == True:
                sites = self.get_object(id)
                serializer = AddUserEmailSerializer(sites)
                return Response(serializer.data)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
    def put(self, request, id, format=None): 
        get_user_data = getUserData(request.user.id)
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'add user email' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['add user email']:
                    AcessToPage = True
            if AcessToPage == True:
                add_user_email = self.get_object(id)
                get_data = request.data
                get_data['business_detail_id'] = get_user_data['business_detail']['id']
                serializer = AddUserEmailSerializer(add_user_email, data=get_data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)  
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
     
    def delete(self, request,id, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'add user email' in get_user_data['permission'].keys():
                if 'delete' in get_user_data['permission']['add user email']:
                    AcessToPage = True
            if AcessToPage == True:
                add_user_email = self.get_object(id)
                add_user_email.delete()
                return Response(status=status.HTTP_204_NO_CONTENT)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
 
class SiteView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'sites' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['sites']:
                    AcessToPage = True
            if AcessToPage == True:
                limit = int(request.GET.get('limit',10))
                offset = int(request.GET.get('offset',0))
                sites_detail = Sites.objects.filter(business_detail = get_user_data['business_detail']['id']).all()[offset:limit+offset]  ##.values('id','licence_plate_number','licence_plate_image','confidence_licence_plate','datetime','speed','speed_violation','lane_change','driver_seat_belt','driver_seat_belt_image','confidence_driver_seat_belt','passanger_seat_belt','passanger_seat_belt_image','confidence_passanger_seat_belt','driver_mobile','driver_mobile_image','confidence_driver_mobile','passanger_mobile','passanger_mobile_image','confidence_passanger_mobile','vehicle_type','vehicle_direction','country','camera_name','created_by','created_datetime','updated_by','updated_datetime')
                sites_detail_count = Sites.objects.filter(business_detail = get_user_data['business_detail']['id']).all().count()
                serializer = SitesSerializer(sites_detail, many=True)
                return Response({'count':sites_detail_count,'results':serializer.data})
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
    
    def post(self, request, format=None):
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'sites' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['sites']:
                    AcessToPage = True
            if AcessToPage == True:
                get_data = request.data
                get_data['business_detail'] = get_user_data['business_detail']['id']
                get_data['plan_start_datetime'] = get_user_data['business_detail']['plan_start_datetime']
                get_data['plan_expire_datetime'] = get_user_data['business_detail']['plan_expire_datetime']
                get_data['days_to_expire'] = get_user_data['business_detail']['days_to_expire']
                get_data['minutes_to_expire'] = get_user_data['business_detail']['minutes_to_expire']
                get_data['plan_validity'] = get_user_data['business_detail']['plan_validity']
                get_data['timezones'] = get_user_data['business_detail']['timezones']
                get_data['active'] = True
                get_data['user_login_or_not'] = False
                get_data['skip_frame'] = 5
                get_data['delete_previous_data_after_day'] = 30
                print(get_data)
                serializer = SitesSerializer(data=get_data)
                print(serializer)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
    
        

class SitesDetailView(APIView):
    permission_classes = (IsAuthenticated,)
    def get_object(self, id):
        try:
            return Sites.objects.get(pk=id)
        except Sites.DoesNotExist:
            raise Http404
    def get(self, request,id, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'sites' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['sites']:
                    AcessToPage = True
            if AcessToPage == True:
                sites = self.get_object(id)
                serializer = SitesSerializer(sites)
                return Response(serializer.data)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
    def put(self, request, id, format=None): 
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'sites' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['sites']:
                    AcessToPage = True
            if AcessToPage == True:
                sites = self.get_object(id)
                get_data = request.data
                get_data['business_detail'] = get_user_data['business_detail']['id']
                get_data['plan_start_datetime'] = sites.plan_start_datetime
                get_data['plan_expire_datetime'] = sites.plan_expire_datetime
                get_data['days_to_expire'] = sites.days_to_expire
                get_data['minutes_to_expire'] = sites.minutes_to_expire
                get_data['plan_validity'] = sites.plan_validity
                get_data['timezones'] = sites.timezones
                get_data['active'] = sites.active
                get_data['user_login_or_not'] = sites.user_login_or_not
                get_data['skip_frame'] = sites.skip_frame
                get_data['delete_previous_data_after_day'] = sites.delete_previous_data_after_day
                serializer = SitesSerializer(sites, data=request.data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)  
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
     
    def delete(self, request,id, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'sites' in get_user_data['permission'].keys():
                if 'delete' in get_user_data['permission']['sites']:
                    AcessToPage = True
            if AcessToPage == True:
                sites = self.get_object(id)
                sites.delete()
                return Response(status=status.HTTP_204_NO_CONTENT)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

class RoleDropdownView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = getUserData(request.user.id)
        if get_user_data['business_detail']['plan_validity'] == True:
            roles = Roles.objects.filter(business_detail_id = get_user_data['business_detail']['id']).all()  ##.values('id','licence_plate_number','licence_plate_image','confidence_licence_plate','datetime','speed','speed_violation','lane_change','driver_seat_belt','driver_seat_belt_image','confidence_driver_seat_belt','passanger_seat_belt','passanger_seat_belt_image','confidence_passanger_seat_belt','driver_mobile','driver_mobile_image','confidence_driver_mobile','passanger_mobile','passanger_mobile_image','confidence_passanger_mobile','vehicle_type','vehicle_direction','country','camera_name','created_by','created_datetime','updated_by','updated_datetime')
            serializer = RoleSerializer(roles, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

class UserEmailView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = getUserData(request.user.id)
        if get_user_data['business_detail']['plan_validity'] == True:
            roles = User.objects.filter(business_detail_id = get_user_data['business_detail']['id']).all()  ##.values('id','licence_plate_number','licence_plate_image','confidence_licence_plate','datetime','speed','speed_violation','lane_change','driver_seat_belt','driver_seat_belt_image','confidence_driver_seat_belt','passanger_seat_belt','passanger_seat_belt_image','confidence_passanger_seat_belt','driver_mobile','driver_mobile_image','confidence_driver_mobile','passanger_mobile','passanger_mobile_image','confidence_passanger_mobile','vehicle_type','vehicle_direction','country','camera_name','created_by','created_datetime','updated_by','updated_datetime')
            serializer = UserEmailSerializer(roles, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


#RolesAndPermissionsView
class RolesAndPermissionView(APIView):
    permission_classes = (IsAuthenticated,)


    def get(self, request):

        limit = int(request.GET.get('limit', 10))
        offset = int(request.GET.get('offset', 0))

        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'roles_permission' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['roles_permission']:
                    AcessToPage = True
            if AcessToPage == True:
                roles = Roles.objects.filter(business_detail_id = get_user_data['business_detail']['id']).all()
                permissions = []

                for role in roles:
                    role_data = {'role': role.id, 'role_name': role.role_name, 'permissions': []}
                    role_permissions = role.permission_set.all()

                    for permission in role_permissions:
                        menu_page = permission.menu_page.id
                        menu_name = permission.menu_page.menu_name
                        action_name = permission.action.action_name

                        # Check if the menu already exists in the permissions list
                        menu_exists = next((menu for menu in role_data['permissions'] if menu['menu_page'] == menu_page), None)

                        if menu_exists:
                            menu_exists['action'].append({
                                'action': permission.action.id,
                                'action_name': action_name
                            })
                        else:
                            role_data['permissions'].append({
                                'menu_page': menu_page,
                                'menu_name': menu_name,
                                'action': [{
                                    'action': permission.action.id,
                                    'action_name': action_name
                                }]
                            })

                    permissions.append(role_data)

                total_count = len(roles)
                permissions = permissions[offset:offset + limit]
                

                return Response({"count": total_count, "results": permissions})
            else:
                return Response({"detail": "You don't have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "Account validity has expired."}, status=status.HTTP_400_BAD_REQUEST)
        

    def post(self, request):

        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'roles_permission' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['roles_permission']:
                    AcessToPage = True
            if AcessToPage == True:
                
                    
                data = request.data
                data['business_detail_id'] = get_user_data['business_detail']['id']
                role_serializer = RoleSerializer(data=data)
                
                if role_serializer.is_valid():
                    role = role_serializer.save()
                else:
                    return Response(role_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                
                permissions_data = data.get('permission')
                if not permissions_data:
                    return Response({"detail": "Permission data is missing or empty."}, status=status.HTTP_400_BAD_REQUEST)

                # Create Permissions for the Role
                for permission_data in permissions_data:
                    permission_serializer = PermissionSerializer(data={
                        'role': role.id,
                        'menu_page': permission_data.get('menu_page'),
                        'action': permission_data.get('action')
                    })
                    if permission_serializer.is_valid():
                        permission_serializer.save()
                    else:
                        # If any permission data is invalid, delete the created role and return error response
                        print("deleted")
                        role.delete()
                        return Response(permission_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                print(permission_serializer.data)
                return Response({"detail": f"Role '{role.role_name}' with permissions has been created."}, status=status.HTTP_201_CREATED)
                    
            else:
                return Response({"detail": "You don't have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"detail": "Account Validity has expired."}, status=status.HTTP_400_BAD_REQUEST)

class RolesAndPermissionDetailView(APIView):
    permission_classes = (IsAuthenticated,)

    

    def get(self, request,id, format=None):
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'roles_permission' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['roles_permission']:
                    AcessToPage = True
            if AcessToPage == True:
                try:
                    business_detail = request.user.business_detail_id
                    role = Roles.objects.get(pk=id, business_detail_id=business_detail)
                except Roles.DoesNotExist:
                    return Response({"detail": "ID not found."}, status=status.HTTP_404_NOT_FOUND)

                role_data = {'role': role.id, 'role_name': role.role_name, 'permissions': []}
                role_permissions = role.permission_set.all()

                for permission in role_permissions:
                    menu_name = permission.menu_page.menu_name
                    action_name = permission.action.action_name
                    menu_page = permission.menu_page.id

                    # Find if the menu already exists in permissions list
                    menu_exists = next((menu for menu in role_data['permissions'] if menu['menu_page'] == menu_page), None)

                    # If menu exists, add action_name to the existing menu
                    if menu_exists:
                        menu_exists['action'].append({
                            'action': permission.action.id,
                            'action_name': action_name
                        })
                    else:
                        # If menu doesn't exist, create a new menu entry and add action_name to it
                        role_data['permissions'].append({
                            'menu_page': menu_page,
                            'menu_name': menu_name,
                            'action': [{
                                'action': permission.action.id,
                                'action_name': action_name
                            }]
                        })

                return Response(role_data)
            else:
                return Response({"detail": "You don't have permission to access."}, status=status.HTTP_403_FORBIDDEN)
        else:
            return Response({"detail": "Account validity has expired."}, status=status.HTTP_400_BAD_REQUEST)
    


    def put(self, request, id, format=None):
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'roles_permission' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['roles_permission']:
                    AcessToPage = True
            if AcessToPage == True:
                try:
                    business_detail = request.user.business_detail_id
                    role = Roles.objects.get(pk=id, business_detail_id = business_detail)
                except Roles.DoesNotExist:
                    return Response({"detail": "Role not found."}, status=status.HTTP_404_NOT_FOUND)
                
                if role.id == get_user_data['role_detail']['id']:
                    raise PermissionDenied({"detail":"You cannot change your own role name."})

                role_name = request.data.get('role_name')
                prev_permissions_data = request.data.get('prev_permission', [])
                new_permissions_data = request.data.get('new_permission', [])

                # Update the role_name if provided
                if role_name:
                    role.role_name = role_name
                    role.save()

                # Process previous permissions
                for prev_permission_data in prev_permissions_data:
                    menu_page = prev_permission_data.get('menu_page')
                    action = prev_permission_data.get('action')
                    permission = Permission.objects.filter(role=role, menu_page=menu_page, action=action).first()

                    if permission:
                        permission.delete()

                # Process new permissions
                for new_permission_data in new_permissions_data:
                    menu_page = new_permission_data.get('menu_page')
                    action = new_permission_data.get('action')
                    role_id = role.id  # Extract the role_id (primary key) from the role object
                    permission_data = {
                        'role': role_id,  # Use the role_id (primary key) in the permission data
                        'menu_page': menu_page,
                        'action': action
                    }
                    permission_serializer = PermissionSerializer(data=permission_data)

                    if permission_serializer.is_valid():
                        permission_serializer.save()
                    else:
                        return Response(permission_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

                return Response({"detail": f"Role '{role.role_name}' permissions have been updated."}, status=status.HTTP_200_OK)
            else:
                return Response({"detail": "You don't have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"detail": "Account Validity has expired."}, status=status.HTTP_400_BAD_REQUEST)


    def delete(self, request,id, format=None):
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'roles_permission' in get_user_data['permission'].keys():
                if 'delete' in get_user_data['permission']['roles_permission']:
                    AcessToPage = True
            if AcessToPage == True:
                try:
                    business_detail = request.user.business_detail_id
                    role = Roles.objects.get(pk=id, business_detail_id = business_detail)
                except Roles.DoesNotExist:
                    return Response({"detail": "Role not found."}, status=status.HTTP_404_NOT_FOUND)
                

                # Check if the role is assigned to some user
                assigned_users = AddUserEmail.objects.filter(role=id)
                if assigned_users.exists():
                    return Response({"detail": "Cannot delete this role. It is assigned to some user."}, status=status.HTTP_400_BAD_REQUEST)
                

                # Check if the role is referenced by UserRoleMapping
                if UserRoleMapping.objects.filter(role=id).exists():
                    return Response({"detail": "Cannot delete this role. It is referenced by UserRoleMapping."}, status=status.HTTP_400_BAD_REQUEST)


                # Delete the associated permissions
                Permission.objects.filter(role=id).delete()

                #  delete the role 
                role.delete()

                return Response({"detail": f"Role '{role.role_name}' and its permissions have been deleted."}, status=status.HTTP_204_NO_CONTENT)
            else:
                return Response({"detail": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"detail": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
        


class GetRolesAndPermissionView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request):
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'roles_permission' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['roles_permission']:
                    AcessToPage = True
            if AcessToPage == True:
                user_role = get_user_data['role_detail']['id']

                # Fetch the role that belongs to the logged-in user
                role = Roles.objects.filter(id=user_role).first()

                if role is not None:
                    # Create a dictionary to store permissions
                    permissions_dict = {}

                    role_permissions = role.permission_set.all()

                    for permission in role_permissions:
                        menu_page = permission.menu_page.id
                        menu_name = permission.menu_page.menu_name
                        action = permission.action.id
                        action_name = permission.action.action_name

                        if menu_page not in permissions_dict:
                            permissions_dict[menu_page] = {
                                'menu_page': menu_page,
                                'menu_name': menu_name,
                                'action': []
                            }

                        permissions_dict[menu_page]['action'].append({
                            'action': action,
                            'action_name': action_name
                        })

                    # Convert the permissions_dict to a list of permissions
                    permissions = list(permissions_dict.values())

                    return Response({'role_name' : role.role_name,'permission': permissions})
                else:
                    return Response({"detail": "Role not found."}, status=status.HTTP_404_NOT_FOUND)
            else:
                return Response({"detail": "You don't have permissions to access."}, status=status.HTTP_403_FORBIDDEN)
        else:
            return Response({"detail": "Account validity has expired."}, status=status.HTTP_400_BAD_REQUEST)



#OTP view

class SendOTP(APIView):
    def post(self, request):
        email = request.data.get('email')
        
        if not email:
            return Response({"error": "Email is required."}, status=status.HTTP_400_BAD_REQUEST)
        
        if User.objects.filter(email=email).exists():
            # Generate a random 6-digit OTP
            print(User.objects.get(email=email).is_verified)
            if User.objects.get(email=email).is_verified == False:
                otp = ''.join([str(random.randint(0, 9)) for _ in range(6)])

                user = User.objects.filter(email=email).first()

                # Store OTP in your database
                otp_instance, created = OTP.objects.get_or_create(user=user, email=email, defaults={'otp': otp, 'otp_validity': datetime.now()})
                if not created:
                    otp_instance.otp = otp
                    otp_instance.otp_validity = datetime.now()
                    otp_instance.save()

                context = {'otp': otp}
                email_html = render_to_string('otp.html', context)
                send_mail(
                    'OTP Verification for VMS',
                    '',
                    'anprsolutionsllp@gmail.com',
                    [email],
                    html_message=email_html,
                    fail_silently=False,
                )

                return Response({"submit": "OTP sent successfully."}, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "Your email is already verified."})
        else:
            return Response({"email": "Email not found."}, status=status.HTTP_400_BAD_REQUEST)


class VerifyOTP(APIView):

    def post(self, request):
        email = request.data.get('email')
        otp = request.data.get('otp')

        if not email or not otp:
            return Response({"submit": "Email and OTP are required."}, status=status.HTTP_400_BAD_REQUEST)
        
        user = User.objects.filter(email=email).first()

        if user:
            otp_model = OTP.objects.filter(email=email).last()
            if otp_model.otp == otp:
                diff = None
                try:
                    diff = datetime.strptime(str(datetime.now()), '%Y-%m-%d %H:%M:%S.%f') - datetime.strptime(str(otp_model.otp_validity), '%Y-%m-%d %H:%M:%S.%f+00:00')
                except Exception as e:
                    diff = datetime.strptime(str(datetime.now()), '%Y-%m-%d %H:%M:%S.%f') - datetime.strptime(str(otp_model.otp_validity), '%Y-%m-%d %H:%M:%S+00:00') 

                print(int(diff.total_seconds() / 60.0))
                if int(diff.total_seconds() / 60.0) <= 10:
                    otp_model.is_verified = True
                    user.is_verified = True
                    otp_model.save()
                    user.save()
                    return Response({"submit": "OTP verified successfully."}, status=status.HTTP_200_OK)
                else:
                    return Response({"submit": "OTP expired."}, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "Invalid OTP."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"submit": "This email is not registered."}, status=status.HTTP_400_BAD_REQUEST)



class PasswordResetView(APIView):
    def post(self, request):
        
        email = request.data.get('email')

        if not email:
            return JsonResponse({"error": "Email is required."}, status=status.HTTP_400_BAD_REQUEST)

        User = get_user_model()
        try:
            user = User.objects.get(email=email)
        except User.DoesNotExist:
            return JsonResponse({"error": "This email is not registered"}, status=status.HTTP_404_NOT_FOUND)
        
        reset_token = PasswordResetToken.objects.create(user=user, is_valid=True)
        
        generate_and_send_otp(user, email)

        return JsonResponse({"submit": "OTP sent successfully.", "token": reset_token.token}, status=status.HTTP_200_OK)



class PasswordResetConfirmationView(APIView):
    
    def post(self, request, token):
      
        reset_token=PasswordResetToken.objects.get(token=token)

        if timezone.now() > reset_token.created_at + timezone.timedelta(hours=24):
            reset_token.is_valid = False
            reset_token.save()
            return JsonResponse({"error": "Password reset link has expired."}, status=status.HTTP_400_BAD_REQUEST)
        new_password1 = request.data.get('new_password1')
        new_password2 = request.data.get('new_password2')
        print(new_password1)
        print(new_password2)
       

       
        if new_password1 != new_password2:
                
            return JsonResponse({"error": "Passwords do not match."}, status=status.HTTP_400_BAD_REQUEST)
           
        #user = reset_token.user
        user=User.objects.get(email=reset_token.user)
        user.set_password(new_password1)
        user.save()
        update_session_auth_hash(request, user)
        reset_token.is_valid = False
        reset_token.save()
        
        return JsonResponse({"message": "Password reset successful."}, status=status.HTTP_200_OK)
        
      
class PasswordResetCompleteView(APIView):
    def get(self, request):
       
        return JsonResponse({"message": "Password reset complete."})
        
