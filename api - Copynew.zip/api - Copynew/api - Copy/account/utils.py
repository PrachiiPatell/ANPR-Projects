import random
from .models import OTP
from django.core.mail import send_mail
from django.template.loader import render_to_string
from django.utils import timezone
from datetime import datetime
from .models import PasswordResetToken


# def generate_and_send_otp(user, email):
#     otp = ''.join([str(random.randint(0, 9)) for _ in range(6)])

    
#     otp_instance, created = OTP.objects.get_or_create(user=user, email=email, defaults={'otp': otp, 'otp_validity': datetime.now()})
#     if not created:
#         otp_instance.otp = otp
#         otp_instance.otp_validity = datetime.now()
#         otp_instance.save()

#     context = {'otp': otp}
#     email_html = render_to_string('otp.html', context)
#     send_mail(
#         'OTP Verification for VMS',
#         '',
#         'anprsolutionsllp@gmail.com',
#         [email],
#         html_message=email_html,
#         fail_silently=False,
#     )

#     return otp

def generate_and_send_otp(user, email):

    otp = ''.join([str(random.randint(0, 9)) for _ in range(6)])
    password_reset_token, created = PasswordResetToken.objects.get_or_create(user=user, token=otp, defaults={'is_valid': True})
    
    if not created:
        password_reset_token.token = otp
        password_reset_token.is_valid = True
        password_reset_token.save()

    context = {'otp': otp}
    email_html = render_to_string('otp.html', context)
    send_mail('OTP Verification for VMS', '', 'anprsolutionsllp@gmail.com', [email], html_message=email_html, fail_silently=False)

    return otp


def save_token_in_database(user, token, expiry_time):
    # Save the token in your PasswordResetToken model
    password_reset_token, created = PasswordResetToken.objects.get_or_create(
        user=user,
        token=token,
        defaults={'is_valid': True, 'created_at': timezone.now()}
    )

    # If the token already exists, update its validity and creation time
    if not created:
        password_reset_token.is_valid = True
        password_reset_token.created_at = timezone.now()
        password_reset_token.save()

    return password_reset_token