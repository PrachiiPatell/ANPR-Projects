from django.contrib import admin
from account.models import VehicleType,VehicleParkingSizeAndType
from .models import Building,BuildingParkingDetail,Wing,WingParkingDetail,Occupant,OccupantParkingDetail,VehicleDetail
from .models import Occupant
from import_export import resources, fields
from import_export.admin import ImportExportActionModelAdmin

class OccupantResource(resources.ModelResource):
    class Meta:
        model = Occupant
        skip_unchanged = True
        report_skipped = False
        import_id_fields = ('id',)

class OccupantAdmin(ImportExportActionModelAdmin):
    resource_class = OccupantResource
    actions = ['import_selected', 'export_selected']

# Register your models here.
#admin.site.register(BusinessDetail)
admin.site.register(VehicleType)
admin.site.register(VehicleParkingSizeAndType)
admin.site.register(Building)
admin.site.register(BuildingParkingDetail)
admin.site.register(Wing)
admin.site.register(WingParkingDetail)
admin.site.register(Occupant, OccupantAdmin)
#admin.site.register(Occupant)
admin.site.register(OccupantParkingDetail)
admin.site.register(VehicleDetail)