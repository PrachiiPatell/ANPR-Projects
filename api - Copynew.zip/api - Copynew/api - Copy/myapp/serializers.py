from rest_framework import serializers
from rest_framework.validators import UniqueValidator
from rest_framework.validators import UniqueTogetherValidator
from django.db.models import Sum
from rest_framework.response import Response

# import model
from account.models import BusinessDetail, BusinessParkingDetail, VehicleType, VehicleParkingSizeAndType, NumberOfWheeler
from .models import Building, BuildingParkingDetail, Wing, WingParkingDetail, Occupant, OccupantParkingDetail, VehicleDetail

# class BusinessDetailSerializer(serializers.ModelSerializer):
#     business_name = serializers.CharField(required=True,validators=[UniqueValidator(queryset=BusinessDetail.objects.all())])
#     class Meta:
#         model = BusinessDetail
#         fields = '__all__'


class VehicleTypeSerializer(serializers.ModelSerializer):
    wheeler = serializers.CharField(
        source='number_of_wheeler_id.wheeler', read_only=True)

    class Meta:
        model = VehicleType
        fields = ['id', 'vehicle_type', 'number_of_wheeler_id',
                  'wheeler', 'business_detail_id']

    def create(self, validate_data):
        if VehicleType.objects.filter(vehicle_type=validate_data['vehicle_type'], business_detail_id=validate_data['business_detail_id']).exists():
            raise serializers.ValidationError(
                {'vehicle_type': 'Vehicle type are already exist.'})
        return VehicleType.objects.create(**validate_data)

    def update(self, instance, validate_data):
        if VehicleType.objects.filter(vehicle_type=validate_data['vehicle_type'], business_detail_id=validate_data['business_detail_id']).exclude(id=instance.pk).exists():
            raise serializers.ValidationError(
                {'vehicle_type': 'Vehicle type are already exist.'})
        return super().update(instance, validate_data)

    def delete(self, instance):
        try:
            instance.delete()
        except Exception as e:
            raise serializers.ValidationError(
                {'submit': 'Cannot delete. This object is referenced by other objects.'})

class VehicleTypeDropdownSerializer(serializers.ModelSerializer):
    class Meta:
        model = VehicleType
        fields = ['id','vehicle_type']

class VehicleParkingSizeAndTypeDropdownSerializer(serializers.ModelSerializer):
    class Meta:
        model = VehicleParkingSizeAndType
        fields = ['id','parking_size_and_type_name']

# class DefaultParkingTypeByVehicleSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = DefaultParkingTypeByVehicle
#         fields = '__all__'


class VehicleParkingSizeAndTypeSerializer(serializers.ModelSerializer):
    vehicle_type = serializers.CharField(source='vehicle_type_id.vehicle_type', read_only=True)
    class Meta:
        model = VehicleParkingSizeAndType
        fields = ['id', 'parking_size_and_type_name', 'parking_size', 'length',
                  'width', 'vehicle_type', 'vehicle_type_id', 'business_detail_id']

    def create(self, validated_data):
        if VehicleParkingSizeAndType.objects.filter(parking_size_and_type_name=validated_data['parking_size_and_type_name'], business_detail_id=validated_data['business_detail_id']).exists():
            raise serializers.ValidationError(
                {"parking_size_and_type_name": "Parking size name is already exist."})
        if VehicleParkingSizeAndType.objects.filter(length=validated_data['length'], width=validated_data['width'], vehicle_type_id=validated_data['vehicle_type_id'], business_detail_id=validated_data['business_detail_id']).exists():
            raise serializers.ValidationError(
                {"submit": "Parkining length,width and vehicle type is alreay exist."})
        return VehicleParkingSizeAndType.objects.create(**validated_data)

    def update(self, instance, validated_data):
        if VehicleParkingSizeAndType.objects.filter(parking_size_and_type_name=validated_data['parking_size_and_type_name'], business_detail_id=validated_data['business_detail_id']).exclude(id=instance.pk).exists():
            raise serializers.ValidationError(
                {"parking_size_and_type_name": "Parking size name is already exist."})
        if VehicleParkingSizeAndType.objects.filter(length=validated_data['length'], width=validated_data['width'], vehicle_type_id=validated_data['vehicle_type_id'], business_detail_id=validated_data['business_detail_id']).exclude(id=instance.pk).exists():
            raise serializers.ValidationError(
                {"submit": "Parkining length,width and vehicle type is alreay exist."})
        return super().update(instance, validated_data)

    def delete(self, instance):
        try:
            instance.delete()
        except Exception as e:
            raise serializers.ValidationError(
                {'submit': 'Cannot delete. This object is referenced by other objects.'})


class BuildingSerializer(serializers.ModelSerializer):
    class Meta:
        model = Building
        fields = ['id', 'building_name', 'total_parking',
                  'total_occupied_parking', 'business_detail_id']

    def create(self, validated_data):
        if Building.objects.filter(building_name=validated_data['building_name'], business_detail_id=validated_data['business_detail_id']).exists():
            raise serializers.ValidationError(
                {"building_name": "Building name is unique for that business."})
        building_parking_sum = Building.objects.filter(
            business_detail_id=validated_data['business_detail_id']).aggregate(Sum('total_parking'))
        business_parking_count = BusinessDetail.objects.filter(
            id=self.initial_data.get('business_detail_id')).values('total_parking').first()
        print("building_parking_sum:", building_parking_sum)

        if building_parking_sum['total_parking__sum'] == None:
            building_parking_sum['total_parking__sum'] = 0
        if business_parking_count != None:
            if building_parking_sum['total_parking__sum']+validated_data['total_parking'] > business_parking_count['total_parking']:
                raise serializers.ValidationError(
                    {"total_parking": "Building parking sum are greater than Business parking count."}
                )
        return super().create(validated_data)

    def update(self, instance, validated_data):
        if Building.objects.filter(building_name=validated_data['building_name'], business_detail_id=validated_data['business_detail_id']).exclude(id=instance.pk).exists():
            raise serializers.ValidationError(
                {"building_name": "Building name is unique for that building."})
        building_parking_sum = Building.objects.filter(business_detail_id=validated_data['business_detail_id']).exclude(
            id=instance.pk).aggregate(Sum('total_parking'))
        business_parking_count = BusinessDetail.objects.filter(
            id=self.initial_data.get('business_detail_id')).values('total_parking').first()
        print("building_parking_sum:", building_parking_sum, instance)
        if building_parking_sum['total_parking__sum'] == None:
            building_parking_sum['total_parking__sum'] = 0
        if business_parking_count != None:
            if building_parking_sum['total_parking__sum']+validated_data['total_parking'] > business_parking_count['total_parking']:
                raise serializers.ValidationError(
                    {"total_parking": "Building parking sum are greater than Business parking count."}
                )
        wing_parking_sum = Wing.objects.filter(
            building_id=instance.pk, business_detail_id=validated_data['business_detail_id']).aggregate(Sum('total_parking'))
        if wing_parking_sum['total_parking__sum'] == None:
            wing_parking_sum['total_parking__sum'] = 0
        if wing_parking_sum['total_parking__sum'] > validated_data['total_parking']:
            raise serializers.ValidationError(
                {"total_parking": "Building Parking are already in use please update wing parking count first."})
        return super().update(instance, validated_data)

    def delete(self, instance):
        try:
            instance.delete()
        except Exception as e:
            raise serializers.ValidationError(
                {'submit': 'Cannot delete. This object is referenced by other objects.'})

class BuildingDropdownSerializer(serializers.ModelSerializer):
    class Meta:
        model = Building
        fields = ['id','building_name']

class BuildingParkingDetailSerializer(serializers.ModelSerializer):
    parking_size_and_type_name = serializers.CharField(
        source='vehicle_parking_size_and_type_id.parking_size_and_type_name', read_only=True)
    building_name = serializers.CharField(
        source='building_id.building_name', read_only=True)

    class Meta:
        model = BuildingParkingDetail
        fields = ['id', 'total_parking','total_occupied_parking', 'vehicle_parking_size_and_type_id',
                  'parking_size_and_type_name', 'building_id', 'building_name', 'business_detail_id']

    def create(self, validated_data):
        if BuildingParkingDetail.objects.filter(vehicle_parking_size_and_type_id=validated_data['vehicle_parking_size_and_type_id'], building_id=validated_data['building_id'], business_detail_id=validated_data['business_detail_id']).exists():
            raise serializers.ValidationError(
                {"vehicle_parking_size_and_type_id": "Building parking size and type already exist."})
        building_total_parking_sum = BuildingParkingDetail.objects.filter(
            building_id=validated_data['building_id'], business_detail_id=validated_data['business_detail_id']).aggregate(Sum('total_parking'))
        building_total_parking = Building.objects.filter(id=self.initial_data.get(
            'building_id'), business_detail_id=validated_data['business_detail_id']).values('total_parking').first()
        if building_total_parking_sum['total_parking__sum'] == None:
            building_total_parking_sum['total_parking__sum'] = 0
        if building_total_parking != None:
            if building_total_parking_sum['total_parking__sum']+validated_data['total_parking'] > building_total_parking['total_parking']:
                raise serializers.ValidationError(
                    {"total_parking": "Building parking count are greater than exist."})
        building_parking_size_and_type_parking_sum = BuildingParkingDetail.objects.filter(
            vehicle_parking_size_and_type_id=validated_data['vehicle_parking_size_and_type_id'], business_detail_id=validated_data['business_detail_id']).aggregate(Sum('total_parking'))
        business_parking_size_and_type_parking = BusinessParkingDetail.objects.filter(
            vehicle_parking_size_and_type_id=validated_data['vehicle_parking_size_and_type_id'], business_detail_id=validated_data['business_detail_id']).values('total_parking').first()
        if building_parking_size_and_type_parking_sum['total_parking__sum'] == None:
            building_parking_size_and_type_parking_sum['total_parking__sum'] = 0
        if business_parking_size_and_type_parking != None:
            if building_parking_size_and_type_parking_sum['total_parking__sum']+validated_data['total_parking'] > business_parking_size_and_type_parking['total_parking']:
                raise serializers.ValidationError(
                    {"total_parking": 'Building total parking size and type count are greater than business parking size and type count.'})
        elif business_parking_size_and_type_parking == None:
            raise serializers.ValidationError(
                {"vehicle_parking_size_and_type_id": "Building parking size and type are not exist business."})
        return super().create(validated_data)

    def update(self, instance, validated_data):
        if BuildingParkingDetail.objects.filter(vehicle_parking_size_and_type_id=validated_data['vehicle_parking_size_and_type_id'], building_id=validated_data['building_id'], business_detail_id=validated_data['business_detail_id']).exclude(id=instance.pk).exists():
            raise serializers.ValidationError(
                {"vehicle_parking_size_and_type_id": "Building parking size and type already exist."})
        building_total_parking_sum = BuildingParkingDetail.objects.filter(
            building_id=validated_data['building_id'], business_detail_id=validated_data['business_detail_id']).exclude(id=instance.pk).aggregate(Sum('total_parking'))
        building_total_parking = Building.objects.filter(id=self.initial_data.get(
            'building_id'), business_detail_id=validated_data['business_detail_id']).values('total_parking').first()
        if building_total_parking_sum['total_parking__sum'] == None:
            building_total_parking_sum['total_parking__sum'] = 0
        if building_total_parking != None:
            if building_total_parking_sum['total_parking__sum']+validated_data['total_parking'] > building_total_parking['total_parking']:
                raise serializers.ValidationError(
                    {"total_parking": "Building parking count are greater than exist."})
        building_parking_size_and_type_parking_sum = BuildingParkingDetail.objects.filter(
            vehicle_parking_size_and_type_id=validated_data['vehicle_parking_size_and_type_id'], business_detail_id=validated_data['business_detail_id']).exclude(id=instance.pk).aggregate(Sum('total_parking'))
        business_parking_size_and_type_parking = BusinessParkingDetail.objects.filter(
            vehicle_parking_size_and_type_id=validated_data['vehicle_parking_size_and_type_id'], business_detail_id=validated_data['business_detail_id']).values('total_parking').first()
        if building_parking_size_and_type_parking_sum['total_parking__sum'] == None:
            building_parking_size_and_type_parking_sum['total_parking__sum'] = 0
        if business_parking_size_and_type_parking != None:
            if building_parking_size_and_type_parking_sum['total_parking__sum']+validated_data['total_parking'] > business_parking_size_and_type_parking['total_parking']:
                raise serializers.ValidationError(
                    {"total_parking": "Building parking count are greater than exist."})
        elif business_parking_size_and_type_parking == None:
            raise serializers.ValidationError(
                {"vehicle_parking_size_and_type_id": "Building parking size and type are not exist in business."})
        wing_parking_size_and_type_sum = WingParkingDetail.objects.filter(
            vehicle_parking_size_and_type_id=validated_data['vehicle_parking_size_and_type_id'], wing_id__building_id=validated_data['building_id'], business_detail_id=validated_data['business_detail_id']).aggregate(Sum('total_parking'))
        print('wing_parking_size_and_type_sum:',
              wing_parking_size_and_type_sum)
        if wing_parking_size_and_type_sum['total_parking__sum'] == None:
            wing_parking_size_and_type_sum['total_parking__sum'] = 0
        if wing_parking_size_and_type_sum['total_parking__sum'] > validated_data['total_parking']:
            raise serializers.ValidationError(
                {'total_parking': 'Wing Parking size and type sum are greater than building count.'})
        return super().update(instance, validated_data)

    def delete(self, instance):
        if WingParkingDetail.objects.filter(vehicle_parking_size_and_type_id=instance.vehicle_parking_size_and_type_id, wing_id__building_id=instance.building_id, business_detail_id=instance.business_detail_id).exists():
            raise serializers.ValidationError(
                {'submit': 'building parking size and type are exist in wing parking.'})
        try:
            instance.delete()
        except Exception as e:
            raise serializers.ValidationError(
                {'submit': 'Cannot delete. This object is referenced by other objects.'})


class WingSerializer(serializers.ModelSerializer):
    building_name = serializers.CharField(
        source='building_id.building_name', read_only=True)

    class Meta:
        model = Wing
        fields = ['id', 'wing_name', 'total_parking', 'total_occupied_parking',
                  'building_id', 'building_name', 'business_detail_id']

    def create(self, validated_data):
        if Wing.objects.filter(wing_name=validated_data['wing_name'], building_id=validated_data['building_id'], business_detail_id=validated_data['business_detail_id']).exists():
            raise serializers.ValidationError(
                {"wing_name": "Wing name is unique for that building."})
        wing_parking_sum = Wing.objects.filter(
            building_id=validated_data['building_id'], business_detail_id=validated_data['business_detail_id']).aggregate(Sum('total_parking'))
        building_parking_count = Building.objects.filter(id=self.initial_data.get(
            'building_id'), business_detail_id=validated_data['business_detail_id']).values('total_parking').first()
        if wing_parking_sum['total_parking__sum'] == None:
            wing_parking_sum['total_parking__sum'] = 0
        if building_parking_count != None:
            if wing_parking_sum['total_parking__sum']+validated_data['total_parking'] > building_parking_count['total_parking']:
                raise serializers.ValidationError(
                    {"total_parking": "Wing parking sum are greater than Building parking count."}
                )
        return super().create(validated_data)

    def update(self, instance, validated_data):
        if Wing.objects.filter(wing_name=validated_data['wing_name'], building_id=validated_data['building_id'], business_detail_id=validated_data['business_detail_id']).exclude(id=instance.pk).exists():
            raise serializers.ValidationError(
                {"wing_name": "Wing name is unique for that building."})
        wing_parking_sum = Wing.objects.filter(building_id=validated_data['building_id'], business_detail_id=validated_data['business_detail_id']).exclude(
            id=instance.pk).aggregate(Sum('total_parking'))
        building_parking_count = Building.objects.filter(id=self.initial_data.get(
            'building_id'), business_detail_id=validated_data['business_detail_id']).values('total_parking').first()
        if wing_parking_sum['total_parking__sum'] == None:
            wing_parking_sum['total_parking__sum'] = 0
        if building_parking_count != None:
            if wing_parking_sum['total_parking__sum']+validated_data['total_parking'] > building_parking_count['total_parking']:
                raise serializers.ValidationError(
                    {"total_parking": "Wing parking sum are greater than Building parking count."}
                )
        occupant_parking_sum = Occupant.objects.filter(
            wing_id=instance.pk, business_detail_id=validated_data['business_detail_id']).aggregate(Sum('total_parking'))
        if occupant_parking_sum['total_parking__sum'] == None:
            occupant_parking_sum['total_parking__sum'] = 0
        if occupant_parking_sum['total_parking__sum'] > validated_data['total_parking']:
            raise serializers.ValidationError(
                {"total_parking": "Wing Parking are already in use please update occupant parking first."})
        return super().update(instance, validated_data)

    def delete(self, instance):
        try:
            instance.delete()
        except Exception as e:
            raise serializers.ValidationError(
                {'submit': 'Cannot delete. This object is referenced by other objects.'})

class WingDropdownSerializer(serializers.ModelSerializer):
    class Meta:
        model = Wing
        fields = ['id','wing_name']

class WingParkingDetailSerializer(serializers.ModelSerializer):
    wing_name = serializers.CharField(
        source='wing_id.wing_name', read_only=True)
    parking_size_and_type_name = serializers.CharField(
        source='vehicle_parking_size_and_type_id.parking_size_and_type_name', read_only=True)
    building_id = serializers.CharField(
        source='wing_id.building_id', read_only=True)

    class Meta:
        model = WingParkingDetail
        fields = ['id', 'total_parking','total_occupied_parking', 'vehicle_parking_size_and_type_id',
                  'parking_size_and_type_name', 'wing_id', 'wing_name', 'building_id', 'business_detail_id']

    def create(self, validated_data):
        if WingParkingDetail.objects.filter(vehicle_parking_size_and_type_id=validated_data['vehicle_parking_size_and_type_id'], wing_id=validated_data['wing_id'], business_detail_id=validated_data['business_detail_id']).exists():
            raise serializers.ValidationError(
                {"vehicle_parking_size_and_type_id": "Wing parking size and type already exist."})
        wing_parking_detail_sum = WingParkingDetail.objects.filter(
            wing_id=validated_data['wing_id'], business_detail_id=validated_data['business_detail_id']).aggregate(Sum('total_parking'))
        wing_total_parking = Wing.objects.filter(id=self.initial_data.get(
            'wing_id'), business_detail_id=validated_data['business_detail_id']).values('total_parking', 'building_id').first()
        if wing_parking_detail_sum['total_parking__sum'] == None:
            wing_parking_detail_sum['total_parking__sum'] = 0
        if wing_total_parking != None:
            if wing_parking_detail_sum['total_parking__sum']+validated_data['total_parking'] > wing_total_parking['total_parking']:
                raise serializers.ValidationError(
                    {"total_parking": "Wing parking count are greater than exist."})
        if wing_total_parking != None:
            wing_parking_size_type_sum = WingParkingDetail.objects.filter(wing_id__building_id=wing_total_parking['building_id'], vehicle_parking_size_and_type_id=validated_data[
                                                                          'vehicle_parking_size_and_type_id'], business_detail_id=validated_data['business_detail_id']).aggregate(Sum('total_parking'))
            building_parking_size_type = BuildingParkingDetail.objects.filter(building_id=wing_total_parking['building_id'], vehicle_parking_size_and_type_id=validated_data[
                                                                              'vehicle_parking_size_and_type_id'], business_detail_id=validated_data['business_detail_id']).values('total_parking').first()
            if wing_parking_size_type_sum['total_parking__sum'] == None:
                wing_parking_size_type_sum['total_parking__sum'] = 0
            if building_parking_size_type != None:
                if wing_parking_size_type_sum['total_parking__sum']+validated_data['total_parking'] > building_parking_size_type['total_parking']:
                    raise serializers.ValidationError(
                        {"total_parking": 'Wing total parking size and type count are greater than building parking size and type count.'})
            elif building_parking_size_type == None:
                raise serializers.ValidationError(
                    {"vehicle_parking_size_and_type_id": "Wing parking size and type are not exist in building."})
        else:
            raise serializers.ValidationError(
                {"vehicle_parking_size_and_type_id": "Wing parking size and type are not exist in building."})
        return super().create(validated_data)

    def update(self, instance, validated_data):
        if WingParkingDetail.objects.filter(vehicle_parking_size_and_type_id=validated_data['vehicle_parking_size_and_type_id'], wing_id=validated_data['wing_id'], business_detail_id=validated_data['business_detail_id']).exclude(id=instance.pk).exists():
            raise serializers.ValidationError(
                {"vehicle_parking_size_and_type_id": "Wing parking size and type already exist."})
        wing_parking_detail_sum = WingParkingDetail.objects.filter(
            wing_id=validated_data['wing_id'], business_detail_id=validated_data['business_detail_id']).exclude(id=instance.pk).aggregate(Sum('total_parking'))
        wing_total_parking = Wing.objects.filter(id=self.initial_data.get(
            'wing_id'), business_detail_id=validated_data['business_detail_id']).values('total_parking', 'building_id').first()
        if wing_parking_detail_sum['total_parking__sum'] == None:
            wing_parking_detail_sum['total_parking__sum'] = 0
        if wing_total_parking != None:
            if wing_parking_detail_sum['total_parking__sum']+validated_data['total_parking'] > wing_total_parking['total_parking']:
                raise serializers.ValidationError(
                    {"total_parking": "Wing parking count are greater than exist."})
        if wing_total_parking != None:
            wing_parking_size_type_sum = WingParkingDetail.objects.filter(wing_id__building_id=wing_total_parking['building_id'], vehicle_parking_size_and_type_id=validated_data[
                                                                          'vehicle_parking_size_and_type_id'], business_detail_id=validated_data['business_detail_id']).exclude(id=instance.pk).aggregate(Sum('total_parking'))
            building_parking_size_type = BuildingParkingDetail.objects.filter(building_id=wing_total_parking['building_id'], vehicle_parking_size_and_type_id=validated_data[
                                                                              'vehicle_parking_size_and_type_id'], business_detail_id=validated_data['business_detail_id']).values('total_parking').first()
            if wing_parking_size_type_sum['total_parking__sum'] == None:
                wing_parking_size_type_sum['total_parking__sum'] = 0
            if building_parking_size_type != None:
                if wing_parking_size_type_sum['total_parking__sum']+validated_data['total_parking'] > building_parking_size_type['total_parking']:
                    raise serializers.ValidationError(
                        {"total_parking": 'Wing total parking size and type count are greater than building parking size and type count.'})
            elif building_parking_size_type == None:
                raise serializers.ValidationError(
                    {"vehicle_parking_size_and_type_id": "Wing parking size and type are not exist in building."})
        else:
            raise serializers.ValidationError(
                {"vehicle_parking_size_and_type_id": "Wing parking size and type are not exist in building."})
        occupant_parking_size_type_sum = OccupantParkingDetail.objects.filter(
            vehicle_parking_size_and_type_id=validated_data['vehicle_parking_size_and_type_id'], occupant_id__wing_id=validated_data['wing_id'], business_detail_id=validated_data['business_detail_id']).aggregate(Sum('total_parking'))
        if occupant_parking_size_type_sum['total_parking__sum'] == None:
            occupant_parking_size_type_sum['total_parking__sum'] = 0
        if occupant_parking_size_type_sum['total_parking__sum'] > validated_data['total_parking']:
            raise serializers.ValidationError(
                {'total_parking': 'Wing parking size and type are already used in occupant count.'})
        return super().update(instance, validated_data)

    def delete(self, instance):
        if OccupantParkingDetail.objects.filter(vehicle_parking_size_and_type_id=instance.vehicle_parking_size_and_type_id, occupant_id__wing_id=instance.wing_id, business_detail_id=instance.business_detail_id).exists():
            raise serializers.ValidationError(
                {'submit': 'wing parking size and type are exist in occupant parking.'})
        try:
            instance.delete()
        except Exception as e:
            raise serializers.ValidationError(
                {'submit': 'Cannot delete. This object is referenced by other objects.'})


class OccupantSerializer(serializers.ModelSerializer):
    wing_name = serializers.CharField(
        source='wing_id.wing_name', read_only=True)
    building_name = serializers.CharField(
        source='building_id.building_name', read_only=True)

    class Meta:
        model = Occupant
        fields = ['id', 'occupant_name', 'occupant_unit_name', 'total_parking', 'total_occupied_parking',
                  'wing_id', 'wing_name', 'building_id', 'building_name', 'business_detail_id']

    def create(self, validated_data):
       

        if Occupant.objects.filter(occupant_name=validated_data['occupant_name'], wing_id=validated_data['wing_id'], business_detail_id=validated_data['business_detail_id']).exists():
            raise serializers.ValidationError(
                {"occupant_name": "Occupant name is already exist"})
        if Occupant.objects.filter(occupant_unit_name=validated_data['occupant_unit_name'], wing_id=validated_data['wing_id'], business_detail_id=validated_data['business_detail_id']).exists():
            raise serializers.ValidationError(
                {"occupant_unit_name": "Occupant unit name is already exist."})
        occupant_parking_sum = Occupant.objects.filter(
            wing_id=validated_data['wing_id'], business_detail_id=validated_data['business_detail_id']).aggregate(Sum('total_parking'))
        wing_total_parking = Wing.objects.filter(id=validated_data['wing_id'].id
        , business_detail_id=validated_data['business_detail_id']).values('total_parking').first()
        if occupant_parking_sum['total_parking__sum'] == None:
            occupant_parking_sum['total_parking__sum'] = 0
        if wing_total_parking != None:
            if occupant_parking_sum['total_parking__sum']+validated_data['total_parking'] > wing_total_parking['total_parking']:
                raise serializers.ValidationError(
                    {"total_parking": "Occupant parking sum are greater than wing parking count."}
                )
        # try:
        #     wing = Wing.objects.get(name=validated_data['wing_name_input'])
        #     building = Building.objects.get(name=validated_data['building_name_input'])
        #     validated_data['wing_id'] = wing.id
        #     validated_data['building_id'] = building.id
        # except Wing.DoesNotExist:
        #     raise serializers.ValidationError({"wing_name_input": f"Wing with name '{validated_data['wing_name_input']}' not found."})
        # except Building.DoesNotExist:
        #     raise serializers.ValidationError({"building_name_input": f"Building with name '{validated_data['building_name_input']}' not found."})
        # try:
        #     wing = Wing.objects.get(name=wing_name_input)
        #     building = Building.objects.get(name=building_name_input)
        #     validated_data['wing_id'] = wing.id
        #     validated_data['building_id'] = building.id
        # except Wing.DoesNotExist:
        #     raise serializers.ValidationError({"wing_name_input": f"Wing with name '{wing_name_input}' not found."})
        # except Building.DoesNotExist:
        #     raise serializers.ValidationError({"building_name_input": f"Building with name '{building_name_input}' not found."})


        return super().create(validated_data)
        
    def update(self, instance, validated_data):
        if Occupant.objects.filter(occupant_name=validated_data['occupant_name'], wing_id=validated_data['wing_id'], business_detail_id=validated_data['business_detail_id']).exclude(id=instance.pk).exists():
            raise serializers.ValidationError(
                {"occupant_name": "Occupant name is already exist."})
        if Occupant.objects.filter(occupant_unit_name=validated_data['occupant_unit_name'], wing_id=validated_data['wing_id'], business_detail_id=validated_data['business_detail_id']).exclude(id=instance.pk).exists():
            raise serializers.ValidationError(
                {"occupant_unit_name": "Occupant unit name is already exist."})
        occupant_parking_sum = Occupant.objects.filter(wing_id=validated_data['wing_id'], business_detail_id=validated_data['business_detail_id']).exclude(
            id=instance.pk).aggregate(Sum('total_parking'))
        wing_total_parking = Wing.objects.filter(id=self.initial_data.get(
            'wing_id'), business_detail_id=validated_data['business_detail_id']).values('total_parking').first()
        if occupant_parking_sum['total_parking__sum'] == None:
            occupant_parking_sum['total_parking__sum'] = 0
        if wing_total_parking != None:
            if occupant_parking_sum['total_parking__sum']+validated_data['total_parking'] > wing_total_parking['total_parking']:
                raise serializers.ValidationError(
                    {"total_parking": "Occupant parking sum are greater than wing parking count."}
                )
        return super().update(instance, validated_data)

    def delete(self, instance):
        try:
            instance.delete()
        except Exception as e:
            raise serializers.ValidationError(
                {'submit': 'Cannot delete. This object is referenced by other objects.'})


class OccupantParkingDetailSerializer(serializers.ModelSerializer):
    wing_id = serializers.CharField(
        source='occupant_id.wing_id', read_only=True)
    wing_name = serializers.CharField(
        source='occupant_id.wing_id.wing_name', read_only=True)
    building_name = serializers.CharField(
        source='occupant_id.wing_id.building_id.building_name', read_only=True)
    parking_size_and_type_name = serializers.CharField(
        source='vehicle_parking_size_and_type_id.parking_size_and_type_name', read_only=True)
    occupant_name = serializers.CharField(
        source='occupant_id.occupant_name', read_only=True)

    class Meta:
        model = OccupantParkingDetail
        fields = ['id', 'total_parking','total_occupied_parking', 'vehicle_parking_size_and_type_id', 'parking_size_and_type_name',
                  'occupant_id', 'occupant_name', 'wing_id', 'wing_name', 'building_name', 'business_detail_id']

    def create(self, validated_data):
        if OccupantParkingDetail.objects.filter(vehicle_parking_size_and_type_id=validated_data['vehicle_parking_size_and_type_id'], occupant_id=validated_data['occupant_id'], business_detail_id=validated_data['business_detail_id']).exists():
            raise serializers.ValidationError(
                {"vehicle_parking_size_and_type_id": "Occupant parking size and type already exist."})
        occupant_parking_sum = OccupantParkingDetail.objects.filter(
            occupant_id=validated_data['occupant_id'], business_detail_id=validated_data['business_detail_id']).aggregate(Sum('total_parking'))
        occupant_parking_total = Occupant.objects.filter(id=validated_data['occupant_id'].id
            , business_detail_id=validated_data['business_detail_id']).values('total_parking', 'wing_id').first()
        if occupant_parking_sum['total_parking__sum'] == None:
            occupant_parking_sum['total_parking__sum'] = 0
        if occupant_parking_total != None:
            if occupant_parking_sum['total_parking__sum']+validated_data['total_parking'] > occupant_parking_total['total_parking']:
                raise serializers.ValidationError(
                    {"total_parking": "Occupant parking sum are greater than occupant total parking exist"})
        if occupant_parking_total != None:
            occupant_parking_detail_size_type_sum = OccupantParkingDetail.objects.filter(occupant_id__wing_id=occupant_parking_total['wing_id'], vehicle_parking_size_and_type_id=validated_data[
                                                                                         'vehicle_parking_size_and_type_id'], business_detail_id=validated_data['business_detail_id']).aggregate(Sum('total_parking'))
            wing_parking_size_type_total = WingParkingDetail.objects.filter(wing_id=occupant_parking_total['wing_id'], vehicle_parking_size_and_type_id=validated_data[
                                                                            'vehicle_parking_size_and_type_id'], business_detail_id=validated_data['business_detail_id']).values('total_parking').first()
            if occupant_parking_detail_size_type_sum['total_parking__sum'] == None:
                occupant_parking_detail_size_type_sum['total_parking__sum'] = 0
            if wing_parking_size_type_total != None:
                if occupant_parking_detail_size_type_sum['total_parking__sum']+validated_data['total_parking'] > wing_parking_size_type_total['total_parking']:
                    raise serializers.ValidationError(
                        {'total_parking': 'Occupant total parking size and type count are greater than wing parking size and type count.'})
            elif wing_parking_size_type_total == None:
                raise serializers.ValidationError(
                    {"vehicle_parking_size_and_type_id": "Occupant parking size and type are not exist in wing."})
        else:
            raise serializers.ValidationError(
                {"vehicle_parking_size_and_type_id": "Occupant parking size and type are not exist in wing."})
        return super().create(validated_data)

    def update(self, instance, validated_data):
        if OccupantParkingDetail.objects.filter(vehicle_parking_size_and_type_id=validated_data['vehicle_parking_size_and_type_id'], occupant_id=validated_data['occupant_id'], business_detail_id=validated_data['business_detail_id']).exclude(id=instance.pk).exists():
            raise serializers.ValidationError(
                {"vehicle_parking_size_and_type_id": "Occupant parking size and type already exist."})
        occupant_parking_sum = OccupantParkingDetail.objects.filter(
            occupant_id=validated_data['occupant_id'], business_detail_id=validated_data['business_detail_id']).exclude(id=instance.pk).aggregate(Sum('total_parking'))
        occupant_parking_total = Occupant.objects.filter(id=self.initial_data.get(
            'occupant_id'), business_detail_id=validated_data['business_detail_id']).values('total_parking', 'wing_id').first()
        if occupant_parking_sum['total_parking__sum'] == None:
            occupant_parking_sum['total_parking__sum'] = 0
        if occupant_parking_total != None:
            if occupant_parking_sum['total_parking__sum']+validated_data['total_parking'] > occupant_parking_total['total_parking']:
                raise serializers.ValidationError(
                    {"total_parking": "Occupant parking sum are greater than occupant total parking exist"})

        if occupant_parking_total != None:
            occupant_parking_detail_size_type_sum = OccupantParkingDetail.objects.filter(occupant_id__wing_id=occupant_parking_total['wing_id'], vehicle_parking_size_and_type_id=validated_data[
                                                                                         'vehicle_parking_size_and_type_id'], business_detail_id=validated_data['business_detail_id']).exclude(id=instance.pk).aggregate(Sum('total_parking'))
            wing_parking_size_type_total = WingParkingDetail.objects.filter(wing_id=occupant_parking_total['wing_id'], vehicle_parking_size_and_type_id=validated_data[
                                                                            'vehicle_parking_size_and_type_id'], business_detail_id=validated_data['business_detail_id']).values('total_parking').first()
            if occupant_parking_detail_size_type_sum['total_parking__sum'] == None:
                occupant_parking_detail_size_type_sum['total_parking__sum'] = 0
            if wing_parking_size_type_total != None:
                if occupant_parking_detail_size_type_sum['total_parking__sum']+validated_data['total_parking'] > wing_parking_size_type_total['total_parking']:
                    raise serializers.ValidationError(
                        {'total_parking': 'Occupant total parking size and type count are greater than wing parking size and type count.'})
            elif wing_parking_size_type_total == None:
                raise serializers.ValidationError(
                    {"vehicle_parking_size_and_type_id": "Occupant parking size and type are not exist in wing."})
        else:
            raise serializers.ValidationError(
                {"vehicle_parking_size_and_type_id": "Occupant parking size and type are not exist in wing."})
        return super().update(instance, validated_data)

    def delete(self, instance):
        if VehicleDetail.objects.filter(vehicle_parking_size_and_type_id=instance.vehicle_parking_size_and_type_id, occupant_id=instance.occupant_id, business_detail_id=instance.business_detail_id).exists():
            raise serializers.ValidationError(
                {'submit': 'Occupant parking size and type are exist in vehicle parking.'})
        try:
            instance.delete()
        except Exception as e:
            raise serializers.ValidationError(
                {'submit': 'Cannot delete. This object is referenced by other objects.'})

## Vehicle Detail API Serializer
class VehicleDetailSerializer(serializers.ModelSerializer):
    wing_name = serializers.CharField(
        source='occupant_id.wing_id.wing_name', read_only=True)
    building_name = serializers.CharField(
        source='occupant_id.wing_id.building_id.building_name', read_only=True)
    parking_size_and_type_name = serializers.CharField(
        source='vehicle_parking_size_and_type_id.parking_size_and_type_name', read_only=True)
    occupant_name = serializers.CharField(
        source='occupant_id.occupant_name', read_only=True)

    class Meta:
        model = VehicleDetail
        fields = ['id', 'vehicle_number','visible_vehicle_number', 'vehicle_owner_name','occupied_parking', 'vehicle_parking_size_and_type_id', 'parking_size_and_type_name',
                  'occupant_id', 'occupant_name', 'wing_name', 'building_name', 'business_detail_id']

    def create(self, validated_data):
        if VehicleDetail.objects.filter(vehicle_number=validated_data['vehicle_number'], business_detail_id=validated_data['business_detail_id']).exists():
            raise serializers.ValidationError(
                {"vehicle_number": 'Vehicle number is already exist.'})
        if VehicleDetail.objects.filter(vehicle_owner_name=validated_data['vehicle_owner_name'], business_detail_id=validated_data['business_detail_id']).exists():
            raise serializers.ValidationError(
                {"vehicle_owner_name": 'Vehicle owner name is already exist.'})
        getOccupantParkingSizeAndType = OccupantParkingDetail.objects.filter(
            vehicle_parking_size_and_type_id=validated_data['vehicle_parking_size_and_type_id'], occupant_id=validated_data['occupant_id'], business_detail_id=validated_data['business_detail_id']).count()
        if getOccupantParkingSizeAndType == 0:
            raise serializers.ValidationError(
                {"vehicle_parking_size_and_type_id": "Occupant doesn't have that parking size and type exist."})
        return super().create(validated_data)

    def update(self, instance, validated_data):
        if VehicleDetail.objects.filter(vehicle_number=validated_data['vehicle_number'], business_detail_id=validated_data['business_detail_id']).exclude(id=instance.pk).exists():
            raise serializers.ValidationError(
                {"vehicle_number": 'Vehicle number is already exist.'})
        if VehicleDetail.objects.filter(vehicle_owner_name=validated_data['vehicle_owner_name'], business_detail_id=validated_data['business_detail_id']).exclude(id=instance.pk).exists():
            raise serializers.ValidationError(
                {"vehicle_owner_name": 'Vehicle owner name is already exist.'})
        getOccupantParkingSizeAndType = OccupantParkingDetail.objects.filter(
            vehicle_parking_size_and_type_id=validated_data['vehicle_parking_size_and_type_id'], occupant_id=validated_data['occupant_id'], business_detail_id=validated_data['business_detail_id']).count()
        if getOccupantParkingSizeAndType == 0:
            raise serializers.ValidationError(
                {"vehicle_parking_size_and_type_id": "Occupant doesn't have that parking size and type exist."})
        return super().update(instance, validated_data)

    def delete(self, instance):
        try:
            instance.delete()
        except Exception as e:
            raise serializers.ValidationError(
                {'submit': 'Cannot delete. This object is referenced by other objects.'})
