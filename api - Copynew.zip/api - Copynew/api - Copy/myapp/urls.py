"""CPPMS URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.conf.urls.static import static
from django.urls import path, include, reverse_lazy
from django.conf import settings 
from myapp import views
#from .views import OccupantView,BulkUploadData

app_name = 'myapp'


from rest_framework.urlpatterns import format_suffix_patterns


urlpatterns = [
    # path('business_detail/', views.BusinessDetailView.as_view()),
    # path('business_detail_detail/<int:id>/', views.BusinessDetailDetailView.as_view()),

    path('vehicle-type',views.VehicleTypeView.as_view()),
    path('vehicle-type/<int:id>', views.VehicleTypeDetailView.as_view()),
    path('wheeler-dropdown',views.GetNumberOfWheelerDropdownView.as_view()),

    path('vehicle-parking-size-and-type',views.VehicleParkingSizeAndTypeView.as_view()),
    path('vehicle-parking-size-and-type/<int:id>',views.VehicleParkingSizeAndTypeDetailView.as_view()),
    path('parking-size-and-type-dropdown',views.GetParkingSizeAndTypeDropdownView.as_view()),
    
    path('building',views.BuildingView.as_view()),
    path('building/<int:id>',views.BuildingDetailView.as_view()),
    path('building-dropdown',views.GetBuildingDropdownView.as_view()),

    path('building-parking',views.BuildingParkingView.as_view()),
    path('building-parking/<int:id>',views.BuildingParkingDetailView.as_view()),
    path('building-parking-of-building/<int:id>',views.GetBuildingParkingBasedOnIdView.as_view()),

    path('wing', views.WingView.as_view()),
    path('wing/<int:id>', views.WingDetailView.as_view()),

    path('wing-parking',views.WingParkingView.as_view()),
    path('wing-parking/<int:id>',views.WingParkingDetailView.as_view()),
    path('wing-parking-of-wing/<int:id>',views.GetWingParkingBasedOnIdView.as_view()),
    path('wing-dropdown/<int:id>',views.GetBuildingWingDropdownView.as_view()),

    path('occupant',views.OccupantView.as_view()),
    path('occupant/<int:id>',views.OccupantDetailView.as_view()),

    path('occupant-parking',views.OccupantParkingView.as_view()),
    path('occupant-parking/<int:id>',views.OccupantParkingDetailView.as_view()),
    path('occupant-parking-of-occupant/<int:id>',views.GetOccupantParkingBasedOnIdView.as_view()),

    path('vehicle-detail',views.VehicleView.as_view()),
    path('vehicle-detail/<int:id>',views.VehicleDetailView.as_view()),
    path('vehicle-detail-of-occupant/<int:id>',views.GetVehicleDetailBasedOnIdView.as_view()),
    #path('bulk-upload-occupant/', BulkUploadData.as_view(), name='bulk_upload_occupant'),
   
    #Dropdown
    #path('api/business-details/', views.get_business_details, name='api-business-details'),
    path('api/vehicle-types', views.GetVehicleTypesView.as_view(), name='api-vehicle-types'),
]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

#urlpatterns = format_suffix_patterns(urlpatterns)
