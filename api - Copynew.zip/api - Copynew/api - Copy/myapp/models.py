from django.db import models
from django.contrib.auth.models import (
    BaseUserManager, AbstractBaseUser,AbstractUser,PermissionsMixin
)
import uuid
import django
from django.core.validators import RegexValidator
from django.contrib.auth.models import User
from django.conf import settings
from account.models import BusinessDetail,VehicleParkingSizeAndType,VehicleType



# Create your models here.

# class BusinessDetail(models.Model):
#     business_name = models.CharField(max_length=50)
#     total_number_of_wings = models.IntegerField()
#     business_type = models.CharField(max_length=50)
#     plan_validity = models.BooleanField()
#     plan_expire_datetime = models.DateTimeField()
#     days_to_expire = models.IntegerField(default=15)
#     created_datetime = models.DateTimeField(auto_now_add=True, blank=True, null=True)
#     modified_datetime = models.DateTimeField(auto_now=True,blank=True, null=True)
#     created_by = models.CharField(max_length=50,blank=True, null=True)
#     modified_by = models.CharField(max_length=50,blank=True, null=True)
#     total_number_of_parking = models.IntegerField()
#     total_number_of_occupants = models.IntegerField()
#     logo = models.TextField()


class Building(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    building_name = models.CharField(max_length=50)
    total_parking = models.IntegerField()
    total_occupied_parking = models.IntegerField(default=0)
    business_detail_id = models.ForeignKey(BusinessDetail, on_delete=models.PROTECT)
    created_datetime = models.DateTimeField(auto_now_add=True,blank=True, null=True)
    modified_datetime = models.DateTimeField(auto_now=True,blank=True, null=True)
    created_by = models.CharField(max_length=50,blank=True, null=True)
    modified_by = models.CharField(max_length=50,blank=True, null=True)

class BuildingParkingDetail(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    total_parking = models.IntegerField()
    total_occupied_parking = models.IntegerField(default=0)
    vehicle_parking_size_and_type_id = models.ForeignKey(VehicleParkingSizeAndType,on_delete=models.PROTECT)
    building_id = models.ForeignKey(Building,on_delete=models.PROTECT)
    business_detail_id = models.ForeignKey(BusinessDetail, on_delete=models.PROTECT)
    created_datetime = models.DateTimeField(auto_now_add=True,blank=True, null=True)
    modified_datetime = models.DateTimeField(auto_now=True,blank=True, null=True)
    created_by = models.CharField(max_length=50,blank=True, null=True)
    modified_by = models.CharField(max_length=50,blank=True, null=True)

class Wing(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    wing_name = models.CharField(max_length=50)
    total_parking = models.IntegerField()
    total_occupied_parking = models.IntegerField(default=0)
    building_id = models.ForeignKey(Building,on_delete=models.PROTECT)
    business_detail_id = models.ForeignKey(BusinessDetail, on_delete=models.PROTECT)
    created_datetime = models.DateTimeField(auto_now_add=True,blank=True, null=True)
    modified_datetime = models.DateTimeField(auto_now=True,blank=True, null=True)
    created_by = models.CharField(max_length=50,blank=True, null=True)
    modified_by = models.CharField(max_length=50,blank=True, null=True)

class WingParkingDetail(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    total_parking = models.IntegerField()
    total_occupied_parking = models.IntegerField(default=0)
    vehicle_parking_size_and_type_id = models.ForeignKey(VehicleParkingSizeAndType,on_delete=models.PROTECT)
    wing_id = models.ForeignKey(Wing,on_delete=models.PROTECT)
    business_detail_id = models.ForeignKey(BusinessDetail, on_delete=models.PROTECT)
    created_datetime = models.DateTimeField(auto_now_add=True,blank=True, null=True)
    modified_datetime = models.DateTimeField(auto_now=True,blank=True, null=True)
    created_by = models.CharField(max_length=50,blank=True, null=True)
    modified_by = models.CharField(max_length=50,blank=True, null=True)


class Occupant(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    occupant_name = models.CharField(max_length=50)
    occupant_unit_name = models.CharField(max_length=50)
    total_parking = models.IntegerField()
    total_occupied_parking = models.IntegerField(default=0)
    wing_id = models.ForeignKey(Wing,on_delete=models.PROTECT)
    building_id = models.ForeignKey(Building,on_delete=models.PROTECT)
    business_detail_id = models.ForeignKey(BusinessDetail, on_delete=models.PROTECT)
    created_datetime = models.DateTimeField(auto_now_add=True,blank=True, null=True)
    modified_datetime = models.DateTimeField(auto_now=True,blank=True, null=True)
    created_by = models.CharField(max_length=50,blank=True, null=True)
    modified_by = models.CharField(max_length=50,blank=True, null=True)

class OccupantParkingDetail(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    total_parking = models.IntegerField()
    total_occupied_parking = models.IntegerField(default=0)
    vehicle_parking_size_and_type_id = models.ForeignKey(VehicleParkingSizeAndType,on_delete=models.PROTECT)
    occupant_id = models.ForeignKey(Occupant,on_delete=models.PROTECT)
    business_detail_id = models.ForeignKey(BusinessDetail, on_delete=models.PROTECT)
    created_datetime = models.DateTimeField(auto_now_add=True,blank=True, null=True)
    modified_datetime = models.DateTimeField(auto_now=True,blank=True, null=True)
    created_by = models.CharField(max_length=50,blank=True, null=True)
    modified_by = models.CharField(max_length=50,blank=True, null=True)

class VehicleDetail(models.Model):
    vehicle_number = models.CharField(max_length=20)
    visible_vehicle_number = models.CharField(max_length=20,null=True,blank=True)
    vehicle_owner_name = models.CharField(max_length=50)
    occupied_parking = models.BooleanField(default=False)
    occupant_id = models.ForeignKey(Occupant, on_delete=models.PROTECT)
    vehicle_parking_size_and_type_id = models.ForeignKey(VehicleParkingSizeAndType,on_delete=models.PROTECT)
    business_detail_id = models.ForeignKey(BusinessDetail, on_delete=models.PROTECT)
    created_datetime = models.DateTimeField(auto_now_add=True,blank=True, null=True)
    modified_datetime = models.DateTimeField(auto_now=True,blank=True, null=True)
    created_by = models.CharField(max_length=50,blank=True, null=True)
    modified_by = models.CharField(max_length=50,blank=True, null=True)
    
