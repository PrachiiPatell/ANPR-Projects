from django.shortcuts import render

# Create your views here.
from django.http import JsonResponse, Http404
from rest_framework.parsers import FileUploadParser
from rest_framework import status,serializers
from rest_framework.response import Response
from rest_framework import permissions
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from account.models import *
from rest_framework.views import APIView
from rest_framework.pagination import LimitOffsetPagination
from django.db import transaction
import pandas as pd
from django.http import QueryDict



#view
from rest_framework.decorators import api_view, permission_classes
#import model
from .models import Building,BuildingParkingDetail,Wing,WingParkingDetail,Occupant,OccupantParkingDetail,VehicleDetail
from account.models import BusinessDetail,VehicleType, VehicleParkingSizeAndType,NumberOfWheeler
#import serializers
from .serializers import VehicleTypeSerializer,VehicleTypeDropdownSerializer, VehicleParkingSizeAndTypeSerializer,VehicleParkingSizeAndTypeDropdownSerializer,BuildingSerializer,BuildingDropdownSerializer,BuildingParkingDetailSerializer,WingSerializer,WingDropdownSerializer,WingParkingDetailSerializer,OccupantSerializer,OccupantParkingDetailSerializer,VehicleDetailSerializer

from rest_framework.permissions import IsAuthenticated
from account.views import getUserData
from django.db.models import Q


#Vehicletype api
class VehicleTypeView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, format=None):
        try:
            # print("request.user",request.user,request.user.id,type(request.user.id))
            get_user_data = getUserData(request.user.id)

            if get_user_data['business_detail']['plan_validity'] == True:
                AcessToPage = False
                if 'vehicle_type' in get_user_data['permission'].keys():
                    if 'view' in get_user_data['permission']['vehicle_type']:
                        AcessToPage = True
                if AcessToPage == True:
                    limit = int(request.GET.get('limit',10))
                    offset = int(request.GET.get('offset',0))
                    vehicle_detail = VehicleType.objects.filter(business_detail_id = get_user_data['business_detail']['id']).all()[offset:limit+offset]
                    vehicle_count = VehicleType.objects.filter(business_detail_id = get_user_data['business_detail']['id']).all().count()
                    serializer = VehicleTypeSerializer(vehicle_detail, many=True)
                    return Response({'count':vehicle_count,'results':serializer.data})
                else:
                    return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            print('error:',e)
            return Response({'error':e},status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    def post(self, request, format=None):
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'vehicle_type' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['vehicle_type']:
                    AcessToPage = True
            if AcessToPage == True:
                get_data = request.data
                get_data['business_detail_id'] = get_user_data['business_detail']['id']
                serializer = VehicleTypeSerializer(data=get_data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                else:
                    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "you don't have permission to access."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
        
class VehicleTypeDetailView(APIView):
    permission_classes = (IsAuthenticated,)
    def get_object(self, id):
        try:
            return VehicleType.objects.get(pk=id)
        except VehicleType.DoesNotExist:
            return Response(status=status.HTTP_404_NOT_FOUND)
    def get(self, request,id, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'vehicle_type' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['vehicle_type']:
                    AcessToPage = True
            if AcessToPage == True:
                vehicle_type = self.get_object(id)
                serializer = VehicleTypeSerializer(vehicle_type)
                return Response(serializer.data)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
    def put(self, request, id, format=None): 
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'vehicle_type' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['vehicle_type']:
                    AcessToPage = True
            if AcessToPage == True:
                vehicle_type = self.get_object(id)
                get_data = request.data
                get_data['business_detail_id'] = get_user_data['business_detail']['id']
                serializer = VehicleTypeSerializer(vehicle_type, data=get_data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)  
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
     
    def delete(self, request,id, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'vehicle_type' in get_user_data['permission'].keys():
                if 'delete' in get_user_data['permission']['vehicle_type']:
                    AcessToPage = True
            if AcessToPage == True:
                vehicle_type = self.get_object(id)
                serializers = VehicleDetailSerializer(vehicle_type)
                serializers.delete(vehicle_type)
                return Response(status=status.HTTP_204_NO_CONTENT)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

class GetNumberOfWheelerDropdownView(APIView):
    permission_classes = (IsAuthenticated,)
    def get(self,request):
        user_id = getUserData(request.user.id)
        number_of_wheeler_dropdown = NumberOfWheeler.objects.all()
        options = [{'id': wheeler_value.id, 'wheeler': wheeler_value.wheeler} for wheeler_value in number_of_wheeler_dropdown]
        return JsonResponse(options, safe=False)

#Vehicle parking size and type api
class VehicleParkingSizeAndTypeView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'vehicle_parking_size_and_type' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['vehicle_parking_size_and_type']:
                    AcessToPage = True
            if AcessToPage == True:
                limit = int(request.GET.get('limit',10))
                offset = int(request.GET.get('offset',0))
                vehicle_parking_size_and_type = VehicleParkingSizeAndType.objects.filter(business_detail_id = get_user_data['business_detail']['id']).all()[offset:limit+offset]
                vehicle_parking_size_and_type_count = VehicleParkingSizeAndType.objects.filter(business_detail_id = get_user_data['business_detail']['id']).all().count()
                serializer = VehicleParkingSizeAndTypeSerializer(vehicle_parking_size_and_type, many=True)
                return Response({'count':vehicle_parking_size_and_type_count,'results':serializer.data})
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
    
    def post(self, request, format=None):
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'vehicle_parking_size_and_type' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['vehicle_parking_size_and_type']:
                    AcessToPage = True
            if AcessToPage == True:
                get_data = request.data
                get_data['business_detail_id'] = get_user_data['business_detail']['id']
                serializer = VehicleParkingSizeAndTypeSerializer(data=get_data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                else:
                    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
        
class VehicleParkingSizeAndTypeDetailView(APIView):
    permission_classes = (IsAuthenticated,)
    def get_object(self, id):
        try:
            return VehicleParkingSizeAndType.objects.get(pk=id)
        except VehicleParkingSizeAndType.DoesNotExist:
            return Response(status=status.HTTP_404_NOT_FOUND)
    def get(self, request,id, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'vehicle_parking_size_and_type' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['vehicle_parking_size_and_type']:
                    AcessToPage = True
            if AcessToPage == True:
                vehicle_parking_size_and_type = self.get_object(id)
                serializer = VehicleParkingSizeAndTypeSerializer(vehicle_parking_size_and_type)
                return Response(serializer.data)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
    def put(self, request, id, format=None): 
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'vehicle_parking_size_and_type' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['vehicle_parking_size_and_type']:
                    AcessToPage = True
            if AcessToPage == True:
                vehicle_parking_size_and_type = self.get_object(id)
                get_data = request.data
                get_data['business_detail_id'] = get_user_data['business_detail']['id']
                serializer = VehicleParkingSizeAndTypeSerializer(vehicle_parking_size_and_type, data=get_data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)  
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
     
    def delete(self, request,id, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'vehicle_parking_size_and_type' in get_user_data['permission'].keys():
                if 'delete' in get_user_data['permission']['vehicle_parking_size_and_type']:
                    AcessToPage = True
            if AcessToPage == True:
                vehicle_parking_size_and_type = self.get_object(id)
                serializers = VehicleParkingSizeAndTypeSerializer(vehicle_parking_size_and_type)
                serializers.delete(vehicle_parking_size_and_type)
                return Response(status=status.HTTP_204_NO_CONTENT)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


#Building API
class BuildingView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'building' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['building']:
                    AcessToPage = True
            if AcessToPage == True:
                limit = int(request.GET.get('limit',10))
                offset = int(request.GET.get('offset',0))
                building = Building.objects.filter(business_detail_id = get_user_data['business_detail']['id']).all()[offset:limit+offset] 
                building_count = Building.objects.filter(business_detail_id = get_user_data['business_detail']['id']).all().count()
                serializer = BuildingSerializer(building, many=True)
                return Response({'count':building_count,'results':serializer.data})
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
    
    def post(self, request, format=None):
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'building' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['building']:
                    AcessToPage = True
            if AcessToPage == True:
                get_data = request.data
                get_data['business_detail_id'] = get_user_data['business_detail']['id']
                serializer = BuildingSerializer(data=get_data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                else:
                    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
        
class BuildingDetailView(APIView):
    permission_classes = (IsAuthenticated,)
    def get_object(self, id):
        try:
            return Building.objects.get(pk=id)
        except Building.DoesNotExist:
            return Response(status=status.HTTP_404_NOT_FOUND)
    def get(self, request,id, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'building' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['building']:
                    AcessToPage = True
            if AcessToPage == True:
                building = self.get_object(id)
                serializer = BuildingSerializer(building)
                return Response(serializer.data)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
    def put(self, request, id, format=None): 
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'building' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['building']:
                    AcessToPage = True
            if AcessToPage == True:
                building = self.get_object(id)
                get_data = request.data
                get_data['business_detail_id'] = get_user_data['business_detail']['id']
                serializer = BuildingSerializer(building, data=get_data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)  
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
     
    def delete(self, request,id, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'building' in get_user_data['permission'].keys():
                if 'delete' in get_user_data['permission']['building']:
                    AcessToPage = True
            if AcessToPage == True:
                building = self.get_object(id)
                serializers = BuildingSerializer(building)
                serializers.delete(building)
                return Response(status=status.HTTP_204_NO_CONTENT)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


#Building Parking Detail API
class BuildingParkingView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = getUserData(request.user.id)
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'building_parking_detail' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['building_parking_detail']:
                    AcessToPage = True
            if AcessToPage == True:
                limit = int(request.GET.get('limit',10))
                offset = int(request.GET.get('offset',0))
                building_parking_detail = BuildingParkingDetail.objects.filter(business_detail_id = get_user_data['business_detail']['id']).all()[offset:limit+offset]
                building_parking_detail_count = BuildingParkingDetail.objects.filter(business_detail_id = get_user_data['business_detail']['id']).all().count()
                serializer = BuildingParkingDetailSerializer(building_parking_detail, many=True)
                return Response({'count':building_parking_detail_count,'results':serializer.data})
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
    
    def post(self, request, format=None):
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'building_parking_detail' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['building_parking_detail']:
                    AcessToPage = True
            if AcessToPage == True:
                get_data = request.data
                get_data['business_detail_id'] = get_user_data['business_detail']['id']
                serializer = BuildingParkingDetailSerializer(data=get_data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                else:
                    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
        
class BuildingParkingDetailView(APIView):
    permission_classes = (IsAuthenticated,)
    def get_object(self, id):
        try:
            return BuildingParkingDetail.objects.get(pk=id)
        except BuildingParkingDetail.DoesNotExist:
            return Response(status=status.HTTP_404_NOT_FOUND)
    def get(self, request,id, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'building_parking_detail' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['building_parking_detail']:
                    AcessToPage = True
            if AcessToPage == True:
                building_parking_detail = self.get_object(id)
                serializer = BuildingParkingDetailSerializer(building_parking_detail)
                return Response(serializer.data)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
    def put(self, request, id, format=None): 
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'building_parking_detail' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['building_parking_detail']:
                    AcessToPage = True
            if AcessToPage == True:
                building_parking_detail = self.get_object(id)
                get_data = request.data
                get_data['business_detail_id'] = get_user_data['business_detail']['id']
                serializer = BuildingParkingDetailSerializer(building_parking_detail, data=get_data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)  
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
     
    def delete(self, request,id, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'building_parking_detail' in get_user_data['permission'].keys():
                if 'delete' in get_user_data['permission']['building_parking_detail']:
                    AcessToPage = True
            if AcessToPage == True:
                building_parking_detail = self.get_object(id)
                serializer = BuildingParkingDetailSerializer(building_parking_detail)
                serializer.delete(building_parking_detail)
                return Response(status=status.HTTP_204_NO_CONTENT)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

class GetBuildingParkingBasedOnIdView(APIView):
    permission_classes = (IsAuthenticated,)
    def get(self, request,id, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'building_parking_detail' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['building_parking_detail']:
                    AcessToPage = True
            if AcessToPage == True:
                limit = int(request.GET.get('limit',10))
                offset = int(request.GET.get('offset',0))
                building_parking_detail = BuildingParkingDetail.objects.filter(business_detail_id = get_user_data['business_detail']['id'],building_id=id).all()[offset:limit+offset]
                building_parking_detail_count = BuildingParkingDetail.objects.filter(business_detail_id = get_user_data['business_detail']['id'],building_id=id).all().count()
                serializer = BuildingParkingDetailSerializer(building_parking_detail, many=True)
                return Response({'count':building_parking_detail_count,'results':serializer.data})
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


#Wing API
class WingView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'wing' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['wing']:
                    AcessToPage = True
            if AcessToPage == True:
                limit = int(request.GET.get('limit',10))
                offset = int(request.GET.get('offset',0))
                wing = Wing.objects.filter(business_detail_id = get_user_data['business_detail']['id']).all()[offset:limit+offset]
                wing_count = Wing.objects.filter(business_detail_id = get_user_data['business_detail']['id']).all().count()
                serializer = WingSerializer(wing, many=True)
                return Response({'count':wing_count,'results':serializer.data})
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
    
    def post(self, request, format=None):
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'wing' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['wing']:
                    AcessToPage = True
            if AcessToPage == True:
                get_data = request.data
                get_data['business_detail_id'] = get_user_data['business_detail']['id']
                serializer = WingSerializer(data=get_data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                else:
                    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
        
class WingDetailView(APIView):
    permission_classes = (IsAuthenticated,)
    def get_object(self, id):
        try:
            return Wing.objects.get(pk=id)
        except Wing.DoesNotExist:
            return Response(status=status.HTTP_404_NOT_FOUND)
    def get(self, request,id, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'wing' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['wing']:
                    AcessToPage = True
            if AcessToPage == True:
                wing = self.get_object(id)
                serializer = WingSerializer(wing)
                return Response(serializer.data)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
    def put(self, request, id, format=None): 
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'wing' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['wing']:
                    AcessToPage = True
            if AcessToPage == True:
                wing = self.get_object(id)
                get_data = request.data
                get_data['business_detail_id'] = get_user_data['business_detail']['id']
                serializer = WingSerializer(wing, data=get_data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)  
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
     
    def delete(self, request,id, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'wing' in get_user_data['permission'].keys():
                if 'delete' in get_user_data['permission']['wing']:
                    AcessToPage = True
            if AcessToPage == True:
                wing = self.get_object(id)
                serializer = WingSerializer(wing)
                serializer.delete(wing)
                return Response(status=status.HTTP_204_NO_CONTENT)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


#Wing Parking Detail API
class WingParkingView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'wing_parking_detail' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['wing_parking_detail']:
                    AcessToPage = True
            if AcessToPage == True:
                limit = int(request.GET.get('limit',10))
                offset = int(request.GET.get('offset',0))
                wing_parking_detail = WingParkingDetail.objects.filter(business_detail_id = get_user_data['business_detail']['id']).all()[offset:limit+offset]
                wing_parking_detail_count = WingParkingDetail.objects.filter(business_detail_id = get_user_data['business_detail']['id']).all().count()
                serializer = WingParkingDetailSerializer(wing_parking_detail, many=True)
                return Response({'count':wing_parking_detail_count,'results':serializer.data})
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
    
    def post(self, request, format=None):
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'wing_parking_detail' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['wing_parking_detail']:
                    AcessToPage = True
            if AcessToPage == True:
                get_data = request.data
                get_data['business_detail_id'] = get_user_data['business_detail']['id']
                serializer = WingParkingDetailSerializer(data=get_data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                else:
                    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
        
class WingParkingDetailView(APIView):
    permission_classes = (IsAuthenticated,)
    def get_object(self, id):
        try:
            return WingParkingDetail.objects.get(pk=id)
        except WingParkingDetail.DoesNotExist:
            return Response(status=status.HTTP_404_NOT_FOUND)
    def get(self, request,id, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'wing_parking_detail' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['wing_parking_detail']:
                    AcessToPage = True
            if AcessToPage == True:
                wing_parking_detail = self.get_object(id)
                serializer = WingParkingDetailSerializer(wing_parking_detail)
                return Response(serializer.data)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
    def put(self, request, id, format=None): 
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'wing_parking_detail' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['wing_parking_detail']:
                    AcessToPage = True
            if AcessToPage == True:
                wing_parking_detail = self.get_object(id)
                get_data = request.data
                get_data['business_detail_id'] = get_user_data['business_detail']['id']
                serializer = WingParkingDetailSerializer(wing_parking_detail, data=get_data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)  
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
     
    def delete(self, request,id, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'wing_parking_detail' in get_user_data['permission'].keys():
                if 'delete' in get_user_data['permission']['wing_parking_detail']:
                    AcessToPage = True
            if AcessToPage == True:
                wing_parking_detail = self.get_object(id)
                serializer = WingParkingDetailSerializer(wing_parking_detail)
                serializer.delete(wing_parking_detail)
                return Response(status=status.HTTP_204_NO_CONTENT)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class GetWingParkingBasedOnIdView(APIView):
    permission_classes = (IsAuthenticated,)
    def get(self, request,id, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'wing_parking_detail' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['wing_parking_detail']:
                    AcessToPage = True
            if AcessToPage == True:
                limit = int(request.GET.get('limit',10))
                offset = int(request.GET.get('offset',0))
                wing_parking_detail = WingParkingDetail.objects.filter(business_detail_id = get_user_data['business_detail']['id'],wing_id=id).all()[offset:limit+offset]
                wing_parking_detail_count = WingParkingDetail.objects.filter(business_detail_id = get_user_data['business_detail']['id'],wing_id=id).all().count()
                serializer = WingParkingDetailSerializer(wing_parking_detail, many=True)
                return Response({'count':wing_parking_detail_count,'results':serializer.data})
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
    



#Occupant API

class BulkDataUpload(APIView):
    permission_classes = (IsAuthenticated,)
    
    def __init__(self,user_data, file, df, **kwargs,):
              super().__init__(**kwargs)   
              self.user_data = user_data
              self.file = file
              self.df = df
        #self.context = {'business_detail_id': user_data['business_detail']['id']}
        
    def validate_and_save_data(self):
           
           try:
              #business_detail_id=get_user_data['business_detail']['id']
              
              df = pd.read_excel(self.file)
              errors = []
              unique_values_set = set()

              with transaction.atomic():
                
                for index, row in df.iterrows():
                    
                    current_row_values = tuple(row[['Wing Name', 'Building Name', 'Vehicle Number']])
                    if current_row_values in unique_values_set:
                        duplicate_column = self.get_duplicate_column(df, row, current_row_values)
                        errors.append({
                            'row': index + 2,
                            'column': duplicate_column,
                            'detail': "Duplicate data in this row."
                        })
                        continue

                    unique_values_set.add(current_row_values)

                   
                    self.process_occupant_row(row, errors, index)

                    
                    self.process_occupant_parking_detail_row(row, errors, index)

                    
                    self.process_vehicle_detail_row(row, errors, index)
                if errors:
               
                    error_details_string = str(serializers.ValidationError(errors).detail)
                    raise serializers.ValidationError(errors)  # This line raises an exception

            
              return {"detail": "Data imported successfully."}, status.HTTP_201_CREATED

           except serializers.ValidationError as validation_error:
        
            error_details_values = QueryDict(mutable=True)
            error_details_values.update({'errors': validation_error.detail})
            return error_details_values, status.HTTP_400_BAD_REQUEST   


           except Exception as e:
            # Handle any exceptions (e.g., invalid Excel format)
            return {"detail": str(e)}, status.HTTP_400_BAD_REQUEST
            

    def get_duplicate_column(self, df, row, current_row_values):
    
        for column_name in df.columns:
            if row[column_name] in current_row_values:
                return df.columns.get_loc(column_name) + 1  
        return 'Unknown Column'

    def get_wing_id(self, wing_name):
        try:
           
            wing = Wing.objects.get(wing_name=wing_name)
            return wing.id
        except Wing.DoesNotExist:
           
            return None
    
    def get_building_id(self, building_name):
        try:
            
            building = Building.objects.get(building_name=building_name)
            return building.id
        except Building.DoesNotExist:
            
            return None
        
    def get_occupant_id(self, occupant_name):
        try:
            
            occupant = Occupant.objects.get(occupant_name=occupant_name)
            return occupant.id
        except Occupant.DoesNotExist:
            return None
        
    def get_vehicle_parking_size_and_type_id(self, parking_size_and_type, business_detail_id):
        try:  
            parking_size_and_type_obj = VehicleParkingSizeAndType.objects.get(
            parking_size_and_type_name=parking_size_and_type, business_detail_id=business_detail_id)
            return parking_size_and_type_obj.id
        except VehicleParkingSizeAndType.DoesNotExist:
            return None
    
    def get_business_detail_id(self,request):
        try:
        #    business_detail = BusinessDetail.objects.get(business_name=business_name)
        #    return business_detail.id
             get_user_data = getUserData(request.user.id)
             business_detail_id=get_user_data['business_detail']['id']
             print(business_detail_id)
             return business_detail_id
        except BusinessDetail.DoesNotExist:   
           return None

    def get_column_number(self, df, serializer):
        for field_name in serializer.fields.keys():
            if field_name in df.columns:
                return df.columns.get_loc(field_name) + 1 
        return 'Unknown Column'

    def validate_and_save(self, serializer, errors, index, df=None):
        if serializer.is_valid():
            serializer.save()
        else:
            field_names = set(serializer.fields.keys())
     
            for error_key, error_detail in serializer.errors.items():
                field_names = set(serializer.fields.keys())
                if error_key in field_names:
                    column = list(serializer.fields.keys()).index(error_key) + 1  
                    break  
            else:
            
                column = None

            errors.append({
                 'row': index + 2,
                 'column': column,
                 'detail': f"Invalid data in this row: {serializer.errors}"
            })
       

          

    def process_occupant_row(self, row, errors, index):
        # get_user_data = getUserData(request.user.id)
        # business_detail_id=get_user_data['business_detail']['id']
        # print(business_detail_id)
       
        wing_id = self.get_wing_id(row['Wing Name'])
        building_id = self.get_building_id(row['Building Name'])
        row_data = {
                    'occupant_name': row['Occupant Name'],
                    'occupant_unit_name': row['Occupant Unit Name'],
                    'building_name': row['Building Name'],
                    'wing_name': row['Wing Name'], 
                    'total_parking': row['Occupant Total Parking'],
                    'total_occupied_parking': row['Occupant Total Occupied Parking'],
                    'wing_id': wing_id,
                    'building_id': building_id,
                    'business_detail_id': self.user_data['business_detail']['id'],
                   
                }
        #row_data['business_detail_id']=business_detail_id
        serializer = OccupantSerializer(data=row_data)
        self.validate_and_save(serializer, errors, index, df=self.df)

    
    def process_occupant_parking_detail_row(self, row, errors, index):
        occupant_name = row['Occupant Name']
        occupant_unit_name = row['Occupant Unit Name']
        wing_name = row['Wing Name']
        building_name = row['Building Name']
        #business_detail_id=row_data['business_detail_id']
    
        wing_id = self.get_wing_id(wing_name)
        building_id = self.get_building_id(building_name)

        if wing_id is not None and building_id is not None:
            
            vehicle_parking_size_and_type_id = self.get_vehicle_parking_size_and_type_id(
               row['Parking Size And Type'], self.user_data['business_detail']['id']
            )  
           
            if vehicle_parking_size_and_type_id is not None:
                row_data = {
                    'total_parking': row['Occupant Total Parking'],
                    'total_occupied_parking': row['Occupant Total Occupied Parking'],
                    'parking_size_and_type_name': row['Parking Size And Type'],
                    'parking_type_total_parking': row['Parking Type Total Parking'],
                    'parking_type_total_occupied_parking': row['Parking Type Total Occupied Parking'],
                    'occupant_name': occupant_name,
                    'occupant_id':self.get_occupant_id(occupant_name),
                    'occupant_unit_name': occupant_unit_name,
                    'wing_id': wing_id,
                    'building_id': building_id,
                    'vehicle_parking_size_and_type_id': vehicle_parking_size_and_type_id,
                    'business_detail_id': self.user_data['business_detail']['id'],
                }
 
                serializer = OccupantParkingDetailSerializer(data=row_data)
                self.validate_and_save(serializer, errors, index, df=self.df)
           
    def process_vehicle_detail_row(self, row, errors, index):
        occupant_name = row['Occupant Name']
        vehicle_number = row['Vehicle Number']
        wing_name = row['Wing Name']
        building_name = row['Building Name']
        #business_detail_id=row_data['business_detail_id']
        wing_id = self.get_wing_id(wing_name)
        building_id = self.get_building_id(building_name)
        occupant_id = self.get_occupant_id(occupant_name)
        if wing_id is not None and building_id is not None:
            
            vehicle_parking_size_and_type_id = self.get_vehicle_parking_size_and_type_id(
               row['Parking Size And Type'], self.user_data['business_detail']['id']
            )  
           

        if occupant_id is not None:
            row_data = {
                'occupant_id':self.get_occupant_id(occupant_name),
                'vehicle_parking_size_and_type_id': vehicle_parking_size_and_type_id,
                'vehicle_number': vehicle_number,
                'visible_vehicle_number': row['Visible Vehicle Number'],
                'vehicle_owner_name': row['Vehicle Owner Name'],
                'occupied_parking': row['Vehicle Occupied Parking'],
                #'vehicle_parking_size_and_type_id': vehicle_parking_size_and_type_id,
                'business_detail_id': self.user_data['business_detail']['id'],
            }

            serializer = VehicleDetailSerializer(data=row_data)
            self.validate_and_save(serializer, errors, index, df=self.df)
        else:
            errors.append(f"Invalid data in row {index + 2}: Occupant not found.")
     
    

    def upload(self):
        return self.validate_and_save_data()

class OccupantView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'occupant' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['occupant']:
                    AcessToPage = True
            if AcessToPage == True:
                limit = int(request.GET.get('limit',10))
                offset = int(request.GET.get('offset',0))
                occupant = Occupant.objects.filter(business_detail_id = get_user_data['business_detail']['id']).all()[offset:limit+offset]
                occupant_count = Occupant.objects.filter(business_detail_id = get_user_data['business_detail']['id']).all().count()
                serializer = OccupantSerializer(occupant, many=True)
                return Response({'count':occupant_count,'results':serializer.data})   
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
    
    def post(self, request, format=None):
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'occupant' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['occupant']:
                    AcessToPage = True
            if AcessToPage == True:
        #         get_data = request.data
        #         get_data['business_detail_id'] = get_user_data['business_detail']['id']
        #         serializer = OccupantSerializer(data=get_data)
        #         if serializer.is_valid():
        #             serializer.save()
        #             return Response(serializer.data, status=status.HTTP_201_CREATED)
        #         else:
        #             return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        #     else:
        #         return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        # else:
        #     return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
             file = request.data.get('file')
             if not file:
                     return Response({"detail": "No file provided."}, status=status.HTTP_400_BAD_REQUEST)
             df = pd.read_excel(file)
             #df['business_detail_id'] = get_user_data['business_detail']['id']
             #print(df['business_detail_id'])
             bulk_upload = BulkDataUpload(get_user_data, file, df)
             response_data = bulk_upload.upload()

             return Response(response_data)
               
        #      if not file:
        #             return Response({"detail": "No file provided."}, status=status.HTTP_400_BAD_REQUEST)

        #      bulk_upload = BulkOccupantUpload(user_data=get_user_data, file=file)
        #      response_data, status_code = bulk_upload.validate_and_save_data()

        #      return Response(response_data, status=status_code)

        #     else:
        #         return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        # else:
        #     return Response({"detail": "account Validity has expired."}, status=status.HTTP_400_BAD_REQUEST)

class OccupantDetailView(APIView):
    permission_classes = (IsAuthenticated,)
    def get_object(self, id):
        try:
            return Occupant.objects.get(pk=id)
        except Occupant.DoesNotExist:
            return Response(status=status.HTTP_404_NOT_FOUND)
    def get(self, request,id, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'occupant' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['occupant']:
                    AcessToPage = True
            if AcessToPage == True:
                occupant = self.get_object(id)
                serializer = OccupantSerializer(occupant)
                return Response(serializer.data)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
    def put(self, request, id, format=None): 
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'occupant' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['occupant']:
                    AcessToPage = True
            if AcessToPage == True:
                occupant = self.get_object(id)
                get_data = request.data
                get_data['business_detail_id'] = get_user_data['business_detail']['id']
                serializer = OccupantSerializer(occupant, data=get_data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)  
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
     
    def delete(self, request,id, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'occupant' in get_user_data['permission'].keys():
                if 'delete' in get_user_data['permission']['occupant']:
                    AcessToPage = True
            if AcessToPage == True:
                occupant = self.get_object(id)
                serializer = OccupantSerializer(occupant)
                serializer.delete(occupant)
                return Response(status=status.HTTP_204_NO_CONTENT)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)



#Occupant Parking Detail API

class OccupantParkingView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'occupant_parking_detail' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['occupant_parking_detail']:
                    AcessToPage = True
            if AcessToPage == True:
                limit = int(request.GET.get('limit',10))
                offset = int(request.GET.get('offset',0))
                occupant_parking_detail = OccupantParkingDetail.objects.filter(business_detail_id = get_user_data['business_detail']['id']).all()[offset:limit+offset] 
                occupant_parking_detail_count = OccupantParkingDetail.objects.filter(business_detail_id = get_user_data['business_detail']['id']).all().count()
                serializer = OccupantParkingDetailSerializer(occupant_parking_detail, many=True)
                return Response({'count':occupant_parking_detail_count,'results':serializer.data})
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
    
    def post(self, request, format=None):
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'occupant_parking_detail' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['occupant_parking_detail']:
                    AcessToPage = True
            if AcessToPage == True:
                
                file = request.data.get('file')

                if not file:
                    return Response({"detail": "No file provided."}, status=status.HTTP_400_BAD_REQUEST)
                df = pd.read_excel(file)
                bulk_upload = BulkDataUpload(user_data=get_user_data, file=file, df=df)
                response_data, status_code = bulk_upload.post()

                return Response(response_data, status=status_code)

            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity has expired."}, status=status.HTTP_400_BAD_REQUEST)
        #         get_data = request.data
        #         get_data['business_detail_id'] = get_user_data['business_detail']['id']
        #         serializer = OccupantParkingDetailSerializer(data=get_data)
        #         if serializer.is_valid():
        #             serializer.save()
        #             return Response(serializer.data, status=status.HTTP_201_CREATED)
        #         else:
        #             return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        #     else:
        #         return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        # else:
        #     return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
              
       
class OccupantParkingDetailView(APIView):
    permission_classes = (IsAuthenticated,)
    def get_object(self, id):
        try:
            return OccupantParkingDetail.objects.get(pk=id)
        except OccupantParkingDetail.DoesNotExist:
            return Response(status=status.HTTP_404_NOT_FOUND)
    def get(self, request,id, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'occupant_parking_detail' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['occupant_parking_detail']:
                    AcessToPage = True
            if AcessToPage == True:
                occupant_parking_detail = self.get_object(id)
                serializer = OccupantParkingDetailSerializer(occupant_parking_detail)
                return Response(serializer.data)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
    def put(self, request, id, format=None): 
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'occupant_parking_detail' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['occupant_parking_detail']:
                    AcessToPage = True
            if AcessToPage == True:
                occupant_parking_detail = self.get_object(id)
                get_data = request.data
                get_data['business_detail_id'] = get_user_data['business_detail']['id']
                serializer = OccupantParkingDetailSerializer(occupant_parking_detail, data=get_data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)  
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
     
    def delete(self, request,id, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'occupant_parking_detail' in get_user_data['permission'].keys():
                if 'delete' in get_user_data['permission']['occupant_parking_detail']:
                    AcessToPage = True
            if AcessToPage == True:
                occupant_parking_detail = self.get_object(id)
                serializer = OccupantParkingDetailSerializer(occupant_parking_detail)
                serializer.delete(occupant_parking_detail)
                return Response(status=status.HTTP_204_NO_CONTENT)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class GetOccupantParkingBasedOnIdView(APIView):
    permission_classes = (IsAuthenticated,)
    def get(self, request,id, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'occupant_parking_detail' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['occupant_parking_detail']:
                    AcessToPage = True
            if AcessToPage == True:
                limit = int(request.GET.get('limit',10))
                offset = int(request.GET.get('offset',0))
                occupant_parking_detail = OccupantParkingDetail.objects.filter(business_detail_id = get_user_data['business_detail']['id'],occupant_id=id).all()[offset:limit+offset]
                occupant_parking_detail_count = OccupantParkingDetail.objects.filter(business_detail_id = get_user_data['business_detail']['id'],occupant_id=id).all().count()
                serializer = OccupantParkingDetailSerializer(occupant_parking_detail, many=True)
                return Response({'count':occupant_parking_detail_count,'results':serializer.data})
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
    


#Vehicle detail api
class VehicleView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'vehicle_detail' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['vehicle_detail']:
                    AcessToPage = True
            if AcessToPage == True:
                limit = int(request.GET.get('limit',10))
                offset = int(request.GET.get('offset',0))
                vehicle_detail = VehicleDetail.objects.filter(business_detail_id = get_user_data['business_detail']['id']).all()[offset:limit+offset]
                vehicle_detail_count = VehicleDetail.objects.filter(business_detail_id = get_user_data['business_detail']['id']).all().count()
                serializer = VehicleDetailSerializer(vehicle_detail, many=True)
                return Response({'count':vehicle_detail_count,'results':serializer.data})
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
    
    def post(self, request, format=None):
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'vehicle_detail' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['vehicle_detail']:
                    AcessToPage = True
            if AcessToPage == True:
                
                file = request.data.get('file')

                if not file:
                    return Response({"detail": "No file provided."}, status=status.HTTP_400_BAD_REQUEST)
                df = pd.read_excel(file)
                bulk_upload = BulkDataUpload(user_data=get_user_data, file=file, df=df)
                response_data, status_code = bulk_upload.post()

                return Response(response_data, status=status_code)

            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity has expired."}, status=status.HTTP_400_BAD_REQUEST)
        #         get_data = request.data
        #         get_data['business_detail_id'] = get_user_data['business_detail']['id']
        #         serializer = VehicleDetailSerializer(data=get_data)
        #         if serializer.is_valid():
        #             serializer.save()
        #             return Response(serializer.data, status=status.HTTP_201_CREATED)
        #         else:
        #             return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        #     else:
        #         return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        # else:
        #     return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
        
class VehicleDetailView(APIView):
    permission_classes = (IsAuthenticated,)
    def get_object(self, id):
        try:
            return VehicleDetail.objects.get(pk=id)
        except VehicleDetail.DoesNotExist:
            return Response(status=status.HTTP_404_NOT_FOUND)
    def get(self, request,id, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'vehicle_detail' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['vehicle_detail']:
                    AcessToPage = True
            if AcessToPage == True:
                vehicle_detail = self.get_object(id)
                serializer = VehicleDetailSerializer(vehicle_detail)
                return Response(serializer.data)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
    def put(self, request, id, format=None): 
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'vehicle_detail' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['vehicle_detail']:
                    AcessToPage = True
            if AcessToPage == True:
                vehicle_detail = self.get_object(id)
                get_data = request.data
                get_data['business_detail_id'] = get_user_data['business_detail']['id']
                serializer = VehicleDetailSerializer(vehicle_detail, data=get_data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)  
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
     
    def delete(self, request,id, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'vehicle_detail' in get_user_data['permission'].keys():
                if 'delete' in get_user_data['permission']['vehicle_detail']:
                    AcessToPage = True
            if AcessToPage == True:
                vehicle_detail = self.get_object(id)
                serializer = VehicleDetailSerializer(vehicle_detail)
                serializer.delete(vehicle_detail)
                return Response(status=status.HTTP_204_NO_CONTENT)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class GetVehicleDetailBasedOnIdView(APIView):
    permission_classes = (IsAuthenticated,)
    def get(self, request,id, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'vehicle_detail' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['vehicle_detail']:
                    AcessToPage = True
            if AcessToPage == True:
                limit = int(request.GET.get('limit',10))
                offset = int(request.GET.get('offset',0))
                vehicle_detail = VehicleDetail.objects.filter(business_detail_id = get_user_data['business_detail']['id'],occupant_id=id).all()[offset:limit+offset]
                vehicle_detail_count = VehicleDetail.objects.filter(business_detail_id = get_user_data['business_detail']['id'],occupant_id=id).all().count()
                serializer = VehicleDetailSerializer(vehicle_detail, many=True)
                return Response({'count':vehicle_detail_count,'results':serializer.data})
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


#Dropdown
class GetVehicleTypesView(APIView):
    permission_classes = (IsAuthenticated,)
    def get(self,request):
        user_id = getUserData(request.user.id)
        vehicle_types = VehicleType.objects.filter(business_detail_id=user_id['business_detail']['id']).values('id','vehicle_type')
        serializer = VehicleTypeDropdownSerializer(vehicle_types, many=True)
        return Response(serializer.data,status=status.HTTP_200_OK)

#Dropdown
class GetParkingSizeAndTypeDropdownView(APIView):
    permission_classes = (IsAuthenticated,)
    def get(self,request):
        user_id = getUserData(request.user.id)
        parking_size_and_type = VehicleParkingSizeAndType.objects.filter(business_detail_id=user_id['business_detail']['id']).values('id','parking_size_and_type_name')
        serializer = VehicleParkingSizeAndTypeDropdownSerializer(parking_size_and_type, many=True)
        return Response(serializer.data,status=status.HTTP_200_OK)

class GetBuildingDropdownView(APIView):
    permission_classes = (IsAuthenticated,)
    def get(self,request):
        user_id = getUserData(request.user.id)
        building_name_dropdown = Building.objects.filter(business_detail_id=user_id['business_detail']['id']).values('id','building_name')
        serializer = BuildingDropdownSerializer(building_name_dropdown, many=True)
        return Response(serializer.data,status=status.HTTP_200_OK)

class GetBuildingWingDropdownView(APIView):
    permission_classes = (IsAuthenticated,)
    def get(self,request,id):
        user_id = getUserData(request.user.id)
        wing_name_dropdown = Wing.objects.filter(business_detail_id=user_id['business_detail']['id'],building_id=id).values('id','wing_name')
        serializer = WingDropdownSerializer(wing_name_dropdown,many=True)
        return Response(serializer.data,status=status.HTTP_200_OK)

# class BulkUploadData(APIView):
#     permission_classes = (IsAuthenticated,)
#     def post(self, request, format=None):
#         get_user_data = getUserData(request.user.id)
        
#         if get_user_data['business_detail']['plan_validity'] == True:
#             AcessToPage = False
#             if 'occupant' in get_user_data['permission'].keys():
#                 if 'create' in get_user_data['permission']['occupant']:
#                     AcessToPage = True
#             if AcessToPage == True:



#                 business_detail_id=get_user_data['business_detail']['id']
#                 file = request.data.get('file')
#                 if not file:
#                     return Response({"detail": "No file provided."}, status=status.HTTP_400_BAD_REQUEST)

#                 df = pd.read_excel(file)

#                 occupants_data = []
#                 occupant_parking_details_data = []
#                 vehicle_details_data = []
#                 errors = []
#                 unique_values_set = set()

#                 required_columns = ['Wing Name', 'Building Name', 'Occupant Name', 'Occupant Unit Name',
#                                      'Occupant Total Parking', 'Occupant Total Occupied Parking',
#                                      'Parking Size And Type', 'Vehicle Number', 'Visible Vehicle Number',
#                                      'Vehicle Owner Name', 'Vehicle Occupied Parking']

#                 with transaction.atomic(): 
#                     for index, row in df.iterrows():
#                         # Check for missing columns
#                         missing_columns = set(required_columns) - set(df.columns)
#                         if missing_columns:
#                             errors.append({
#                                 'row': 1,
#                                 'column': 0,
#                                 'detail': f"Missing columns: {', '.join(missing_columns)}"
#                             })

#                             continue
                        
#                         current_row_values = tuple(row[['Wing Name', 'Building Name', 'Vehicle Number']])

#                         if current_row_values in unique_values_set:
#                             duplicate_column = self.get_duplicate_column(df, row, current_row_values)
#                             errors.append({
#                                 'row': index + 2,
#                                 'column': duplicate_column,
#                                 'detail': "Duplicate data in this row."
#                             })
#                             continue
                        
#                         unique_values_set.add(current_row_values)
#                         wing_name = row['Wing Name']
#                         building_name = row['Building Name']

#                         try:
#                             wing = Wing.objects.get(wing_name=wing_name)
#                         except Wing.DoesNotExist:
#                             errors.append({
#                                 'row': index + 2,
#                                 'column': self.get_column_number(df, 'Wing Name'),
#                                 'detail': f"Wing does not exist with name: {wing_name}."
#                             })
#                             continue
                        
#                         try:
#                             building = Building.objects.get(building_name=building_name)
#                         except Building.DoesNotExist:
#                             errors.append({
#                                 'row': index + 2,
#                                 'column': self.get_column_number(df, 'Building Name'),
#                                 'detail': f"Building does not exist with name: {building_name}."
#                             })
#                             continue

#                         parking_size_and_type_name = row['Parking Size And Type']

#                         try:
#                             parking_size_and_type_obj = VehicleParkingSizeAndType.objects.get(
#                                 parking_size_and_type_name=parking_size_and_type_name, business_detail_id=business_detail_id)
#                         except VehicleParkingSizeAndType.DoesNotExist:
#                             errors.append({
#                                 'row': index + 2,
#                                 'column': self.get_column_number(df, 'Parking Size And Type'),
#                                 'detail': f"Parking Size And Type does not exist with name: {parking_size_and_type_name}."
#                             })
#                             continue
#                     #building = Building.objects.get(building_name=row['Building Name'])
#                     #parking_size_and_type_obj = VehicleParkingSizeAndType.objects.get(
#                     #parking_size_and_type_name=row['Parking Size And Type'], business_detail_id=business_detail_id)
                    
#                     occupant_data = {
#                         'occupant_name': row['Occupant Name'],
#                         'occupant_unit_name': row['Occupant Unit Name'],
#                         'total_parking': row['Occupant Total Parking'],
#                         'total_occupied_parking': row['Occupant Total Occupied Parking'],
#                         'wing_id':wing.id,
#                         'building_id': building.id,
#                         'business_detail_id': business_detail_id,
#                     }
#                     occupants_data.append(occupant_data)
#                     # Serialize and save Occupants
#                     occupant_serializer = OccupantSerializer(data=occupants_data,many=True)
#                     # occupant_id = None                 

#                     # if occupant_serializer.is_valid():
#                     #     occupant_obj = occupant_serializer.save()
#                     #     print('occupant',occupant_obj)
#                     #     occupant_id = occupant_obj.id
#                     occupant_ids = []

#                     if occupant_serializer.is_valid():
#                         occupant_objects = occupant_serializer.save()
                        
#                         # Extract IDs from the list of instances
#                         occupant_ids = [occupant_obj.id for occupant_obj in occupant_objects]
#                         #print('occupant_ids',occupant_ids)
#                     else:
#                         # print("else")
#                         # return Response(occupant_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
#                           errors.append({"row": index, 
#                                          "column": self.get_column_number(df, 'Occupant'),
#                                          "detail": occupant_serializer.errors
#                           })
#                     occupant_parking_detail_data = {
#                         'total_parking': row['Occupant Total Parking'],
#                         'total_occupied_parking': row['Occupant Total Occupied Parking'],
#                         'vehicle_parking_size_and_type_id': parking_size_and_type_obj.id,
#                         'occupant_id':  int(occupant_ids[0]),
#                         'business_detail_id': business_detail_id,
#                     }
#                     occupant_parking_details_data.append(occupant_parking_detail_data)
#                      # Serialize and save Occupant Parking Details
#                     occupant_parking_detail_serializer = OccupantParkingDetailSerializer(data=occupant_parking_details_data, many=True)
#                     if occupant_parking_detail_serializer.is_valid():
#                         occupant_parking_detail_serializer.save()
#                     else:
#                         # Rollback Occupants if Occupant Parking Details are not valid
#                         # Occupant.objects.filter(business_detail_id__in=df['business_detail_id']).delete()
#                         # return Response(occupant_parking_detail_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
#                           errors.append({"row": index + 2, 
#                                          "column": self.get_column_number(df, 'Occupant Parking Detail'),
#                                          "detail": occupant_parking_detail_serializer.errors
#                           })
#                     vehicle_detail_data = {
#                         'vehicle_number': row['Vehicle Number'],
#                         'visible_vehicle_number': row['Visible Vehicle Number'],
#                         'vehicle_owner_name': row['Vehicle Owner Name'],
#                         'occupied_parking': row['Vehicle Occupied Parking'],
#                         'occupant_id':  int(occupant_ids[0]),
#                         'vehicle_parking_size_and_type_id': parking_size_and_type_obj.id,
#                         'business_detail_id': business_detail_id,
#                     }
#                     vehicle_details_data.append(vehicle_detail_data)

                

#                 # Serialize and save Vehicle Details
#                     vehicle_detail_serializer = VehicleDetailSerializer(data=vehicle_details_data, many=True)
#                     if vehicle_detail_serializer.is_valid():
#                        vehicle_detail_serializer.save()
#                        return Response({'Success': 'Bulk Upload Completed Successfully.'}, status=status.HTTP_201_CREATED)
#                     else:
#                         errors.append({"row": index + 2, 
#                                 "column": self.get_column_number(df, 'Vehicle Detail'),
#                                 "detail": vehicle_detail_serializer.errors
#                                 })
#                     # Rollback Occupants and Occupant Parking Details if Vehicle Details are not valid
#                     # Occupant.objects.filter(business_detail_id__in=df['business_detail_id']).delete()
#                     # OccupantParkingDetail.objects.filter(business_detail_id__in=df['business_detail_id']).delete()
#                     # return Response(vehicle_detail_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
#             else:
#                     return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
#         else:
#             return Response({"detail": "account Validity has expired."}, status=status.HTTP_400_BAD_REQUEST)
    
#     def get_column_number(self, df, column_name):
#         return df.columns.get_loc(column_name) + 1