from django.core.management.base import BaseCommand
from detected.models import Detected, PartiallyDetected,DetectedFrameImage, PartiallyDetectedFrameImage
from account.models import BusinessDetail
from datetime import timedelta
from django.utils import timezone
from detected.tasks import delete_old_data_task

class Command(BaseCommand):
    help = 'Deletes old data based on backup days'

    def handle(self, *args, **options):
    
        self.stdout.write(self.style.SUCCESS('Task triggered successfully.'))
        businesses = BusinessDetail.objects.all()

        for business in businesses:
 
            delete_old_data_task.apply_async(args=[str(business.id)],countdown=10)
            self.stdout.write(self.style.SUCCESS(f'Task enqueued for business "{business.business_name}".'))

        #self.stdout.write(self.style.SUCCESS('Tasks enqueued successfully.'))

            delete_previous_data_after_day = business.delete_previous_data_after_day

            threshold_date = timezone.now() - timedelta(days=delete_previous_data_after_day)
 
            DetectedFrameImage.objects.filter(detected__datetime__lt=threshold_date, detected__business_detail=business).delete()

            Detected.objects.filter(datetime__lt=threshold_date, business_detail=business).delete()

            PartiallyDetectedFrameImage.objects.filter(partially_detected__datetime__lt=threshold_date, partially_detected__business_detail=business).delete()

            PartiallyDetected.objects.filter(datetime__lt=threshold_date, business_detail=business).delete()

            self.stdout.write(self.style.SUCCESS(f'Old data for business "{business.business_name}" deleted successfully.'))
        
        self.stdout.write(self.style.SUCCESS('Tasks enqueued and old data deleted successfully.'))
