from celery import shared_task
from django.core.management import call_command
from account.models import BusinessDetail

@shared_task
def delete_old_data_task(business_id):
    try:
        business = BusinessDetail.objects.get(id=business_id)
        
        
       
        call_command('delete_old_data',str(business_id))
        
        return f'Delete old data task completed for business "{business.business_name}".'
    except BusinessDetail.DoesNotExist:
        return f'Business with id {business_id} does not exist.'
    except Exception as e:
        return f'An error occurred while processing the task: {e}'
# @shared_task
# def delete_old_data_task(business_id):
    
#     call_command('delete_old_data')