from django.shortcuts import render
from rest_framework.permissions import AllowAny,IsAuthenticated
from rest_framework.views import APIView
from django.http.response import JsonResponse,Http404
from rest_framework.response import Response
from account.views import getUserData
from rest_framework import status
from .models import Detected,DetectedFrameImage,PartiallyDetected,PartiallyDetectedFrameImage,TotalParkingCount,VehicleParkingCount,VehicleParkingCountDays
from .serializers import DetectedSerializer,DetectedDetailSerializer,PartiallyDetectedSerializer,PartiallyDetectedDetailSerializer, DetectedGetTableSerializer, PartiallyDetectedGetTableSerializer
from rest_framework.pagination import LimitOffsetPagination
from django.db.models import Q
from datetime import datetime,timedelta
from django.utils import timezone
from account.models import WindowsDeactiveLog,WindowsSitesActiveLog,Sites,BusinessDetail
import pytz
import boto3
from PIL import Image
from io import BytesIO
import base64
import os
from django.core.files.storage import default_storage
# Create your views here.
# class StandardResultsSetPagination(LimitOffsetPagination):
#     default_limit = 'limit'
#print(Detected.objects.filter(detected_violationfine__isnull=False,detected_violationfine__fine_collected=False).distinct().values('id','licence_plate_number'))

class ParkingCountView(APIView):
    permission_classes = (IsAuthenticated,)
    def get(self, request):
        get_user_data = getUserData(request.user.id)
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'dashboard' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['dashboard']:
                    AcessToPage = True
            if AcessToPage == True:
                GetParkingCount = TotalParkingCount.objects.filter(business_detail_id=get_user_data['business_detail']['id']).values('id','total_parking_count','total_parking_in_count','total_parking_available','total_parking_extra').last()
                Get2WheelerVehicleCount = VehicleParkingCount.objects.filter(business_detail_id=get_user_data['business_detail']['id'],vehicle_type='2 wheeler').values('id','total_parking_count','total_parking_in_count','total_parking_available','total_parking_extra').last()
                Get4WheelerVehicleCount = VehicleParkingCount.objects.filter(business_detail_id=get_user_data['business_detail']['id'],vehicle_type='4 wheeler').values('id','total_parking_count','total_parking_in_count','total_parking_available','total_parking_extra').last()
                Get4WheelerVehicleCountToday = VehicleParkingCountDays.objects.filter(business_detail_id=get_user_data['business_detail']['id'],vehicle_type='4 wheeler',datetime__gte=timezone.now().replace(hour=0, minute=0, second=0),datetime__lte=timezone.now().replace(hour=23, minute=59, second=59)).values('id','total_parking_in_count','total_parking_out_count','datetime').last()
                current_datetime = timezone.now()-timedelta(minutes=15)
                UpdateSiteLog = WindowsSitesActiveLog.objects.filter(business_detail=get_user_data['business_detail']['id'],last_active_datetime__lte=current_datetime).update(active=False)
                GetCountTotalSites = WindowsSitesActiveLog.objects.filter(business_detail=get_user_data['business_detail']['id']).distinct('sites').values('id','sites','sites__site_name','business_detail','last_active_datetime','application_open','active')
                GetCountActiveSites = WindowsSitesActiveLog.objects.filter(business_detail=get_user_data['business_detail']['id'],active=True).distinct('sites').count()
                GetCountClosedApplicationCount = WindowsSitesActiveLog.objects.filter(business_detail=get_user_data['business_detail']['id'],application_open=False).distinct('sites').count()
                GetCountDeactiveSites = len(GetCountTotalSites)-GetCountActiveSites
                print(GetCountTotalSites,GetCountActiveSites,len(GetCountTotalSites),current_datetime)
                if GetParkingCount is None:
                    crete_parking = TotalParkingCount.objects.create(total_parking_count=0,total_parking_in_count=1,business_detail_id=get_user_data['business_detail']['id'])
                    crete_parking.save()
                    GetParkingCount = TotalParkingCount.objects.filter(business_detail_id=get_user_data['business_detail']['id']).values('id','total_parking_count','total_parking_in_count','total_parking_available','total_parking_extra').last()

                if Get2WheelerVehicleCount is None:
                    crete_parking = VehicleParkingCount.objects.create(vehicle_type='2 wheeler',total_parking_count=0,total_parking_in_count=1,business_detail_id=get_user_data['business_detail']['id'])
                    crete_parking.save()
                    Get2WheelerVehicleCount = VehicleParkingCount.objects.filter(business_detail_id=get_user_data['business_detail']['id'],vehicle_type='2 wheeler').values('id','total_parking_count','total_parking_in_count','total_parking_available','total_parking_extra').last()
                
                if Get4WheelerVehicleCount is None:
                    crete_parking = VehicleParkingCount.objects.create(vehicle_type='4 wheeler',total_parking_count=0,total_parking_in_count=1,business_detail_id=get_user_data['business_detail']['id'])
                    crete_parking.save()
                    Get4WheelerVehicleCount = VehicleParkingCount.objects.filter(business_detail_id=get_user_data['business_detail']['id'],vehicle_type='4 wheeler').values('id','total_parking_count','total_parking_in_count','total_parking_available','total_parking_extra').last()
                
                if Get4WheelerVehicleCountToday is None:
                    in_parking_count = 0
                    if Get4WheelerVehicleCount is not None:
                        in_parking_count = Get4WheelerVehicleCount.get('total_parking_in_count')
                    create_parking = VehicleParkingCountDays.objects.create(vehicle_type='4 wheeler',total_parking_in_count=in_parking_count,total_parking_out_count=0,datetime=timezone.now(),business_detail_id=get_user_data['business_detail']['id'])
                    create_parking.save()
                    Get4WheelerVehicleCountToday = VehicleParkingCountDays.objects.filter(business_detail_id=get_user_data['business_detail']['id'],vehicle_type='4 wheeler',datetime__gte=timezone.now().replace(hour=0, minute=0, second=0),datetime__lte=timezone.now().replace(hour=23, minute=59, second=59)).values('id','total_parking_in_count','total_parking_out_count').last()
                return Response({'total_parking':GetParkingCount,'two_wheeler_parking':Get2WheelerVehicleCount,'four_wheeler_parking':Get4WheelerVehicleCount,'in_out_parking_today':Get4WheelerVehicleCountToday,'sites':{'active':GetCountActiveSites,'deactive':GetCountDeactiveSites,'total':len(GetCountTotalSites),'close_application':GetCountClosedApplicationCount,'data':GetCountTotalSites}})
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class ParkingCountWindowsView(APIView):
    permission_classes = (IsAuthenticated,)
    def get(self, request):
        get_user_data = getUserData(request.user.id)
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'dashboard' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['dashboard']:
                    AcessToPage = True
            if AcessToPage == True:
                GetParkingCount = TotalParkingCount.objects.filter(business_detail_id=get_user_data['business_detail']['id']).values('id','total_parking_count','total_parking_in_count','total_parking_available','total_parking_extra').last()
                Get2WheelerVehicleCount = VehicleParkingCount.objects.filter(business_detail_id=get_user_data['business_detail']['id'],vehicle_type='2 wheeler').values('id','total_parking_count','total_parking_in_count','total_parking_available','total_parking_extra').last()
                Get4WheelerVehicleCount = VehicleParkingCount.objects.filter(business_detail_id=get_user_data['business_detail']['id'],vehicle_type='4 wheeler').values('id','total_parking_count','total_parking_in_count','total_parking_available','total_parking_extra').last()
                Get4WheelerVehicleCountToday = VehicleParkingCountDays.objects.filter(business_detail_id=get_user_data['business_detail']['id'],vehicle_type='4 wheeler',datetime__gte=timezone.now().replace(hour=0, minute=0, second=0),datetime__lte=timezone.now().replace(hour=23, minute=59, second=59)).values('id','total_parking_in_count','total_parking_out_count','datetime').last()
                if GetParkingCount is None:
                    crete_parking = TotalParkingCount.objects.create(total_parking_count=0,total_parking_in_count=1,business_detail_id=get_user_data['business_detail']['id'])
                    crete_parking.save()
                    GetParkingCount = TotalParkingCount.objects.filter(business_detail_id=get_user_data['business_detail']['id']).values('id','total_parking_count','total_parking_in_count','total_parking_available','total_parking_extra').last()

                if Get2WheelerVehicleCount is None:
                    crete_parking = VehicleParkingCount.objects.create(vehicle_type='2 wheeler',total_parking_count=0,total_parking_in_count=1,business_detail_id=get_user_data['business_detail']['id'])
                    crete_parking.save()
                    Get2WheelerVehicleCount = VehicleParkingCount.objects.filter(business_detail_id=get_user_data['business_detail']['id'],vehicle_type='2 wheeler').values('id','total_parking_count','total_parking_in_count','total_parking_available','total_parking_extra').last()
                
                if Get4WheelerVehicleCount is None:
                    crete_parking = VehicleParkingCount.objects.create(vehicle_type='4 wheeler',total_parking_count=0,total_parking_in_count=1,business_detail_id=get_user_data['business_detail']['id'])
                    crete_parking.save()
                    Get4WheelerVehicleCount = VehicleParkingCount.objects.filter(business_detail_id=get_user_data['business_detail']['id'],vehicle_type='4 wheeler').values('id','total_parking_count','total_parking_in_count','total_parking_available','total_parking_extra').last()
                if Get4WheelerVehicleCountToday is None:
                    in_parking_count = 0
                    if Get4WheelerVehicleCount is not None:
                        in_parking_count = Get4WheelerVehicleCount.get('total_parking_in_count')
                    create_parking = VehicleParkingCountDays.objects.create(vehicle_type='4 wheeler',total_parking_in_count=in_parking_count,total_parking_out_count=0,datetime=timezone.now(),business_detail_id=get_user_data['business_detail']['id'])
                    create_parking.save()
                    Get4WheelerVehicleCountToday = VehicleParkingCountDays.objects.filter(business_detail_id=get_user_data['business_detail']['id'],vehicle_type='4 wheeler',datetime__gte=timezone.now().replace(hour=0, minute=0, second=0),datetime__lte=timezone.now().replace(hour=23, minute=59, second=59)).values('id','total_parking_in_count','total_parking_out_count','datetime').last()
                getSites = Sites.objects.filter(user=request.user.id).values('id','site_name','user','anpr_check_allowed','blacklist_check_allowed','business_detail','plan_start_datetime','plan_expire_datetime','days_to_expire','minutes_to_expire','plan_validity','timezones','active','user_login_or_not','skip_frame','delete_previous_data_after_day').first()
                application_active = request.GET.get('application_active',None)
                if application_active ==None:
                    application_active = False
                if application_active != None:
                    if application_active == 'true':
                        application_active = True
                    else:
                        application_active=False

                get_active_log = WindowsSitesActiveLog.objects.filter(sites_id=getSites['id']).values('id','sites','last_active_datetime').last()
                TimeZoneLoc = pytz.timezone(getSites['timezones'])
                if get_active_log == None:
                    insert_active_log =  WindowsSitesActiveLog.objects.create(sites_id=getSites['id'],business_detail_id=getSites['business_detail'],last_active_datetime=timezone.now(),application_open=application_active,active=True)
                    insert_active_log.save()
                else:
                    last_active_datetime = get_active_log['last_active_datetime']
                    diff = datetime.strptime(str(last_active_datetime), '%Y-%m-%d %H:%M:%S.%f+00:00') - datetime.strptime(str(datetime.now()), '%Y-%m-%d %H:%M:%S.%f')
                    if int(diff.total_seconds() / 60.0) >= 15:
                        insert_deactive_log =  WindowsDeactiveLog.objects.create(sites_id=getSites['id'],business_detail_id=getSites['business_detail'],start_datetime=last_active_datetime,end_datetime=timezone.now())
                        insert_deactive_log.save()
                    update_active_log = WindowsSitesActiveLog.objects.filter(sites_id=getSites['id']).update(last_active_datetime=timezone.now(),application_open=application_active,active=True)
                print(Get4WheelerVehicleCountToday)
                return Response({'total_parking':GetParkingCount,'two_wheeler_parking':Get2WheelerVehicleCount,'four_wheeler_parking':Get4WheelerVehicleCount,'in_out_parking_today':Get4WheelerVehicleCountToday})
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)



class DetectedTempView(APIView):
    def convert_base64_to_image(self, base64_data):
        # Decode the base64 data
        image_data = base64.b64decode(base64_data)

        # Create a PIL Image object from the image data
        image = Image.open(BytesIO(image_data))
        return image

    def upload_image_to_s3(self, image,file_path):
        image_io = BytesIO()
        image.save(image_io, format='JPEG')

        # Set the S3 object key
        file_name = file_path
        storage = default_storage
        image_file = storage.save(f'{file_name}', image_io)
        # s3 = boto3.resource('s3')
        # bucket = s3.Bucket(default_storage.bucket_name)
        # object = bucket.Object(image_file)
        # object.upload_file(image_file, ExtraArgs={'ContentType': 'image/webp'})
        return image_file
    def post(self,request, format=None):
        get_data = request.data
        licence_plate_image_data = get_data['licence_plate_image']
        get_business_name = BusinessDetail.objects.filter(id=get_data['business_detail']).values('business_name').first()
        get_site_name = Sites.objects.filter(id=get_data['sites']).values('site_name').first()
        datetime_format = datetime.strptime(get_data['datetime'],'%Y-%m-%d %H:%M:%S.%f%z')
        get_date_string = str(datetime_format.date())
        if licence_plate_image_data != None:
            image = self.convert_base64_to_image(licence_plate_image_data['image_base64'])
            folder_path = 'eazzy_park/'+get_business_name['business_name']+'/'+get_site_name['site_name']+'/'+get_data['camera_name'] +'/licence_plate_image/'+get_date_string+'/detected'

            # folder_path = 'parking_management/licence_plate_image/'+get_data['camera_name']  # Modify this as per your requirements
            object_key = os.path.join(folder_path, licence_plate_image_data['image_name'])
            get_data['licence_plate_image'] = self.upload_image_to_s3(image,object_key)
            
        for index,data in enumerate(get_data['detected_frame']):
            frame_image_data = data['frame_image']
            if frame_image_data != None:
                image = self.convert_base64_to_image(frame_image_data['image_base64'])
                folder_path = 'eazzy_park/'+get_business_name['business_name']+'/'+get_site_name['site_name']+'/'+get_data['camera_name'] +'/frame_image/'+get_date_string+'/detected'

                # folder_path = 'parking_management/frame_image/'+get_data['camera_name']  # Modify this as per your requirements
                object_key = os.path.join(folder_path, frame_image_data['image_name'])
                get_data['detected_frame'][index]['frame_image'] = self.upload_image_to_s3(image,object_key)

        detected_serializer = DetectedSerializer(data=get_data)
        if detected_serializer.is_valid(raise_exception=True):
            detected_serializer.save()
            return Response(detected_serializer.data, status=status.HTTP_201_CREATED)
        return Response(detected_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class PartiallyDetectedTempView(APIView):
    def post(self,request, format=None):
        partially_detected_serializer = PartiallyDetectedSerializer(data=request.data)
        if partially_detected_serializer.is_valid(raise_exception=True):
            partially_detected_serializer.save()
            return Response(partially_detected_serializer.data, status=status.HTTP_201_CREATED)
        return Response(partially_detected_serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class DetectedView(APIView):
    permission_classes = (IsAuthenticated,)
    def get(self, request):
        get_user_data = getUserData(request.user.id)
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'detected' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['detected']:
                    AcessToPage = True
            if AcessToPage == True:
                licence_plate_number = request.GET.get('licence_plate_number', None)
                limit = int(request.GET.get('limit',10))
                offset = int(request.GET.get('offset',0))
                in_out = request.GET.get('in_out', None)
                ordering = request.GET.get('order_by',None)
                from_datetime = request.GET.get('start_datetime',None)
                to_datetime = request.GET.get('end_datetime',None)
                vehicle_type = request.GET.get('vehicle_type',None)
                camera_name = request.GET.get('camera_name',None)
                if ordering ==None:
                    ordering = '-datetime'
                f= Q(business_detail = get_user_data['business_detail']['id'])
                if licence_plate_number != '' and licence_plate_number != None:
                    f &= Q(licence_plate_number__contains=licence_plate_number)
                if in_out != 'All' and in_out != None:
                    f &= Q(in_out=in_out)
                if vehicle_type != 'All' and vehicle_type != None:
                    f &= Q(vehicle_type=vehicle_type)
                if from_datetime != None:
                        f &= Q(datetime__gte=from_datetime)
                if to_datetime != None:
                    f &= Q(datetime__lte=to_datetime)
                if camera_name != '' and camera_name != None:
                    f &= Q(camera_name=camera_name)
                detected_detail = Detected.objects.filter(f).order_by(ordering).values('id','licence_plate_number','datetime','blacklisted_licence_plate','vehicle_type','country','make','model','camera_name','in_out')[offset:limit+offset]
                detected_count = Detected.objects.filter(f).order_by(ordering).count()
                serializer = DetectedGetTableSerializer(detected_detail, many=True)
                return Response({'count':detected_count,'results':serializer.data})
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class DetectedDistinctView(APIView):
    permission_classes = (IsAuthenticated,)
    def get(self, request):
        get_user_data = getUserData(request.user.id)
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'detected' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['detected']:
                    AcessToPage = True
            if AcessToPage == True:
                licence_plate_number = request.GET.get('licence_plate_number', None)
                limit = int(request.GET.get('limit',10))
                offset = int(request.GET.get('offset',0))
                in_out = request.GET.get('in_out', None)
                ordering = request.GET.get('order_by',None)
                if ordering ==None:
                    ordering = '-datetime'
                f= Q(business_detail = get_user_data['business_detail']['id'])
                if licence_plate_number != '' and licence_plate_number != None:
                    f &= Q(licence_plate_number__contains=licence_plate_number)
                if in_out != 'All' and in_out != None:
                    f &= Q(in_out=in_out)
                detected_detail = Detected.objects.filter(f).order_by(ordering,'licence_plate_number').distinct('licence_plate_number','datetime').only('id','licence_plate_number','datetime','blacklisted_licence_plate','vehicle_type','country','make','model','camera_name','in_out','vehicle_detail')[offset:limit+offset]
                detected_count = Detected.objects.filter(f).order_by(ordering,'licence_plate_number').distinct('licence_plate_number','datetime').count()
                serializer = DetectedGetTableSerializer(detected_detail, many=True)
                return Response({'count':detected_count,'results':serializer.data})
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

class DetectedLicencePlateNumberDetailView(APIView):
    permission_classes = (IsAuthenticated,)
    def get(self, request,licence_plate_number):
        get_user_data = getUserData(request.user.id)
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'detected' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['detected']:
                    AcessToPage = True
            if AcessToPage == True:
                limit = int(request.GET.get('limit',10))
                offset = int(request.GET.get('offset',0))
                licence_plate_number = request.GET.get('licence_plate_number', None)
                in_out = request.GET.get('in_out', None)
                ordering = request.GET.get('order_by',None)
                if ordering ==None:
                    ordering = '-datetime'
                f= Q(business_detail = get_user_data['business_detail']['id'])
                print(licence_plate_number,in_out)
                if licence_plate_number != '' and licence_plate_number != None:
                    f &= Q(licence_plate_number__contains=licence_plate_number)
                if in_out != 'All' and in_out != None:
                    f &= Q(in_out=in_out)
                detected_detail = Detected.objects.filter(f).order_by(ordering).only('id','licence_plate_number','datetime',
                    'blacklisted_licence_plate','vehicle_type','country','make','model','camera_name','in_out')[offset:limit+offset]
                detected_count = Detected.objects.filter(f).order_by(ordering).count()
                serializer = DetectedGetTableSerializer(detected_detail, many=True)
                return Response({'count':detected_count,'results':serializer.data})
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    
class DetectedDetailView(APIView):
    permission_classes = (IsAuthenticated,)
    def get_object(self, id):
        try:
            return Detected.objects.get(pk=id)
        except Detected.DoesNotExist:
            raise Http404
    def get(self, request,id, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'detected' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['detected']:
                    AcessToPage = True
            if AcessToPage == True:
                detected = self.get_object(id)
                serializer = DetectedDetailSerializer(detected)
                return Response(serializer.data)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
          

    
class PartiallyDetectedView(APIView):
    permission_classes = (IsAuthenticated,)
    def get(self, request):
        get_user_data = getUserData(request.user.id)
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'partially detected' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['partially detected']:
                    AcessToPage = True
            if AcessToPage == True:
                limit = int(request.GET.get('limit',10))
                offset = int(request.GET.get('offset',0))
                licence_plate_number = request.GET.get('licence_plate_number', None)
                in_out = request.GET.get('in_out', None)
                ordering = request.GET.get('order_by',None)
                if ordering ==None:
                    ordering = '-datetime'
                f= Q(business_detail = get_user_data['business_detail']['id'])
                if licence_plate_number != '' and licence_plate_number != None:
                    f &= Q(licence_plate_number__contains=licence_plate_number)
                if in_out != 'All' and in_out != None:
                    f &= Q(in_out=in_out)
                partially_detected_detail = PartiallyDetected.objects.filter(f).order_by(ordering).only('id','licence_plate_number','datetime','vehicle_type','country','make','model','camera_name','in_out','business_detail','vehicle_detail')[offset:limit+offset]
                partially_detected_detail_count = PartiallyDetected.objects.filter(f).order_by(ordering).count()
                serializer = PartiallyDetectedGetTableSerializer(partially_detected_detail, many=True)
                return Response({'count':partially_detected_detail_count,'results':serializer.data})
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class PartiallyDetectedDetailView(APIView):
    permission_classes = (IsAuthenticated,)
    def get_object(self, id):
        try:
            return PartiallyDetected.objects.get(pk=id)
        except PartiallyDetected.DoesNotExist:
            raise Http404
    def get(self, request,id, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = getUserData(request.user.id)
        
        if get_user_data['business_detail']['plan_validity'] == True:
            AcessToPage = False
            if 'partially detected' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['partially detected']:
                    AcessToPage = True
            if AcessToPage == True:
                partially_detected = self.get_object(id)
                serializer = PartiallyDetectedDetailSerializer(partially_detected)
                return Response(serializer.data)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
          

    
    
