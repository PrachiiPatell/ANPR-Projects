from django.contrib import admin
from .models import *
# Register your models here.


class DetectedAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','licence_plate_number','licence_plate_image','confidence_licence_plate','datetime','blacklisted_licence_plate','vehicle_type','country','make','model','camera_name','in_out','user','business_detail','vehicle_detail')
class DetectedFrameImageAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','frame_image','detected')


class PartiallyDetectedAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','licence_plate_number','licence_plate_image','confidence_licence_plate','datetime','vehicle_type','country','make','model','camera_name','in_out','user','business_detail','vehicle_detail')


class PartiallyDetectedFrameImageAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','frame_image','partially_detected')


admin.site.register(Detected, DetectedAdmin)
admin.site.register(DetectedFrameImage,DetectedFrameImageAdmin)
admin.site.register(PartiallyDetected,PartiallyDetectedAdmin)
admin.site.register(PartiallyDetectedFrameImage,PartiallyDetectedFrameImageAdmin)
admin.site.register(TotalParkingCount)
admin.site.register(VehicleParkingCount)
admin.site.register(VehicleParkingCountDays)

