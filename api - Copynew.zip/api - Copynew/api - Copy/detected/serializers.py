from rest_framework.serializers import ModelSerializer
from account.models import User,BusinessDetail,Roles,Permission,UserRoleMapping,AddUserEmail,UserType,MenuPage,BusinessParkingDetail ##UserRolePermission
from rest_framework.validators import UniqueValidator
from django.contrib.auth.password_validation import validate_password
from .models import Detected,DetectedFrameImage,PartiallyDetected,PartiallyDetectedFrameImage,TotalParkingCount,VehicleParkingCount,VehicleParkingCountDays
from rest_framework import serializers
from django.utils import timezone
from myapp.models import VehicleDetail,Occupant,OccupantParkingDetail,Wing,WingParkingDetail,Building,BuildingParkingDetail
import boto3
from PIL import Image
from io import BytesIO
import base64
import os
from django.core.files.base import ContentFile
from django.core.files.storage import default_storage

class DetectedFrameImageSerializer(ModelSerializer):
    frame_image = serializers.CharField()
    class Meta:
        model = DetectedFrameImage
        fields = ['id','frame_image']

class DetectedGetTableSerializer(ModelSerializer):
    vehicle_owner_name = serializers.CharField(source='vehicle_detail.vehicle_owner_name',read_only=True)
    occupant_name = serializers.CharField(source='vehicle_detail.occupant_id.occupant_name',read_only=True)
    occupant_unit_name = serializers.CharField(source='vehicle_detail.occupant_id.occupant_unit_name',read_only=True)
    parking_size_and_type_name = serializers.CharField(source='vehicle_detail.vehicle_parking_size_and_type_id.parking_size_and_type_name',read_only=True)
    wing_name = serializers.CharField(source='vehicle_detail.occupant_id.wing_id.wing_name',read_only=True)
    building_name = serializers.CharField(source='vehicle_detail.occupant_id.wing_id.building_id.building_name',read_only=True)
    class Meta:
        model = Detected
        fields = ('id','licence_plate_number','datetime','blacklisted_licence_plate','vehicle_type','country','make','model','camera_name','in_out','vehicle_detail','vehicle_owner_name','occupant_name','occupant_unit_name','parking_size_and_type_name','wing_name','building_name')


class DetectedSerializer(ModelSerializer):    
    detected_frame = DetectedFrameImageSerializer(many=True,write_only=True)
    licence_plate_image = serializers.CharField()
    def create(self, validated_data):
        detected_frames = validated_data.pop('detected_frame')
        direction = validated_data.get('in_out')
        vehicle_detail_id = None
        if direction == 'In':
            GetParkingCount = TotalParkingCount.objects.filter(business_detail_id=validated_data.get('business_detail')).values('id','total_parking_count','total_parking_in_count','total_parking_available','total_parking_extra').last()
            Get2WheelerVehicleCount = VehicleParkingCount.objects.filter(business_detail_id=validated_data.get('business_detail'),vehicle_type='2 wheeler').values('id','total_parking_count','total_parking_in_count','total_parking_available','total_parking_extra').last()
            Get4WheelerVehicleCount = VehicleParkingCount.objects.filter(business_detail_id=validated_data.get('business_detail'),vehicle_type='4 wheeler').values('id','total_parking_count','total_parking_in_count','total_parking_available','total_parking_extra').last()
            Get4WheelerVehicleCountToday = VehicleParkingCountDays.objects.filter(business_detail_id=validated_data.get('business_detail'),vehicle_type='4 wheeler',datetime__gte=timezone.now().replace(hour=0, minute=0, second=0),datetime__lte=timezone.now().replace(hour=23, minute=59, second=59)).values('id','total_parking_in_count','total_parking_out_count').last()
            if GetParkingCount is None:
                crete_parking = TotalParkingCount.objects.create(total_parking_count=0,total_parking_in_count=1,total_parking_available= 0,total_parking_extra=1,business_detail_id=validated_data.get('business_detail'))
                crete_parking.save()
            else:
                availableParking = GetParkingCount.get('total_parking_count')-(GetParkingCount.get('total_parking_in_count')+1)
                extraParking = 0
                if availableParking >= 0:
                    if availableParking >= GetParkingCount.get('total_parking_count'):
                        availableParking = GetParkingCount.get('total_parking_count')
                    else:
                        availableParking = availableParking
                else:
                    extraParking = abs(availableParking)
                    availableParking = 0
                
                update_parking = TotalParkingCount.objects.filter(id=GetParkingCount.get('id')).update(total_parking_in_count=max(0,GetParkingCount.get('total_parking_in_count')+1),total_parking_available=availableParking,total_parking_extra=extraParking)
            # if validated_data.get('vehicle_type') in ['Bike','Scooty']:
            #     if Get2WheelerVehicleCount is None:
            #         crete_parking = VehicleParkingCount.objects.create(vehicle_type='2 wheeler',total_parking_count=0,total_parking_in_count=1,business_detail_id=validated_data.get('business_detail'))
            #         crete_parking.save()
            #     else:
            #         availableParking = Get2WheelerVehicleCount.get('total_parking_count')-(Get2WheelerVehicleCount.get('total_parking_in_count')+1)
            #         extraParking = 0
            #         if availableParking >= 0:
            #             if availableParking >= Get2WheelerVehicleCount.get('total_parking_count'):
            #                 availableParking = Get2WheelerVehicleCount.get('total_parking_count')
            #             else:
            #                 availableParking = availableParking
            #         else:
            #             extraParking = abs(availableParking)
            #             availableParking = 0
            #         update_parking = VehicleParkingCount.objects.filter(id=Get2WheelerVehicleCount.get('id')).update(total_parking_in_count=max(0,Get2WheelerVehicleCount.get('total_parking_in_count')+1),total_parking_available=availableParking,total_parking_extra=extraParking)
            
            if validated_data.get('vehicle_type') in ['Car','Truck','Mini Truck','Bus']:
                if Get4WheelerVehicleCount is None:
                    crete_parking = VehicleParkingCount.objects.create(vehicle_type='4 wheeler',total_parking_count=0,total_parking_in_count=1,business_detail_id=validated_data.get('business_detail'))
                    crete_parking.save()
                else:
                    availableParking = Get4WheelerVehicleCount.get('total_parking_count')-(Get4WheelerVehicleCount.get('total_parking_in_count')+1)
                    extraParking = 0
                    if availableParking >= 0:
                        if availableParking >= Get4WheelerVehicleCount.get('total_parking_count'):
                            availableParking = Get4WheelerVehicleCount.get('total_parking_count')
                        else:
                            availableParking = availableParking
                    else:
                        extraParking = abs(availableParking)
                        availableParking = 0
                    update_parking = VehicleParkingCount.objects.filter(id=Get4WheelerVehicleCount.get('id')).update(total_parking_in_count=max(0,Get4WheelerVehicleCount.get('total_parking_in_count')+1),total_parking_available=availableParking,total_parking_extra=extraParking)
                if Get4WheelerVehicleCountToday is None:
                    in_parking_count = 1
                    if Get4WheelerVehicleCount is not None:
                        in_parking_count = Get4WheelerVehicleCount.get('total_parking_in_count')+1  
                    create_parking = VehicleParkingCountDays.objects.create(vehicle_type='4 wheeler',total_parking_in_count=in_parking_count,total_parking_out_count=0,datetime=timezone.now(),business_detail=validated_data.get('business_detail'))
                    create_parking.save()
                else:
                    update = VehicleParkingCountDays.objects.filter(id=Get4WheelerVehicleCountToday.get('id')).update(total_parking_in_count=Get4WheelerVehicleCountToday.get('total_parking_in_count')+1)
            get_vehicle_detail = VehicleDetail.objects.filter(vehicle_number=validated_data.get('licence_plate_number'),business_detail_id=validated_data.get('business_detail')).values('id','vehicle_number','occupied_parking','vehicle_parking_size_and_type_id','business_detail_id','business_detail_id__total_occupied_parking','occupant_id','occupant_id__total_occupied_parking','occupant_id__wing_id','occupant_id__wing_id__total_occupied_parking','occupant_id__building_id','occupant_id__building_id__total_occupied_parking').first()
            if get_vehicle_detail != None:
                vehicle_detail_id = get_vehicle_detail.get('id')
                if get_vehicle_detail.get('occupied_parking') == False:
                    update_vehicle_detail = VehicleDetail.objects.filter(id=get_vehicle_detail.get('id'),business_detail_id=get_vehicle_detail.get('business_detail_id')).update(occupied_parking=True)
                    update_occupant = Occupant.objects.filter(id=get_vehicle_detail.get('occupant_id'),business_detail_id=get_vehicle_detail.get('business_detail_id')).update(total_occupied_parking = get_vehicle_detail('occupant_id__total_occupied_parking')+1)
                    get_occupant_parking = OccupantParkingDetail.objects.filter(occupant_id=get_vehicle_detail.get('occupant_id'),vehicle_parking_size_and_type_id=get_vehicle_detail.get('vehicle_parking_size_and_type_id')).values('id','total_occupied_parking').first()
                    if get_occupant_parking != None:
                        update_occupant_parking = OccupantParkingDetail.objects.filter(occupant_id=get_vehicle_detail.get('occupant_id'),vehicle_parking_size_and_type_id=get_vehicle_detail.get('vehicle_parking_size_and_type_id')).update(total_occupied_parking=get_occupant_parking.get('total_occupied_parking')+1)
                    
                    update_wing = Wing.objects.filter(id=get_vehicle_detail.get('occupant_id__wing_id'),business_detail_id=get_vehicle_detail.get('business_detail_id')).update(total_occupied_parking = get_vehicle_detail('occupant_id__wing_id__total_occupied_parking')+1)
                    get_wing_parking = WingParkingDetail.objects.filter(wing_id=get_vehicle_detail.get('occupant_id__wing_id'),vehicle_parking_size_and_type_id=get_vehicle_detail.get('vehicle_parking_size_and_type_id')).values('id','total_occupied_parking').first()
                    if get_wing_parking != None:
                        update_wing_parking = WingParkingDetail.objects.filter(wing_id=get_vehicle_detail.get('occupant_id__wing_id'),vehicle_parking_size_and_type_id=get_vehicle_detail.get('vehicle_parking_size_and_type_id')).update(total_occupied_parking=get_wing_parking.get('total_occupied_parking')+1)
                    
                    update_building = Building.objects.filter(id=get_vehicle_detail.get('occupant_id__building_id'),business_detail_id=get_vehicle_detail.get('business_detail_id')).update(total_occupied_parking = get_vehicle_detail('occupant_id__building_id__total_occupied_parking')+1)
                    get_building_parking = BuildingParkingDetail.objects.filter(building_id=get_vehicle_detail.get('occupant_id__building_id'),vehicle_parking_size_and_type_id=get_vehicle_detail.get('vehicle_parking_size_and_type_id')).values('id','total_occupied_parking').first()
                    if get_building_parking != None:
                        update_building_parking = BuildingParkingDetail.objects.filter(building_id=get_vehicle_detail.get('occupant_id__building_id'),vehicle_parking_size_and_type_id=get_vehicle_detail.get('vehicle_parking_size_and_type_id')).update(total_occupied_parking=get_building_parking.get('total_occupied_parking')+1)
                    
                    update_business = BusinessDetail.objects.filter(id=get_vehicle_detail.get('business_detail_id')).update(total_occupied_parking = get_vehicle_detail('business_detail_id__total_occupied_parking')+1)
                    get_business_parking = BusinessParkingDetail.objects.filter(business_detail_id=get_vehicle_detail.get('business_detail_id'),vehicle_parking_size_and_type_id=get_vehicle_detail.get('vehicle_parking_size_and_type_id')).values('id','total_occupied_parking').first()
                    if get_business_parking != None:
                        update_business_parking = BusinessParkingDetail.objects.filter(business_detail_id=get_vehicle_detail.get('business_detail_id'),vehicle_parking_size_and_type_id=get_vehicle_detail.get('vehicle_parking_size_and_type_id')).update(total_occupied_parking=get_business_parking.get('total_occupied_parking')+1)
        elif direction == 'Out':
            GetParkingCount = TotalParkingCount.objects.filter(business_detail_id=validated_data.get('business_detail')).values('id','total_parking_count','total_parking_in_count').last()
            Get2WheelerVehicleCount = VehicleParkingCount.objects.filter(business_detail_id=validated_data.get('business_detail'),vehicle_type='2 wheeler').values('id','total_parking_count','total_parking_in_count').last()
            Get4WheelerVehicleCount = VehicleParkingCount.objects.filter(business_detail_id=validated_data.get('business_detail'),vehicle_type='4 wheeler').values('id','total_parking_count','total_parking_in_count').last()
            Get4WheelerVehicleCountToday = VehicleParkingCountDays.objects.filter(business_detail_id=validated_data.get('business_detail'),vehicle_type='4 wheeler',datetime__gte=timezone.now().replace(hour=0, minute=0, second=0),datetime__lte=timezone.now().replace(hour=23, minute=59, second=59)).values('id','total_parking_in_count','total_parking_out_count','datetime').last()
            if GetParkingCount is None:
                crete_parking = TotalParkingCount.objects.create(total_parking_count=0,total_parking_in_count=1,business_detail_id=validated_data.get('business_detail'))
                crete_parking.save()
            else:
                availableParking = GetParkingCount.get('total_parking_count')-(GetParkingCount.get('total_parking_in_count')-1)
                extraParking = 0
                if availableParking >= 0:
                    if availableParking >= GetParkingCount.get('total_parking_count'):
                        availableParking = GetParkingCount.get('total_parking_count')
                    else:
                        availableParking = availableParking
                else:
                    extraParking = abs(availableParking)
                    availableParking = 0
                update_parking = TotalParkingCount.objects.filter(id=GetParkingCount.get('id')).update(total_parking_in_count=max(0,GetParkingCount.get('total_parking_in_count')-1),total_parking_available=availableParking,total_parking_extra=extraParking)
            # if validated_data.get('vehicle_type') in ['Bike','Scooty']:
            #     if Get2WheelerVehicleCount is None:
            #         crete_parking = VehicleParkingCount.objects.create(vehicle_type='2 wheeler',total_parking_count=0,total_parking_in_count=1,business_detail_id=validated_data.get('business_detail'))
            #         crete_parking.save()
            #     else:
            #         availableParking = Get2WheelerVehicleCount.get('total_parking_count')-(Get2WheelerVehicleCount.get('total_parking_in_count')-1)
            #         extraParking = 0
            #         if availableParking >= 0:
            #             if availableParking >= Get2WheelerVehicleCount.get('total_parking_count'):
            #                 availableParking = Get2WheelerVehicleCount.get('total_parking_count')
            #             else:
            #                 availableParking = availableParking
            #         else:
            #             extraParking = abs(availableParking)
            #             availableParking = 0
            #         update_parking = VehicleParkingCount.objects.filter(id=Get2WheelerVehicleCount.get('id')).update(total_parking_in_count=max(0,Get2WheelerVehicleCount.get('total_parking_in_count')-1),total_parking_available=availableParking,total_parking_extra=extraParking)
            
            if validated_data.get('vehicle_type') in ['Car','Truck','Mini Truck','Bus']:
                if Get4WheelerVehicleCount is None:
                    crete_parking = VehicleParkingCount.objects.create(vehicle_type='4 wheeler',total_parking_count=0,total_parking_in_count=1,business_detail_id=validated_data.get('business_detail'))
                    crete_parking.save()
                else:
                    availableParking = Get4WheelerVehicleCount.get('total_parking_count')-(Get4WheelerVehicleCount.get('total_parking_in_count')-1)
                    extraParking = 0
                    if availableParking >= 0:
                        if availableParking >= Get4WheelerVehicleCount.get('total_parking_count'):
                            availableParking = Get4WheelerVehicleCount.get('total_parking_count')
                        else:
                            availableParking = availableParking
                    else:
                        extraParking = abs(availableParking)
                        availableParking = 0
                    update_parking = VehicleParkingCount.objects.filter(id=Get4WheelerVehicleCount.get('id')).update(total_parking_in_count=max(0,Get4WheelerVehicleCount.get('total_parking_in_count')-1),total_parking_available=availableParking,total_parking_extra=extraParking)
                if Get4WheelerVehicleCountToday is None:
                    in_parking_count = 0
                    if Get4WheelerVehicleCount is not None:
                        in_parking_count = Get4WheelerVehicleCount.get('total_parking_in_count')
                    create_parking = VehicleParkingCountDays.objects.create(vehicle_type='4 wheeler',total_parking_in_count=max(0,in_parking_count),total_parking_out_count=1,datetime=timezone.now(),business_detail_id=validated_data.get('business_detail'))
                    create_parking.save()
                else:
                    update = VehicleParkingCountDays.objects.filter(id=Get4WheelerVehicleCountToday.get('id')).update(total_parking_in_count = max(0,Get4WheelerVehicleCountToday.get('total_parking_in_count')-1),total_parking_out_count=Get4WheelerVehicleCountToday.get('total_parking_out_count')+1)
            get_vehicle_detail = VehicleDetail.objects.filter(vehicle_number=validated_data.get('licence_plate_number'),business_detail_id=validated_data.get('business_detail')).values('id','vehicle_number','occupied_parking','vehicle_parking_size_and_type_id','business_detail_id','business_detail_id__total_occupied_parking','occupant_id','occupant_id__total_occupied_parking','occupant_id__wing_id','occupant_id__wing_id__total_occupied_parking','occupant_id__building_id','occupant_id__building_id__total_occupied_parking').first()
            if get_vehicle_detail != None:
                vehicle_detail_id = get_vehicle_detail.get('id')
                if get_vehicle_detail.get('occupied_parking') == False:
                    update_vehicle_detail = VehicleDetail.objects.filter(id=get_vehicle_detail.get('id'),business_detail_id=get_vehicle_detail.get('business_detail_id')).update(occupied_parking=True)
                    update_occupant = Occupant.objects.filter(id=get_vehicle_detail.get('occupant_id'),business_detail_id=get_vehicle_detail.get('business_detail_id')).update(total_occupied_parking = get_vehicle_detail('occupant_id__total_occupied_parking')-1)
                    get_occupant_parking = OccupantParkingDetail.objects.filter(occupant_id=get_vehicle_detail.get('occupant_id'),vehicle_parking_size_and_type_id=get_vehicle_detail.get('vehicle_parking_size_and_type_id')).values('id','total_occupied_parking').first()
                    if get_occupant_parking != None:
                        update_occupant_parking = OccupantParkingDetail.objects.filter(occupant_id=get_vehicle_detail.get('occupant_id'),vehicle_parking_size_and_type_id=get_vehicle_detail.get('vehicle_parking_size_and_type_id')).update(total_occupied_parking=get_occupant_parking.get('total_occupied_parking')-1)
                    
                    update_wing = Wing.objects.filter(id=get_vehicle_detail.get('occupant_id__wing_id'),business_detail_id=get_vehicle_detail.get('business_detail_id')).update(total_occupied_parking = get_vehicle_detail('occupant_id__wing_id__total_occupied_parking')-1)
                    get_wing_parking = WingParkingDetail.objects.filter(wing_id=get_vehicle_detail.get('occupant_id__wing_id'),vehicle_parking_size_and_type_id=get_vehicle_detail.get('vehicle_parking_size_and_type_id')).values('id','total_occupied_parking').first()
                    if get_wing_parking != None:
                        update_wing_parking = WingParkingDetail.objects.filter(wing_id=get_vehicle_detail.get('occupant_id__wing_id'),vehicle_parking_size_and_type_id=get_vehicle_detail.get('vehicle_parking_size_and_type_id')).update(total_occupied_parking=get_wing_parking.get('total_occupied_parking')-1)
                    
                    update_building = Building.objects.filter(id=get_vehicle_detail.get('occupant_id__building_id'),business_detail_id=get_vehicle_detail.get('business_detail_id')).update(total_occupied_parking = get_vehicle_detail('occupant_id__building_id__total_occupied_parking')-1)
                    get_building_parking = BuildingParkingDetail.objects.filter(building_id=get_vehicle_detail.get('occupant_id__building_id'),vehicle_parking_size_and_type_id=get_vehicle_detail.get('vehicle_parking_size_and_type_id')).values('id','total_occupied_parking').first()
                    if get_building_parking != None:
                        update_building_parking = BuildingParkingDetail.objects.filter(building_id=get_vehicle_detail.get('occupant_id__building_id'),vehicle_parking_size_and_type_id=get_vehicle_detail.get('vehicle_parking_size_and_type_id')).update(total_occupied_parking=get_building_parking.get('total_occupied_parking')-1)
                    
                    update_business = BusinessDetail.objects.filter(id=get_vehicle_detail.get('business_detail_id')).update(total_occupied_parking = get_vehicle_detail('business_detail_id__total_occupied_parking')-1)
                    get_business_parking = BusinessParkingDetail.objects.filter(business_detail_id=get_vehicle_detail.get('business_detail_id'),vehicle_parking_size_and_type_id=get_vehicle_detail.get('vehicle_parking_size_and_type_id')).values('id','total_occupied_parking').first()
                    if get_business_parking != None:
                        update_business_parking = BusinessParkingDetail.objects.filter(business_detail_id=get_vehicle_detail.get('business_detail_id'),vehicle_parking_size_and_type_id=get_vehicle_detail.get('vehicle_parking_size_and_type_id')).update(total_occupied_parking=get_business_parking.get('total_occupied_parking')-1)
        
        validated_data['vehicle_detail'] = vehicle_detail_id
        
        detected_data = Detected.objects.create(**validated_data)
        for frame in detected_frames:
            DetectedFrameImage.objects.create(detected=detected_data,**frame)
        return detected_data
    
    class Meta:
        model = Detected
        fields = ('id','licence_plate_number','licence_plate_image','datetime','blacklisted_licence_plate','vehicle_type','country','make','model','camera_name','in_out','user','business_detail','sites','vehicle_detail','detected_frame')


class DetectedDetailSerializer(ModelSerializer):
    detected_frame = DetectedFrameImageSerializer(many=True, read_only=True)
    class Meta:
        model = Detected
        fields = ('id','licence_plate_number','licence_plate_image','datetime','blacklisted_licence_plate','vehicle_type','country','make','model','camera_name','in_out','detected_frame')


class PartiallyDetectedFrameImageSerializer(ModelSerializer):
    class Meta:
        model = PartiallyDetectedFrameImage
        fields = ['id','frame_image']

class PartiallyDetectedGetTableSerializer(ModelSerializer):
    class Meta:
        model = PartiallyDetected
        fields = ('id','licence_plate_number','datetime','vehicle_type','country','make','model','camera_name','in_out')

class PartiallyDetectedSerializer(ModelSerializer):
    partially_detected_frame = PartiallyDetectedFrameImageSerializer(many=True,write_only=True)
    def create(self, validated_data):
        partially_detected_frames = validated_data.pop('partially_detected_frame')
        direction = validated_data.get('in_out')
        # if validated_data.get('vehicle_type') in ['Bike','Scooty']:
        #     if direction == 'In':
        #         GetParkingCount = TotalParkingCount.objects.filter(business_detail=validated_data.get('business_detail')).values('id','total_parking_count','total_parking_in_count').last()
        #         Get2WheelerVehicleCount = VehicleParkingCount.objects.filter(business_detail=validated_data.get('business_detail'),vehicle_type='2 wheeler').values('id','total_parking_count','total_parking_in_count').last()
        #         # Get4WheelerVehicleCount = VehicleParkingCount.objects.filter(business_detail=validated_data.get('business_detail'),vehicle_type='4 wheeler').values('id','total_parking_count','total_parking_in_count').last()
        #         if GetParkingCount is None:
        #             crete_parking = TotalParkingCount.objects.create(total_parking_count=0,total_parking_in_count=1,business_detail=validated_data.get('business_detail'))
        #             crete_parking.save()
        #         else:
        #             availableParking = GetParkingCount.get('total_parking_count')-(GetParkingCount.get('total_parking_in_count')+1)
        #             extraParking = 0
        #             if availableParking >= 0:
        #                 if availableParking >= GetParkingCount.get('total_parking_count'):
        #                     availableParking = GetParkingCount.get('total_parking_count')
        #                 else:
        #                     availableParking = availableParking
        #             else:
        #                 extraParking = abs(availableParking)
        #                 availableParking = 0
        #             update_parking = TotalParkingCount.objects.filter(id=GetParkingCount.get('id')).update(total_parking_in_count=max(0,GetParkingCount.get('total_parking_in_count')+1),total_parking_available=availableParking,total_parking_extra=extraParking)

        #         if Get2WheelerVehicleCount is None:
        #             crete_parking = VehicleParkingCount.objects.create(vehicle_type='2 wheeler',total_parking_count=0,total_parking_in_count=1,business_detail=validated_data.get('business_detail'))
        #             crete_parking.save()
        #         else:
        #             availableParking = Get2WheelerVehicleCount.get('total_parking_count')-(Get2WheelerVehicleCount.get('total_parking_in_count')+1)
        #             extraParking = 0
        #             if availableParking >= 0:
        #                 if availableParking >= Get2WheelerVehicleCount.get('total_parking_count'):
        #                     availableParking = Get2WheelerVehicleCount.get('total_parking_count')
        #                 else:
        #                     availableParking = availableParking
        #             else:
        #                 extraParking = abs(availableParking)
        #                 availableParking = 0
        #             update_parking = VehicleParkingCount.objects.filter(id=Get2WheelerVehicleCount.get('id')).update(total_parking_in_count=max(0,Get2WheelerVehicleCount.get('total_parking_in_count')+1),total_parking_available=availableParking,total_parking_extra=extraParking)

        #         # if Get4WheelerVehicleCount is None:
        #         #     crete_parking = VehicleParkingCount.objects.create(vehicle_type='2 wheeler',total_parking_count=0,total_parking_in_count=1,business_detail=validated_data.get('business_detail'))
        #         #     crete_parking.save()
        #         # else:
        #         #     update_parking = VehicleParkingCount.objects.filter(id=Get4WheelerVehicleCount.get('id')).update(total_parking_in_count=Get4WheelerVehicleCount.get('total_parking_in_count')+1)

        #     elif direction == 'Out':
        #         GetParkingCount = TotalParkingCount.objects.filter(business_detail=validated_data.get('business_detail')).values('id','total_parking_count','total_parking_in_count').last()
        #         Get2WheelerVehicleCount = VehicleParkingCount.objects.filter(business_detail=validated_data.get('business_detail'),vehicle_type='2 wheeler').values('id','total_parking_count','total_parking_in_count').last()
        #         # Get4WheelerVehicleCount = VehicleParkingCount.objects.filter(business_detail=validated_data.get('business_detail'),vehicle_type='4 wheeler').values('id','total_parking_count','total_parking_in_count').last()
        #         if GetParkingCount is None:
        #             crete_parking = TotalParkingCount.objects.create(total_parking_count=0,total_parking_in_count=1,business_detail=validated_data.get('business_detail'))
        #             crete_parking.save()
        #         else:
        #             availableParking = GetParkingCount.get('total_parking_count')-(GetParkingCount.get('total_parking_in_count')-1)
        #             extraParking = 0
        #             if availableParking >= 0:
        #                 if availableParking >= GetParkingCount.get('total_parking_count'):
        #                     availableParking = GetParkingCount.get('total_parking_count')
        #                 else:
        #                     availableParking = availableParking
        #             else:
        #                 extraParking = abs(availableParking)
        #                 availableParking = 0
        #             update_parking = TotalParkingCount.objects.filter(id=GetParkingCount.get('id')).update(total_parking_in_count=max(0,GetParkingCount.get('total_parking_in_count')-1),total_parking_available=availableParking,total_parking_extra=extraParking)

        #         if Get2WheelerVehicleCount is None:
        #             crete_parking = VehicleParkingCount.objects.create(vehicle_type='2 wheeler',total_parking_count=0,total_parking_in_count=1,business_detail=validated_data.get('business_detail'))
        #             crete_parking.save()
        #         else:
        #             availableParking = Get2WheelerVehicleCount.get('total_parking_count')-(Get2WheelerVehicleCount.get('total_parking_in_count')-1)
        #             extraParking = 0
        #             if availableParking >= 0:
        #                 if availableParking >= Get2WheelerVehicleCount.get('total_parking_count'):
        #                     availableParking = Get2WheelerVehicleCount.get('total_parking_count')
        #                 else:
        #                     availableParking = availableParking
        #             else:
        #                 extraParking = abs(availableParking)
        #                 availableParking = 0
        #             update_parking = VehicleParkingCount.objects.filter(id=Get2WheelerVehicleCount.get('id')).update(total_parking_in_count=max(0,Get2WheelerVehicleCount.get('total_parking_in_count')-1),total_parking_available=availableParking,total_parking_extra=extraParking)

        #         # if Get4WheelerVehicleCount is None:
        #         #     crete_parking = VehicleParkingCount.objects.create(vehicle_type='2 wheeler',total_parking_count=0,total_parking_in_count=1,business_detail=validated_data.get('business_detail'))
        #         #     crete_parking.save()
        #         # else:
        #         #     update_parking = VehicleParkingCount.objects.filter(id=Get4WheelerVehicleCount.get('id')).update(total_parking_in_count=Get4WheelerVehicleCount.get('total_parking_in_count')-1)
        
        partially_detected_data = PartiallyDetected.objects.create(**validated_data)
        for frame in partially_detected_frames:
            PartiallyDetectedFrameImage.objects.create(partially_detected=partially_detected_data,**frame)
        return partially_detected_data
    class Meta:
        model = PartiallyDetected
        fields = ('id','licence_plate_number','licence_plate_image','datetime','vehicle_type','country','make','model','camera_name','in_out','user','business_detail','vehicle_detail','partially_detected_frame')

class PartiallyDetectedDetailSerializer(ModelSerializer):
    partially_detected_frame = PartiallyDetectedFrameImageSerializer(many=True,read_only=True)
    class Meta:
        model = PartiallyDetected
        fields = ('id','licence_plate_number','licence_plate_image','datetime','vehicle_type','country','make','model','camera_name','in_out','partially_detected_frame')



