from django.db import models
import uuid
import django
from account.models import User,Sites
from myapp.models import BusinessDetail,VehicleDetail
# Create your models here.

class TotalParkingCount(models.Model):
    uuid = models.UUIDField(default=uuid.uuid4,editable=False)
    total_parking_count = models.IntegerField()
    total_parking_in_count = models.IntegerField()
    total_parking_available = models.IntegerField(default=0)
    total_parking_extra = models.IntegerField(default=0)
    datetime = models.DateTimeField(default=django.utils.timezone.now)
    business_detail = models.ForeignKey(BusinessDetail,related_name='total_parking_count',on_delete=models.PROTECT)

class VehicleParkingCount(models.Model):
    uuid = models.UUIDField(default=uuid.uuid4,editable=False)
    vehicle_type = models.CharField(max_length=20)
    total_parking_count = models.IntegerField()
    total_parking_in_count = models.IntegerField()
    total_parking_available = models.IntegerField(default=0)
    total_parking_extra = models.IntegerField(default=0)
    datetime = models.DateTimeField(default=django.utils.timezone.now)
    business_detail = models.ForeignKey(BusinessDetail,related_name='vehicle_parking_count',on_delete=models.PROTECT)

class VehicleParkingCountDays(models.Model):
    uuid = models.UUIDField(default=uuid.uuid4,editable=False)
    vehicle_type = models.CharField(max_length=20)
    total_parking_in_count = models.IntegerField(default=0)
    total_parking_out_count =  models.IntegerField(default=0)
    datetime = models.DateTimeField(default=django.utils.timezone.now)
    business_detail = models.ForeignKey(BusinessDetail,related_name='vehicle_parking_count_days',on_delete=models.PROTECT)


class BlackListedNumber(models.Model):
    uuid = models.UUIDField(default=uuid.uuid4,editable=False)
    licence_plate_number = models.CharField(max_length=50)
    reason_blacklist = models.CharField(max_length=100)
    datetime = models.DateTimeField(default=django.utils.timezone.now)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    b_detail = models.ForeignKey(BusinessDetail,on_delete=models.CASCADE)
    created_by = models.ForeignKey(User,on_delete=models.CASCADE,related_name='created_by_%(class)s_related',blank=True,null=True)
    created_datetime = models.DateTimeField(blank=True,null=True)
    updated_by = models.ForeignKey(User,on_delete=models.CASCADE,related_name='updated_by_%(class)s_related',blank=True,null=True)
    updated_datetime = models.DateTimeField(blank=True,null=True)


class Detected(models.Model):
    uuid = models.UUIDField(default=uuid.uuid4,editable=False)
    licence_plate_number = models.CharField(max_length=20, blank=True,null=True)
    licence_plate_image = models.ImageField(upload_to='parking_management/licence_plate_image/',blank=True,null=True,max_length=500)
    # licence_plate_image = models.TextField(blank=True,null=True)
    confidence_licence_plate = models.FloatField(blank=True,null=True)
    datetime = models.DateTimeField(default=django.utils.timezone.now)
    blacklisted_licence_plate = models.BooleanField(default=False)
    vehicle_type = models.CharField(max_length=50,blank=True,null=True)
    country = models.CharField(max_length=20,blank=True,null=True)
    state = models.CharField(max_length=20,blank=True,null=True)
    distic = models.CharField(max_length=20,blank=True,null=True)
    make = models.CharField(max_length=50,blank=True,null=True)
    model = models.CharField(max_length=50,blank=True,null=True)
    body = models.CharField(max_length=50,blank=True,null=True)
    camera_name = models.CharField(max_length=50)
    in_out = models.CharField(max_length=5)
    user = models.ForeignKey(User, on_delete=models.PROTECT)
    business_detail = models.ForeignKey(BusinessDetail,on_delete=models.PROTECT)
    sites = models.ForeignKey(Sites,on_delete=models.PROTECT)
    vehicle_detail = models.ForeignKey(VehicleDetail,on_delete=models.PROTECT,blank=True, null=True)


class DetectedFrameImage(models.Model):
    uuid = models.UUIDField(default=uuid.uuid4,editable=False)
    frame_image = models.ImageField(upload_to='parking_management/frame_image/',max_length=500)
    # frame_image = models.TextField()
    detected = models.ForeignKey(Detected,related_name='detected_frame', on_delete=models.PROTECT)


class PartiallyDetected(models.Model):
    uuid = models.UUIDField(default=uuid.uuid4,editable=False)
    licence_plate_number = models.CharField(max_length=20,blank=True,null=True)
    licence_plate_image = models.ImageField(upload_to='parking_management/licence_plate_image/',blank=True,null=True,max_length=500)
    # licence_plate_image = models.TextField(blank=True,null=True)
    confidence_licence_plate = models.FloatField(blank=True,null=True)
    datetime = models.DateTimeField(default=django.utils.timezone.now)
    vehicle_type = models.CharField(max_length=50,blank=True,null=True)
    country = models.CharField(max_length=20,blank=True,null=True)
    state = models.CharField(max_length=20,blank=True,null=True)
    distic = models.CharField(max_length=20,blank=True,null=True)
    make = models.CharField(max_length=50,blank=True,null=True)
    model = models.CharField(max_length=50,blank=True,null=True)
    body = models.CharField(max_length=50,blank=True,null=True)
    camera_name = models.CharField(max_length=50)
    in_out = models.CharField(max_length=5)
    user = models.ForeignKey(User, on_delete=models.PROTECT)
    business_detail = models.ForeignKey(BusinessDetail,on_delete=models.PROTECT)
    vehicle_detail = models.ForeignKey(VehicleDetail,on_delete=models.PROTECT,blank=True, null=True)



class PartiallyDetectedFrameImage(models.Model):
    uuid = models.UUIDField(default=uuid.uuid4,editable=False)
    frame_image = models.ImageField(upload_to='parking_management/frame_image/',max_length=500)
    # frame_image = models.TextField()
    partially_detected = models.ForeignKey(PartiallyDetected,related_name='partially_detected_frame', on_delete=models.PROTECT)



