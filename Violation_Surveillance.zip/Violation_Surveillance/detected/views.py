from django.shortcuts import render
from rest_framework.permissions import AllowAny,IsAuthenticated
from rest_framework.views import APIView
from django.http.response import JsonResponse,Http404
from rest_framework.response import Response
from account.views import *
from rest_framework import status
from .models import Detected,DetectedFrameImage,DetectedViolationFines,PartiallyDetected,PartiallyDetectedFrameImage,Violation,SubViolationAndCharges,BlackListedNumber, PartiallyDetectedViolationFines, InOutGate, InOutGateFrameImage
from .serializers import DetectedSerializer,DetectedDetailSerializer,PartiallyDetectedSerializer,PartiallyDetectedDetailSerializer,BlackListedNumberSerializer, DetectedGetTableSerializer, PartiallyDetectedGetTableSerializer,DetectedGetViolationChargesSerializer,InOutGateDetailSerializer,InOutGateFrameImageSerializer,InOutGateGetTableSerializer,InOutGateSerializer
from django.db.models import Q
from account.models import CompanyDetail,Sites
from PIL import Image
from io import BytesIO
import base64
import os
from django.core.files.storage import default_storage
from datetime import datetime
from django.utils.timezone import make_aware
import boto3
# Create your views here.
# class StandardResultsSetPagination(LimitOffsetPagination):
#     default_limit = 'limit'
#print(Detected.objects.filter(detected_violationfine__isnull=False,detected_violationfine__fine_collected=False).distinct().values('id','licence_plate_number'))
class DetectedTempView(APIView):
    permission_classes = (IsAuthenticated,)
    def convert_base64_to_image(self, base64_data):
        # Decode the base64 data
        image_data = base64.b64decode(base64_data)

        # Create a PIL Image object from the image data
        image = Image.open(BytesIO(image_data))
        return image

    def upload_image_to_s3(self, image,file_path):
        image_io = BytesIO()
        image.save(image_io, format='JPEG')

        # Set the S3 object key
        file_name = file_path
        storage = default_storage
        image_file = storage.save(f'{file_name}', image_io)
        # s3 = boto3.resource('s3')
        # bucket = s3.Bucket(default_storage.bucket_name)
        # object = bucket.Object(image_file)
        # object.upload_file(image_file, ExtraArgs={'ContentType': 'image/webp'})
        return image_file
    def post(self,request, format=None):
        get_user_data = get_user_data_page_plans(request.user.id,'detected','create')
        if get_user_data['business_plan_history_detail']['plan_validity'] == True:
            AccessToPage = False
            if get_user_data['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                get_data = request.data
                licence_plate_image_data = get_data['licence_plate_image']
                get_company_name = CompanyDetail.objects.filter(id=get_data['company_detail']).values('company_name').first()
                get_site_name = Sites.objects.filter(id=get_data['sites']).values('site_name').first()
                datetime_format = datetime.strptime(get_data['datetime'],'%Y-%m-%d %H:%M:%S.%f%z')
                get_date_string = str(datetime_format.date())
                if get_company_name != None or get_site_name != None:
                    if licence_plate_image_data != None:
                        image = self.convert_base64_to_image(licence_plate_image_data['image_base64'])
                        folder_path = 'violation_surveillance_management/'+get_company_name['company_name']+'/'+get_site_name['site_name']+'/'+get_data['camera_name'] +'/licence_plate_image/'+get_date_string+'/detected'
                        object_key = os.path.join(folder_path, licence_plate_image_data['image_name'])
                        get_data['licence_plate_image'] = self.upload_image_to_s3(image,object_key)

                    if get_data['driver_seat_belt_image'] != None:
                        image = self.convert_base64_to_image(get_data['driver_seat_belt_image']['image_base64'])
                        folder_path = 'violation_surveillance_management/'+get_company_name['company_name']+'/'+get_site_name['site_name']+'/'+get_data['camera_name'] +'/driver_seatbelt_image/'+get_date_string+'/detected'
                        object_key = os.path.join(folder_path, get_data['driver_seat_belt_image']['image_name'])
                        get_data['driver_seat_belt_image'] = self.upload_image_to_s3(image,object_key)

                    if get_data['passanger_seat_belt_image'] != None:
                        image = self.convert_base64_to_image(get_data['passanger_seat_belt_image']['image_base64'])
                        folder_path = 'violation_surveillance_management/'+get_company_name['company_name']+'/'+get_site_name['site_name']+'/'+get_data['camera_name'] +'/passanger_seatbelt_image/'+get_date_string+'/detected'
                        object_key = os.path.join(folder_path, get_data['passanger_seat_belt_image']['image_name'])
                        get_data['passanger_seat_belt_image'] = self.upload_image_to_s3(image,object_key)

                    if get_data['driver_mobile_image'] != None:
                        image = self.convert_base64_to_image(get_data['driver_mobile_image']['image_base64'])
                        folder_path = 'violation_surveillance_management/'+get_company_name['company_name']+'/'+get_site_name['site_name']+'/'+get_data['camera_name'] +'/driver_mobile_image/'+get_date_string+'/detected'
                        object_key = os.path.join(folder_path, get_data['driver_mobile_image']['image_name'])
                        get_data['driver_mobile_image'] = self.upload_image_to_s3(image,object_key)

                    if get_data['passanger_mobile_image'] != None:
                        image = self.convert_base64_to_image(get_data['passanger_mobile_image']['image_base64'])
                        folder_path = 'violation_surveillance_management/'+get_company_name['company_name']+'/'+get_site_name['site_name']+'/'+get_data['camera_name'] +'/driver_mobile_image/'+get_date_string+'/detected'
                        object_key = os.path.join(folder_path, get_data['passanger_mobile_image']['image_name'])
                        get_data['passanger_mobile_image'] = self.upload_image_to_s3(image,object_key) 

                    for index,data in enumerate(get_data['detected_frame']):
                        frame_image_data = data['frame_image']
                        if frame_image_data != None:
                            image = self.convert_base64_to_image(frame_image_data['image_base64'])
                            folder_path = 'violation_surveillance_management/'+get_company_name['company_name']+'/'+get_site_name['site_name']+'/'+get_data['camera_name'] +'/frame_image/'+get_date_string+'/detected'
                            object_key = os.path.join(folder_path, frame_image_data['image_name'])
                            get_data['detected_frame'][index]['frame_image'] = self.upload_image_to_s3(image,object_key)

                    detected_serializer = DetectedSerializer(data=get_data)
                    if detected_serializer.is_valid(raise_exception=True):
                        obj = detected_serializer.save()
                        get_all_violation = Violation.objects.values('id','violation_name','data_type')
                        for get_violation in get_all_violation:
                            print(get_violation.get('data_type'))
                            if get_violation['data_type'] == 'integer' and request.data['speed_violation'] == True:
                                get_speed_sub_violation = SubViolationAndCharges.objects.filter(violation=get_violation['id'],company_detail=get_user_data['company_detail']['id']).values('id','violation','sub_violation_name','charges')
                                for get_sub_violation in get_speed_sub_violation:
                                    split_speed = get_sub_violation['sub_violation_name'].split('-')
                                    if len(split_speed) > 1:
                                        if int(split_speed[0]) <= request.data['speed'] and int(split_speed[1]) >= request.data['speed']:
                                            DetectedViolationFines.objects.create(violation_id = get_violation['id'],sub_violation_and_charges_id = get_sub_violation['id'], fine_collected = False,detected_id = obj.id)   
                                    elif len(split_speed) == 1:
                                        if int(split_speed[0].replace('>=','')) <= request.data['speed']:
                                            DetectedViolationFines.objects.create(violation_id = get_violation['id'],sub_violation_and_charges_id = get_sub_violation['id'], fine_collected = False,detected_id = obj.id)     
                            elif get_violation['data_type'] == 'string':
                                if request.data['driver_seat_belt'] == 'No' and get_violation['violation_name'] == 'seat belt':
                                    get_all_sub_violation = SubViolationAndCharges.objects.filter(violation=get_violation['id'],sub_violation_name='driver seat belt',company_detail=get_user_data['company_detail']['id']).values('id','violation','sub_violation_name','charges')
                                    for get_sub_violation in get_all_sub_violation:
                                        DetectedViolationFines.objects.create(violation_id = get_violation['id'],sub_violation_and_charges_id = get_sub_violation['id'], fine_collected = False,detected_id = obj.id)                            
                                elif request.data['passanger_seat_belt'] == 'No' and get_violation['violation_name'] == 'seat belt':
                                    get_all_sub_violation = SubViolationAndCharges.objects.filter(violation=get_violation['id'],sub_violation_name='passanger seat belt',company_detail=get_user_data['company_detail']['id']).values('id','violation','sub_violation_name','charges')
                                    for get_sub_violation in get_all_sub_violation:
                                        DetectedViolationFines.objects.create(violation_id = get_violation['id'],sub_violation_and_charges_id = get_sub_violation['id'], fine_collected = False,detected_id = obj.id)                            
                                elif request.data['driver_mobile'] == 'Yes' and get_violation['violation_name'] == 'mobile':
                                    get_all_sub_violation = SubViolationAndCharges.objects.filter(violation=get_violation['id'],sub_violation_name='driver mobile',company_detail=get_user_data['company_detail']['id']).values('id','violation','sub_violation_name','charges')
                                    for get_sub_violation in get_all_sub_violation:
                                        DetectedViolationFines.objects.create(violation_id = get_violation['id'],sub_violation_and_charges_id = get_sub_violation['id'], fine_collected = False,detected_id = obj.id)
                                elif request.data['passanger_mobile'] == 'Yes' and get_violation['violation_name'] == 'mobile':
                                    get_all_sub_violation = SubViolationAndCharges.objects.filter(violation=get_violation['id'],sub_violation_name='passanger mobile',company_detail=get_user_data['company_detail']['id']).values('id','violation','sub_violation_name','charges')
                                    for get_sub_violation in get_all_sub_violation:
                                        DetectedViolationFines.objects.create(violation_id = get_violation['id'],sub_violation_and_charges_id = get_sub_violation['id'], fine_collected = False,detected_id = obj.id)
                                elif request.data['lane_change'] == True and get_violation['violation_name'] == 'lane change':
                                    get_all_sub_violation = SubViolationAndCharges.objects.filter(violation=get_violation['id'],sub_violation_name='lane change',company_detail=get_user_data['company_detail']['id']).values('id','violation','sub_violation_name','charges')
                                    for get_sub_violation in get_all_sub_violation:
                                        DetectedViolationFines.objects.create(violation_id = get_violation['id'],sub_violation_and_charges_id = get_sub_violation['id'], fine_collected = False,detected_id = obj.id) 
                        
                        return Response(detected_serializer.data, status=status.HTTP_201_CREATED)
                    return Response(detected_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                else:
                    return Response({'message':'company and sites are required.'}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
    
class PartiallyDetectedTempView(APIView):
    permission_classes = (IsAuthenticated,)
    def convert_base64_to_image(self, base64_data):
        # Decode the base64 data
        image_data = base64.b64decode(base64_data)

        # Create a PIL Image object from the image data
        image = Image.open(BytesIO(image_data))
        return image

    def upload_image_to_s3(self, image,file_path):
        image_io = BytesIO()
        image.save(image_io, format='JPEG')

        # Set the S3 object key
        file_name = file_path
        storage = default_storage
        image_file = storage.save(f'{file_name}', image_io)
        # s3 = boto3.resource('s3')
        # bucket = s3.Bucket(default_storage.bucket_name)
        # object = bucket.Object(image_file)
        # object.upload_file(image_file, ExtraArgs={'ContentType': 'image/webp'})
        return image_file
    def post(self,request, format=None):
        get_user_data = get_user_data_page_plans(request.user.id,'detected','create')
        if get_user_data['business_plan_history_detail']['plan_validity'] == True:
            AccessToPage = False
            if get_user_data['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                get_data = request.data
                licence_plate_image_data = get_data['licence_plate_image']
                get_company_name = CompanyDetail.objects.filter(id=get_data['company_detail']).values('company_name').first()
                get_site_name = Sites.objects.filter(id=get_data['sites']).values('site_name').first()
                datetime_format = datetime.strptime(get_data['datetime'],'%Y-%m-%d %H:%M:%S.%f%z')
                get_date_string = str(datetime_format.date())
                if get_company_name != None or get_site_name != None:
                    if licence_plate_image_data != None:
                        image = self.convert_base64_to_image(licence_plate_image_data['image_base64'])
                        folder_path = 'violation_surveillance_management/'+get_company_name['company_name']+'/'+get_site_name['site_name']+'/'+get_data['camera_name'] +'/licence_plate_image/'+get_date_string+'/partially_detected'
                        object_key = os.path.join(folder_path, licence_plate_image_data['image_name'])
                        get_data['licence_plate_image'] = self.upload_image_to_s3(image,object_key)

                    if get_data['driver_seat_belt_image'] != None:
                        image = self.convert_base64_to_image(get_data['driver_seat_belt_image']['image_base64'])
                        folder_path = 'violation_surveillance_management/'+get_company_name['company_name']+'/'+get_site_name['site_name']+'/'+get_data['camera_name'] +'/driver_seatbelt_image/'+get_date_string+'/partially_detected'
                        object_key = os.path.join(folder_path, get_data['driver_seat_belt_image']['image_name'])
                        get_data['driver_seat_belt_image'] = self.upload_image_to_s3(image,object_key)

                    if get_data['passanger_seat_belt_image'] != None:
                        image = self.convert_base64_to_image(get_data['passanger_seat_belt_image']['image_base64'])
                        folder_path = 'violation_surveillance_management/'+get_company_name['company_name']+'/'+get_site_name['site_name']+'/'+get_data['camera_name'] +'/passanger_seatbelt_image/'+get_date_string+'/partially_detected'
                        object_key = os.path.join(folder_path, get_data['passanger_seat_belt_image']['image_name'])
                        get_data['passanger_seat_belt_image'] = self.upload_image_to_s3(image,object_key)

                    if get_data['driver_mobile_image'] != None:
                        image = self.convert_base64_to_image(get_data['driver_mobile_image']['image_base64'])
                        folder_path = 'violation_surveillance_management/'+get_company_name['company_name']+'/'+get_site_name['site_name']+'/'+get_data['camera_name'] +'/driver_mobile_image/'+get_date_string+'/partially_detected'
                        object_key = os.path.join(folder_path, get_data['driver_mobile_image']['image_name'])
                        get_data['driver_mobile_image'] = self.upload_image_to_s3(image,object_key)

                    if get_data['passanger_mobile_image'] != None:
                        image = self.convert_base64_to_image(get_data['passanger_mobile_image']['image_base64'])
                        folder_path = 'violation_surveillance_management/'+get_company_name['company_name']+'/'+get_site_name['site_name']+'/'+get_data['camera_name'] +'/driver_mobile_image/'+get_date_string+'/partially_detected'
                        object_key = os.path.join(folder_path, get_data['passanger_mobile_image']['image_name'])
                        get_data['passanger_mobile_image'] = self.upload_image_to_s3(image,object_key) 

                    for index,data in enumerate(get_data['partially_detected_frame']):
                        frame_image_data = data['frame_image']
                        if frame_image_data != None:
                            image = self.convert_base64_to_image(frame_image_data['image_base64'])
                            folder_path = 'violation_surveillance_management/'+get_company_name['company_name']+'/'+get_site_name['site_name']+'/'+get_data['camera_name'] +'/frame_image/'+get_date_string+'/partially_detected'
                            object_key = os.path.join(folder_path, frame_image_data['image_name'])
                            get_data['partially_detected_frame'][index]['frame_image'] = self.upload_image_to_s3(image,object_key)

                    partially_detected_serializer = PartiallyDetectedSerializer(data=get_data)
                    if partially_detected_serializer.is_valid(raise_exception=True):
                        obj = partially_detected_serializer.save()
                        get_all_violation = Violation.objects.values('id','violation_name','data_type')
                        for get_violation in get_all_violation:
                            if get_violation['data_type'] == 'integer' and request.data['speed_violation'] == True:
                                get_speed_sub_violation = SubViolationAndCharges.objects.filter(violation=get_violation['id'],company_detail=get_user_data['company_detail']['id']).values('id','violation','sub_violation_name','charges')
                                for get_sub_violation in get_speed_sub_violation:
                                    split_speed = get_sub_violation['sub_violation_name'].split('-')
                                    if len(split_speed) > 1:
                                        if int(split_speed[0]) <= request.data['speed'] and int(split_speed[1]) >= request.data['speed']:
                                            PartiallyDetectedViolationFines.objects.create(violation_id = get_violation['id'],sub_violation_and_charges_id = get_sub_violation['id'], fine_collected = False,partially_detected_id = obj.id)
                                    elif len(split_speed) == 1:
                                        if int(split_speed[0].replace('>=','')) <= request.data['speed']:
                                            PartiallyDetectedViolationFines.objects.create(violation_id = get_violation['id'],sub_violation_and_charges_id = get_sub_violation['id'], fine_collected = False,partially_detected_id = obj.id)
                            elif get_violation['data_type'] == 'string':
                                if request.data['driver_seat_belt'] == 'No' and get_violation['violation_name'] == 'seat belt':
                                    get_all_sub_violation = SubViolationAndCharges.objects.filter(violation=get_violation['id'],sub_violation_name='driver seat belt',company_detail=get_user_data['company_detail']['id']).values('id','violation','sub_violation_name','charges')
                                    for get_sub_violation in get_all_sub_violation:
                                        PartiallyDetectedViolationFines.objects.create(violation_id = get_violation['id'],sub_violation_and_charges_id = get_sub_violation['id'], fine_collected = False,partially_detected_id = obj.id)                            
                                if request.data['passanger_seat_belt'] == 'No' and get_violation['violation_name'] == 'seat belt':
                                    get_all_sub_violation = SubViolationAndCharges.objects.filter(violation=get_violation['id'],sub_violation_name='passanger seat belt',company_detail=get_user_data['company_detail']['id']).values('id','violation','sub_violation_name','charges')
                                    for get_sub_violation in get_all_sub_violation:
                                        PartiallyDetectedViolationFines.objects.create(violation_id = get_violation['id'],sub_violation_and_charges_id = get_sub_violation['id'], fine_collected = False,partially_detected_id = obj.id)                            
                                if request.data['driver_mobile'] == 'Yes' and get_violation['violation_name'] == 'mobile':
                                    get_all_sub_violation = SubViolationAndCharges.objects.filter(violation=get_violation['id'],sub_violation_name='driver mobile',company_detail=get_user_data['company_detail']['id']).values('id','violation','sub_violation_name','charges')
                                    for get_sub_violation in get_all_sub_violation:
                                        PartiallyDetectedViolationFines.objects.create(violation_id = get_violation['id'],sub_violation_and_charges_id = get_sub_violation['id'], fine_collected = False,partially_detected_id = obj.id)
                                if request.data['passanger_mobile'] == 'Yes' and get_violation['violation_name'] == 'mobile':
                                    get_all_sub_violation = SubViolationAndCharges.objects.filter(violation=get_violation['id'],sub_violation_name='passanger mobile',company_detail=get_user_data['company_detail']['id']).values('id','violation','sub_violation_name','charges')
                                    for get_sub_violation in get_all_sub_violation:
                                        PartiallyDetectedViolationFines.objects.create(violation_id = get_violation['id'],sub_violation_and_charges_id = get_sub_violation['id'], fine_collected = False,partially_detected_id = obj.id)
                                if request.data['lane_change'] == True and get_violation['violation_name'] == 'lane change':
                                    get_all_sub_violation = SubViolationAndCharges.objects.filter(violation=get_violation['id'],sub_violation_name='lane change',company_detail=get_user_data['company_detail']['id']).values('id','violation','sub_violation_name','charges')
                                    for get_sub_violation in get_all_sub_violation:
                                        PartiallyDetectedViolationFines.objects.create(violation_id = get_violation['id'],sub_violation_and_charges_id = get_sub_violation['id'], fine_collected = False,partially_detected_id = obj.id)
                        return Response(partially_detected_serializer.data, status=status.HTTP_201_CREATED)
                    return Response(partially_detected_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                else:
                    return Response({'message':'company and sites are required.'}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

class DetectedView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = get_user_data_page_plans(request.user.id,'detected','create')
        if get_user_data['business_plan_history_detail']['plan_validity'] == True:
            AccessToPage = False
            if get_user_data['permission'] != None:
                AccessToPage = True
            # if 'detected' in get_user_data['permission'].keys():
            #     if 'view' in get_user_data['permission']['detected']:
            #         AccessToPage = True
            if AccessToPage == True:
                # fields = ['id','licence_plate_number','licence_plate_image','confidence_licence_plate','datetime','speed','speed_violation','lane_change','blacklisted_licence_plate','driver_seat_belt','driver_seat_belt_image','confidence_driver_seat_belt','passanger_seat_belt','passanger_seat_belt_image','confidence_passanger_seat_belt','driver_mobile','driver_mobile_image','confidence_driver_mobile','passanger_mobile','passanger_mobile_image','confidence_passanger_mobile','vehicle_type','vehicle_direction','country','camera_name']
                # if get_user_data['company_detail']['lane_change_check_allowed'] == False:
                #     fields.remove('lane_change')
                # if get_user_data['company_detail']['mobile_check_allowed'] == False:
                #     fields.remove('driver_mobile')
                #     fields.remove('driver_mobile_image')
                #     fields.remove('confidence_driver_mobile')
                #     fields.remove('passanger_mobile')
                #     fields.remove('passanger_mobile_image')
                #     fields.remove('confidence_passanger_mobile')
                # if get_user_data['company_detail']['seat_belt_check_allowed'] == False:
                #     fields.remove('driver_seat_belt')
                #     fields.remove('driver_seat_belt_image')
                #     fields.remove('confidence_driver_seat_belt')
                #     fields.remove('passanger_seat_belt')
                #     fields.remove('passanger_seat_belt_image')
                #     fields.remove('confidence_passanger_seat_belt')

                # if get_user_data['company_detail']['speed_check_allowed'] == False:
                #     fields.remove('speed')
                #     fields.remove('speed_violation')
                licence_plate_number = request.GET.get('licence_plate_number', None)
                speed_violation = request.GET.get('speed_violation', None)
                seat_belt = request.GET.get('seat_belt', None)
                ordering = request.GET.get('order_by',None)
                from_datetime = request.GET.get('start_datetime',None)
                to_datetime = request.GET.get('end_datetime',None)
                direction = request.GET.get('vehicle_direction',None)

                if ordering ==None:
                    ordering = '-datetime'

                print("licence_plate_number,speed_violation,seat_belt:",type(licence_plate_number),type(speed_violation),seat_belt)
                f= Q(company_detail = get_user_data['company_detail']['id'])
                if licence_plate_number != '' and licence_plate_number != None:
                    f &= Q(licence_plate_number__contains=licence_plate_number)
                if speed_violation != '0' and speed_violation != None:
                    f &= Q(speed__gt=int(speed_violation))
                if seat_belt != 'All' and seat_belt != None:
                    f &= Q(driver_seat_belt=seat_belt)
                if from_datetime != None:
                    f &= Q(datetime__gte=from_datetime)
                if to_datetime != None:
                    f &= Q(datetime__lte=to_datetime)
                if direction != 'All' and direction != None:
                    f &= Q(vehicle_direction=direction)
                limit = int(request.GET.get('limit',10))
                offset = int(request.GET.get('offset',0))
                detected_detail = Detected.objects.filter(f).order_by(ordering).all()[offset:limit+offset] # .values('id','licence_plate_number','datetime','speed','speed_violation','lane_change','blacklisted_licence_plate','driver_seat_belt','passanger_seat_belt','driver_mobile','passanger_mobile','vehicle_type','vehicle_direction','country','camera_name','sites') ##company_detail = get_user_data['company_detail']['id'], licence_plate_number__contains=licence_plate_number, speed__gt=int(speed_violation),driver_seat_belt=seat_belt
                detected_detail_count = Detected.objects.filter(f).order_by(ordering).values('id','licence_plate_number','datetime','speed','speed_violation','lane_change','blacklisted_licence_plate','driver_seat_belt','passanger_seat_belt','driver_mobile','passanger_mobile','vehicle_type','vehicle_direction','country','camera_name').count()
                #.values('id','licence_plate_number','licence_plate_image','confidence_licence_plate','datetime','speed','speed_violation','lane_change','blacklisted_licence_plate','driver_seat_belt','driver_seat_belt_image','confidence_driver_seat_belt','passanger_seat_belt','passanger_seat_belt_image','confidence_passanger_seat_belt','driver_mobile','driver_mobile_image','confidence_driver_mobile','passanger_mobile','passanger_mobile_image','confidence_passanger_mobile','vehicle_type','vehicle_direction','country','camera_name','created_by','created_datetime','updated_by','updated_datetime','no_of_unpaid_fine').all()
                serializer = DetectedGetTableSerializer(detected_detail, many=True)
                return Response({'count':detected_detail_count,'results':serializer.data})
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class GenerateChallanView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = get_user_data_page_plans(request.user.id,'detected','create')
        if get_user_data['business_plan_history_detail']['plan_validity'] == True:
            AccessToPage = False
            if get_user_data['permission'] != None:
                AccessToPage = True
            # if 'detected' in get_user_data['permission'].keys():
            #     if 'view' in get_user_data['permission']['detected']:
            #         AccessToPage = True
            if AccessToPage == True:
                licence_plate_number = request.GET.get('licence_plate_number', None)
                paid_type = request.GET.get('paid_type', None)
                ordering = request.GET.get('order_by',None)
                if ordering ==None:
                    ordering = '-datetime'
                f= Q(company_detail = get_user_data['company_detail']['id'])
                f &= Q(detected_violationfine__isnull=False)
                
                if licence_plate_number != '' and licence_plate_number != None:
                    f &= Q(licence_plate_number__contains=licence_plate_number)
                if paid_type != 'All' and paid_type != None:
                    PaidType = False
                    if paid_type == 'true':
                        PaidType = True
                    f &= Q(detected_violationfine__fine_collected=PaidType)
                detected_detail = Detected.objects.filter(f).distinct().order_by(ordering).all() #values('id','licence_plate_number','datetime','speed','speed_violation','lane_change','blacklisted_licence_plate','driver_seat_belt','passanger_seat_belt','driver_mobile','passanger_mobile','vehicle_type','vehicle_direction','country','camera_name') 
                ##company_detail = get_user_data['company_detail']['id'], licence_plate_number__contains=licence_plate_number, speed__gt=int(speed_violation),driver_seat_belt=seat_belt
                #.values('id','licence_plate_number','licence_plate_image','confidence_licence_plate','datetime','speed','speed_violation','lane_change','blacklisted_licence_plate','driver_seat_belt','driver_seat_belt_image','confidence_driver_seat_belt','passanger_seat_belt','passanger_seat_belt_image','confidence_passanger_seat_belt','driver_mobile','driver_mobile_image','confidence_driver_mobile','passanger_mobile','passanger_mobile_image','confidence_passanger_mobile','vehicle_type','vehicle_direction','country','camera_name','created_by','created_datetime','updated_by','updated_datetime','no_of_unpaid_fine').all()
                serializer = DetectedGetViolationChargesSerializer(detected_detail, many=True)
                return Response(serializer.data,status=status.HTTP_200_OK)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)



class DetectedDetailView(APIView):
    permission_classes = (IsAuthenticated,)
    def get_object(self, id):
        try:
            return Detected.objects.get(pk=id)
        except Detected.DoesNotExist:
            raise Http404
    def get(self, request,id, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = get_user_data_page_plans(request.user.id,'detected','create')
        if get_user_data['business_plan_history_detail']['plan_validity'] == True:
            AccessToPage = False
            if get_user_data['permission'] != None:
                AccessToPage = True
            # if 'detected' in get_user_data['permission'].keys():
            #     if 'view' in get_user_data['permission']['detected']:
            #         AccessToPage = True
            if AccessToPage == True:
                detected = self.get_object(id)
                serializer = DetectedDetailSerializer(detected)
                return Response(serializer.data)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
          
    
class PartiallyDetectedView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = get_user_data_page_plans(request.user.id,'detected','create')
        if get_user_data['business_plan_history_detail']['plan_validity'] == True:
            AccessToPage = False
            if get_user_data['permission'] != None:
                AccessToPage = True
            # if 'partially detected' in get_user_data['permission'].keys():
            #     if 'view' in get_user_data['permission']['partially detected']:
            #         AccessToPage = True
            if AccessToPage == True:
                licence_plate_number = request.GET.get('licence_plate_number', None)
                speed_violation = request.GET.get('speed_violation', None)
                seat_belt = request.GET.get('seat_belt', None)
                ordering = request.GET.get('order_by',None)
                from_datetime = request.GET.get('start_datetime',None)
                to_datetime = request.GET.get('end_datetime',None)
                direction = request.GET.get('vehicle_direction',None)
                if ordering ==None:
                    ordering = '-datetime'
                f= Q(company_detail = get_user_data['company_detail']['id'])
                if licence_plate_number != '' and licence_plate_number != None:
                    f &= Q(licence_plate_number__contains=licence_plate_number)
                if speed_violation != '0' and speed_violation != None:
                    f &= Q(speed__gt=int(speed_violation))
                if seat_belt != 'All' and seat_belt != None:
                    f &= Q(driver_seat_belt=seat_belt)
                if from_datetime != None:
                    f &= Q(datetime__gte=from_datetime)
                if to_datetime != None:
                    f &= Q(datetime__lte=to_datetime)
                if direction != 'All' and direction != None:
                    f &= Q(vehicle_direction=direction)
                limit = int(request.GET.get('limit', 10))
                offset = int(request.GET.get('offset', 0))
                partially_detected_detail = PartiallyDetected.objects.filter(f).order_by(ordering).all()[offset:limit+offset] # .values('id','licence_plate_number','datetime','speed','speed_violation','lane_change','driver_seat_belt','passanger_seat_belt','driver_mobile','passanger_mobile','vehicle_type','vehicle_direction','country','camera_name','sites','company_detail_id')
                partially_detected_detail_count = PartiallyDetected.objects.filter(f).order_by(ordering).values('id','licence_plate_number','datetime','speed','speed_violation','lane_change','driver_seat_belt','passanger_seat_belt','driver_mobile','passanger_mobile','vehicle_type','vehicle_direction','country','camera_name','sites','company_detail_id').count()
                serializer = PartiallyDetectedGetTableSerializer(partially_detected_detail, many=True)
                return Response({'count':partially_detected_detail_count,'results':serializer.data})
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class PartiallyDetectedDetailView(APIView):
    permission_classes = (IsAuthenticated,)
    def get_object(self, id):
        try:
            return PartiallyDetected.objects.get(pk=id)
        except PartiallyDetected.DoesNotExist:
            raise Http404
    def get(self, request,id, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = get_user_data_page_plans(request.user.id,'detected','create')
        if get_user_data['business_plan_history_detail']['plan_validity'] == True:
            AccessToPage = False
            if get_user_data['permission'] != None:
                AccessToPage = True
            # if 'partially detected' in get_user_data['permission'].keys():
            #     if 'view' in get_user_data['permission']['partially detected']:
            #         AccessToPage = True
            if AccessToPage == True:
                partially_detected = self.get_object(id)
                serializer = PartiallyDetectedDetailSerializer(partially_detected)
                return Response(serializer.data)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
          
    def delete(self, request,id, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = get_user_data_page_plans(request.user.id,'detected','create')
        if get_user_data['business_plan_history_detail']['plan_validity'] == True:
            AccessToPage = False
            if get_user_data['permission'] != None:
                AccessToPage = True
            # if 'partially detected' in get_user_data['permission'].keys():
            #     if 'delete' in get_user_data['permission']['partially detected']:
            #         AccessToPage = True
            if AccessToPage == True:
                partially_detected = self.get_object(id)
                violation_fine = None
                try:
                    violation_fine = PartiallyDetectedViolationFines.objects.filter(violation=id).all()
                except PartiallyDetectedViolationFines.DoesNotExist:
                    raise Http404
                partially_detected.delete()
                violation_fine.delete()
                return Response(status=status.HTTP_204_NO_CONTENT)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
    
    
class BlackListedNumberView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = get_user_data_page_plans(request.user.id,'detected','create')
        if get_user_data['business_plan_history_detail']['plan_validity'] == True:
            AccessToPage = False
            if get_user_data['permission'] != None:
                AccessToPage = True
            # if 'black listed' in get_user_data['permission'].keys():
            #     if 'view' in get_user_data['permission']['black listed']:
            #         AccessToPage = True
            if AccessToPage == True:
                limit = int(request.GET.get('limit', 10))
                offset = int(request.GET.get('offset', 0))
                black_listed_number_detail = BlackListedNumber.objects.filter(company_detail = get_user_data['company_detail']['id']).all()[offset:limit+offset]
                black_listed_number_detail_count = BlackListedNumber.objects.filter(company_detail = get_user_data['company_detail']['id']).count()
                serializer = BlackListedNumberSerializer(black_listed_number_detail, many=True)
                return Response({'count':black_listed_number_detail_count,'results':serializer.data})
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def post(self, request, format=None):
        get_user_data = get_user_data_page_plans(request.user.id,'detected','create')
        if get_user_data['business_plan_history_detail']['plan_validity'] == True:
            AccessToPage = False
            if get_user_data['permission'] != None:
                AccessToPage = True
            # if 'black listed' in get_user_data['permission'].keys():
            #     if 'create' in get_user_data['permission']['black listed']:
            #         AccessToPage = True
            if AccessToPage == True:
                get_data = request.data
                get_data['company_detail'] = get_user_data['company_detail']['id']
                get_data['user'] = request.user.id
                serializer = BlackListedNumberSerializer(data=get_data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)



class BlackListedDetailView(APIView):
    permission_classes = (IsAuthenticated,)
    def get_object(self, id):
        try:
            return BlackListedNumber.objects.get(pk=id)
        except BlackListedNumber.DoesNotExist:
            raise Http404
    def get(self, request,id, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = get_user_data_page_plans(request.user.id,'detected','create')
        if get_user_data['business_plan_history_detail']['plan_validity'] == True:
            AccessToPage = False
            if get_user_data['permission'] != None:
                AccessToPage = True
            # if 'black listed' in get_user_data['permission'].keys():
            #     if 'view' in get_user_data['permission']['black listed']:
            #         AccessToPage = True
            if AccessToPage == True:
                black_listed = self.get_object(id)
                serializer = BlackListedNumberSerializer(black_listed)
                return Response(serializer.data)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
    def put(self, request, id, format=None): 
        get_user_data = get_user_data_page_plans(request.user.id,'detected','create')
        if get_user_data['business_plan_history_detail']['plan_validity'] == True:
            AccessToPage = False
            if get_user_data['permission'] != None:
                AccessToPage = True
            # if 'black listed' in get_user_data['permission'].keys():
            #     if 'update' in get_user_data['permission']['black listed']:
            #         AccessToPage = True
            if AccessToPage == True:
                black_listed = self.get_object(id)
                get_data = request.data
                get_data['company_detail'] = get_user_data['company_detail']['id']
                get_data['user'] = request.user.id
                serializer = BlackListedNumberSerializer(black_listed, data=get_data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)  
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
     
    def delete(self, request,id, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = get_user_data_page_plans(request.user.id,'detected','create')
        if get_user_data['business_plan_history_detail']['plan_validity'] == True:
            AccessToPage = False
            if get_user_data['permission'] != None:
                AccessToPage = True
            # if 'black listed' in get_user_data['permission'].keys():
            #     if 'delete' in get_user_data['permission']['black listed']:
            #         AccessToPage = True
            if AccessToPage == True:
                add_user_email = self.get_object(id)
                add_user_email.delete()
                return Response(status=status.HTTP_204_NO_CONTENT)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
 

class DetectedViolationFinesView(APIView):
    def get_object(self, id):
        try:
            return DetectedViolationFines.objects.get(pk=id)
        except DetectedViolationFines.DoesNotExist:
            raise Http404
    def get(self, request, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = get_user_data_page_plans(request.user.id,'detected','create')
        if get_user_data['business_plan_history_detail']['plan_validity'] == True:
            AccessToPage = False
            if get_user_data['permission'] != None:
                AccessToPage = True
            # if 'detected' in get_user_data['permission'].keys():
            #     if 'view' in get_user_data['permission']['black listed']:
            #         AccessToPage = True
            if AccessToPage == True:
                list_id = request.GET.get('list_id', None)
                print(list_id)
                list_fine_id = []
                if list_id != None:
                    list_id.replace('[','')
                    list_id.replace(']','')
                    list_fine_id = list_id.split(',')
                print(list_fine_id)
                for id in list_fine_id:
                    violation_fine = self.get_object(int(id))
                    violation_fine.fine_collected=True
                    violation_fine.save()
                return Response({"detail": "Updated Record."},status=status.HTTP_200_OK)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
      


#filter
from django.db.models import Count, Sum, Case, When, F
from django.http import JsonResponse
from django.views.decorators.http import require_GET
from .models import Detected, DetectedViolationFines
from django.views import View


class FilterDataView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self,request, format=None):
        start_date = request.GET.get('start_date')
        end_date = request.GET.get('end_date')

        # Parse and make dates timezone aware if needed
        # start_date = make_aware(datetime.strptime(start_date, "%Y-%m-%d"))
        # end_date = make_aware(datetime.strptime(end_date, "%Y-%m-%d"))


        user_detail_page = getUserDataPage(request.user.id, 'filter', 'view')

        company_detail = user_detail_page['company_detail']
        detected_qs = Detected.objects.filter(datetime__gte=start_date, datetime__lte=end_date,company_detail=user_detail_page['company_detail']['id'])


        vmtc_count = 0
        odv_count = 0
        for data in detected_qs:
            if data.vehicle_direction=='VMTC':
                vmtc_count += 1
            elif data.vehicle_direction=='ODV':
                odv_count += 1



        seat_belt_violation_count = 0
        mobile_violation_count = 0
        speed_violation_count = 0

        for record in detected_qs:
            if record.driver_seat_belt == 'No':
                seat_belt_violation_count += 1
            
            if record.driver_mobile=='Yes':
                mobile_violation_count += 1

            if record.speed_violation == True:
                speed_violation_count += 1

        total_violation_count=seat_belt_violation_count + mobile_violation_count + speed_violation_count

        # Filter the DetectedViolationFines queryset by start and end dates
        fines_qs = DetectedViolationFines.objects.filter(detected__datetime__gte=start_date, detected__datetime__lte=end_date,detected__company_detail=user_detail_page['company_detail']['id'])

        # Count the total number of fines and the total number of collected fines
        total_fines = fines_qs.count()
        collected_fines = fines_qs.filter(fine_collected=True).count()

        # Sum the total fine (charges) and the total collected fine (charges)
        total_fine_charges = fines_qs.aggregate(Sum('sub_violation_and_charges__charges'))['sub_violation_and_charges__charges__sum']
        collected_fine_charges = fines_qs.filter(fine_collected=True).aggregate(Sum('sub_violation_and_charges__charges'))['sub_violation_and_charges__charges__sum']

        # Create a dictionary with the desired format
        results = {
            'company_details': company_detail,
            #'filter': {'StartDateTime': start_date, 'EndDateTime': end_date},
            'vehicle_direction': {
            'VMTC':{},
            'ODV':{}
            },
            'violations': {
            'seat_belt_violation': {},
            'mobile_violation': {},
            'speed_violation': {},
            'total_violation': {}
            },
            'chalan': {
                'total_chalan': total_fines,
                'collected_chalan': collected_fines,
                'total_chalan_charges': total_fine_charges,
                'collected_chalan_charges': collected_fine_charges,
                'filter': {'StartDateTime': start_date, 'EndDateTime': end_date}
            },
        }


        # Add direction data to results
        results['vehicle_direction']['VMTC'] = {'count': vmtc_count, 'filter': {'direction': 'VMTC','StartDateTime': start_date, 'EndDateTime': end_date}}
        results['vehicle_direction']['ODV'] = {'count': odv_count, 'filter': {'direction': 'ODV','StartDateTime': start_date, 'EndDateTime': end_date}}


        # Add violation data to results
        results['violations']['seat_belt_violation'] = {
                    'count': seat_belt_violation_count,
                    'filter': {
                        'violation': 'seat_belt_violation',
                        'StartDateTime': start_date,
                        'EndDateTime': end_date
                    }
                }
        
        
        results['violations']['mobile_violation'] = {
                    'count': mobile_violation_count,
                    'filter': {
                        'violation': 'mobile_violation',
                        'StartDateTime': start_date,
                        'EndDateTime': end_date
                    }
                }
        
        results['violations']['speed_violation'] = {
                    'count': speed_violation_count,
                    'filter': {
                        'violation': 'speed_violation',
                        'StartDateTime': start_date,
                        'EndDateTime': end_date
                    }
                }
        
        
        results['violations']['total_violation'] = {
                    'count': total_violation_count,
                    'filter': {
                        'violation': 'total_violation',
                        'StartDateTime': start_date,
                        'EndDateTime': end_date
                    }
                }


        
        return JsonResponse(results, safe=False)
    

class InOutGateView(APIView):
    permission_classes = (IsAuthenticated,)
    def convert_base64_to_image(self, base64_data):
        # Decode the base64 data
        image_data = base64.b64decode(base64_data)

        # Create a PIL Image object from the image data
        image = Image.open(BytesIO(image_data))
        return image

    def upload_image_to_s3(self, image,file_path):
        image_io = BytesIO()
        image.save(image_io, format='JPEG')

        # Set the S3 object key
        file_name = file_path
        storage = default_storage
        image_file = storage.save(f'{file_name}', image_io)
        return image_file

    def post(self,request, format=None):
        get_data = request.data
        licence_plate_image_data = get_data['licence_plate_image']
        # get_company_name = CompanyDetail.objects.filter(id=get_data['company_detail']).values('company_name').first()
        # get_site_name = Sites.objects.filter(id=get_data['sites']).values('site_name').first()
        # datetime_format = datetime.strptime(get_data['datetime'],'%Y-%m-%d %H:%M:%S.%f%z')
        # get_date_string = str(datetime_format.date())

        if licence_plate_image_data != None:
            image = self.convert_base64_to_image(licence_plate_image_data['image_base64'])
            folder_path = 'violation_surveillance_management/licence_plate_image/'+get_data['camera_name']  # Modify this as per your requirements
            object_key = os.path.join(folder_path, licence_plate_image_data['image_name'])
            get_data['licence_plate_image'] = self.upload_image_to_s3(image,object_key)
            
        for index,data in enumerate(get_data['in_out_gate_frame']):
            frame_image_data = data['frame_image']
            if frame_image_data != None:
                image = self.convert_base64_to_image(frame_image_data['image_base64'])
                folder_path = 'violation_surveillance_management/frame_image/'+get_data['camera_name']  # Modify this as per your requirements

                object_key = os.path.join(folder_path, frame_image_data['image_name'])
                get_data['in_out_gate_frame'][index]['frame_image'] = self.upload_image_to_s3(image,object_key)

        in_out_gate_serializer = InOutGateSerializer(data=get_data)
        if in_out_gate_serializer.is_valid(raise_exception=True):
            in_out_gate_serializer.save()
            return Response(in_out_gate_serializer.data, status=status.HTTP_201_CREATED)
        return Response(in_out_gate_serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    def get(self, request):
        get_user_data = get_user_data_page_plans(request.user.id,'detected','create')
        if get_user_data['business_plan_history_detail']['plan_validity'] == True:
            AccessToPage = False
            if get_user_data['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                licence_plate_number = request.GET.get('licence_plate_number', None)
                limit = int(request.GET.get('limit',10))
                offset = int(request.GET.get('offset',0))
                in_out = request.GET.get('in_out', None)
                ordering = request.GET.get('order_by',None)
                from_datetime = request.GET.get('start_datetime',None)
                to_datetime = request.GET.get('end_datetime',None)
                vehicle_type = request.GET.get('vehicle_type',None)
                camera_name = request.GET.get('camera_name',None)
                if ordering ==None:
                    ordering = '-datetime'
                f= Q(company_detail = get_user_data['company_detail']['id'])
                if licence_plate_number != '' and licence_plate_number != None:
                    f &= Q(licence_plate_number__contains=licence_plate_number)
                if in_out != 'All' and in_out != None:
                    f &= Q(in_out=in_out)
                if vehicle_type != 'All' and vehicle_type != None:
                    f &= Q(vehicle_type=vehicle_type)
                if from_datetime != None:
                        f &= Q(datetime__gte=from_datetime)
                if to_datetime != None:
                    f &= Q(datetime__lte=to_datetime)
                if camera_name != '' and camera_name != None:
                    f &= Q(camera_name=camera_name)
                in_out_gate_detail = InOutGate.objects.filter(f).order_by(ordering).values('id','licence_plate_number','datetime','blacklisted_licence_plate','vehicle_type','country','make','model','camera_name','in_out')[offset:limit+offset]
                in_out_gate_count = InOutGate.objects.filter(f).order_by(ordering).count()
                serializer = InOutGateGetTableSerializer(in_out_gate_detail, many=True)
                return Response({'count':in_out_gate_count,'results':serializer.data})
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

class InOutGateDetailView(APIView):
    permission_classes = (IsAuthenticated,)
    def get_object(self, id):
        try:
            return InOutGate.objects.get(pk=id)
        except InOutGate.DoesNotExist:
            raise Http404
    def get(self, request,id, format=None):
        get_user_data = get_user_data_page_plans(request.user.id,'detected','create')
        if get_user_data['business_plan_history_detail']['plan_validity'] == True:
            AccessToPage = False
            if get_user_data['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                in_out_gate = self.get_object(id)
                serializer = InOutGateDetailSerializer(in_out_gate)
                return Response(serializer.data)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
