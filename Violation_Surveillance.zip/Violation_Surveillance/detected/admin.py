from django.contrib import admin
from .models import *
# Register your models here.

class ViolationAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','violation_name','data_type','created_by','created_datetime','updated_by','updated_datetime')

class SubViolationAndChargesAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','violation','sub_violation_name','charges','company_detail','created_by','created_datetime','updated_by','updated_datetime')

class BlackListedNumberAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','licence_plate_number','reason_blacklist','datetime','user','company_detail','created_by','created_datetime','updated_by','updated_datetime')

class DetectedAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','licence_plate_number','licence_plate_image','confidence_licence_plate','datetime','speed','speed_violation','lane_change','blacklisted_licence_plate','driver_seat_belt','driver_seat_belt_image','confidence_driver_seat_belt','passanger_seat_belt','passanger_seat_belt_image','confidence_passanger_seat_belt','driver_mobile','driver_mobile_image','confidence_driver_mobile','passanger_mobile','passanger_mobile_image','confidence_passanger_mobile','vehicle_type','vehicle_direction','country','camera_name','company_detail','detected_frame')

class DetectedFrameImageAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','frame_image','detected','created_by','created_datetime','updated_by','updated_datetime')

class DetectedViolationFinesAdmin(admin.ModelAdmin):
    list_disply = ('id','uuid','violation','sub_violation_and_charges','fine_collected','detected','created_by','created_datetime','updated_by','updated_datetime')

class PartiallyDetectedAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','licence_plate_number','licence_plate_image','confidence_licence_plate','datetime','speed','speed_violation','lane_change','driver_seat_belt','driver_seat_belt_image','confidence_driver_seat_belt','passanger_seat_belt','passanger_seat_belt_image','confidence_passanger_seat_belt','driver_mobile','driver_mobile_image','confidence_driver_mobile','passanger_mobile','passanger_mobile_image','confidence_passanger_mobile','vehicle_type','vehicle_direction','country','camera_name','company_detail','created_by','created_datetime','updated_by','updated_datetime')

class PartiallyDetectedFrameImageAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','frame_image','partially_detected','created_by','created_datetime','updated_by','updated_datetime')

class PartiallyDetectedViolationFinesAdmin(admin.ModelAdmin):
    list_disply = ('id','uuid','violation','sub_violation_and_charges','fine_collected','partially_detected','created_by','created_datetime','updated_by','updated_datetime')


admin.site.register(Violation,ViolationAdmin)
admin.site.register(SubViolationAndCharges, SubViolationAndChargesAdmin)
admin.site.register(BlackListedNumber, BlackListedNumberAdmin)
admin.site.register(Detected, DetectedAdmin)
admin.site.register(DetectedFrameImage,DetectedFrameImageAdmin)
admin.site.register(DetectedViolationFines,DetectedViolationFinesAdmin)
admin.site.register(PartiallyDetected,PartiallyDetectedAdmin)
admin.site.register(PartiallyDetectedFrameImage,PartiallyDetectedFrameImageAdmin)
admin.site.register(PartiallyDetectedViolationFines,PartiallyDetectedViolationFinesAdmin)

