from rest_framework.serializers import ModelSerializer
from account.models import User,CompanyDetail,Roles,Permission,UserRoleMapping,AddUserEmail,UserType,MenuPage  ##UserRolePermission
from rest_framework.validators import UniqueValidator
from django.contrib.auth.password_validation import validate_password
from .models import Detected,DetectedFrameImage,DetectedViolationFines,PartiallyDetected,PartiallyDetectedFrameImage,PartiallyDetectedViolationFines,Violation,SubViolationAndCharges, BlackListedNumber, InOutGate, InOutGateFrameImage
from rest_framework import serializers

class ViolationSerializer(ModelSerializer):
    class Meta:
        model = Violation
        fields = ['id','violation_name','data_type']

class SubViolationAndChargesSerializer(ModelSerializer):
    class Meta:
        model = SubViolationAndCharges
        fields = ['id','violation','sub_violation_name','charges','company_detail']

class DetectedFrameImageSerializer(ModelSerializer):
    frame_image = serializers.CharField()
    class Meta:
        model = DetectedFrameImage
        fields = ['id','frame_image']
    

class DetectedGetTableSerializer(ModelSerializer):
    site_name = serializers.CharField(source='sites.site_name',read_only=True)
    class Meta:
        model = Detected
        fields = ('id','licence_plate_number','datetime','speed','speed_violation','lane_change','blacklisted_licence_plate','driver_seat_belt','passanger_seat_belt','driver_mobile','passanger_mobile','vehicle_type','vehicle_direction','country','camera_name','sites','site_name')


class DetectedViolationFinesSerializer(ModelSerializer):
    # detected_violation = ViolationSerializer(many=True,read_only=True)
    # detected_sub_violation_charge = SubViolationAndChargesSerializer(many=True,read_only=True)
    violation_name = serializers.ReadOnlyField(source='violation.violation_name')
    charges = serializers.ReadOnlyField(source='sub_violation_and_charges.charges')
    sub_violation_name = serializers.ReadOnlyField(source='sub_violation_and_charges.sub_violation_name')
    class Meta:
        model = DetectedViolationFines
        fields = ['id','violation','sub_violation_and_charges','fine_collected','violation_name','charges','sub_violation_name']

class DetectedGetViolationChargesSerializer(ModelSerializer):
    detected_violationfine = DetectedViolationFinesSerializer(many=True,read_only=True)
    detected_frame = DetectedFrameImageSerializer(many=True, read_only=True)
    site_name = serializers.CharField(source='sites.site_name',read_only=True)
    class Meta:
        model = Detected
        fields = ['id','licence_plate_number','licence_plate_image','datetime','speed','speed_violation','lane_change','blacklisted_licence_plate','driver_seat_belt','passanger_seat_belt','driver_mobile','passanger_mobile','vehicle_type','vehicle_direction','country','camera_name','sites','detected_violationfine','detected_frame','site_name']

class DetectedSerializer(ModelSerializer):    
    detected_frame = DetectedFrameImageSerializer(many=True,write_only=True)
    licence_plate_image = serializers.CharField()
    driver_seat_belt_image = serializers.CharField(required=False,allow_null=True)
    passanger_seat_belt_image = serializers.CharField(required=False,allow_null=True)
    driver_mobile_image = serializers.CharField(required=False,allow_null=True)
    passanger_mobile_image = serializers.CharField(required=False,allow_null=True)
    no_of_unpaid_fine = serializers.IntegerField(read_only=True)
    def create(self, validated_data):
        detected_frames = validated_data.pop('detected_frame')
        detected_data = Detected.objects.create(**validated_data)
        for frame in detected_frames:
            DetectedFrameImage.objects.create(detected=detected_data,**frame)
        return detected_data
    class Meta:
        model = Detected
        fields = ('id','licence_plate_number','licence_plate_image','confidence_licence_plate','datetime','speed','speed_violation','lane_change','blacklisted_licence_plate','driver_seat_belt','driver_seat_belt_image','confidence_driver_seat_belt','passanger_seat_belt','passanger_seat_belt_image','confidence_passanger_seat_belt','driver_mobile','driver_mobile_image','confidence_driver_mobile','passanger_mobile','passanger_mobile_image','confidence_passanger_mobile','vehicle_type','vehicle_direction','country','camera_name','sites','company_detail','detected_frame','no_of_unpaid_fine')


class DetectedDetailSerializer(ModelSerializer):
    detected_frame = DetectedFrameImageSerializer(many=True, read_only=True)
    no_of_unpaid_fine = serializers.IntegerField()
    site_name = serializers.CharField(source='sites.site_name',read_only=True)
    class Meta:
        model = Detected
        fields = ['id','licence_plate_number','licence_plate_image','confidence_licence_plate','datetime','speed','speed_violation','lane_change','blacklisted_licence_plate','driver_seat_belt','driver_seat_belt_image','confidence_driver_seat_belt','passanger_seat_belt','passanger_seat_belt_image','confidence_passanger_seat_belt','driver_mobile','driver_mobile_image','confidence_driver_mobile','passanger_mobile','passanger_mobile_image','confidence_passanger_mobile','vehicle_type','vehicle_direction','country','camera_name','sites','site_name','no_of_unpaid_fine','detected_frame']


class PartiallyDetectedFrameImageSerializer(ModelSerializer):
    frame_image = serializers.CharField()
    class Meta:
        model = PartiallyDetectedFrameImage
        fields = ['id','frame_image']

class PartiallyDetectedGetTableSerializer(ModelSerializer):
    site_name = serializers.CharField(source='sites.site_name',read_only=True)
    class Meta:
        model = PartiallyDetected
        fields = ('id','licence_plate_number','datetime','speed','speed_violation','lane_change','driver_seat_belt','passanger_seat_belt','driver_mobile','passanger_mobile','vehicle_type','vehicle_direction','country','camera_name','sites','site_name','company_detail')

class PartiallyDetectedSerializer(ModelSerializer):
    partially_detected_frame = PartiallyDetectedFrameImageSerializer(many=True,write_only=True)
    licence_plate_image = serializers.CharField()
    driver_seat_belt_image = serializers.CharField()
    passanger_seat_belt_image = serializers.CharField()
    driver_mobile_image = serializers.CharField()
    passanger_mobile_image = serializers.CharField()
    no_of_unpaid_fine = serializers.IntegerField(read_only=True)
    def create(self, validated_data):
        partially_detected_frames = validated_data.pop('partially_detected_frame')
        partially_detected_data = PartiallyDetected.objects.create(**validated_data)
        for frame in partially_detected_frames:
            PartiallyDetectedFrameImage.objects.create(partially_detected=partially_detected_data,**frame)
        return partially_detected_data
    class Meta:
        model = PartiallyDetected
        fields = ['id','licence_plate_number','licence_plate_image','confidence_licence_plate','datetime','speed','speed_violation','lane_change','driver_seat_belt','driver_seat_belt_image','confidence_driver_seat_belt','passanger_seat_belt','passanger_seat_belt_image','confidence_passanger_seat_belt','driver_mobile','driver_mobile_image','confidence_driver_mobile','passanger_mobile','passanger_mobile_image','confidence_passanger_mobile','vehicle_type','vehicle_direction','country','camera_name','sites','company_detail','no_of_unpaid_fine','partially_detected_frame']

class PartiallyDetectedDetailSerializer(ModelSerializer):
    partially_detected_frame = PartiallyDetectedFrameImageSerializer(many=True,read_only=True)
    no_of_unpaid_fine = serializers.IntegerField()
    site_name = serializers.CharField(source='sites.site_name',read_only=True)
    class Meta:
        model = PartiallyDetected
        fields = ['id','licence_plate_number','licence_plate_image','confidence_licence_plate','datetime','speed','speed_violation','lane_change','driver_seat_belt','driver_seat_belt_image','confidence_driver_seat_belt','passanger_seat_belt','passanger_seat_belt_image','confidence_passanger_seat_belt','driver_mobile','driver_mobile_image','confidence_driver_mobile','passanger_mobile','passanger_mobile_image','confidence_passanger_mobile','vehicle_type','vehicle_direction','country','camera_name','sites','site_name','no_of_unpaid_fine','partially_detected_frame']


class BlackListedNumberSerializer(ModelSerializer):
    class Meta:
        model = BlackListedNumber
        fields = ['id','licence_plate_number','reason_blacklist','datetime','user','company_detail']
    def create(self, validate_data):
        if BlackListedNumber.objects.filter(licence_plate_number=validate_data['licence_plate_number'], company_detail=validate_data['company_detail']).exists():
            raise serializers.ValidationError(
                {'licence_plate_number': 'Licence plate number are already exist.'})
        return BlackListedNumber.objects.create(**validate_data)

    def update(self, instance, validate_data):
        if BlackListedNumber.objects.filter(licence_plate_number=validate_data['licence_plate_number'], company_detail=validate_data['company_detail']).exclude(id=instance.pk).exists():
            raise serializers.ValidationError(
                {'licence_plate_number': 'Licence plate number are already exist.'})
        return super().update(instance, validate_data)


class InOutGateFrameImageSerializer(ModelSerializer):
    frame_image = serializers.CharField()
    class Meta:
        model = InOutGateFrameImage
        fields = ['id','frame_image']

class InOutGateGetTableSerializer(ModelSerializer):
   
    class Meta:
        model = InOutGate
        fields = ('id','licence_plate_number','datetime','blacklisted_licence_plate','vehicle_type','country','make','model','camera_name','in_out')


class InOutGateSerializer(ModelSerializer):    
    in_out_gate_frame = InOutGateFrameImageSerializer(many=True,write_only=True)
    licence_plate_image = serializers.CharField()
    
    def create(self, validated_data):
        in_out_gate_frames = validated_data.pop('in_out_gate_frame')
        in_out_gate_data = InOutGate.objects.create(**validated_data)
        for frame in in_out_gate_frames:
            InOutGateFrameImage.objects.create(in_out_gate=in_out_gate_data,**frame)
        return in_out_gate_data

    class Meta:
        model = InOutGate
        fields = ('id','licence_plate_number','licence_plate_image','datetime','blacklisted_licence_plate','vehicle_type','country','make','model','camera_name','in_out','user','company_detail','sites','in_out_gate_frame')


class InOutGateDetailSerializer(ModelSerializer):
    in_out_gate_frame = InOutGateFrameImageSerializer(many=True, read_only=True)
    class Meta:
        model = InOutGate
        fields = ('id','licence_plate_number','licence_plate_image','datetime','blacklisted_licence_plate','vehicle_type','country','make','model','camera_name','in_out','in_out_gate_frame')
