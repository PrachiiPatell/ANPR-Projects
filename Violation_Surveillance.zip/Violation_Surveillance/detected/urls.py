from django.conf.urls import url
from django.urls import path,reverse,reverse_lazy
from detected import views
from django.conf.urls.static import static
from django.conf import settings 
from django.contrib.auth import views as auth_views
from .views import *
app_name = 'detect'
urlpatterns = [
    # path('register/', views.register, name='register'),
    path('detected', views.DetectedView.as_view()),
    path('detected/<int:id>', views.DetectedDetailView.as_view()),
    path('partially-detected', views.PartiallyDetectedView.as_view()),
    path('partially-detected/<int:id>', views.PartiallyDetectedDetailView.as_view()),
    path('detected-temp',views.DetectedTempView.as_view()),  
    path('partially-detected-temp',views.PartiallyDetectedTempView.as_view()),
    path('black-listed-number',views.BlackListedNumberView.as_view()),
    path('black-listed-number/<int:id>',views.BlackListedDetailView.as_view()),
    path('generate-challan',views.GenerateChallanView.as_view()),
    path('detected-violation-fine',views.DetectedViolationFinesView.as_view()),
    path('filter_data/', views.FilterDataView.as_view(), name='filter_data'),

    path('in-out-gate', views.InOutGateView.as_view()),
    path('in-out-gate-detail/<int:id>', views.InOutGateDetailView.as_view()),
    # path('api/login',views.Login.as_view()),
] + static(settings.STATIC_URL)

# + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)