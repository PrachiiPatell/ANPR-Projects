from django.db import models
# from django.contrib.auth.models import User
import datetime
import uuid
from django.contrib.postgres.functions import RandomUUID
import pytz
from django.contrib.auth.models import (
    BaseUserManager, AbstractBaseUser
)
import django
# Create your models here.

class UserManager(BaseUserManager):
    def create_user(self, email, password=None):
        """
        Creates and saves a User with the given email and password.
        """
        if not email:
            raise ValueError('Users must have an email address')

        user = self.model(
            email=self.normalize_email(email),
        )

        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_staffuser(self, email, password):
        """
        Creates and saves a staff user with the given email and password.
        """
        user = self.create_user(
            email,
            password=password,
        )
        user.staff = True
        user.save(using=self._db)
        return user

    def create_superuser(self, email, password):
        """
        Creates and saves a superuser with the given email and password.
        """
        user = self.create_user(
            email,
            password=password,
            
        )
        user.staff = True
        user.admin = True
        user.save(using=self._db)
        return user


class CompanyDetail(models.Model):
    Uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    CompanyName = models.CharField(max_length=50)
    Country = models.CharField(max_length=20)
    UsesType = models.CharField(max_length=100,default='free trail')
    Speed = models.BooleanField(default=False)
    LaneChange = models.BooleanField(default=False)
    StartDateTime = models.DateTimeField(default=django.utils.timezone.now)
    EndDateTime = models.DateTimeField(default=django.utils.timezone.now)
    AccountValidity = models.BooleanField(default=True)
    CreatedBy = models.CharField(max_length=50,blank=True, null=True)
    CreatedDateTime = models.DateTimeField(default=django.utils.timezone.now)
    UpdatedBy = models.CharField(max_length=50,blank=True, null=True)
    UpdatedDateTime = models.DateTimeField(default=django.utils.timezone.now)

class Role(models.Model):
    Uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    RoleName = models.CharField(max_length=50)
    CompanyDetailId = models.ForeignKey(CompanyDetail, on_delete=models.CASCADE)
    CreatedBy = models.CharField(max_length=50,blank=True, null=True)
    CreatedDateTime = models.DateTimeField(default=django.utils.timezone.now)
    UpdatedBy = models.CharField(max_length=50,blank=True, null=True)
    UpdatedDateTime = models.DateTimeField(default=django.utils.timezone.now)

class Permission(models.Model):
    Uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    PermissionName = models.CharField(max_length=100)
    CompanyDetailId = models.ForeignKey(CompanyDetail, on_delete=models.CASCADE)
    CreatedBy = models.CharField(max_length=50,blank=True, null=True)
    CreatedDateTime = models.DateTimeField(default=django.utils.timezone.now)
    UpdatedBy = models.CharField(max_length=50,blank=True, null=True)
    UpdatedDateTime = models.DateTimeField(default=django.utils.timezone.now)

class UserRolePermission(models.Model):
    Uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    RoleId = models.ForeignKey(Role, on_delete=models.CASCADE)
    PermissionId = models.ForeignKey(Permission, on_delete=models.CASCADE)
    CompanyDetailId = models.ForeignKey(CompanyDetail, on_delete=models.CASCADE)
    CreatedBy = models.CharField(max_length=50,blank=True, null=True)
    CreatedDateTime = models.DateTimeField(default=django.utils.timezone.now)
    UpdatedBy = models.CharField(max_length=50,blank=True, null=True)
    UpdatedDateTime = models.DateTimeField(default=django.utils.timezone.now)


class User(AbstractBaseUser):
    Uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    email = models.EmailField(verbose_name='email address',max_length=255,unique=True,)
    CompanyDetailId = models.ForeignKey(CompanyDetail, on_delete=models.CASCADE)
    UserLoginOrNot = models.BooleanField(default=False)
    timezones = models.CharField(max_length=50,default='Asia/Kolkata')
    is_active = models.BooleanField(default=False)
    staff = models.BooleanField(default=False) # a admin user; non super-user
    admin = models.BooleanField(default=False) # a superuser
    CreatedBy = models.CharField(max_length=50,blank=True, null=True)
    CreatedDateTime = models.DateTimeField(default=django.utils.timezone.now)
    UpdatedBy = models.CharField(max_length=50,blank=True, null=True)
    UpdatedDateTime = models.DateTimeField(default=django.utils.timezone.now)

    # notice the absence of a "Password field", that is built in.

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['CompanyDetailId'] # Email & Password are required by default.
    objects = UserManager()
    def get_full_name(self):
        # The user is identified by their email address
        return self.email

    def get_short_name(self):
        # The user is identified by their email address
        return self.email

    def __str__(self):
        return self.email

    def has_perm(self, perm, obj=None):
        "Does the user have a specific permission?"
        # Simplest possible answer: Yes, always
        return True

    def has_module_perms(self, app_label):
        "Does the user have permissions to view the app `app_label`?"
        # Simplest possible answer: Yes, always
        return True

    @property
    def is_staff(self):
        "Is the user a member of staff?"
        return self.staff

    @property
    def is_admin(self):
        "Is the user a admin member?"
        return self.admin

class UserRoleMapping(models.Model):
    Uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    UserId = models.ForeignKey(User, on_delete=models.CASCADE)
    RoleId = models.ForeignKey(Role, on_delete=models.CASCADE)
    CompanyDetailId = models.ForeignKey(CompanyDetail, on_delete=models.CASCADE)
    CreatedBy = models.CharField(max_length=50,blank=True, null=True)
    CreatedDateTime = models.DateTimeField(default=django.utils.timezone.now)
    UpdatedBy = models.CharField(max_length=50,blank=True, null=True)
    UpdatedDateTime = models.DateTimeField(default=django.utils.timezone.now)


# class UserProfileInformation(models.Model):
#     Uuid = models.UUIDField(default = uuid.uuid4,editable = False)
#     user=models.OneToOneField(User,on_delete=models.CASCADE)   
#     UserLoginOrNot = models.BooleanField(default=False)
#     timezones = models.CharField(max_length=50,default='Asia/Kolkata')
#     CreatedBy = models.CharField(max_length=50,blank=True, null=True)
#     CreatedDateTime = models.DateTimeField(default=django.utils.timezone.now)
#     UpdatedBy = models.CharField(max_length=50,blank=True, null=True)
#     UpdatedDateTime = models.DateTimeField(default=django.utils.timezone.now)



# class PrimaryIndustryOption(models.Model):
#     Industry = models.CharField(max_length=100)

# class PrimaryUseCaseOption(models.Model):
#     UseCase = models.CharField(max_length=100)
    