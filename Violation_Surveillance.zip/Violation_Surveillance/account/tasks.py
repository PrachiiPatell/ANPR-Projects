import django
import logging
django.setup()

from account.models import *
from celery import shared_task
from django.utils import timezone
from django.contrib.auth import get_user_model
import requests
from django.core.mail import send_mail as django_send_mail
from django.template.loader import render_to_string
from django.utils.html import strip_tags
from datetime import timedelta
from django.utils import timezone
from django.core.mail import send_mail

@shared_task
def notify_expired_plans():
    now = timezone.now()

    for schedule in Schedule.objects.all():
        #days_threshold = schedule.days
        #expiration_date = now - timezone.timedelta(days=days_threshold)
        reminder_days = schedule.days  
        reminder_date = now + timezone.timedelta(days=reminder_days)
        
       
        plans_to_remind = BusinessPlanHistory.objects.filter(
            plan_expire_datetime__lte=reminder_date,
            plan_expire_datetime__gt=now
        )
        
        for plan in plans_to_remind:
            company_detail = plan.company_detail
            user = User.objects.filter(company_detail=company_detail).first()
            
            if user:
                user_email = user.email
                plan_name = plan.plan_name
                plan_expire_date = plan.plan_expire_datetime.strftime('%Y-%m-%d')
                send_mail(
                    'Plan Expiry Reminder',
                    f'Dear User,\n\nYour plan "{plan_name}" is set to expire on {plan_expire_date}. Please take necessary action.\n\nThank you!',
                    'anprsolutionsllp@gmail.com',
                    [user_email],
                    fail_silently=False,
                )
                print(f'Sent reminder email for plan {plan.uuid} to {user_email}')