from rest_framework import serializers
from .models import *
from rest_framework.validators import UniqueValidator
from django.contrib.auth.password_validation import validate_password
from rest_framework.validators import UniqueTogetherValidator

class CurrencySerializer(serializers.ModelSerializer):
    currency_type = serializers.CharField(required=True,validators=[UniqueValidator(queryset=Currency.objects.all())])
    currency_symbol = serializers.CharField(required=True,validators=[UniqueValidator(queryset=Currency.objects.all())])
    class Meta:
        model = Currency
        fields = ['id','currency_type','currency_symbol']
class CompanyDetailSerializer(serializers.ModelSerializer):
    company_name = serializers.CharField(required=True,validators=[UniqueValidator(queryset=CompanyDetail.objects.all())])
    class Meta:
        model = CompanyDetail
        fields = ['id','company_name','country','uses_type','anpr_check_allowed','blacklist_check_allowed','speed_check_allowed','lane_change_check_allowed','seat_belt_check_allowed','mobile_check_allowed','plan_start_datetime','plan_expire_datetime','days_to_expire','minutes_to_expire','plan_validity','currency']

class AddUserEmailSerializer(serializers.ModelSerializer):
    email = serializers.EmailField(required=True,validators=[UniqueValidator(queryset=AddUserEmail.objects.all())])
    role_name = serializers.CharField(source='role.role_name', read_only=True)
    class Meta:
        model = AddUserEmail
        fields = ['id','email','role','role_name','company_detail']
        
class RoleSerializer(serializers.ModelSerializer):
    class Meta:
        model = Roles
        fields = ['id','role_name','company_detail','created_by','created_datetime']

class UserTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserType
        fields = ['id','is_menu_visible']

class MenuPageSerializer(serializers.ModelSerializer):
    class Meta:
        model = MenuPage
        fields = ['id','menu_name','is_menu_type']

# class PermissionSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = Permission
#         fields = ['PermissionName','CompanyDetailId','CreatedBy','CreatedDateTime']

class PermissionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Permission
        fields = ['id','role','menu_page','action']

# class UserRolePermissionSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = UserRolePermission
#         fields = ['RoleId','PermissionId','CompanyDetailId','CreatedBy','CreatedDateTime']

class UserRoleMappingSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserRoleMapping
        fields = ['id','user','role','company_detail','created_by','created_datetime']


class UserSerializer(serializers.ModelSerializer):
    email = serializers.EmailField(required=True,validators=[UniqueValidator(queryset=User.objects.all())])
    password = serializers.CharField(write_only=True, required=True, validators=[validate_password])
    password2 = serializers.CharField(write_only=True, required=True)
    company_detail = serializers.IntegerField(required=True)
    class Meta:
        model = User
        fields = ['id','email','phone_number','anpr_check_allowed','blacklist_check_allowed','speed_check_allowed','lane_change_check_allowed','seat_belt_check_allowed','mobile_check_allowed','password','password2','company_detail','user_login_or_not','is_superuser','is_active']
    def validate(self, attrs):
        if attrs['password'] != attrs['password2']:
            raise serializers.ValidationError({"password": "Password fields didn't match."})
        return attrs
    def create(self, validated_data):
        user = User.objects.create(
            email=validated_data['email'],
            phone_number=validated_data['phone_number'],
            anpr_check_allowed=validated_data['anpr_check_allowed'],
            blacklist_check_allowed=validated_data['blacklist_check_allowed'],
            speed_check_allowed=validated_data['speed_check_allowed'],
            lane_change_check_allowed=validated_data['lane_change_check_allowed'],
            seat_belt_check_allowed=validated_data['seat_belt_check_allowed'],
            mobile_check_allowed=validated_data['mobile_check_allowed'],
            company_detail_id=validated_data['company_detail'],
            user_login_or_not=validated_data['user_login_or_not'],
            is_superuser=validated_data['is_superuser'],
            is_active=validated_data['is_active'])

        user.set_password(validated_data['password'])
        user.save()
        return user


# class UserProfileSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = UserProfileInformation
#         fields = '__all__'


class UserLoginSerializer(serializers.ModelSerializer):
  email = serializers.EmailField(max_length=255)
  class Meta:
    model = User
    fields = ['email', 'password']

class SitesSerializer(serializers.ModelSerializer):
    # site_name = serializers.CharField(required=True,validators=[UniqueValidator(queryset=Sites.objects.all())])
    user_email = serializers.CharField(source='user.email', read_only=True)
    class Meta:
        model = Sites
        fields = ['id','site_name','user','user_email','company_detail','anpr_check_allowed','blacklist_check_allowed','speed_check_allowed','lane_change_check_allowed','seat_belt_check_allowed','mobile_check_allowed','plan_start_datetime','plan_expire_datetime','days_to_expire','minutes_to_expire','plan_validity','timezones','active','user_login_or_not','skip_frame','delete_previous_data_after_day']
    def create(self, validated_data):
        if Sites.objects.filter(company_detail=validated_data['company_detail'], site_name=validated_data['site_name']).exists():
            raise serializers.ValidationError({"site_name":"site name is unique field."})
        if Sites.objects.filter(company_detail=validated_data['company_detail'], user=validated_data['user']).exists():
            raise serializers.ValidationError({"user":"user email is unique field."})
        return super().create(validated_data)
    
    def update(self, instance, validated_data):
        if Sites.objects.filter(company_detail=validated_data['company_detail'], site_name=validated_data['site_name']).exclude(id=instance.pk).exists():
            raise serializers.ValidationError({"site_name":"site name is unique field."})
        if Sites.objects.filter(company_detail=validated_data['company_detail'], user=validated_data['user']).exclude(id=instance.pk).exists():
            raise serializers.ValidationError({"user":"user email is unique field."})
        return super().update(instance, validated_data)


class UserEmailSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id','email']

class BusinessPricingTierSerializer(serializers.ModelSerializer):
    class Meta:
        model = BusinessPricingTier
        fields=['id','uuid','backup_days_id','backup_days','quantity','price','days_price','currency_id','default_product_id','default_product_feature_id','plan_feature_pricing_category_id','category_name','plan_id','business_plan_history_id','plan_feature_pricing_tier_id','company_detail','plan_pricing_description']

class BusinessPlanHistorySerializer(serializers.ModelSerializer):
  # business_pricing_tiers = BusinessPricingTierSerializer(source='businesspricingtier_set', many=True)
    #plan_features_pricing_categories = serializers.SerializerMethodField()
    class Meta:
        model = BusinessPlanHistory
        # fields = ['id','uuid','plan_name','price','price_after_discount','price_after_tax','days_price','currency','currency_type','currency_symbol','country_category','country_type','plan_id','plan_days_id','plan_days','discount_in_percentage','discount_in_currency','buy_datetime','plan_end_datetime','minutes_to_expire','active_plan','plan_type']
        fields = ['id','uuid','plan_name','price','price_after_discount','price_after_tax','days_price','days_price_after_discount','days_price_after_tax','currency_id','currency_type','currency_symbol','country_category_id','country_type','plan_id','plan_days_and_discount_id','plan_days','discount_in_percentage','discount_in_currency','total_discount','total_tax_in_percentage','total_tax_in_currency','buy_datetime','plan_start_datetime','plan_expire_datetime','minutes_to_expire','days_to_expire','plan_validity','current_active','plan_status','plan_type','company_detail','upgrade_plan_id']
        #fields = '__all__'

class BusinessPlanPricingTaxSerializer(serializers.ModelSerializer):
    class Meta:
        model = BusinessPlanPricingTax
        fields = ['id','uuid','business_plan_history_id','tax_percentage_detail_id','tax_type','tax_percentage','tax_amount','company_detail']