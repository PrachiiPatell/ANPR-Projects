from django.shortcuts import render,redirect

# Create your views here.
# from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
# from .forms import UserProfileInformationForm
from .models import User,Roles,MenuPage,MenuActionMap,UserType,CompanyDetail,AddUserEmail,Permission,Action,UserRoleMapping,Sites #,UserProfileInformation
from django.contrib.auth import authenticate,login,logout
from django.http import HttpResponseRedirect,HttpResponse
from django.http.response import JsonResponse,Http404
from rest_framework.response import Response
from rest_framework.parsers import JSONParser
from rest_framework.decorators import api_view
from rest_framework.views import APIView
from .serializers import UserSerializer,CompanyDetailSerializer,RoleSerializer,PermissionSerializer,UserRoleMappingSerializer,AddUserEmailSerializer,UserLoginSerializer,SitesSerializer, UserEmailSerializer,CurrencySerializer  ##UserRolePermissionSerializer
from rest_framework import status
import json
from datetime import datetime,timedelta
from django_countries import countries
from django.core.mail import EmailMultiAlternatives,send_mail
from django.conf import settings
from django.template.loader import render_to_string, get_template
from rest_framework_simplejwt.tokens import RefreshToken
from django.db import transaction
from django.db.models import Count
from django.db.models import F
from rest_framework.permissions import AllowAny,IsAuthenticated
from rest_framework.authentication import TokenAuthentication
from rest_framework_simplejwt.backends import TokenBackend
from django.core.exceptions import ValidationError
from rest_framework.pagination import LimitOffsetPagination
import pytz
# get_menu_action = MenuActionMap.objects.values('id','menu_page','action').all()[2:20]
# print(get_menu_action)

# GetPermissionData = MenuActionMap.objects.filter(action=1).values('menu_page','menu_page__menu_name').distinct('menu_page')
# print(GetPermissionData)
def getUserData(user):
    user_detail = User.objects.filter(id=user).values('id','email','company_detail','anpr_check_allowed','blacklist_check_allowed','speed_check_allowed','lane_change_check_allowed','seat_belt_check_allowed','mobile_check_allowed').first()
    company_details = CompanyDetail.objects.filter(id=user_detail['company_detail']).values('id','company_name','country','anpr_check_allowed','blacklist_check_allowed','speed_check_allowed','lane_change_check_allowed','seat_belt_check_allowed','mobile_check_allowed','plan_start_datetime','plan_expire_datetime','days_to_expire','minutes_to_expire','plan_validity').first()
    
    user_role_maps = UserRoleMapping.objects.filter(user=user_detail['id']).values('id','role').first()
    # print("company:",company_details)
    diff = datetime.strptime(str(company_details['plan_expire_datetime']), '%Y-%m-%d %H:%M:%S+00:00') - datetime.strptime(str(datetime.now()), '%Y-%m-%d %H:%M:%S.%f')
    if int(diff.total_seconds() / 60.0) > 0:
        CompanyDetail.objects.filter(id=user_detail['company_detail']).update(plan_validity=True,days_to_expire=diff.days,minutes_to_expire=int(diff.total_seconds() / 60.0))
    else:
        CompanyDetail.objects.filter(id=user_detail['company_detail']).update(plan_validity=False,days_to_expire=diff.days,minutes_to_expire=int(diff.total_seconds() / 60.0))
    company_details = CompanyDetail.objects.filter(id=user_detail['company_detail']).values('id','company_name','country','anpr_check_allowed','blacklist_check_allowed','speed_check_allowed','lane_change_check_allowed','seat_belt_check_allowed','mobile_check_allowed','plan_start_datetime','plan_expire_datetime','days_to_expire','minutes_to_expire','plan_validity','currency__currency_symbol').first()
    role_detail = Roles.objects.filter(id=user_role_maps['role']).values('id','role_name').last()
    get_menu_data = Permission.objects.filter(role=user_role_maps['role']).values('id','menu_page','menu_page__menu_name').distinct('menu_page')
    permissions = {}
    for get_menu in get_menu_data:
        get_action = Permission.objects.filter(role=user_role_maps['role'],menu_page=get_menu['menu_page']).values('id','menu_page','action','action__action_name').distinct('action')
        permissions[get_menu['menu_page__menu_name']] = []
        for get_action in get_action:
            permissions[get_menu['menu_page__menu_name']].append(get_action.get('action__action_name'))
    data = {'user_detail':user_detail,'company_detail':company_details,'role_detail':role_detail,'permission':permissions}
    return data


def getUserDataPage(user,pages,action):
    user_detail = User.objects.filter(id=user).values('id','email','company_detail').first()
    company_details = CompanyDetail.objects.filter(id=user_detail['company_detail']).values('id','plan_start_datetime','plan_expire_datetime','days_to_expire','minutes_to_expire','plan_validity').first()
    user_role_maps = UserRoleMapping.objects.filter(user=user_detail['id']).values('id','role').first()
    # print("company:",company_details)
    diff = datetime.strptime(str(company_details['plan_expire_datetime']), '%Y-%m-%d %H:%M:%S+00:00') - datetime.strptime(str(datetime.now()), '%Y-%m-%d %H:%M:%S.%f')
    if int(diff.total_seconds() / 60.0) > 0:
        CompanyDetail.objects.filter(id=user_detail['company_detail']).update(plan_validity=True,days_to_expire=diff.days,minutes_to_expire=int(diff.total_seconds() / 60.0)) 
    else:
        CompanyDetail.objects.filter(id=user_detail['company_detail']).update(plan_validity=False,days_to_expire=diff.days,minutes_to_expire=int(diff.total_seconds() / 60.0))
    company_details = CompanyDetail.objects.filter(id=user_detail['company_detail']).values('id','company_name','plan_validity','currency__currency_symbol').first()
    permissions = Permission.objects.filter(role=user_role_maps['role'],menu_page__menu_name = pages,action__action_name=action).values('id','role','role__role_name','menu_page','menu_page__menu_name','action__action_name').distinct('menu_page')
    data = {'user_detail':user_detail,'company_detail':company_details,'permission':permissions}
    return data


class Register(APIView):
    permission_classes = (AllowAny,)
    def post(self, request, format=None):
        add_user_emails = AddUserEmail.objects.filter(email=request.data['email']).values('email','role','company_detail').first()
        if add_user_emails != None:
            get_company_detail = CompanyDetail.objects.filter(id=add_user_emails.get('company_detail')).values('anpr_check_allowed','blacklist_check_allowed','speed_check_allowed','lane_change_check_allowed','seat_belt_check_allowed','mobile_check_allowed').first()
            serializer = UserSerializer(data={'email':request.data['email'],'phone_number':request.data['phone_number'],'anpr_check_allowed':get_company_detail.get('anpr_check_allowed'),'blacklist_check_allowed':get_company_detail.get('blacklist_check_allowed'),'speed_check_allowed':get_company_detail.get('speed_check_allowed'),'lane_change_check_allowed':get_company_detail.get('lane_change_check_allowed'),'seat_belt_check_allowed':get_company_detail.get('seat_belt_check_allowed'),'mobile_check_allowed':get_company_detail.get('mobile_check_allowed'),'password':request.data['password'],'password2':request.data['password2'],'company_detail': int(add_user_emails.get('company_detail')),'user_login_or_not':False,'is_superuser':False,'is_active':False})
            user_id = None
            if serializer.is_valid():
                obj = serializer.save()
                user_id = obj.id
            else:
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            user_role_map_serializer = UserRoleMappingSerializer(data={'user':user_id,'role':add_user_emails.get('role'),'company_detail': add_user_emails.get('company_detail')})
            if user_role_map_serializer.is_valid():
                user_role_map_serializer.save()
            else:
                User.objects.filter(id=user_id).delete()
                return Response(user_role_map_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            user_select = User.objects.filter(id=user_id).last()
            refresh = RefreshToken.for_user(user_select)
            user_detail = getUserData(user_id)
            user_detail['refresh'] = str(refresh)
            user_detail['access'] = str(refresh.access_token)
            return Response(user_detail, status=status.HTTP_201_CREATED)
        else:
            print("Yes")
            return Response({"result": {},"message": "Company are not register with this email."}, status=status.HTTP_400_BAD_REQUEST)

class AddCompany(APIView):
    # authentication_classes = (TokenAuthentication,)
    permission_classes = (AllowAny,)
    def post(self, request, format=None):
        # token = request.META.get('HTTP_AUTHORIZATION', " ").split(' ')[1]
        # data = {'token': token}
        # try:
        #     valid_data = TokenBackend(algorithm='HS256').decode(token,verify=True)
        #     user = valid_data['user']
        #     print("User:",user)
        #     request.user = user
        # except ValidationError as v:
        #     print("validation error", v)
        currency_detail = {'currency_type':request.data['currency_type'],'currency_symbol':request.data['currency_symbol']}
        currency_serializer = CurrencySerializer(data=currency_detail)
        currency_id = None
        if currency_serializer.is_valid():
            obj = currency_serializer.save()
            currency_id = obj.id
        else:
            return Response(currency_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            
        company_detail = {'company_name':request.data['company_name'],'country':request.data['country'],'uses_type':'free trail','anpr_check_allowed':request.data['anpr_check_allowed'],'blacklist_check_allowed':request.data['blacklist_check_allowed'],'speed_check_allowed':request.data['speed_check_allowed'],'lane_change_check_allowed':request.data['lane_change_check_allowed'],'seat_belt_check_allowed':request.data['seat_belt_check_allowed'],'mobile_check_allowed':request.data['mobile_check_allowed'],'plan_start_datetime':datetime.now(),'plan_expire_datetime':datetime.now()+timedelta(days=15),'days_to_expire':15,'minutes_to_expire':21600,'plan_validity':True,'currency_id':currency_id}
        company_serializer = CompanyDetailSerializer(data=company_detail)
        company_id = None
        if company_serializer.is_valid():
            obj = company_serializer.save()
            company_id = obj.id
        else:
            return Response(company_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        
        role_detail = {'role_name':'Admin','company_detail':company_id}
        
        role_serializer = RoleSerializer(data=role_detail)
        role_id = None
        if role_serializer.is_valid():
            obj = role_serializer.save()
            role_id = obj.id
        else:
            CompanyDetail.objects.filter(id=company_id).delete()
            return Response(role_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        add_user_email_serializer = AddUserEmailSerializer(data = {'email':request.data['email'],'role':role_id,'company_detail':company_id})
        add_user_emailid = None
        if add_user_email_serializer.is_valid():
            obj = add_user_email_serializer.save()
            add_user_emailid = obj.id
        else:
            CompanyDetail.objects.filter(id=company_id).delete()
            Roles.objects.filter(id=role_id).delete()
            return Response(add_user_email_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        permission_id = []
        get_menu_data = MenuPage.objects.exclude(is_menu_type__is_menu_visible ='SuperAdmin').all().values('id','menu_name')
        print(get_menu_data)
        # for perm in range(len(PermissionDetail)):
        for menus in get_menu_data:
            get_menu_action_data = MenuActionMap.objects.filter(menu_page=menus['id']).values('id','menu_page','action').all()
            for menu_action in get_menu_action_data:
                print(menu_action)
                permission_serializer = PermissionSerializer(data={'role':role_id,'menu_page':menu_action['menu_page'],'action':menu_action['action']})
                if permission_serializer.is_valid():
                    obj = permission_serializer.save()
                    permission_id.append(obj.id)
                else:
                    CompanyDetail.objects.filter(id=company_id).delete()
                    Roles.objects.filter(id=role_id).delete()
                    AddUserEmail.objects.filter(id=add_user_emailid).delete()
                    for perm_id in permission_id:
                        Permission.objects.filter(id=perm_id).delete()
                    return Response(permission_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        return Response({'Sucess':'Company Created Successfully.'},status.HTTP_201_CREATED)
   
class Login(APIView):
    permission_classes = (AllowAny,)
    def post(self, request, format=None):
        serializer = UserLoginSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        email = serializer.data.get('email')
        password = serializer.data.get('password')
        print(email,password)
        user = authenticate(email=email,password=password)
        if user:
            if user.is_active:
                refresh = RefreshToken.for_user(user)
                user_detail = getUserData(user.id)
                user_detail['refresh'] = str(refresh)
                user_detail['access'] = str(refresh.access_token)
                print(user_detail)
                return JsonResponse(user_detail, status=status.HTTP_200_OK)
            else:
                res = {"code": 400, "message": "Account was not active."}
                return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)
        else:
            res = {"code": 400, "message": "Invalid Username and Password."}
            return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)

class WindowsLogin(APIView):
    permission_classes = (AllowAny,)
    def post(self, request, format=None):
        serializer = UserLoginSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        email = serializer.data.get('email')
        password = serializer.data.get('password')
        print(email,password)
        user = authenticate(email=email,password=password)
        if user:
            if user.is_active:
                getSites = Sites.objects.filter(user=user.id).values('id','site_name','user','company_detail','anpr_check_allowed','blacklist_check_allowed','speed_check_allowed','lane_change_check_allowed','seat_belt_check_allowed','mobile_check_allowed').first()
                if getSites != None:
                    if getSites['user_login_or_not'] == False:
                        if getSites['active'] == True:
                            TimeZoneLoc = pytz.timezone('Asia/Kolkata')
                            diff = datetime.strptime(str(getSites['plan_expire_datetime']), '%Y-%m-%d %H:%M:%S.%f+00:00') - datetime.strptime(str(datetime.now()), '%Y-%m-%d %H:%M:%S.%f')
                            if int(diff.total_seconds() / 60.0) > 0:
                                Sites.objects.filter(id=getSites['id']).update(plan_validity=True,days_to_expire=diff.days,minutes_to_expire=int(diff.total_seconds() / 60.0),user_login_or_not=True)
                            else:
                                Sites.objects.filter(id=getSites['id']).update(plan_validity=False,days_to_expire=diff.days,minutes_to_expire=int(diff.total_seconds() / 60.0),user_login_or_not=True)   
                            update_sites = Sites.objects.filter(user=user.id).values('id','site_name','user','anpr_check_allowed','blacklist_check_allowed','company_detail','plan_start_datetime','plan_expire_datetime','days_to_expire','minutes_to_expire','plan_validity','timezones','active','user_login_or_not','skip_frame','delete_previous_data_after_day').first()
                            refresh = RefreshToken.for_user(user)
                            user_detail = getUserData(user.id)
                            user_detail['refresh'] = str(refresh)
                            user_detail['access'] = str(refresh.access_token)
                            user_detail['sites'] = getSites
                            # print(user_detail)
                            return JsonResponse(user_detail, status=status.HTTP_200_OK)
                        else:
                            res = {"code": 400, "message": "Your Sites is not active."}
                            return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)
                    else:
                        res = {"code": 400, "message": "Your sites account is already login in other system. Please logout first. "}
                        return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)
                else:
                    res = {"code": 400, "message": "Your account is not valid for windows application."}
                    return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)
            else:
                res = {"code": 400, "message": "Account was not active."}
                return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)
        else:
            res = {"code": 400, "message": "Invalid Username and Password."}
            return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)

class GetUserDetail(APIView):
    permission_classes = (IsAuthenticated,)
    # authentication_classes = (TokenAuthentication,)
    
    def get(self, request, format=None):
        try:
            token = request.META.get('HTTP_AUTHORIZATION', " ").split(' ')[1]
            if token != '':
                data = {'token': token}
                print("data:",data)
                valid_data = TokenBackend(algorithm='HS256').decode(token,verify=False)
                print(valid_data)
                user = valid_data['user_id']
                print("User:",user,request.user.id)
                request.user = user
                print("request.user1:",request.user)
            else:
                Response({"result": {},"message": "Invalid Token."}, status=status.HTTP_201_CREATED)
        except ValidationError as v:
            print("validation error", v)
        get_user_data = getUserData(request.user)
        return Response(get_user_data)

    
class AddUserEmailView(APIView):
    permission_classes = (IsAuthenticated,)
    pagination_class = LimitOffsetPagination

    def get(self, request, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = getUserDataPage(request.user.id,'add user email','view')
        if get_user_data['company_detail']['plan_validity'] == True:
            AccessToPage = False
            # if 'add user email' in get_user_data['permission'].keys():
            #     if 'view' in get_user_data['permission']['add user email']:
            #         AccessToPage = True
            if get_user_data['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                add_user_email_detail = AddUserEmail.objects.filter(company_detail = get_user_data['company_detail']['id']).order_by('-id').all()  ##.values('id','licence_plate_number','licence_plate_image','confidence_licence_plate','datetime','speed','speed_violation','lane_change','driver_seat_belt','driver_seat_belt_image','confidence_driver_seat_belt','passanger_seat_belt','passanger_seat_belt_image','confidence_passanger_seat_belt','driver_mobile','driver_mobile_image','confidence_driver_mobile','passanger_mobile','passanger_mobile_image','confidence_passanger_mobile','vehicle_type','vehicle_direction','country','camera_name','created_by','created_datetime','updated_by','updated_datetime')
                paginator = LimitOffsetPagination()
                serializer = AddUserEmailSerializer(add_user_email_detail, many=True)
                result_page = paginator.paginate_queryset(serializer.data, request,view=paginator)
                return paginator.get_paginated_response(result_page)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def post(self, request, format=None):
        get_user_data = getUserDataPage(request.user.id,'add user email','create')  
        if get_user_data['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if get_user_data['permission'] != None:
                AccessToPage = True
            # if 'add user email' in get_user_data['permission'].keys():
            #     if 'create' in get_user_data['permission']['add user email']:
            #         AccessToPage = True
            if AccessToPage == True:
                get_data = request.data
                get_data['company_detail'] = get_user_data['company_detail']['id']
                print(get_data)
                serializer = AddUserEmailSerializer(data=get_data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

class UserEmailDetailView(APIView):
    permission_classes = (IsAuthenticated,)
    def get_object(self, id):
        try:
            return AddUserEmail.objects.get(pk=id)
        except AddUserEmail.DoesNotExist:
            raise Http404
    def get(self, request,id, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = getUserDataPage(request.user.id,'add user email','view')  
        if get_user_data['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if get_user_data['permission'] != None:
                AccessToPage = True
            # if 'add user email' in get_user_data['permission'].keys():
            #     if 'view' in get_user_data['permission']['add user email']:
            #         AccessToPage = True
            if AccessToPage == True:
                sites = self.get_object(id)
                serializer = AddUserEmailSerializer(sites)
                return Response(serializer.data)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
    def put(self, request, id, format=None): 
        get_user_data = getUserDataPage(request.user.id,'add user email','update')  
        if get_user_data['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if get_user_data['permission'] != None:
                AccessToPage = True
            # if 'add user email' in get_user_data['permission'].keys():
            #     if 'update' in get_user_data['permission']['add user email']:
            #         AccessToPage = True
            if AccessToPage == True:
                add_user_email = self.get_object(id)
                get_data = request.data
                get_data['company_detail'] = get_user_data['company_detail']['id']
                serializer = AddUserEmailSerializer(add_user_email, data=get_data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)  
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
     
    def delete(self, request,id, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = getUserDataPage(request.user.id,'add user email','delete')  
        if get_user_data['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if get_user_data['permission'] != None:
                AccessToPage = True
            # if 'add user email' in get_user_data['permission'].keys():
            #     if 'delete' in get_user_data['permission']['add user email']:
            #         AccessToPage = True
            if AccessToPage == True:
                add_user_email = self.get_object(id)
                add_user_email.delete()
                return Response(status=status.HTTP_204_NO_CONTENT)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
 
class SiteView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = getUserDataPage(request.user.id,'sites','view')  
        if get_user_data['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if get_user_data['permission'] != None:
                AccessToPage = True
            # if 'sites' in get_user_data['permission'].keys():
            #     if 'view' in get_user_data['permission']['sites']:
            #         AccessToPage = True
            if AccessToPage == True:
                sites_detail = Sites.objects.filter(company_detail = get_user_data['company_detail']['id']).all()  ##.values('id','licence_plate_number','licence_plate_image','confidence_licence_plate','datetime','speed','speed_violation','lane_change','driver_seat_belt','driver_seat_belt_image','confidence_driver_seat_belt','passanger_seat_belt','passanger_seat_belt_image','confidence_passanger_seat_belt','driver_mobile','driver_mobile_image','confidence_driver_mobile','passanger_mobile','passanger_mobile_image','confidence_passanger_mobile','vehicle_type','vehicle_direction','country','camera_name','created_by','created_datetime','updated_by','updated_datetime')
                paginator = LimitOffsetPagination()
                serializer = SitesSerializer(sites_detail, many=True)
                result_page = paginator.paginate_queryset(serializer.data, request,view=paginator)
                return paginator.get_paginated_response(result_page)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
    
    def post(self, request, format=None):
        get_user_data = getUserDataPage(request.user.id,'sites','create')  
        if get_user_data['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if get_user_data['permission'] != None:
                AccessToPage = True
            # if 'sites' in get_user_data['permission'].keys():
            #     if 'create' in get_user_data['permission']['sites']:
            #         AccessToPage = True
            if AccessToPage == True:
                get_data = request.data
                get_data['company_detail'] = get_user_data['company_detail']['id']
                serializer = SitesSerializer(data=get_data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                else:
                    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
    
class SitesDetailView(APIView):
    permission_classes = (IsAuthenticated,)
    def get_object(self, id):
        try:
            return Sites.objects.get(pk=id)
        except Sites.DoesNotExist:
            raise Http404
    def get(self, request,id, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = getUserDataPage(request.user.id,'sites','view')  
        if get_user_data['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if get_user_data['permission'] != None:
                AccessToPage = True
            # if 'sites' in get_user_data['permission'].keys():
            #     if 'view' in get_user_data['permission']['sites']:
            #         AccessToPage = True
            if AccessToPage == True:
                sites = self.get_object(id)
                serializer = SitesSerializer(sites)
                return Response(serializer.data)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
    def put(self, request, id, format=None): 
        get_user_data = getUserDataPage(request.user.id,'sites','update')  
        if get_user_data['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if get_user_data['permission'] != None:
                AccessToPage = True
            # if 'sites' in get_user_data['permission'].keys():
            #     if 'update' in get_user_data['permission']['sites']:
            #         AccessToPage = True
            if AccessToPage == True:
                sites = self.get_object(id)
                serializer = SitesSerializer(sites, data=request.data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)  
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
     
    def delete(self, request,id, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = getUserDataPage(request.user.id,'sites','delete')  
        if get_user_data['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if get_user_data['permission'] != None:
                AccessToPage = True
            # if 'sites' in get_user_data['permission'].keys():
            #     if 'delete' in get_user_data['permission']['sites']:
            #         AccessToPage = True
            if AccessToPage == True:
                sites = self.get_object(id)
                sites.delete()
                return Response(status=status.HTTP_204_NO_CONTENT)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

class RoleDropdownView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = getUserData(request.user.id)
        if get_user_data['company_detail']['plan_validity'] == True:
            roles = Roles.objects.filter(company_detail = get_user_data['company_detail']['id']).all()  ##.values('id','licence_plate_number','licence_plate_image','confidence_licence_plate','datetime','speed','speed_violation','lane_change','driver_seat_belt','driver_seat_belt_image','confidence_driver_seat_belt','passanger_seat_belt','passanger_seat_belt_image','confidence_passanger_seat_belt','driver_mobile','driver_mobile_image','confidence_driver_mobile','passanger_mobile','passanger_mobile_image','confidence_passanger_mobile','vehicle_type','vehicle_direction','country','camera_name','created_by','created_datetime','updated_by','updated_datetime')
            serializer = RoleSerializer(roles, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

class UserEmailView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        get_user_data = getUserData(request.user.id)
        if get_user_data['company_detail']['plan_validity'] == True:
            roles = User.objects.filter(company_detail = get_user_data['company_detail']['id']).all()  ##.values('id','licence_plate_number','licence_plate_image','confidence_licence_plate','datetime','speed','speed_violation','lane_change','driver_seat_belt','driver_seat_belt_image','confidence_driver_seat_belt','passanger_seat_belt','passanger_seat_belt_image','confidence_passanger_seat_belt','driver_mobile','driver_mobile_image','confidence_driver_mobile','passanger_mobile','passanger_mobile_image','confidence_passanger_mobile','vehicle_type','vehicle_direction','country','camera_name','created_by','created_datetime','updated_by','updated_datetime')
            serializer = UserEmailSerializer(roles, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

