from django.contrib import admin
from .models import *
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin

from .forms import UserCreationForm, UserChangeForm

User = get_user_model()

# class UserAdmin(BaseUserAdmin):
#     # The forms to add and change user instances
#     form = UserChangeForm
#     add_form = UserCreationForm

#     # The fields to be used in displaying the User model.
#     # These override the definitions on the base UserAdmin
#     # that reference specific fields on auth.User.
#     list_display = ['email', 'admin']
#     list_filter = ['admin']
#     fieldsets = (
#         (None, {'fields': ('email', 'password')}),
#         ('Personal info', {'fields': ()}),
#         ('Permissions', {'fields': ('admin',)}),
#     )
#     # add_fieldsets is not a standard ModelAdmin attribute. UserAdmin
#     # overrides get_fieldsets to use this attribute when creating a user.
#     add_fieldsets = (
#         (None, {
#             'classes': ('wide',),
#             'fields': ('email', 'password1', 'password2')}
#         ),
#     )
#     search_fields = ['email']
#     ordering = ['email']
#     filter_horizontal = ()


# admin.site.register(User, UserAdmin)

class AccountAdmin(BaseUserAdmin):
    form = UserChangeForm
    add_form = UserCreationForm

    list_display = ('id','uuid','email', 'phone_number','anpr_check_allowed','blacklist_check_allowed','speed_check_allowed','lane_change_check_allowed','seat_belt_check_allowed','mobile_check_allowed', 'company_detail', 'user_login_or_not', 'timezones','is_active', 'is_staff',  'is_superuser')
    list_filter = ('is_superuser',)

    fieldsets = (
        (None, {'fields': ('email','is_active', 'is_staff', 'is_superuser', 'password')}),
        ('Personal info', {'fields': ('phone_number','anpr_check_allowed','blacklist_check_allowed','speed_check_allowed','lane_change_check_allowed','seat_belt_check_allowed','mobile_check_allowed', 'company_detail', 'user_login_or_not', 'timezones')}),
        ('Groups', {'fields': ('groups',)}),
        ('Permissions', {'fields': ('user_permissions',)}),
    )
    add_fieldsets = (
        (None, {'fields': ('email','is_active','is_staff', 'is_superuser', 'password1', 'password2')}),
        ('Personal info', {'fields': ('phone_number','anpr_check_allowed','blacklist_check_allowed','speed_check_allowed','lane_change_check_allowed','seat_belt_check_allowed','mobile_check_allowed', 'company_detail', 'user_login_or_not', 'timezones')}),
        ('Groups', {'fields': ('groups',)}),
        ('Permissions', {'fields': ('user_permissions',)}),
    )

    search_fields = ('phone_number','anpr_check_allowed','blacklist_check_allowed','speed_check_allowed','lane_change_check_allowed','seat_belt_check_allowed','mobile_check_allowed', 'company_detail', 'user_login_or_not', 'timezones')
    ordering = ('email',)
    filter_horizontal = ()


admin.site.register(User, AccountAdmin)

# class UserProfileInformationAdmin(admin.ModelAdmin):
#     list_display= ('user', 'Country', 'CompanyName','UsesType','Speed','LaneChange','StartDateTime','EndDateTime','UserLoginOrNot','timezones')

# class PrimaryIndustryOptionAdmin(admin.ModelAdmin):
#     list_display= ('Industry',)

# class PrimaryUseCaseOptionAdmin(admin.ModelAdmin):
#     list_display= ('UseCase',)

class CompanyDetailAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','company_name','country','uses_type','anpr_check_allowed','speed_check_allowed','lane_change_check_allowed','seat_belt_check_allowed','mobile_check_allowed','plan_start_datetime','plan_expire_datetime','days_to_expire','minutes_to_expire','plan_validity','created_by','created_datetime','updated_by','updated_datetime')

class RolesAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','role_name','company_detail','created_by','created_datetime','updated_by','updated_datetime')

class UserTypeAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','is_menu_visible')

class MenuPageAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','menu_name','is_menu_type','created_by','created_datetime','updated_by','updated_datetime')

class ActionAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','action_name')

class MenuActionMapAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','menu_page','action')

class PermissionAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','role','menu_page','action')

class UserRoleMappingAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','user','role','company_detail','created_by','created_datetime','updated_by','updated_datetime')

class AddUserEmailAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','email','role','company_detail')

class SitesAdmin(admin.ModelAdmin):
    list_display = ('id','site_name','user','company_detail','anpr_check_allowed','blacklist_check_allowed','speed_check_allowed','lane_change_check_allowed','seat_belt_check_allowed','mobile_check_allowed','plan_start_datetime','plan_expire_datetime','days_to_expire','minutes_to_expire','plan_validity','timezones','active','user_login_or_not','skip_frame','delete_previous_data_after_day')

class CurrencyAdmin(admin.ModelAdmin):
    list_display = ('id','currency_type','currency_symbol')

class DefaultProductAdmin(admin.ModelAdmin):
    list_display = ('id', 'uuid', 'product_name')

class DefaultProductFeatureAdmin(admin.ModelAdmin):
    list_display = ('id', 'uuid', 'feature', 'default_product', 'parent_feature')

class DaysAdmin(admin.ModelAdmin):
    list_display = ('id', 'uuid', 'days', 'category')

class PlanFeaturesPricingCategoryAdmin(admin.ModelAdmin): 
    list_display = ('id', 'uuid', 'category_name')

class CountryCategoryAdmin(admin.ModelAdmin):
    list_display = ('id', 'uuid', 'country')

class TaxPercentageDetailAdmin(admin.ModelAdmin):
    list_display = ('id', 'uuid', 'tax_percentage', 'tax_type', 'country_category')

class PlanPricingTaxAdmin(admin.ModelAdmin):
    list_display = ('id', 'uuid', 'plan_pricing_id', 'tax_percentage_detail_id', 'tax_amount', 'currency_id')

class PlanFeaturePricingTierAdmin(admin.ModelAdmin):
    list_display = (
        'id', 'uuid', 'min_quantity', 'max_quantity', 'default_quantity', 'default_product_id', 
        'default_product_feature_id', 'pricing_feature_category_id', 'plan_id', 
        'plan_pricing_description', 'show_plan_pricing', 'is_encluded_plan_feature_id'
    )

class PlanFeatureDaysPriceAdmin(admin.ModelAdmin):
    list_display = (
        'id', 'uuid', 'backup_days_id', 'plan_days_and_discount_id', 'days_price', 
        'currency_id', 'plan_feature_pricing_tier_id', 'plans_id', 'default_selected'
    )

class CouponAdmin(admin.ModelAdmin):
    list_display = (
        'id', 'uuid', 'code', 'description', 'discount_type', 'discount_value', 'currency_id', 
        'country_category_id', 'plan_buy_days', 'coupon_expiry_datetime', 'is_active', 'user_valid_for_coupon'
    )

class PlanDescriptionAdmin(admin.ModelAdmin):
    list_display = ('id', 'uuid', 'plan_description', 'plan_id')

class PlanDaysAndDiscountAdmin(admin.ModelAdmin):
    list_display = (
        'id', 'uuid', 'plan_days', 'discount_percentage', 'category', 'default_select', 
        'plan_id', 'plan_pricing_id'
    )

class PlanPricingAdmin(admin.ModelAdmin):
    list_display = (
        'id', 'uuid', 'basic_price', 'basic_price_after_discount', 'basic_price_after_tax', 
        'days_price', 'days_price_after_discount', 'days_price_after_tax', 'currency_id', 
        'country_type_id', 'plan_id'
    )

class PlansAdmin(admin.ModelAdmin):
    list_display = ('id', 'uuid', 'plan_name')

# class BusinessCameraDetailAdmin(admin.ModelAdmin):
#     list_display = ('id', 'uuid', 'camera_name', 'camera_url', 'date_time', 'active', 'is_deleted', 'sites_id', 'company_detail')

class BusinessPlanHistoryAdmin(admin.ModelAdmin):
    list_display = (
        'id', 'uuid', 'plan_name', 'price', 'price_after_discount', 'price_after_tax', 
        'days_price', 'days_price_after_discount', 'days_price_after_tax', 'currency_id', 
        'currency_type', 'currency_symbol', 'country_category_id', 'country_type', 'plan_id', 
        'plan_days_and_discount_id', 'plan_days', 'discount_in_percentage', 'discount_in_currency', 
        'total_discount', 'total_tax_in_percentage', 'total_tax_in_currency', 'buy_datetime', 
        'plan_start_datetime', 'plan_expire_datetime', 'minutes_to_expire', 'days_to_expire', 
        'plan_validity', 'current_active', 'plan_status', 'plan_type', 'company_detail', 
        'upgrade_plan_id'
    )

class BusinessPlanPricingTaxAdmin(admin.ModelAdmin):
    list_display = (
        'id', 'uuid', 'business_plan_history_id', 'tax_percentage_detail_id', 'tax_type', 
        'tax_percentage', 'tax_amount', 'company_detail'
    )

class BusinessPlanCouponAdmin(admin.ModelAdmin):
    list_display = (
        'id', 'uuid', 'coupon_code', 'description', 'discount_type', 'discount_value', 'coupon_id', 
        'total_coupon_amount', 'business_plan_history_id', 'company_detail'
    )

class BusinessPricingTierAdmin(admin.ModelAdmin):
    list_display = (
        'id', 'uuid', 'backup_days_id', 'backup_days', 'quantity', 'price', 'days_price', 
        'currency_id', 'default_product_id', 'default_product_feature_id', 'plan_feature_pricing_category_id', 
        'category_name', 'plan_id', 'business_plan_history_id', 'plan_feature_pricing_tier_id', 
        'company_detail', 'plan_pricing_description'
    )

class BusinessTransactionHistoryAdmin(admin.ModelAdmin):
    list_display = (
        'id', 'uuid', 'amout_paid', 'currency_id', 'currency_type', 'currency_symbol', 
        'date_and_time', 'company_detail', 'business_plan_history_id'
    )
class ScheduleAdmin(admin.ModelAdmin):
    list_display=(
        'id','uuid','days','type'
    )
# Register your models here.
# admin.site.register(UserProfileInformation,UserProfileInformationAdmin)

# admin.site.register(PrimaryIndustryOption,PrimaryIndustryOptionAdmin)
# admin.site.register(PrimaryUseCaseOption,PrimaryUseCaseOptionAdmin)
admin.site.register(CompanyDetail,CompanyDetailAdmin)
admin.site.register(Roles,RolesAdmin)
admin.site.register(UserType,UserTypeAdmin)
admin.site.register(MenuPage,MenuPageAdmin)
admin.site.register(Action,ActionAdmin)
admin.site.register(MenuActionMap,MenuActionMapAdmin)
admin.site.register(Permission,PermissionAdmin)
admin.site.register(UserRoleMapping,UserRoleMappingAdmin)
admin.site.register(AddUserEmail,AddUserEmailAdmin)
admin.site.register(Sites,SitesAdmin)
admin.site.register(Currency,CurrencyAdmin)
admin.site.register(DefaultProduct, DefaultProductAdmin)
admin.site.register(DefaultProductFeature, DefaultProductFeatureAdmin)
admin.site.register(Days, DaysAdmin)
admin.site.register(PlanFeaturesPricingCategory, PlanFeaturesPricingCategoryAdmin)
admin.site.register(CountryCategory, CountryCategoryAdmin)
admin.site.register(TaxPercentageDetail, TaxPercentageDetailAdmin)
admin.site.register(PlanPricingTax, PlanPricingTaxAdmin)
admin.site.register(PlanFeaturePricingTier, PlanFeaturePricingTierAdmin)
admin.site.register(PlanFeatureDaysPrice, PlanFeatureDaysPriceAdmin)
admin.site.register(Coupon, CouponAdmin)
admin.site.register(PlanDescription, PlanDescriptionAdmin)
admin.site.register(PlanDaysAndDiscount, PlanDaysAndDiscountAdmin)
admin.site.register(PlanPricing, PlanPricingAdmin)
admin.site.register(Plans, PlansAdmin)
admin.site.register(BusinessPlanHistory, BusinessPlanHistoryAdmin)
admin.site.register(BusinessPlanPricingTax, BusinessPlanPricingTaxAdmin)
admin.site.register(BusinessPlanCoupon, BusinessPlanCouponAdmin)
admin.site.register(BusinessPricingTier, BusinessPricingTierAdmin)
admin.site.register(BusinessTransactionHistory, BusinessTransactionHistoryAdmin)
admin.site.register(Schedule,ScheduleAdmin)