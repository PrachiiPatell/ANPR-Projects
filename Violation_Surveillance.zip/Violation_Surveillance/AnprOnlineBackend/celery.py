from __future__ import absolute_import, unicode_literals
import os
from celery import Celery
from celery.schedules import crontab
import django
from account.tasks import *
from django.conf import settings


os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'AnprOnlineBackend.settings')


app = Celery('AnprOnlineBackend')

app.config_from_object('django.conf:settings', namespace='CELERY')

#app.conf.worker_pool = 'solo'
#app.conf.worker_concurrency = 1  
# app.conf.worker_pool = 'prefork'
# app.conf.worker_concurrency = 2

@app.task(bind=True)
def debug_task(self):
    print(f'Request: {self.request!r}')

app.conf.broker_url = 'redis://localhost:6379/0'
app.conf.result_backend = 'redis://localhost:6379/0'


app.autodiscover_tasks()
app.conf.beat_scheduler = 'django_celery_beat.schedulers:DatabaseScheduler'

#django.setup()

app.conf.beat_schedule = {
   'notify-expired-plans-every-day': {
        'task': 'account.tasks.notify_expired_plans',
        'schedule': crontab(hour=0, minute=0), 
    },
}