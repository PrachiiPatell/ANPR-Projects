from django.contrib import admin
from .models import *

# Register your models here.

class WareHouseAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','total_occupency','remaining_occupency','occupency_percentage','from_datetime','to_datetime','camera_name','camera_view_name','camera_group_name','sites','company_detail_id')

class WareHouseObjectCountAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','warehouse_id','object_id','count','sites','company_detail_id')

admin.site.register(WareHouse, WareHouseAdmin)
admin.site.register(WareHouseObjectCount, WareHouseObjectCountAdmin)
