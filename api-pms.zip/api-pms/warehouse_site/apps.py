from django.apps import AppConfig


class WareHouseSiteConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "warehouse_site"
