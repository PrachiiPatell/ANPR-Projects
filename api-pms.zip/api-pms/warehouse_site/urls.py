from django.urls import path
from warehouse_site import views
from django.conf.urls.static import static
from django.conf import settings 

from .views import *
app_name = 'warehouse_site'
urlpatterns = [
    path('warehouse/',views.WareHouseView.as_view()),
    path('warehouse-detail/<int:id>', views.WareHouseDetailView.as_view()),
    path('object/',views.ObjectView.as_view()),
    path('warehouse-object-count/',views.WareHouseObjectCountView.as_view()),
    path('warehouse-object-count-detail/<int:id>', views.WareHouseObjectCountDetailView.as_view()),
    path('object-dropdown/',views.ObjectListView.as_view()),
    path('ware-house-dashboard/', views.DashboardData.as_view()),
] + static(settings.STATIC_URL)