from django.shortcuts import render,redirect

# Create your views here.
# from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
# from .forms import UserProfileInformationForm
from .models import User,Roles,MenuPage,MenuActionMap,UserType,CompanyDetail,AddUserEmail,Permission,Action,UserRoleMapping,Sites 
from .models import *
from .serializers import *
from django.contrib.auth import authenticate,login,logout
from django.http import HttpResponseRedirect,HttpResponse
from django.http.response import JsonResponse,Http404
from rest_framework.response import Response
from rest_framework.parsers import JSONParser
from rest_framework.decorators import api_view
from rest_framework.views import APIView
from .serializers import UserSerializer,CompanyDetailSerializer,RoleSerializer,PermissionSerializer,UserRoleMappingSerializer,AddUserEmailSerializer,UserLoginSerializer,SitesSerializer, UserEmailSerializer,CurrencySerializer  ##UserRolePermissionSerializer
from rest_framework import status
import json
from datetime import datetime,timedelta
#from django_countries import countries
from django.core.mail import EmailMultiAlternatives,send_mail
from django.conf import settings
from django.template.loader import render_to_string, get_template
from rest_framework_simplejwt.tokens import RefreshToken
from django.db import transaction
from django.db.models import Count
from django.db.models import F
from rest_framework.permissions import AllowAny,IsAuthenticated
from rest_framework.authentication import TokenAuthentication
from rest_framework_simplejwt.backends import TokenBackend
from django.core.exceptions import ValidationError
from rest_framework.pagination import LimitOffsetPagination
from datetime import datetime, timezone
import pytz
# get_menu_action = MenuActionMap.objects.values('id','menu_page','action').all()[2:20]
# print(get_menu_action)

# GetPermissionData = MenuActionMap.objects.filter(action=1).values('menu_page','menu_page__menu_name').distinct('menu_page')
# print(GetPermissionData)

def get_user_data(user):
    user_detail = User.objects.filter(id=user).values('id','email','company_detail_id').first()
    company_details = CompanyDetail.objects.filter(id=user_detail['company_detail_id']).values('id','company_name','country','plan_start_datetime','plan_expire_datetime','days_to_expire','minute_to_expire','plan_validity').first()
    
    user_role_maps = UserRoleMapping.objects.filter(user=user_detail['id']).values('id','role').first()
    # print("company:",company_details)
    #diff = datetime.strptime(str(company_details['plan_expire_datetime']), '%Y-%m-%d %H:%M:%S+00:00') - datetime.strptime(str(datetime.now()), '%Y-%m-%d %H:%M:%S.%f')
    plan_expire_datetime = company_details['plan_expire_datetime']
    plan_expire_datetime = plan_expire_datetime.replace(tzinfo=timezone.utc)  # Make it offset-aware

    diff = plan_expire_datetime - datetime.now(timezone.utc)

    if int(diff.total_seconds() / 60.0) > 0:
        CompanyDetail.objects.filter(id=user_detail['company_detail_id']).update(plan_validity=True,days_to_expire=diff.days,minute_to_expire=int(diff.total_seconds() / 60.0))
    else:
        CompanyDetail.objects.filter(id=user_detail['company_detail_id']).update(plan_validity=False,days_to_expire=diff.days,minute_to_expire=int(diff.total_seconds() / 60.0))
    company_details = CompanyDetail.objects.filter(id=user_detail['company_detail_id']).values('id','company_name','company_logo','country','plan_start_datetime','plan_expire_datetime','days_to_expire','minute_to_expire','plan_validity','currency__currency_symbol').first()
    role_detail = Roles.objects.filter(id=user_role_maps['role']).values('id','role_name').last()
    get_menu_data = Permission.objects.filter(role=user_role_maps['role']).values('id','menu_page','menu_page__menu_name').distinct('menu_page')
    permissions = {}
    for get_menu in get_menu_data:
        get_action = Permission.objects.filter(role=user_role_maps['role'],menu_page=get_menu['menu_page']).values('id','menu_page','action','action__action_name').distinct('action')
        permissions[get_menu['menu_page__menu_name']] = []
        for get_action in get_action:
            permissions[get_menu['menu_page__menu_name']].append(get_action.get('action__action_name'))

    product_allowed = ProductAllowed.objects.filter(company_detail_id=user_detail['company_detail_id']).values('id','default_product','allowed_status','default_product__product_name')
    feature_allowed = FeatureAllowed.objects.filter(company_detail_id=user_detail['company_detail_id']).values('id','default_product_feature','default_product_feature__parent_feature','allowed_status','product_allowed','default_product_feature__feature')

    product_allowed_data = []
    feature_allowed_data = []

    for product in product_allowed:
        product_data = {
            'id': product['id'],
            'default_product': product['default_product'],
            'allowed_status': product['allowed_status'],
            'default_product__product_name': product['default_product__product_name']
        }
        product_allowed_data.append(product_data)

    for feature in feature_allowed:
        feature_data = {
            'id': feature['id'],
            'default_product_feature': feature['default_product_feature'],
            'default_product_feature__parent_feature': feature['default_product_feature__parent_feature'],
            'allowed_status': feature['allowed_status'],
            'product_allowed': feature['product_allowed'],
            'default_product_feature__feature': feature['default_product_feature__feature']
        }
        feature_allowed_data.append(feature_data)

    
    data = {'user_detail':user_detail,'company_detail':company_details,'role_detail':role_detail,'permission':permissions,'product_allowed':product_allowed_data,'feature_allowed':feature_allowed_data}
    return data



def get_user_data_page(user,pages,action):
    user_detail = User.objects.filter(id=user).values('id','email','company_detail_id').first()
    company_details = CompanyDetail.objects.filter(id=user_detail['company_detail_id']).values('id','plan_start_datetime','plan_expire_datetime','days_to_expire','minute_to_expire','plan_validity').first()
    user_role_maps = UserRoleMapping.objects.filter(user=user_detail['id']).values('id','role').first()
    # print("company:",company_details)
    #diff = datetime.strptime(str(company_details['plan_expire_datetime']), '%Y-%m-%d %H:%M:%S+00:00') - datetime.strptime(str(datetime.now()), '%Y-%m-%d %H:%M:%S.%f')
    plan_expire_datetime = company_details['plan_expire_datetime']
    plan_expire_datetime = plan_expire_datetime.replace(tzinfo=timezone.utc)  # Make it offset-aware

    diff = plan_expire_datetime - datetime.now(timezone.utc)
    if int(diff.total_seconds() / 60.0) > 0:
        CompanyDetail.objects.filter(id=user_detail['company_detail_id']).update(plan_validity=True,days_to_expire=diff.days,minute_to_expire=int(diff.total_seconds() / 60.0)) 
    else:
        CompanyDetail.objects.filter(id=user_detail['company_detail_id']).update(plan_validity=False,days_to_expire=diff.days,minute_to_expire=int(diff.total_seconds() / 60.0))
    company_details = CompanyDetail.objects.filter(id=user_detail['company_detail_id']).values('id','company_name','company_logo','plan_validity','currency__currency_symbol').first()
    # permissions = Permission.objects.filter(role=user_role_maps['role'],menu_page__menu_name = pages,action__action_name=action).values('id','role','role__role_name','menu_page','menu_page__menu_name','action__action_name').distinct('menu_page').first()
    permissions = Permission.objects.filter(
    role=user_role_maps['role'],
    menu_page__menu_name=pages,
    action__action_name=action
).order_by('menu_page').distinct('menu_page').values(
    'id', 'role', 'role__role_name', 'menu_page', 'menu_page__menu_name', 'action__action_name'
).first()
    
    product_allowed = ProductAllowed.objects.filter(company_detail_id=user_detail['company_detail_id']).values('id','default_product','allowed_status','default_product__product_name')
    feature_allowed = FeatureAllowed.objects.filter(company_detail_id=user_detail['company_detail_id']).values('id','default_product_feature','default_product_feature__parent_feature','allowed_status','product_allowed','default_product_feature__feature')

    product_allowed_data = []
    feature_allowed_data = []

    for product in product_allowed:
        product_data = {
            'id': product['id'],
            'default_product': product['default_product'],
            'allowed_status': product['allowed_status'],
            'default_product__product_name': product['default_product__product_name']
        }
        product_allowed_data.append(product_data)

    for feature in feature_allowed:
        feature_data = {
            'id': feature['id'],
            'default_product_feature': feature['default_product_feature'],
            'allowed_status': feature['allowed_status'],
            'product_allowed': feature['product_allowed'],
            'default_product_feature__feature': feature['default_product_feature__feature']
        }
        feature_allowed_data.append(feature_data)

    data = {'user_detail':user_detail,'company_detail':company_details,'permission':permissions,'product_allowed':product_allowed_data,'feature_allowed':feature_allowed_data}
    return data



async def get_user_data_page_async(user,pages,action):
    user_detail = await User.objects.filter(id=user).values('id','email','company_detail_id').first()
    company_details = await CompanyDetail.objects.filter(id=user_detail['company_detail_id']).values('id','plan_start_datetime','plan_expire_datetime','days_to_expire','minute_to_expire','plan_validity').first()
    user_role_maps = await UserRoleMapping.objects.filter(user=user_detail['id']).values('id','role').first()
    # print("company:",company_details)
    #diff = datetime.strptime(str(company_details['plan_expire_datetime']), '%Y-%m-%d %H:%M:%S+00:00') - datetime.strptime(str(datetime.now()), '%Y-%m-%d %H:%M:%S.%f')
    plan_expire_datetime = company_details['plan_expire_datetime']
    plan_expire_datetime = plan_expire_datetime.replace(tzinfo=timezone.utc)  # Make it offset-aware

    diff = plan_expire_datetime - datetime.now(timezone.utc)
    if int(diff.total_seconds() / 60.0) > 0:
        await CompanyDetail.objects.filter(id=user_detail['company_detail_id']).update(plan_validity=True,days_to_expire=diff.days,minute_to_expire=int(diff.total_seconds() / 60.0)) 
    else:
        await CompanyDetail.objects.filter(id=user_detail['company_detail_id']).update(plan_validity=False,days_to_expire=diff.days,minute_to_expire=int(diff.total_seconds() / 60.0))
    company_details = await CompanyDetail.objects.filter(id=user_detail['company_detail_id']).values('id','company_name','company_logo','plan_validity','currency__currency_symbol').first()
    # permissions = Permission.objects.filter(role=user_role_maps['role'],menu_page__menu_name = pages,action__action_name=action).values('id','role','role__role_name','menu_page','menu_page__menu_name','action__action_name').distinct('menu_page').first()
    permissions = await Permission.objects.filter(
    role=user_role_maps['role'],
    menu_page__menu_name=pages,
    action__action_name=action
).order_by('menu_page').distinct('menu_page').values(
    'id', 'role', 'role__role_name', 'menu_page', 'menu_page__menu_name', 'action__action_name'
).first()
    
    product_allowed = await ProductAllowed.objects.filter(company_detail_id=user_detail['company_detail_id']).values('id','default_product','allowed_status','default_product__product_name')
    feature_allowed = await FeatureAllowed.objects.filter(company_detail_id=user_detail['company_detail_id']).values('id','default_product_feature','default_product_feature__parent_feature','allowed_status','product_allowed','default_product_feature__feature')

    product_allowed_data = []
    feature_allowed_data = []

    for product in product_allowed:
        product_data = {
            'id': product['id'],
            'default_product': product['default_product'],
            'allowed_status': product['allowed_status'],
            'default_product__product_name': product['default_product__product_name']
        }
        product_allowed_data.append(product_data)

    for feature in feature_allowed:
        feature_data = {
            'id': feature['id'],
            'default_product_feature': feature['default_product_feature'],
            'allowed_status': feature['allowed_status'],
            'product_allowed': feature['product_allowed'],
            'default_product_feature__feature': feature['default_product_feature__feature']
        }
        feature_allowed_data.append(feature_data)

    data = {'user_detail':user_detail,'company_detail':company_details,'permission':permissions,'product_allowed':product_allowed_data,'feature_allowed':feature_allowed_data}
    return data



# DefaultProduct API
class DefaultProductView(APIView):

    def get(self, request, format=None):
        limit = int(request.GET.get('limit',10))
        offset = int(request.GET.get('offset',0))
        queryset = DefaultProduct.objects.all()[offset:limit+offset]
        serializer = DefaultProductSerializer(queryset, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
       
    
    def post(self, request, format=None):
        get_data = request.data
        serializer = DefaultProductSerializer(data=get_data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        

#DefaultProductFeature API       
class DefaultProductFeatureView(APIView):

    def get(self, request, format=None):
        limit = int(request.GET.get('limit',10))
        offset = int(request.GET.get('offset',0))
        queryset = DefaultProductFeature.objects.filter(parent_feature__isnull=True).all()[offset:limit+offset]
        serializer = DefaultProductFeatureSerializer(queryset, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
       
    
    def post(self, request, format=None):
        get_data = request.data
        serializer = DefaultProductFeatureSerializer(data=get_data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class Register(APIView):
    permission_classes = (AllowAny,)
    def post(self, request, format=None):
        add_user_emails = AddUserEmail.objects.filter(email=request.data['email']).values('email','role','company_detail_id').first()
        if add_user_emails != None:
            company_detail_id = add_user_emails.get('company_detail_id')
            get_company_detail = CompanyDetail.objects.filter(id=company_detail_id).first()

            
            serializer = UserSerializer(data={'email':request.data['email'],'phone_number':request.data['phone_number'],'password':request.data['password'],'password2':request.data['password2'],'company_detail_id': company_detail_id,'user_login_or_not':False,'is_superuser':False,'is_active':False})
            user_id = None
            if serializer.is_valid():
                obj = serializer.save()
                user_id = obj.id
            else:
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            user_role_map_serializer = UserRoleMappingSerializer(data={'user':user_id,'role':add_user_emails.get('role'),'company_detail_id': add_user_emails.get('company_detail_id')})
            if user_role_map_serializer.is_valid():
                user_role_map_serializer.save()
            else:
                User.objects.filter(id=user_id).delete()
                return Response(user_role_map_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            user_select = User.objects.filter(id=user_id).last()
            refresh = RefreshToken.for_user(user_select)
            user_detail = get_user_data(user_id)
            user_detail['refresh'] = str(refresh)
            user_detail['access'] = str(refresh.access_token)
            return Response(user_detail, status=status.HTTP_201_CREATED)
        else:
            print("Yes")
            return Response({"result": {},"message": "Company are not register with this email."}, status=status.HTTP_400_BAD_REQUEST)



# class AddCompany(APIView):
#     # authentication_classes = (TokenAuthentication,)
#     permission_classes = (AllowAny,)

#     def post(self, request, format=None):
#         currency_detail = {'currency_type': request.data['currency_type'], 'currency_symbol': request.data['currency_symbol']}
#         currency_serializer = CurrencySerializer(data=currency_detail)
#         currency_id = None
#         if currency_serializer.is_valid():
#             obj = currency_serializer.save()
#             currency_id = obj.id
#         else:
#             return Response(currency_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

#         company_detail = {
#             'company_name': request.data['company_name'],
#             'country': request.data['country'],
#             'uses_type': 'free trail',
#             'plan_start_datetime': datetime.now(),
#             'plan_expire_datetime': datetime.now() + timedelta(days=15),
#             'days_to_expire': 15,
#             'plan_validity': True,
#             'currency': currency_id
#         }
#         company_serializer = CompanyDetailSerializer(data=company_detail)
#         company_id = None
#         if company_serializer.is_valid():
#             obj = company_serializer.save()
#             company_id = obj.id
#         else:
#             return Response(company_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

#         role_detail = {'role_name': 'Admin', 'company_detail_id': company_id}

#         role_serializer = RoleSerializer(data=role_detail)
#         role_id = None
#         if role_serializer.is_valid():
#             obj = role_serializer.save()
#             role_id = obj.id
#         else:
#             CompanyDetail.objects.filter(id=company_id).delete()
#             return Response(role_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

#         add_user_email_serializer = AddUserEmailSerializer(data={'email': request.data['email'], 'role': role_id, 'company_detail_id': company_id})
#         add_user_emailid = None
#         if add_user_email_serializer.is_valid():
#             obj = add_user_email_serializer.save()
#             add_user_emailid = obj.id
#         else:
#             CompanyDetail.objects.filter(id=company_id).delete()
#             Roles.objects.filter(id=role_id).delete()
#             return Response(add_user_email_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

#         permission_id = []
#         get_menu_data = MenuPage.objects.exclude(is_menu_type__is_menu_visible='SuperAdmin').all().values('id', 'menu_name')
#         print(get_menu_data)
#         # for perm in range(len(PermissionDetail)):
#         for menus in get_menu_data:
#             get_menu_action_data = MenuActionMap.objects.filter(menu_page=menus['id']).values('id', 'menu_page', 'action').all()
#             for menu_action in get_menu_action_data:
#                 print(menu_action)
#                 permission_serializer = PermissionSerializer(data={'role': role_id, 'menu_page': menu_action['menu_page'], 'action': menu_action['action']})
#                 if permission_serializer.is_valid():
#                     obj = permission_serializer.save()
#                     permission_id.append(obj.id)
#                 else:
#                     CompanyDetail.objects.filter(id=company_id).delete()
#                     Roles.objects.filter(id=role_id).delete()
#                     AddUserEmail.objects.filter(id=add_user_emailid).delete()
#                     for perm_id in permission_id:
#                         Permission.objects.filter(id=perm_id).delete()
#                     return Response(permission_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

#         default_product = request.data['default_product']  
#         default_product_features = DefaultProductFeature.objects.filter(default_product=default_product)

#         product_allowed_data = {
#             'default_product':default_product,
#             'allowed_status': request.data['allowed_status'],
#             'company_detail_id': company_id
#         }
#         product_allowed_serializer = ProductAllowedSerializer(data=product_allowed_data)
#         if product_allowed_serializer.is_valid():
#             product_allowed_serializer.save()
#         else:
#             CompanyDetail.objects.filter(id=company_id).delete()
#             Roles.objects.filter(id=role_id).delete()
#             AddUserEmail.objects.filter(id=add_user_emailid).delete()
#             for perm_id in permission_id:
#                 Permission.objects.filter(id=perm_id).delete()
#             return Response(product_allowed_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

#         for feature in default_product_features:
#             feature_allowed_data = {
#                 'default_product_feature': feature.id,
#                 'allowed_status': request.data['allowed_status'],
#                 'product_allowed': product_allowed_serializer.instance.id,
#                 'company_detail_id': company_id
#             }
#             feature_allowed_serializer = FeatureAllowedSerializer(data=feature_allowed_data)
#             if feature_allowed_serializer.is_valid():
#                 feature_allowed_serializer.save()
#             else:
#                 CompanyDetail.objects.filter(id=company_id).delete()
#                 Roles.objects.filter(id=role_id).delete()
#                 AddUserEmail.objects.filter(id=add_user_emailid).delete()
#                 for perm_id in permission_id:
#                     Permission.objects.filter(id=perm_id).delete()
#                 ProductAllowed.objects.filter(id=product_allowed_serializer.instance.id).delete()
#                 return Response(feature_allowed_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

#         return Response({'Sucess': 'Company Created Successfully.'}, status.HTTP_201_CREATED)


class AddCompany(APIView):
    # authentication_classes = (TokenAuthentication,)
    permission_classes = (AllowAny,)

    def post(self, request, format=None):
        currency_detail = Currency.objects.filter(currency_type=request.data['currency_type']).values('id').first()
        # currency_detail = {'currency_type': request.data['currency_type'], 'currency_symbol': request.data['currency_symbol']}
        # currency_serializer = CurrencySerializer(data=currency_detail)
        # currency_id = None
        # if currency_serializer.is_valid():
        #     currency_obj = currency_serializer.save()
        #     currency_id = currency_obj.id
        # else:
        #     return Response(currency_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        company_detail = {
            'company_name': request.data['company_name'],
            'country': request.data['country'],
            'uses_type': 'free trail',
            'plan_start_datetime': datetime.now(),
            'plan_expire_datetime': datetime.now() + timedelta(days=15),
            'days_to_expire': 15,
            'plan_validity': True,
            'currency': currency_detail['id'],
            'delete_previous_data_after_day_cloud': request.data['delete_previous_data_after_day_cloud'],
            'delete_previous_data_after_day_on_premises': request.data['delete_previous_data_after_day_on_premises']
        }
        company_serializer = CompanyDetailSerializer(data=company_detail)
        company_id = None
        if company_serializer.is_valid():
            company_obj = company_serializer.save()
            company_id = company_obj.id
        else:
            return Response(company_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        role_detail = {'role_name': 'Admin', 'company_detail_id': company_id}

        role_serializer = RoleSerializer(data=role_detail)
        role_id = None
        if role_serializer.is_valid():
            role_obj = role_serializer.save()
            role_id = role_obj.id
        else:
            CompanyDetail.objects.filter(id=company_id).delete()
            return Response(role_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        add_user_email_serializer = AddUserEmailSerializer(data={'email': request.data['email'], 'role': role_id, 'company_detail_id': company_id})
        add_user_email_id = None
        if add_user_email_serializer.is_valid():
            add_user_email_obj = add_user_email_serializer.save()
            add_user_email_id = add_user_email_obj.id
        else:
            CompanyDetail.objects.filter(id=company_id).delete()
            Roles.objects.filter(id=role_id).delete()
            return Response(add_user_email_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        permission_ids = []
        get_menu_data = MenuPage.objects.exclude(is_menu_type__is_menu_visible='SuperAdmin').all().values('id', 'menu_name')
        for menu in get_menu_data:
            get_menu_action_data = MenuActionMap.objects.filter(menu_page=menu['id']).values('id', 'menu_page', 'action').all()
            for menu_action in get_menu_action_data:
                permission_serializer = PermissionSerializer(data={'role': role_id, 'menu_page': menu_action['menu_page'], 'action': menu_action['action']})
                if permission_serializer.is_valid():
                    permission_obj = permission_serializer.save()
                    permission_ids.append(permission_obj.id)
                else:
                    CompanyDetail.objects.filter(id=company_id).delete()
                    Roles.objects.filter(id=role_id).delete()
                    AddUserEmail.objects.filter(id=add_user_email_id).delete()
                    for permission_id in permission_ids:
                        Permission.objects.filter(id=permission_id).delete()
                    return Response(permission_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        default_products = request.data.get('default_products', [])
        default_product_instances = []
        feature_instances = []

        for default_product in default_products:
            default_product_data = {
                'default_product': default_product['default_product'],
                'allowed_status': default_product['allowed_status'],
                'company_detail_id': company_id
            }
            default_product_serializer = ProductAllowedSerializer(data=default_product_data)
            if default_product_serializer.is_valid():
                default_product_instance = default_product_serializer.save()
                default_product_instances.append(default_product_instance)

                default_product_features = default_product.get('default_product_features', [])
                for feature in default_product_features:
                    feature_allowed_data = {
                        'default_product_feature': feature['default_product_feature'],
                        'allowed_status': feature['allowed_status'],
                        'product_allowed': default_product_instance.id,
                        'parent_feature': feature['parent_feature'],
                        'company_detail_id': company_id
                    }
                    feature_allowed_serializer = FeatureAllowedSerializer(data=feature_allowed_data)
                    if feature_allowed_serializer.is_valid():
                        feature_instance = feature_allowed_serializer.save()
                        feature_instances.append(feature_instance)
                    else:
                        CompanyDetail.objects.filter(id=company_id).delete()
                        Roles.objects.filter(id=role_id).delete()
                        AddUserEmail.objects.filter(id=add_user_email_id).delete()
                        for permission_id in permission_ids:
                            Permission.objects.filter(id=permission_id).delete()
                        for instance in default_product_instances:
                            instance.delete()
                        for instance in feature_instances:
                            instance.delete()
                        return Response(feature_allowed_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

            else:
                CompanyDetail.objects.filter(id=company_id).delete()
                Roles.objects.filter(id=role_id).delete()
                AddUserEmail.objects.filter(id=add_user_email_id).delete()
                for permission_id in permission_ids:
                    Permission.objects.filter(id=permission_id).delete()
                return Response(default_product_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        return Response({'Success': 'Company Created Successfully.'}, status=status.HTTP_201_CREATED)


   
class Login(APIView):
    permission_classes = (AllowAny,)
    def post(self, request, format=None):
        serializer = UserLoginSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        email = serializer.data.get('email')
        password = serializer.data.get('password')
        print(email,password)
        user = authenticate(email=email,password=password)
        if user:
            if user.is_active:
                refresh = RefreshToken.for_user(user)
                user_detail = get_user_data(user.id)
                user_detail['refresh'] = str(refresh)
                user_detail['access'] = str(refresh.access_token)
                #print(user_detail)
                return JsonResponse(user_detail, status=status.HTTP_200_OK)
            else:
                res = {"code": 400, "message": "Account was not active."}
                return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)
        else:
            res = {"code": 400, "message": "Invalid Username and Password."}
            return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)
        

class WindowsLogin(APIView):
    permission_classes = (AllowAny,)

    def post(self, request, format=None):
        serializer = UserLoginSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        email = serializer.data.get('email')
        password = serializer.data.get('password')
        print(email, password)
        user = authenticate(email=email, password=password)

        if user:
            if user.is_active:
                getSites = Sites.objects.filter(user=user.id).values('id', 'site_name', 'user','user_login_or_not','active','company_detail_id__plan_expire_datetime').first()

                if getSites is not None:
                    if getSites['user_login_or_not'] is False:
                        if getSites['active'] is True:
                            # Check allowed_status for site_product and site_feature
                            # site_product_allowed = SiteProductAllowed.objects.filter(site=getSites['id']).first()
                            # site_feature_allowed = SiteFeatureAllowed.objects.filter(site_product_allowed=site_product_allowed.id).first()

                            # if site_product_allowed and site_feature_allowed:
                            #     if site_product_allowed.allowed_status and site_feature_allowed.allowed_status:
                            #         TimeZoneLoc = pytz.timezone('Asia/Kolkata')
                            #         diff = datetime.strptime(str(getSites['company_detail_id__plan_expire_datetime']),
                            #                                  '%Y-%m-%d %H:%M:%S.%f+00:00') - datetime.strptime(
                            #             str(datetime.now()), '%Y-%m-%d %H:%M:%S.%f')

                            #         if int(diff.total_seconds() / 60.0) > 0:
                            #             Sites.objects.filter(id=getSites['id']).update(
                            #                 plan_validity=True, days_to_expire=diff.days, user_login_or_not=True)
                            #         else:
                            Sites.objects.filter(id=getSites['id']).update(user_login_or_not=True)
                            user_detail = get_user_data(user.id)
                            update_sites = Sites.objects.filter(user=user.id).first()
                            # .values('id', 'site_name', 'user__email',
                            # 'company_detail_id',
                            # 'company_detail_id__plan_start_datetime',
                            # 'company_detail_id__plan_expire_datetime',
                            # 'days_to_expire',
                            # 'minute_to_expire',
                            # 'plan_validity', 'company_detail_id__timezones',
                            # 'active', 'user_login_or_not',
                            # 'skip_frame',
                            # 'company_detail_id__delete_previous_data_after_day_cloud',
                            # 'company_detail_id__delete_previous_data_after_day_on_premises')
                            sites_serializer = SitesSerializer(update_sites)
                            refresh = RefreshToken.for_user(user)
                            
                            user_detail['refresh'] = str(refresh)
                            user_detail['access'] = str(refresh.access_token)
                            user_detail['sites'] = sites_serializer.data
                            # print(user_detail)
                            return JsonResponse(user_detail, status=status.HTTP_200_OK)
                            #     else:
                            #         res = {"code": 400, "message": "Site or its features are not allowed."}
                            #         return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)
                            # else:
                            #     res = {"code": 400, "message": "Site or its features are not allowed."}
                            #     return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)
                        else:
                            res = {"code": 400, "message": "Your Sites is not active."}
                            return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)
                    else:
                        res = {"code": 400, "message": "Your sites account is already logged in to another system. Please logout first."}
                        return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)
                else:
                    res = {"code": 400, "message": "Your account is not valid for the Windows application."}
                    return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)
            else:
                res = {"code": 400, "message": "Account is not active."}
                return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)
        else:
            res = {"code": 400, "message": "Invalid username and password."}
            return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)

class WindowsLogout(APIView):
    permission_classes = (IsAuthenticated,)
    def post(self, request, format=None):
        getSites = Sites.objects.filter(user=request.user.id).values('id','site_name').first()
        if getSites != None:
                updateSites = Sites.objects.filter(user=request.user.id).update(user_login_or_not=False)
                res = {"code": 200, "submit": "Your account are logout successfully."}
                return JsonResponse(res, status=status.HTTP_200_OK)
        else:
            res = {"code": 400, "submit": "Your account is not valid for windows application."}
            return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)


class WindowsGetUserDetail(APIView):
    permission_classes = (IsAuthenticated,)
    def get(self, request, format=None):
        getSites = Sites.objects.filter(user=request.user.id).values('id', 'site_name', 'user','user_login_or_not','active','company_detail_id__plan_expire_datetime').first()
        if getSites != None:
            Sites.objects.filter(id=getSites['id']).update(user_login_or_not=True)
            user_detail = get_user_data(request.user.id)
            update_sites = Sites.objects.filter(user=request.user.id).first()
            sites_serializer = SitesSerializer(update_sites)
            user_detail['sites'] = sites_serializer.data

            # print(user_detail)
            return JsonResponse(user_detail, status=status.HTTP_200_OK)
        else:
            res = {"code": 400, "submit": "Your account is not valid for windows application."}
            return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)



# class WindowsLogin(APIView):
#     permission_classes = (AllowAny,)
#     def post(self, request, format=None):
#         serializer = UserLoginSerializer(data=request.data)
#         serializer.is_valid(raise_exception=True)
#         email = serializer.data.get('email')
#         password = serializer.data.get('password')
#         print(email,password)
#         user = authenticate(email=email,password=password)
#         if user:
#             if user.is_active:
#                 getSites = Sites.objects.filter(user=user.id).values('id','site_name','user','company_detail').first()
#                 if getSites != None:
#                     if getSites['user_login_or_not'] == False:
#                         if getSites['active'] == True:
#                             TimeZoneLoc = pytz.timezone('Asia/Kolkata')
#                             diff = datetime.strptime(str(getSites['plan_expire_datetime']), '%Y-%m-%d %H:%M:%S.%f+00:00') - datetime.strptime(str(datetime.now()), '%Y-%m-%d %H:%M:%S.%f')
#                             if int(diff.total_seconds() / 60.0) > 0:
#                                 Sites.objects.filter(id=getSites['id']).update(plan_validity=True,days_to_expire=diff.days,user_login_or_not=True)
#                             else:
#                                 Sites.objects.filter(id=getSites['id']).update(plan_validity=False,days_to_expire=diff.days,user_login_or_not=True)   
#                             update_sites = Sites.objects.filter(user=user.id).values('id','site_name','user','company_detail_id','plan_start_datetime','plan_expire_datetime','days_to_expire','plan_validity','timezones','active','user_login_or_not','skip_frame','delete_previous_data_after_day').first()
#                             refresh = RefreshToken.for_user(user)
#                             user_detail = get_user_data(user.id)
#                             user_detail['refresh'] = str(refresh)
#                             user_detail['access'] = str(refresh.access_token)
#                             user_detail['sites'] = getSites
#                             # print(user_detail)
#                             return JsonResponse(user_detail, status=status.HTTP_200_OK)
#                         else:
#                             res = {"code": 400, "message": "Your Sites is not active."}
#                             return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)
#                     else:
#                         res = {"code": 400, "message": "Your sites account is already login in other system. Please logout first. "}
#                         return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)
#                 else:
#                     res = {"code": 400, "message": "Your account is not valid for windows application."}
#                     return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)
#             else:
#                 res = {"code": 400, "message": "Account was not active."}
#                 return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)
#         else:
#             res = {"code": 400, "message": "Invalid Username and Password."}
#             return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)

class GetUserDetail(APIView):
    permission_classes = (IsAuthenticated,)
    # authentication_classes = (TokenAuthentication,)
    
    def get(self, request, format=None):
        try:
            token = request.META.get('HTTP_AUTHORIZATION', " ").split(' ')[1]
            if token != '':
                data = {'token': token}
                print("data:",data)
                valid_data = TokenBackend(algorithm='HS256').decode(token,verify=False)
                print(valid_data)
                user = valid_data['user_id']
                print("User:",user,request.user.id)
                request.user = user
                print("request.user1:",request.user)
            else:
                Response({"result": {},"message": "Invalid Token."}, status=status.HTTP_201_CREATED)
        except ValidationError as v:
            print("validation error", v)
        user_detail = get_user_data(request.user)
        return Response(user_detail)

    
class AddUserEmailView(APIView):
    permission_classes = (IsAuthenticated,)
    pagination_class = LimitOffsetPagination

    async def get(self, request, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        user_detail_page = await get_user_data_page_async(request.user.id,'add user email','view')
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            # if 'add user email' in user_detail_page['permission'].keys():
            #     if 'view' in user_detail_page['permission']['add user email']:
            #         AccessToPage = True
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                limit = int(request.GET.get('limit',10))
                offset = int(request.GET.get('offset',0))
                get_data,get_data_count = await self.get_object(limit,offset,user_detail_page['company_detail']['id'])
                serializer = AddUserEmailSerializer(get_data, many=True)
                return Response({"count":get_data_count, "results":serializer.data})
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    async def post(self, request, format=None):
        user_detail_page = await get_user_data_page_async(request.user.id,'add user email','create')  
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            # if 'add user email' in user_detail_page['permission'].keys():
            #     if 'create' in user_detail_page['permission']['add user email']:
            #         AccessToPage = True
            if AccessToPage == True:
                limit = int(request.GET.get('limit',10))
                offset = int(request.GET.get('offset',0))
                get_data = request.data
                get_data['company_detail_id'] = user_detail_page['company_detail']['id']
                print(get_data)
                serializer = AddUserEmailSerializer(data=get_data)
                if serializer.is_valid():
                    await serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    async def get_object(self,limit,offset,company_detail_id):
        add_user_email_detail = await AddUserEmail.objects.filter(company_detail_id = company_detail_id).order_by('-id').all()[offset:limit+offset]  ##.values('id','licence_plate_number','licence_plate_image','confidence_licence_plate','datetime','speed','speed_violation','lane_change','driver_seat_belt','driver_seat_belt_image','confidence_driver_seat_belt','passanger_seat_belt','passanger_seat_belt_image','confidence_passanger_seat_belt','driver_mobile','driver_mobile_image','confidence_driver_mobile','passanger_mobile','passanger_mobile_image','confidence_passanger_mobile','vehicle_type','vehicle_direction','country','camera_name','created_by','created_datetime','updated_by','updated_datetime')
        add_user_email_detail_count = await AddUserEmail.objects.filter(company_detail_id = company_detail_id).order_by('-id').count()
        return add_user_email_detail,add_user_email_detail_count

class UserEmailDetailView(APIView):
    permission_classes = (IsAuthenticated,)
    def get_object(self, id):
        try:
            return AddUserEmail.objects.get(pk=id)
        except AddUserEmail.DoesNotExist:
            raise Http404
    def get(self, request,id, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        user_detail_page = get_user_data_page(request.user.id,'add user email','view')  
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            # if 'add user email' in user_detail_page['permission'].keys():
            #     if 'view' in user_detail_page['permission']['add user email']:
            #         AccessToPage = True
            if AccessToPage == True:
                sites = self.get_object(id)
                serializer = AddUserEmailSerializer(sites)
                return Response(serializer.data)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
    def put(self, request, id, format=None): 
        user_detail_page = get_user_data_page(request.user.id,'add user email','update')  
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            # if 'add user email' in user_detail_page['permission'].keys():
            #     if 'update' in user_detail_page['permission']['add user email']:
            #         AccessToPage = True
            if AccessToPage == True:
                add_user_email = self.get_object(id)
                get_data = request.data
                get_data['company_detail_id'] = user_detail_page['company_detail']['id']
                serializer = AddUserEmailSerializer(add_user_email, data=get_data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)  
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
     
    def delete(self, request,id, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        user_detail_page = get_user_data_page(request.user.id,'add user email','delete')  
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            # if 'add user email' in user_detail_page['permission'].keys():
            #     if 'delete' in user_detail_page['permission']['add user email']:
            #         AccessToPage = True
            if AccessToPage == True:
                add_user_email = self.get_object(id)
                add_user_email.delete()
                return Response(status=status.HTTP_204_NO_CONTENT)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
 
class SiteView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, format=None):
        limit = int(request.GET.get('limit',10))
        offset = int(request.GET.get('offset',0))
        # print("request.user",request.user,request.user.id,type(request.user.id))
        user_detail_page = get_user_data_page(request.user.id,'sites','view')  
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            # if 'sites' in user_detail_page['permission'].keys():
            #     if 'view' in user_detail_page['permission']['sites']:
            #         AccessToPage = True
            if AccessToPage == True:
                sites_detail = Sites.objects.filter(company_detail_id = user_detail_page['company_detail']['id']).all()[offset:limit+offset]
                sites_count = Sites.objects.filter(company_detail_id = user_detail_page['company_detail']['id']).count()
                serializer = SitesSerializer(sites_detail, many=True)

                return Response({"count":sites_count, "results":serializer.data})
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
    
    # def post(self, request, format=None):
    #     user_detail_page = get_user_data_page(request.user.id,'sites','create')  
    #     if user_detail_page['company_detail']['plan_validity'] == True:
    #         AccessToPage = False
    #         if user_detail_page['permission'] != None:
    #             AccessToPage = True
    #         # if 'sites' in user_detail_page['permission'].keys():
    #         #     if 'create' in user_detail_page['permission']['sites']:
    #         #         AccessToPage = True
    #         if AccessToPage == True:
    #             get_data = request.data
    #             get_data['company_detail'] = user_detail_page['company_detail']['id']
    #             serializer = SitesSerializer(data=get_data)
    #             if serializer.is_valid():
    #                 serializer.save()
    #                 return Response(serializer.data, status=status.HTTP_201_CREATED)
    #             else:
    #                 return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    #         else:
    #             return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
    #     else:
    #         return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def post(self, request, format=None):
        user_detail_page = get_user_data_page(request.user.id, 'sites', 'create')
        if user_detail_page['company_detail']['plan_validity']:
            AccessToPage = False
            if user_detail_page['permission'] is not None:
                AccessToPage = True

            if AccessToPage:
                get_data = request.data
                get_data['company_detail_id'] = user_detail_page['company_detail']['id']
                site_product_allow = get_data.pop('site_product_allow')
                product_id=[]
                feature_id=[]
                serializer = SitesSerializer(data=get_data, context={'request': request})
                if serializer.is_valid():
                    site_instance = serializer.save()
                    for product in site_product_allow:
                        product_data = {
                            "product_allowed":product['product_allowed'],
                            "allowed_status":product['allowed_status'],
                            "company_detail_id":user_detail_page['company_detail']['id'],
                            "site":site_instance.id
                        }
                        site_product_allowed_serializer = SiteProductAllowedSerializer(data=product_data)
                        if site_product_allowed_serializer.is_valid():
                            site_product_instance = site_product_allowed_serializer.save()
                            product_id.append(site_product_instance.id)
                        else:
                            site_instance.delete()
                            for product_instance in product_id:
                                SiteProductAllowed.objects.filter(id=product_instance['id']).delete()
                            return Response(site_product_allowed_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                        for feature in product['site_product_feature_allow']:
                            feature_data = {
                                'feature_allowed': feature['feature_allowed'],
                                'allowed_status': feature['allowed_status'],
                                'site_product_allowed': site_product_allowed_serializer.instance.id,
                                'company_detail_id': user_detail_page['company_detail']['id'],
                                'site': site_instance.id
                            }
                            for sub_feature in feature['sub_features']:
                                feature_data = {
                                'feature_allowed': sub_feature['feature_allowed'],
                                'allowed_status': sub_feature['allowed_status'],
                                'site_product_allowed': site_product_allowed_serializer.instance.id,
                                'company_detail_id': user_detail_page['company_detail']['id'],
                                'site': site_instance.id
                                }
                                site_feature_allowed_serializer = SiteFeatureAllowedSerializer(data=feature_data)
                                if site_feature_allowed_serializer.is_valid():
                                    site_feature_instance = site_feature_allowed_serializer.save()
                                    feature_id.append(site_feature_instance.id)
                                else:
                                    site_instance.delete()
                                    for product_instance in product_id:
                                        SiteProductAllowed.objects.filter(id=product_instance['id']).delete()
                                    for feature_instance in feature_id:
                                        SiteFeatureAllowed.objects.filter(id=feature_instance['id']).delete()
                                    return Response(site_feature_allowed_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

                            site_feature_allowed_serializer = SiteFeatureAllowedSerializer(data=feature_data)
                            if site_feature_allowed_serializer.is_valid():
                                site_feature_instance = site_feature_allowed_serializer.save()
                                feature_id.append(site_feature_instance.id)
                            else:
                                site_instance.delete()
                                for product_instance in product_id:
                                    SiteProductAllowed.objects.filter(id=product_instance['id']).delete()
                                for feature_instance in feature_id:
                                    SiteFeatureAllowed.objects.filter(id=feature_instance['id']).delete()
                                return Response(site_feature_allowed_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                else:
                    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "You don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "Account validity has expired."}, status=status.HTTP_400_BAD_REQUEST)
    
       
class SitesDetailView(APIView):
    permission_classes = (IsAuthenticated,)
    def get_object(self, id):
        try:
            return Sites.objects.get(pk=id)
        except Sites.DoesNotExist:
            raise Http404
    def get(self, request,id, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        user_detail_page = get_user_data_page(request.user.id,'sites','view')  
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            # if 'sites' in user_detail_page['permission'].keys():
            #     if 'view' in user_detail_page['permission']['sites']:
            #         AccessToPage = True
            if AccessToPage == True:
                sites = self.get_object(id)
                serializer = SitesSerializer(sites)
                return Response(serializer.data)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
        
       
    def put(self, request, id, format=None):
        user_detail_page = get_user_data_page(request.user.id, 'sites', 'update')
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True

            if AccessToPage == True:
                site = self.get_object(id)
                serializer = SitesSerializer(site, data=request.data)
                if serializer.is_valid():
                    site_instance = serializer.save()

                    # Update SiteProductAllowed
                    site_product_allowed_data = {
                        'default_product': request.data['default_product'],
                        'allowed_status': request.data['allowed_status'],
                        'company_detail_id': user_detail_page['company_detail']['id'],
                        'site': site_instance.id
                    }
                    site_product_allowed_serializer = SiteProductAllowedSerializer(
                        site.site_product_allowed.all(),
                        data=site_product_allowed_data,
                        many=True
                    )
                    if site_product_allowed_serializer.is_valid():
                        site_product_allowed_serializer.save()
                    else:
                        return Response(site_product_allowed_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

                    # Update SiteFeatureAllowed
                    default_product_features = DefaultProductFeature.objects.filter(
                        default_product=request.data['default_product']
                    )
                    for feature in default_product_features:
                        site_feature_allowed_data = {
                            'default_product_feature': feature,
                            'allowed_status': request.data['allowed_status'],
                            'product_allowed': site_product_allowed_serializer.instance,
                            'company_detail_id': user_detail_page['company_detail']['id'],
                            'site': site_instance.id
                        }
                        site_feature_allowed_serializer = SiteFeatureAllowedSerializer(
                            site.site_feature_allowed.all(),
                            data=site_feature_allowed_data,
                            many=True
                        )
                        if site_feature_allowed_serializer.is_valid():
                            site_feature_allowed_serializer.save()
                        else:
                            return Response(site_feature_allowed_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "You don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "Account validity has expired."}, status=status.HTTP_400_BAD_REQUEST)
        

    # def put(self, request, id, format=None): 
    #     user_detail_page = get_user_data_page(request.user.id,'sites','update')  
    #     if user_detail_page['company_detail']['plan_validity'] == True:
    #         AccessToPage = False
    #         if user_detail_page['permission'] != None:
    #             AccessToPage = True
    #         # if 'sites' in user_detail_page['permission'].keys():
    #         #     if 'update' in user_detail_page['permission']['sites']:
    #         #         AccessToPage = True
    #         if AccessToPage == True:
    #             sites = self.get_object(id)
    #             serializer = SitesSerializer(sites, data=request.data)
    #             if serializer.is_valid():
    #                 serializer.save()
    #                 return Response(serializer.data)
    #             return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)  
    #         else:
    #             return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
    #     else:
    #         return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
     
    def delete(self, request,id, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        user_detail_page = get_user_data_page(request.user.id,'sites','delete')  
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            # if 'sites' in user_detail_page['permission'].keys():
            #     if 'delete' in user_detail_page['permission']['sites']:
            #         AccessToPage = True
            if AccessToPage == True:
                sites = self.get_object(id)
                sites.delete()
                return Response(status=status.HTTP_204_NO_CONTENT)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class GetCompanyProductAndFeatureDetail(APIView):
    permission_classes = (IsAuthenticated,)
    def get(self, request, format=None):
        user_detail_page = get_user_data_page(request.user.id,'sites','view')  
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                product_allowed = ProductAllowed.objects.filter(company_detail_id=user_detail_page['company_detail']['id']).values('id','default_product','allowed_status','default_product__product_name')
                product_allowed_data = []
                for product in product_allowed:
                    feature_allowed_data = []
                    feature_allowed = FeatureAllowed.objects.filter(company_detail_id=user_detail_page['company_detail']['id'],product_allowed=product['id']).values('id','default_product_feature','default_product_feature__parent_feature','allowed_status','product_allowed','default_product_feature__feature')
                    for feature in feature_allowed:
                        feature_data = {
                            'id': feature['id'],
                            'default_product_feature': feature['default_product_feature'],
                            'default_product_feature__parent_feature': feature['default_product_feature__parent_feature'],
                            'allowed_status': feature['allowed_status'],
                            'product_allowed': feature['product_allowed'],
                            'default_product_feature__feature': feature['default_product_feature__feature']
                        }
                        feature_allowed_data.append(feature_data)
                    product_data = {
                        'id': product['id'],
                        'default_product': product['default_product'],
                        'allowed_status': product['allowed_status'],
                        'default_product__product_name': product['default_product__product_name'],
                        'feature_allowed': feature_allowed_data
                    }
                    product_allowed_data.append(product_data)

                return Response(product_allowed_data)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
                

class RoleDropdownView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        user_detail_page = get_user_data(request.user.id)
        if user_detail_page['company_detail']['plan_validity'] == True:
            roles = Roles.objects.filter(company_detail_id = user_detail_page['company_detail']['id']).all()  ##.values('id','licence_plate_number','licence_plate_image','confidence_licence_plate','datetime','speed','speed_violation','lane_change','driver_seat_belt','driver_seat_belt_image','confidence_driver_seat_belt','passanger_seat_belt','passanger_seat_belt_image','confidence_passanger_seat_belt','driver_mobile','driver_mobile_image','confidence_driver_mobile','passanger_mobile','passanger_mobile_image','confidence_passanger_mobile','vehicle_type','vehicle_direction','country','camera_name','created_by','created_datetime','updated_by','updated_datetime')
            serializer = RoleSerializer(roles, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

class UserEmailView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        user_detail_page = get_user_data(request.user.id)
        if user_detail_page['company_detail']['plan_validity'] == True:
            roles = User.objects.filter(company_detail_id = user_detail_page['company_detail']['id']).all()  ##.values('id','licence_plate_number','licence_plate_image','confidence_licence_plate','datetime','speed','speed_violation','lane_change','driver_seat_belt','driver_seat_belt_image','confidence_driver_seat_belt','passanger_seat_belt','passanger_seat_belt_image','confidence_passanger_seat_belt','driver_mobile','driver_mobile_image','confidence_driver_mobile','passanger_mobile','passanger_mobile_image','confidence_passanger_mobile','vehicle_type','vehicle_direction','country','camera_name','created_by','created_datetime','updated_by','updated_datetime')
            serializer = UserEmailSerializer(roles, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class RolesAndPermissionView(APIView):
    permission_classes = (IsAuthenticated,)

    def get_user_action(self, method):
        if method == 'GET':
            return 'view'
        elif method == 'POST':
            return 'create'
        elif method == 'PUT':
            return 'update'
        elif method == 'DELETE':
            return 'delete'
        else:
            return 'unknown'

    def get(self, request):

        limit = int(request.GET.get('limit', 10))
        offset = int(request.GET.get('offset', 0))

        user_detail_page = get_user_data_page(request.user.id,'roles_permission','view')  
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                    roles = Roles.objects.all()
                    permissions = []

                    for role in roles:
                        role_data = {'role_name': role.role_name, 'permissions': []}
                        role_permissions = role.permission_set.all()

                        for permission in role_permissions:
                            permission_data = {
                                'menu_name': permission.menu_page_id.menu_name,
                                'action': permission.action_id.action_name,
                                'user_action': self.get_user_action(request.method)  
                            }
                            role_data['permissions'].append(permission_data)

                        permissions.append(role_data)
                        permissions = permissions[offset:offset+limit]

                    return Response(permissions)
            else:
                return Response({"detail": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"detail": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


    def post(self, request):
        user_detail_page = get_user_data_page(request.user.id,'roles_permission','create')  
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                data = request.data
                serializer = PermissionSerializer(data=data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"detail": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class RolesAndPermissionDetailView(APIView):
    permission_classes = (IsAuthenticated,)

    def get_user_action(self, method):
        if method == 'GET':
            return 'view'
        elif method == 'POST':
            return 'create'
        elif method == 'PUT':
            return 'update'
        elif method == 'DELETE':
            return 'delete'
        else:
            return 'unknown'

    def get(self, request,id, format=None):
        user_detail_page = get_user_data_page(request.user.id,'roles_permission','view')  
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                try:
                    role = Roles.objects.get(pk=id)
                except Roles.DoesNotExist:
                    return Response({"detail": "ID not found."}, status=status.HTTP_404_NOT_FOUND)

                role_data = {'role_name': role.role_name, 'permissions': []}
                role_permissions = role.permission_set.all()

                for permission in role_permissions:
                    permission_data = {
                        'menu_name': permission.menu_page_id.menu_name,
                        'action': permission.action_id.action_name,
                        'user_action': self.get_user_action(request.method)
                    }
                    role_data['permissions'].append(permission_data)

                return Response(role_data)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request,id, format=None):
        user_detail_page = get_user_data_page(request.user.id,'roles_permission','update')  
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                try:
                    role = Roles.objects.get(pk=id)
                except Roles.DoesNotExist:
                    return Response({"detail": "Role not found."}, status=status.HTTP_404_NOT_FOUND)

                # current_actions = role.permission_set.values_list('action_id__action_name', flat=True)

                # for data in request.data:
                #     action = data
                #     if action not in current_actions:
                #         #raise ValidationError(f"Invalid action: {action}")
                #         return Response({"detail": "You don`t have permissions to provide this action."}, status=status.HTTP_400_BAD_REQUEST)

                queryset = role.permission_set.first()
                serializer = PermissionSerializer(queryset,  data=request.data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_200_OK)
                print(serializer.errors)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"detail": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


    def delete(self, request,id, format=None):
        user_detail_page = get_user_data_page(request.user.id,'roles_permission','delete')  
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                try:
                    role = Roles.objects.get(id=id)
                except Roles.DoesNotExist:
                    return Response({"detail": "Role not found."}, status=status.HTTP_404_NOT_FOUND)

                role.permission_set.all().delete()
                return Response(status=status.HTTP_204_NO_CONTENT)
            else:
                return Response({"detail": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"detail": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
