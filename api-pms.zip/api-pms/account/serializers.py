from rest_framework import serializers
from .models import *
from rest_framework.validators import UniqueValidator
from django.contrib.auth.password_validation import validate_password
from rest_framework.validators import UniqueTogetherValidator
from .models import OTP

class CurrencySerializer(serializers.ModelSerializer):
    currency_type = serializers.CharField(required=True,validators=[UniqueValidator(queryset=Currency.objects.all())])
    currency_symbol = serializers.CharField(required=True,validators=[UniqueValidator(queryset=Currency.objects.all())])
    class Meta:
        model = Currency
        fields = ['id','currency_type','currency_symbol']

class DefaultProductSerializer(serializers.ModelSerializer):
    product_name = serializers.CharField(required=True,validators=[UniqueValidator(queryset=DefaultProduct.objects.all())])

    class Meta:
        model = DefaultProduct
        fields = ['id','product_name']

class DefaultProductFeatureSerializer(serializers.ModelSerializer):
    feature = serializers.CharField(required=True,validators=[UniqueValidator(queryset=DefaultProductFeature.objects.all())])
    default_product = serializers.PrimaryKeyRelatedField(queryset=DefaultProduct.objects.all(), required=True)
    product_name = serializers.CharField(source='default_product.product_name', read_only=True)
    children = serializers.SerializerMethodField()

    def get_children(self, obj):
        serializer = DefaultProductFeatureSerializer(obj.children.all(), many=True)
        return serializer.data
    class Meta:
        model = DefaultProductFeature
        fields = ['id','feature','default_product','parent_feature','product_name','children']

class CompanyDetailSerializer(serializers.ModelSerializer):
    company_name = serializers.CharField(required=True,validators=[UniqueValidator(queryset=CompanyDetail.objects.all())])
    # default_product = DefaultProductSerializer(many=True,read_only=True)
    # default_product_features = DefaultProductFeatureSerializer(many=True, read_only=True)
    class Meta:
        model = CompanyDetail
        fields = ['id', 'company_name', 'country', 'uses_type', 'plan_start_datetime', 'plan_expire_datetime', 'days_to_expire','minute_to_expire', 'plan_validity', 'currency','delete_previous_data_after_day_cloud','delete_previous_data_after_day_on_premises'] #,'default_product','default_product_features'

class FeatureAllowedSerializer(serializers.ModelSerializer):
    feature_name = serializers.CharField(source='default_product_feature.feature', read_only=True)
    parent_feature = serializers.IntegerField(source='default_product_feature.parent_feature',read_only=True)
    default_product_feature = serializers.PrimaryKeyRelatedField(queryset=DefaultProductFeature.objects.all(), required=True)
    product_name = serializers.CharField(source='product_allowed.default_product.product_name', read_only=True)
    class Meta:
        model = FeatureAllowed
        fields = ['id','default_product_feature','allowed_status','product_allowed','company_detail_id','feature_name','parent_feature','product_name']


class ProductAllowedSerializer(serializers.ModelSerializer):
    product_name = serializers.CharField(source='default_product.product_name', read_only=True)
    default_product = serializers.PrimaryKeyRelatedField(queryset=DefaultProduct.objects.all(), required=True)
    # feature_allowed = serializers.SerializerMethodField()
    feature_allowed = FeatureAllowedSerializer(many=True,read_only=True)
    class Meta:
        model = ProductAllowed
        fields = ['id','default_product','allowed_status','company_detail_id','product_name','feature_allowed']
    # def get_feature_allowed(self,product_allowed):
    #     feature_allowed = FeatureAllowed.objects.filter(product_allowed=product_allowed)
    #     return FeatureAllowedSerializer(feature_allowed,many=True).data

class AddUserEmailSerializer(serializers.ModelSerializer):
    email = serializers.EmailField(required=True,validators=[UniqueValidator(queryset=AddUserEmail.objects.all())])
    role_name = serializers.CharField(source='role.role_name', read_only=True)
    class Meta:
        model = AddUserEmail
        fields = ['id','email','role','role_name','company_detail_id']
        
# class RoleSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = Roles
#         fields = ['id','role_name','company_detail_id','created_by','created_datetime']


class RolesSerializer(serializers.ModelSerializer):
    company_detail = serializers.CharField(source='company_detail_id.company_name', read_only=True)

    class Meta:
        model = Roles
        fields = '__all__'

    def create(self,validated_data):
        role_name = validated_data.get('role_name', '').strip()

        if role_name:
        
            validated_data['role_name'] = role_name.capitalize()
        if Roles.objects.filter(
                company_detail_id = validated_data['company_detail_id'],
                role_name=validated_data['role_name']).exists():
            raise serializers.ValidationError(
                    {'role_name': 'An entry with the same role name of this company already exists.'}
                )
        return Roles.objects.create(**validated_data)
        
 

    def update(self, instance, validated_data):
        role_name = validated_data.get('role_name', '').strip()

        if role_name:
           
            validated_data['role_name'] = role_name.capitalize()
        if Roles.objects.filter(
                company_detail_id = validated_data['company_detail_id'],
                role_name=validated_data['role_name']).exclude(pk=getattr(self.instance, 'pk', None)).exists():
            raise serializers.ValidationError(
                    {'role_name': 'An entry with the same role name of this company already exists.'}
                )
        
        return super().update(instance, validated_data)
    
    def delete(self, instance):
        try:
            instance.delete()
        except  Exception as e:
            raise serializers.ValidationError(
                {'submit': 'Cannot delete. This object is referenced by other objects.'})


class UserTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserType
        fields = ['id','is_menu_visible']

class MenuPageSerializer(serializers.ModelSerializer):
    class Meta:
        model = MenuPage
        fields = ['id','menu_name','is_menu_type']

# class PermissionSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = Permission
#         fields = ['PermissionName','CompanyDetailId','CreatedBy','CreatedDateTime']


class PermissionSerializer(serializers.ModelSerializer):
    role_detail = RolesSerializer(read_only=True)  # Use the RolesSerializer for the role field
    action_name = serializers.CharField(source='action.action_name', read_only=True)
    menu_name = serializers.CharField(source='menu_page.menu_name', read_only=True)

    class Meta:
        model = Permission
        fields = '__all__'

    def validate(self, attrs):
        role = attrs.get('role')
        menu_page = attrs.get('menu_page')
        action = attrs.get('action')

        # Check if the combination of role_id, menu_page_id, and action_id already exists
        existing_qs = Permission.objects.filter(role=role, menu_page=menu_page, action=action)

        if self.instance:
            # Exclude the current instance from the queryset for updates
            existing_qs = existing_qs.exclude(pk=self.instance.pk)

        if existing_qs.exists():
            raise serializers.ValidationError({'submit': 'This combination of role, menu_page, and action already exists.'})

        return attrs
    

    def delete(self, instance):
        try:
            instance.delete()
        except  Exception as e:
            raise serializers.ValidationError(
                {'submit': 'Cannot delete. This object is referenced by other objects.'})



# class UserRolePermissionSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = UserRolePermission
#         fields = ['RoleId','PermissionId','CompanyDetailId','CreatedBy','CreatedDateTime']

class UserRoleMappingSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserRoleMapping
        fields = ['id','user','role','company_detail_id','created_by','created_datetime']


class UserSerializer(serializers.ModelSerializer):
    email = serializers.EmailField(required=True,validators=[UniqueValidator(queryset=User.objects.all())])
    password = serializers.CharField(write_only=True, required=True, validators=[validate_password])
    password2 = serializers.CharField(write_only=True, required=True)
    company_detail_id = serializers.PrimaryKeyRelatedField(queryset=CompanyDetail.objects.all(), required=True)
    class Meta:
        model = User
        fields = ['id','email','phone_number','password','password2','company_detail_id','user_login_or_not','is_superuser','is_active']
    def validate(self, attrs):
        if attrs['password'] != attrs['password2']:
            raise serializers.ValidationError({"password": "Password fields didn't match."})
        return attrs
    def create(self, validated_data):
        user = User.objects.create(
            email=validated_data['email'],
            phone_number=validated_data['phone_number'],
            company_detail_id=validated_data['company_detail_id'],
            user_login_or_not=validated_data['user_login_or_not'],
            is_superuser=validated_data['is_superuser'],
            is_active=validated_data['is_active'])

        user.set_password(validated_data['password'])
        user.save()
        return user


# class UserProfileSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = UserProfileInformation
#         fields = '__all__'


class UserLoginSerializer(serializers.ModelSerializer):
  email = serializers.EmailField(max_length=255)
  class Meta:
    model = User
    fields = ['email', 'password']

class SiteFeatureAllowedSerializer(serializers.ModelSerializer):
    feature_name = serializers.CharField(source='feature_allowed.default_product_feature.feature', read_only=True)
    # parent_features = serializers.IntegerField(source='feature_allowed.default_product_feature.parent_feature',read_only=True)
    parent_feature = serializers.PrimaryKeyRelatedField(source='feature_allowed.default_product_feature.parent_feature', read_only=True)
    feature_allowed = serializers.PrimaryKeyRelatedField(queryset=FeatureAllowed.objects.all(), required=True)
    product_name = serializers.CharField(source='site_product_allowed.default_product.product_name', read_only=True)
    site_name = serializers.CharField(source='site.site_name',read_only=True)
    class Meta:
        model = SiteFeatureAllowed
        fields = ['id','feature_allowed','allowed_status','site_product_allowed','company_detail_id','site','feature_name','parent_feature','product_name','site_name']



class SiteProductAllowedSerializer(serializers.ModelSerializer):
    product_allowed = serializers.PrimaryKeyRelatedField(queryset=ProductAllowed.objects.all())
    product_name = serializers.CharField(source='product_allowed.default_product.product_name',read_only=True)
    site_name = serializers.CharField(source='site.site_name',read_only=True)
    site_feature_allowed = serializers.SerializerMethodField()
    # site_feature_allowed = SiteFeatureAllowedSerializer(many=True,read_only=True)
    class Meta:
        model = SiteProductAllowed
        fields = ['id', 'product_allowed', 'allowed_status', 'company_detail_id', 'site','product_name','site_name','site_feature_allowed']
    def get_site_feature_allowed(self,site_product_allowed):
        sites_feature_allowed = SiteFeatureAllowed.objects.filter(site_product_allowed=site_product_allowed)
        # sites_feature_allowed = site_product_allowed.sitefeatureallowed_set.all()
        # for sites_feature in sites_feature_allowed:
        #     print(sites_feature)
        return SiteFeatureAllowedSerializer(sites_feature_allowed,many=True).data


class SitesSerializer(serializers.ModelSerializer):
    user_email = serializers.CharField(source='user.email', read_only=True)
    sites_product_allowed = serializers.SerializerMethodField()
    # sites_feature_allowed = serializers.SerializerMethodField()
    # sites_product_features = SiteFeatureAllowedSerializer(many=True, read_only=True)
    plan_start_datetime = serializers.DateTimeField(source='company_detail_id.plan_start_datetime', read_only=True)
    plan_expire_datetime = serializers.DateTimeField(source='company_detail_id.plan_expire_datetime', read_only=True)
    days_to_expire = serializers.IntegerField(source='company_detail_id.days_to_expire', read_only=True)
    minute_to_expire = serializers.IntegerField(source='company_detail_id.minute_to_expire', read_only=True)
    plan_validity = serializers.BooleanField(source='company_detail_id.plan_validity', read_only=True)
    timezones = serializers.CharField(source='company_detail_id.timezones', read_only=True)
    delete_previous_data_after_day_cloud = serializers.IntegerField(source='company_detail_id.delete_previous_data_after_day_cloud', read_only=True)
    delete_previous_data_after_day_on_premises = serializers.IntegerField(source='company_detail_id.delete_previous_data_after_day_on_premises', read_only=True)

    class Meta:
        model = Sites
        fields = ['id', 'site_name','user', 'user_email', 'company_detail_id', 'plan_start_datetime',
                  'plan_expire_datetime', 'days_to_expire','minute_to_expire', 'plan_validity', 'timezones','skip_frame','user_login_or_not','active','site_encryption_key',
                  'delete_previous_data_after_day_cloud','delete_previous_data_after_day_on_premises','sites_product_allowed']

    def validate(self, attrs):
        site_name_unique = Sites.objects.filter(company_detail_id=attrs['company_detail_id'], site_name=attrs['site_name']).last()
        user_unique = Sites.objects.filter(company_detail_id=attrs['company_detail_id'], user=attrs['user']).last()
        if site_name_unique is not None:
            raise serializers.ValidationError({"site_name": "Site name must be unique."})
        if user_unique is not None:
            raise serializers.ValidationError({"user": "User email must be unique."})
        return attrs
    def get_sites_product_allowed(self,sites):
        sites_product_allowed = SiteProductAllowed.objects.filter(site=sites)
        print(sites_product_allowed)
        return SiteProductAllowedSerializer(sites_product_allowed,many=True).data
    # def get_sites_feature_allowed(self,sites):
    #     sites_feature_allowed = SiteFeatureAllowed.objects.filter(site=sites)
    #     print(sites_feature_allowed)
    #     return SiteFeatureAllowedSerializer(sites_feature_allowed,many=True).data
    # def create(self, validated_data):
    #     user = self.context['request'].user
    #     company_detail_id = validated_data.pop('company_detail_id')
    #     skip_frame = validated_data.pop('skip_frame')

    #     default_product = validated_data.get('default_product')
    #     if not default_product:
    #         raise serializers.ValidationError({"default_product": "Default product is required."})

    #     # Create the Site object
    #     site = Sites.objects.create(user=user, company_detail_id=company_detail_id, **validated_data)

    #     # Save additional fields
    #     site.skip_frame = skip_frame
    #     site.save()

    #     # Create SiteProductAllowed
    #     site_product_allowed_data = {
    #         'default_product': default_product,
    #         'allowed_status': default_product['allowed_status'],
    #         'company_detail_id': company_detail_id,
    #         'site': site
    #     }
    #     site_product_allowed_serializer = SiteProductAllowedSerializer(data=site_product_allowed_data, many=True)
    #     if site_product_allowed_serializer.is_valid():
    #         site_product_allowed_serializer.save()
    #     else:
    #         site.delete()
    #         raise serializers.ValidationError(site_product_allowed_serializer.errors)

    #     # Create SiteFeatureAllowed
    #     default_product_features = DefaultProductFeature.objects.filter(default_product=default_product)
    #     for feature in default_product_features:
    #         site_feature_allowed_data = {
    #             'default_product_feature': feature,
    #             'allowed_status': feature['allowed_status'],
    #             'product_allowed': site_product_allowed_serializer.instance,
    #             'company_detail_id': company_detail_id,
    #             'site': site
    #         }
    #         site_feature_allowed_serializer = SiteFeatureAllowedSerializer(data=site_feature_allowed_data, many=True)
    #         if site_feature_allowed_serializer.is_valid():
    #             site_feature_allowed_serializer.save()
    #         else:
    #             site.delete()
    #             SiteProductAllowed.objects.filter(id=site_product_allowed_serializer.instance.id).delete()
    #             raise serializers.ValidationError(site_feature_allowed_serializer.errors)

    #     return site




class UserEmailSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id','email']


class OTPSerializer(serializers.ModelSerializer):
    class Meta:
        model = OTP
        fields = '__all__'


class SitesListSerializer(serializers.ModelSerializer):
    
    class Meta:
        model = Sites
        fields = ['id', 'site_name']

class SendMailNotificationSerializer(serializers.ModelSerializer):
    
    class Meta:
        model = SendMailNotification
        fields = '__all__'


class DaysSerializer(serializers.ModelSerializer):
    class Meta:
        model = Days
        fields = ['id','uuid','days','category']

class PlanFeaturesPricingCategorySerializer(serializers.ModelSerializer):
    #category_name = serializers.PrimaryKeyRelatedField(read_only=True)

    class Meta:
        model = PlanFeaturesPricingCategory
        fields = ['id', 'uuid', 'category_name']
    # class Meta:
    #     model = PlanFeaturesPricingCategory
    #     fields = ['id','uuid','category_name']

class CountryCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = CountryCategory
        fields = ['id','uuid','country']

class TaxPercentageDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = TaxPercentageDetail
        fields = ['id','uuid','tax_percentage','tax_type','country_category']

class PlanPricingTaxSerializer(serializers.ModelSerializer):
    class Meta:
        model = PlanPricingTax
        fields = ['id','uuid','plan_pricing_id','tax_percentage_detail_id','tax_amount','currency_id']

class PlanFeaturePricingTierSerializer(serializers.ModelSerializer):
    class Meta:
        model = PlanFeaturePricingTier
        fields = ['id','uuid','min_quantity','max_quantity','default_quantity','default_product_id','default_product_feature_id','pricing_feature_category_id','plan_id','plan_pricing_description','show_plan_pricing','is_encluded_plan_feature_id']

class PlanFeatureDaysPriceSerializer(serializers.ModelSerializer):
    class Meta:
        model = PlanFeatureDaysPrice
        fields = ['id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','plan_feature_pricing_tier_id','plans_id','default_selected']


class CouponSerializer(serializers.ModelSerializer):
    class Meta:
        model = Coupon
        fields = ['id','uuid','code','description','discount_type','discount_value','currency_id','country_category_id','plan_buy_days','coupon_expiry_datetime','is_active','user_valid_for_coupon']

class PlanDescriptionSerializer(serializers.ModelSerializer):
    class Meta:
        model = PlanDescription
        fields = ['id','uuid','plan_description','plan_id']

class PlanDaysAndDiscountSerializer(serializers.ModelSerializer):
    class Meta:
        model = PlanDaysAndDiscount
        fields = ['id','uuid','plan_days','discount_percentage','category','default_select','plan_id','plan_pricing_id']

class PlanPricingSerializer(serializers.ModelSerializer):
    class Meta:
        model = PlanPricing
        fields = ['id','uuid','basic_price','basic_price_after_discount','basic_price_after_tax','days_price','days_price_after_discount','days_price_after_tax','currency_id','country_type_id','plan_id']


class PlansSerializer(serializers.ModelSerializer):
    class Meta:
        model = Plans
        fields = ['id','uuid','plan_name']


class BusinessPricingTierSerializer(serializers.ModelSerializer):
    class Meta:
        model = BusinessPricingTier
        fields=['id','uuid','backup_days_id','backup_days','quantity','price','days_price','currency_id','default_product_id','default_product_feature_id','plan_feature_pricing_category_id','category_name','plan_id','business_plan_history_id','plan_feature_pricing_tier_id','company_detail_id','plan_pricing_description']

class BusinessPlanHistorySerializer(serializers.ModelSerializer):
    # business_pricing_tiers = BusinessPricingTierSerializer(source='businesspricingtier_set', many=True)
    #plan_features_pricing_categories = serializers.SerializerMethodField()
    class Meta:
        model = BusinessPlanHistory
        # fields = ['id','uuid','plan_name','price','price_after_discount','price_after_tax','days_price','currency','currency_type','currency_symbol','country_category','country_type','plan_id','plan_days_id','plan_days','discount_in_percentage','discount_in_currency','buy_datetime','plan_end_datetime','minutes_to_expire','active_plan','plan_type']
        fields = ['id','uuid','plan_name','price','price_after_discount','price_after_tax','days_price','days_price_after_discount','days_price_after_tax','currency_id','currency_type','currency_symbol','country_category_id','country_type','plan_id','plan_days_and_discount_id','plan_days','discount_in_percentage','discount_in_currency','total_discount','total_tax_in_percentage','total_tax_in_currency','buy_datetime','plan_start_datetime','plan_expire_datetime','minutes_to_expire','days_to_expire','plan_validity','current_active','plan_status','plan_type','company_detail_id','upgrade_plan_id','payment_status']
       # fields = '__all__'
   
class BusinessPlanPricingTaxSerializer(serializers.ModelSerializer):
    class Meta:
        model = BusinessPlanPricingTax
        fields = ['id','uuid','business_plan_history_id','tax_percentage_detail_id','tax_type','tax_percentage','tax_amount','company_detail_id']

class BusinessPlanCouponSerializer(serializers.ModelSerializer):
    class Meta:
        model = BusinessPlanCoupon
        fields = ['id','uuid','coupon_code','description','discount_type','discount_value','coupon_id','total_coupon_amount','business_plan_history_id','company_detail_id']


class BusinessTransactionHistorySerializer(serializers.ModelSerializer):
    class Meta:
        model = BusinessTransactionHistory
        fields = ['id','uuid','amout_paid','currency_id','currency_type','currency_symbol','date_and_time','company_detail_id','business_plan_history_id']
# class BusinessTransactionHistorySerializer(serializers.ModelSerializer):
#     plan_type = serializers.CharField(source='business_plan_history_id.plan_type')
#     price = serializers.FloatField(source='business_plan_history_id.price_after_tax')
#     payment_status = serializers.BooleanField(source='business_plan_history_id.payment_status')
#     date_and_time = serializers.DateTimeField()
    
#     class Meta:
#         model = BusinessTransactionHistory
#         fields = ['date_and_time', 'price', 'plan_type', 'payment_status']