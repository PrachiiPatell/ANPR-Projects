from django.shortcuts import render,redirect

# Create your views here.
# from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
# from .forms import UserProfileInformationForm
from .models import User,Roles,MenuPage,MenuActionMap,UserType,CompanyDetail,AddUserEmail,Permission,Action,UserRoleMapping,Sites 
from .models import *
from .serializers import *
from django.contrib.auth import authenticate,login,logout
from django.http import HttpResponseRedirect,HttpResponse
from django.http.response import JsonResponse,Http404
from rest_framework.response import Response
from rest_framework.parsers import JSONParser
from rest_framework.decorators import api_view
from rest_framework.views import APIView
from .serializers import UserSerializer,CompanyDetailSerializer,RolesSerializer,PermissionSerializer,UserRoleMappingSerializer,AddUserEmailSerializer,UserLoginSerializer,SitesSerializer, UserEmailSerializer,CurrencySerializer  ##UserRolePermissionSerializer
from rest_framework import status
import json
from datetime import datetime,timedelta
#from django_countries import countries
from django.core.mail import EmailMultiAlternatives,send_mail
from django.conf import settings
from django.template.loader import render_to_string, get_template
from rest_framework_simplejwt.tokens import RefreshToken
from django.db import transaction
from django.db.models import Count
from django.db.models import F
from rest_framework.permissions import AllowAny,IsAuthenticated
from rest_framework.authentication import TokenAuthentication
from rest_framework_simplejwt.backends import TokenBackend
from django.core.exceptions import ValidationError
from rest_framework.pagination import LimitOffsetPagination
from datetime import datetime
import pytz
from django.utils import timezone
from rest_framework.exceptions import PermissionDenied
from .utils import *
import random
from django.db.models import Q
import logging
logger = logging.getLogger(__name__)
# get_menu_action = MenuActionMap.objects.values('id','menu_page','action').all()[2:20]
# print(get_menu_action)

# GetPermissionData = MenuActionMap.objects.filter(action=1).values('menu_page','menu_page__menu_name').distinct('menu_page')
# print(GetPermissionData)

def get_user_data(user):
    user_detail = User.objects.filter(id=user).values('id','email','company_detail_id').first()
    company_details = CompanyDetail.objects.filter(id=user_detail['company_detail_id']).values('id','company_name','country','plan_start_datetime','plan_expire_datetime','days_to_expire','minute_to_expire','plan_validity').first()
    
    user_role_maps = UserRoleMapping.objects.filter(user=user_detail['id']).values('id','role').first()
    # print("company:",company_details)
    #diff = datetime.strptime(str(company_details['plan_expire_datetime']), '%Y-%m-%d %H:%M:%S+00:00') - datetime.strptime(str(datetime.now()), '%Y-%m-%d %H:%M:%S.%f')
    plan_expire_datetime = company_details['plan_expire_datetime']
    plan_expire_datetime = plan_expire_datetime.replace(tzinfo=timezone.utc)  # Make it offset-aware

    diff = plan_expire_datetime - datetime.now(timezone.utc)

    if int(diff.total_seconds() / 60.0) > 0:
        CompanyDetail.objects.filter(id=user_detail['company_detail_id']).update(plan_validity=True,days_to_expire=diff.days,minute_to_expire=int(diff.total_seconds() / 60.0))
    else:
        CompanyDetail.objects.filter(id=user_detail['company_detail_id']).update(plan_validity=False,days_to_expire=diff.days,minute_to_expire=int(diff.total_seconds() / 60.0))
    company_details = CompanyDetail.objects.filter(id=user_detail['company_detail_id']).values('id','company_name','company_logo','country','plan_start_datetime','plan_expire_datetime','days_to_expire','minute_to_expire','plan_validity','currency__currency_symbol').first()
    role_detail = Roles.objects.filter(id=user_role_maps['role']).values('id','role_name').last()
    get_menu_data = Permission.objects.filter(role=user_role_maps['role']).values('id','menu_page','menu_page__menu_name').distinct('menu_page')
    permissions = {}
    for get_menu in get_menu_data:
        get_action = Permission.objects.filter(role=user_role_maps['role'],menu_page=get_menu['menu_page']).values('id','menu_page','action','action__action_name').distinct('action')
        permissions[get_menu['menu_page__menu_name']] = []
        for get_action in get_action:
            permissions[get_menu['menu_page__menu_name']].append(get_action.get('action__action_name'))

    product_allowed = ProductAllowed.objects.filter(company_detail_id=user_detail['company_detail_id']).values('id','default_product','allowed_status','default_product__product_name')
    feature_allowed = FeatureAllowed.objects.filter(company_detail_id=user_detail['company_detail_id']).values('id','default_product_feature','default_product_feature__parent_feature','allowed_status','product_allowed','default_product_feature__feature')

    product_allowed_data = []
    feature_allowed_data = []

    for product in product_allowed:
        product_data = {
            'id': product['id'],
            'default_product': product['default_product'],
            'allowed_status': product['allowed_status'],
            'default_product__product_name': product['default_product__product_name']
        }
        product_allowed_data.append(product_data)

    for feature in feature_allowed:
        feature_data = {
            'id': feature['id'],
            'default_product_feature': feature['default_product_feature'],
            'default_product_feature__parent_feature': feature['default_product_feature__parent_feature'],
            'allowed_status': feature['allowed_status'],
            'product_allowed': feature['product_allowed'],
            'default_product_feature__feature': feature['default_product_feature__feature']
        }
        feature_allowed_data.append(feature_data)

    #sites = Sites.objects.filter(company_detail_id = user_detail['company_detail_id'], user = user_detail['id']).values('id','site_name','user','company_detail_id','skip_frame','user_login_or_not','active')

    
    data = {'user_detail':user_detail,'company_detail':company_details,'role_detail':role_detail,'permission':permissions,'product_allowed':product_allowed_data,'feature_allowed':feature_allowed_data}
    return data



def get_user_data_page(user,pages,action):
    user_detail = User.objects.filter(id=user).values('id','email','company_detail_id').first()
    company_details = CompanyDetail.objects.filter(id=user_detail['company_detail_id']).values('id','plan_start_datetime','plan_expire_datetime','days_to_expire','minute_to_expire','plan_validity').first()
    user_role_maps = UserRoleMapping.objects.filter(user=user_detail['id']).values('id','role').first()
    # print("company:",company_details)
    #diff = datetime.strptime(str(company_details['plan_expire_datetime']), '%Y-%m-%d %H:%M:%S+00:00') - datetime.strptime(str(datetime.now()), '%Y-%m-%d %H:%M:%S.%f')
    plan_expire_datetime = company_details['plan_expire_datetime']
    plan_expire_datetime = plan_expire_datetime.replace(tzinfo=timezone.utc)  # Make it offset-aware

    diff = plan_expire_datetime - datetime.now(timezone.utc)
    if int(diff.total_seconds() / 60.0) > 0:
        CompanyDetail.objects.filter(id=user_detail['company_detail_id']).update(plan_validity=True,days_to_expire=diff.days,minute_to_expire=int(diff.total_seconds() / 60.0)) 
    else:
        CompanyDetail.objects.filter(id=user_detail['company_detail_id']).update(plan_validity=False,days_to_expire=diff.days,minute_to_expire=int(diff.total_seconds() / 60.0))
    company_details = CompanyDetail.objects.filter(id=user_detail['company_detail_id']).values('id','company_name','company_logo','plan_validity','currency__currency_symbol').first()
    role_detail = Roles.objects.filter(id=user_role_maps['role']).values('id','role_name').last()
    # permissions = Permission.objects.filter(role=user_role_maps['role'],menu_page__menu_name = pages,action__action_name=action).values('id','role','role__role_name','menu_page','menu_page__menu_name','action__action_name').distinct('menu_page').first()
    permissions = Permission.objects.filter(
    role=user_role_maps['role'],
    menu_page__menu_name=pages,
    action__action_name=action
).order_by('menu_page').distinct('menu_page').values(
    'id', 'role', 'role__role_name', 'menu_page', 'menu_page__menu_name', 'action__action_name'
).first()
    
    product_allowed = ProductAllowed.objects.filter(company_detail_id=user_detail['company_detail_id']).values('id','default_product','allowed_status','default_product__product_name')
    feature_allowed = FeatureAllowed.objects.filter(company_detail_id=user_detail['company_detail_id']).values('id','default_product_feature','default_product_feature__parent_feature','allowed_status','product_allowed','default_product_feature__feature')

    product_allowed_data = []
    feature_allowed_data = []

    for product in product_allowed:
        product_data = {
            'id': product['id'],
            'default_product': product['default_product'],
            'allowed_status': product['allowed_status'],
            'default_product__product_name': product['default_product__product_name']
        }
        product_allowed_data.append(product_data)

    for feature in feature_allowed:
        feature_data = {
            'id': feature['id'],
            'default_product_feature': feature['default_product_feature'],
            'allowed_status': feature['allowed_status'],
            'product_allowed': feature['product_allowed'],
            'default_product_feature__feature': feature['default_product_feature__feature']
        }
        feature_allowed_data.append(feature_data)

    # sites = Sites.objects.filter(company_detail_id = user_detail['company_detail_id'], user = user_detail['id']).values('id','site_name','user','company_detail_id','skip_frame','user_login_or_not','active')

    data = {'user_detail':user_detail,'company_detail':company_details,'role_detail':role_detail,'permission':permissions,'product_allowed':product_allowed_data,'feature_allowed':feature_allowed_data}
    return data


# DefaultProduct API
class DefaultProductView(APIView):

    def get(self, request, format=None):
        limit = int(request.GET.get('limit',10))
        offset = int(request.GET.get('offset',0))
        queryset = DefaultProduct.objects.all()[offset:limit+offset]
        serializer = DefaultProductSerializer(queryset, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
       
    
    def post(self, request, format=None):
        get_data = request.data
        serializer = DefaultProductSerializer(data=get_data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        

#DefaultProductFeature API       
class DefaultProductFeatureView(APIView):

    def get(self, request, format=None):
        limit = int(request.GET.get('limit',10))
        offset = int(request.GET.get('offset',0))
        queryset = DefaultProductFeature.objects.filter(parent_feature__isnull=True).all()[offset:limit+offset]
        serializer = DefaultProductFeatureSerializer(queryset, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
       
    
    def post(self, request, format=None):
        get_data = request.data
        serializer = DefaultProductFeatureSerializer(data=get_data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class Register(APIView):
    permission_classes = (AllowAny,)
    def post(self, request, format=None):
        add_user_emails = AddUserEmail.objects.filter(email=request.data['email']).values('email','role','company_detail_id').first()
        if add_user_emails != None:
            company_detail_id = add_user_emails.get('company_detail_id')
            get_company_detail = CompanyDetail.objects.filter(id=company_detail_id).first()

            
            serializer = UserSerializer(data={'email':request.data['email'],'phone_number':request.data['phone_number'],'password':request.data['password'],'password2':request.data['password2'],'company_detail_id': company_detail_id,'user_login_or_not':False,'is_superuser':False,'is_active':False})
            user_id = None
            if serializer.is_valid():
                obj = serializer.save()
                user_id = obj.id
            else:
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            user_role_map_serializer = UserRoleMappingSerializer(data={'user':user_id,'role':add_user_emails.get('role'),'company_detail_id': add_user_emails.get('company_detail_id')})
            if user_role_map_serializer.is_valid():
                user_role_map_serializer.save()
            else:
                User.objects.filter(id=user_id).delete()
                return Response(user_role_map_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            user_select = User.objects.filter(id=user_id).last()
            refresh = RefreshToken.for_user(user_select)
            user_detail = get_user_data(user_id)
            user_detail['refresh'] = str(refresh)
            user_detail['access'] = str(refresh.access_token)
            return Response(user_detail, status=status.HTTP_201_CREATED)
        else:
            print("Yes")
            return Response({"result": {},"message": "Company are not register with this email."}, status=status.HTTP_400_BAD_REQUEST)



# class AddCompany(APIView):
#     # authentication_classes = (TokenAuthentication,)
#     permission_classes = (AllowAny,)

#     def post(self, request, format=None):
#         currency_detail = {'currency_type': request.data['currency_type'], 'currency_symbol': request.data['currency_symbol']}
#         currency_serializer = CurrencySerializer(data=currency_detail)
#         currency_id = None
#         if currency_serializer.is_valid():
#             obj = currency_serializer.save()
#             currency_id = obj.id
#         else:
#             return Response(currency_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

#         company_detail = {
#             'company_name': request.data['company_name'],
#             'country': request.data['country'],
#             'uses_type': 'free trail',
#             'plan_start_datetime': datetime.now(),
#             'plan_expire_datetime': datetime.now() + timedelta(days=15),
#             'days_to_expire': 15,
#             'plan_validity': True,
#             'currency': currency_id
#         }
#         company_serializer = CompanyDetailSerializer(data=company_detail)
#         company_id = None
#         if company_serializer.is_valid():
#             obj = company_serializer.save()
#             company_id = obj.id
#         else:
#             return Response(company_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

#         role_detail = {'role_name': 'Admin', 'company_detail_id': company_id}

#         role_serializer = RoleSerializer(data=role_detail)
#         role_id = None
#         if role_serializer.is_valid():
#             obj = role_serializer.save()
#             role_id = obj.id
#         else:
#             CompanyDetail.objects.filter(id=company_id).delete()
#             return Response(role_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

#         add_user_email_serializer = AddUserEmailSerializer(data={'email': request.data['email'], 'role': role_id, 'company_detail_id': company_id})
#         add_user_emailid = None
#         if add_user_email_serializer.is_valid():
#             obj = add_user_email_serializer.save()
#             add_user_emailid = obj.id
#         else:
#             CompanyDetail.objects.filter(id=company_id).delete()
#             Roles.objects.filter(id=role_id).delete()
#             return Response(add_user_email_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

#         permission_id = []
#         get_menu_data = MenuPage.objects.exclude(is_menu_type__is_menu_visible='SuperAdmin').all().values('id', 'menu_name')
#         print(get_menu_data)
#         # for perm in range(len(PermissionDetail)):
#         for menus in get_menu_data:
#             get_menu_action_data = MenuActionMap.objects.filter(menu_page=menus['id']).values('id', 'menu_page', 'action').all()
#             for menu_action in get_menu_action_data:
#                 print(menu_action)
#                 permission_serializer = PermissionSerializer(data={'role': role_id, 'menu_page': menu_action['menu_page'], 'action': menu_action['action']})
#                 if permission_serializer.is_valid():
#                     obj = permission_serializer.save()
#                     permission_id.append(obj.id)
#                 else:
#                     CompanyDetail.objects.filter(id=company_id).delete()
#                     Roles.objects.filter(id=role_id).delete()
#                     AddUserEmail.objects.filter(id=add_user_emailid).delete()
#                     for perm_id in permission_id:
#                         Permission.objects.filter(id=perm_id).delete()
#                     return Response(permission_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

#         default_product = request.data['default_product']  
#         default_product_features = DefaultProductFeature.objects.filter(default_product=default_product)

#         product_allowed_data = {
#             'default_product':default_product,
#             'allowed_status': request.data['allowed_status'],
#             'company_detail_id': company_id
#         }
#         product_allowed_serializer = ProductAllowedSerializer(data=product_allowed_data)
#         if product_allowed_serializer.is_valid():
#             product_allowed_serializer.save()
#         else:
#             CompanyDetail.objects.filter(id=company_id).delete()
#             Roles.objects.filter(id=role_id).delete()
#             AddUserEmail.objects.filter(id=add_user_emailid).delete()
#             for perm_id in permission_id:
#                 Permission.objects.filter(id=perm_id).delete()
#             return Response(product_allowed_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

#         for feature in default_product_features:
#             feature_allowed_data = {
#                 'default_product_feature': feature.id,
#                 'allowed_status': request.data['allowed_status'],
#                 'product_allowed': product_allowed_serializer.instance.id,
#                 'company_detail_id': company_id
#             }
#             feature_allowed_serializer = FeatureAllowedSerializer(data=feature_allowed_data)
#             if feature_allowed_serializer.is_valid():
#                 feature_allowed_serializer.save()
#             else:
#                 CompanyDetail.objects.filter(id=company_id).delete()
#                 Roles.objects.filter(id=role_id).delete()
#                 AddUserEmail.objects.filter(id=add_user_emailid).delete()
#                 for perm_id in permission_id:
#                     Permission.objects.filter(id=perm_id).delete()
#                 ProductAllowed.objects.filter(id=product_allowed_serializer.instance.id).delete()
#                 return Response(feature_allowed_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

#         return Response({'Sucess': 'Company Created Successfully.'}, status.HTTP_201_CREATED)


class AddCompany(APIView):
    # authentication_classes = (TokenAuthentication,)
    permission_classes = (AllowAny,)

    def post(self, request, format=None):
        currency_detail = {'currency_type': request.data['currency_type'], 'currency_symbol': request.data['currency_symbol']}
        currency_serializer = CurrencySerializer(data=currency_detail)
        currency_id = None
        if currency_serializer.is_valid():
            currency_obj = currency_serializer.save()
            currency_id = currency_obj.id
        else:
            return Response(currency_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        #currency_detail = Currency.objects.filter(currency_type=request.data['currency_type']).values('id').first()
        # currency_serializer = CurrencySerializer(data=currency_detail)
        # currency_id = None
        # if currency_serializer.is_valid():
        #     currency_obj = currency_serializer.save()
        #     currency_id = currency_obj.id
        # else:
        #     return Response(currency_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        company_detail = {
            'company_name': request.data['company_name'],
            'country': request.data['country'],
            'uses_type': 'free trail',
            'plan_start_datetime': datetime.now(),
            'plan_expire_datetime': datetime.now() + timedelta(days=15),
            'days_to_expire': 15,
            'plan_validity': True,
            'currency': currency_id,
            #'currency': currency_detail[id],
            'delete_previous_data_after_day_cloud': request.data['delete_previous_data_after_day_cloud'],
            'delete_previous_data_after_day_on_premises': request.data['delete_previous_data_after_day_on_premises']
        }
        company_serializer = CompanyDetailSerializer(data=company_detail)
        company_id = None
        if company_serializer.is_valid():
            company_obj = company_serializer.save()
            company_id = company_obj.id
        else:
            return Response(company_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        role_detail = {'role_name': 'Admin', 'company_detail_id': company_id}

        role_serializer = RolesSerializer(data=role_detail)
        role_id = None
        if role_serializer.is_valid():
            role_obj = role_serializer.save()
            role_id = role_obj.id
        else:
            CompanyDetail.objects.filter(id=company_id).delete()
            return Response(role_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        add_user_email_serializer = AddUserEmailSerializer(data={'email': request.data['email'], 'role': role_id, 'company_detail_id': company_id})
        add_user_email_id = None
        if add_user_email_serializer.is_valid():
            add_user_email_obj = add_user_email_serializer.save()
            add_user_email_id = add_user_email_obj.id
        else:
            CompanyDetail.objects.filter(id=company_id).delete()
            Roles.objects.filter(id=role_id).delete()
            return Response(add_user_email_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        permission_ids = []
        get_menu_data = MenuPage.objects.exclude(is_menu_type__is_menu_visible='SuperAdmin').all().values('id', 'menu_name')
        for menu in get_menu_data:
            get_menu_action_data = MenuActionMap.objects.filter(menu_page=menu['id']).values('id', 'menu_page', 'action').all()
            for menu_action in get_menu_action_data:
                permission_serializer = PermissionSerializer(data={'role': role_id, 'menu_page': menu_action['menu_page'], 'action': menu_action['action']})
                if permission_serializer.is_valid():
                    permission_obj = permission_serializer.save()
                    permission_ids.append(permission_obj.id)
                else:
                    CompanyDetail.objects.filter(id=company_id).delete()
                    Roles.objects.filter(id=role_id).delete()
                    AddUserEmail.objects.filter(id=add_user_email_id).delete()
                    for permission_id in permission_ids:
                        Permission.objects.filter(id=permission_id).delete()
                    return Response(permission_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                
        send_email_notification = {'email': request.data['email'], 'company_detail_id': company_id}

        send_email_notification_serializer = SendMailNotificationSerializer(data=send_email_notification)
        send_email_notification_id = None
        if send_email_notification_serializer.is_valid():
            send_email_notification_obj = send_email_notification_serializer.save()
            send_email_notification_id = send_email_notification_obj.id
        else:
            CompanyDetail.objects.filter(id=company_id).delete()
            Roles.objects.filter(id=role_id).delete()
            AddUserEmail.objects.filter(id=add_user_email_id).delete()
            for permission_id in permission_ids:
                Permission.objects.filter(id=permission_id).delete()
            return Response(send_email_notification_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        default_products = request.data.get('default_products', [])
        default_product_instances = []
        feature_instances = []

        for default_product in default_products:
            default_product_data = {
                'default_product': default_product['default_product'],
                'allowed_status': default_product['allowed_status'],
                'company_detail_id': company_id
            }
            default_product_serializer = ProductAllowedSerializer(data=default_product_data)
            if default_product_serializer.is_valid():
                default_product_instance = default_product_serializer.save()
                default_product_instances.append(default_product_instance)

                default_product_features = default_product.get('default_product_features', [])
                for feature in default_product_features:
                    feature_allowed_data = {
                        'default_product_feature': feature['default_product_feature'],
                        'allowed_status': feature['allowed_status'],
                        'product_allowed': default_product_instance.id,
                        'parent_feature': feature['parent_feature'],
                        'company_detail_id': company_id
                    }
                    feature_allowed_serializer = FeatureAllowedSerializer(data=feature_allowed_data)
                    if feature_allowed_serializer.is_valid():
                        feature_instance = feature_allowed_serializer.save()
                        feature_instances.append(feature_instance)
                    else:
                        CompanyDetail.objects.filter(id=company_id).delete()
                        Roles.objects.filter(id=role_id).delete()
                        AddUserEmail.objects.filter(id=add_user_email_id).delete()
                        for permission_id in permission_ids:
                            Permission.objects.filter(id=permission_id).delete()
                        for instance in default_product_instances:
                            instance.delete()
                        for instance in feature_instances:
                            instance.delete()
                        return Response(feature_allowed_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

            else:
                CompanyDetail.objects.filter(id=company_id).delete()
                Roles.objects.filter(id=role_id).delete()
                AddUserEmail.objects.filter(id=add_user_email_id).delete()
                for permission_id in permission_ids:
                    Permission.objects.filter(id=permission_id).delete()
                SendMailNotification.objects.filter(id=send_email_notification_id).delete()
                return Response(default_product_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            

        return Response({'Success': 'Company Created Successfully.'}, status=status.HTTP_201_CREATED)


   
class Login(APIView):
    permission_classes = (AllowAny,)
    def post(self, request, format=None):
        serializer = UserLoginSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        email = serializer.data.get('email')
        password = serializer.data.get('password')
        print(email,password)
        user = authenticate(email=email,password=password)
        if user:
            if user.is_active:
                if user.is_verified:
                    refresh = RefreshToken.for_user(user)
                    user_detail = get_user_data(user.id)
                    user_detail['refresh'] = str(refresh)
                    user_detail['access'] = str(refresh.access_token)
                    #print(user_detail)
                    return JsonResponse(user_detail, status=status.HTTP_200_OK)
                else:
                    return Response({"submit":"Please Verify your email."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                res = {"code": 400, "message": "Account was not active."}
                return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)
        else:
            res = {"code": 400, "message": "Invalid Username and Password."}
            return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)

def get_user_data_page_plans(user,menu_name,action):
    user_detail = User.objects.filter(id=user).values('id','email','company_detail_id').first()
    
    if user_detail is None:
        # handle the case where the user is not found
        return None
    #business_details = BusinessDetail.objects.filter(id=user_detail['business_detail_id']).values('id','business_name').first()
    # business_details = BusinessDetail.objects.filter(id=user_detail['business_detail_id']).values('id','business_name', 'plan_expire_datetime','plan_validity','timezones').first()
    company_details = CompanyDetail.objects.filter(id=user_detail['company_detail_id']).values('id','plan_start_datetime','plan_expire_datetime','days_to_expire','minute_to_expire','plan_validity').first()
    
    business_plan_history_by_datetime = BusinessPlanHistory.objects.filter(Q(company_detail_id=user_detail['company_detail_id']) & (Q(plan_expire_datetime__gte=datetime.now()) | Q(current_active=True))).all()
   
    business_plan_history_details = None
    if len(business_plan_history_by_datetime) == 1:
        
        # business_plan_history_current_active = business_plan_history_by_datetime.filter(plan_status='active',current_active=True).first()
        business_plan_history_current_active = business_plan_history_by_datetime.filter(current_active=True).first()

        # plan_working = False
        # business_plan_history_details = None
        # if business_plan_history_current_active != None:
        diff = None
        try:
            diff = datetime.strptime(str(business_plan_history_by_datetime[0]['plan_expire_datetime']), '%Y-%m-%d %H:%M:%S.%f+00:00') - datetime.strptime(str(datetime.now()), '%Y-%m-%d %H:%M:%S.%f')
        except Exception as e:
            #diff = datetime.strptime(str(business_plan_history_by_datetime[0].plan_expire_datetime), '%Y-%m-%d %H:%M:%S+00:00') - datetime.strptime(str(datetime.now()), '%Y-%m-%d %H:%M:%S.%f')
            # diff = timezone.datetime.strptime(str(business_plan_history_by_datetime[0].plan_expire_datetime), '%Y-%m-%d %H:%M:%S.%f+00:00') - datetime.strptime(str(datetime.now()), '%Y-%m-%d %H:%M:%S.%f')
            diff = timezone.datetime.strptime(str(business_plan_history_current_active.plan_expire_datetime), '%Y-%m-%d %H:%M:%S+00:00') - datetime.strptime(str(datetime.now()), '%Y-%m-%d %H:%M:%S.%f')

        if int(diff.total_seconds() / 60.0) > 0:
            plan_working = True
            BusinessPlanHistory.objects.filter(id=business_plan_history_by_datetime[0].id).update(plan_validity=True,plan_status='active',current_active=True,days_to_expire=diff.days,minutes_to_expire=int(diff.total_seconds() / 60.0))
            business_plan_history_details = BusinessPlanHistory.objects.filter(id=business_plan_history_by_datetime[0].id).first()
        else:
            plan_working = False
            BusinessPlanHistory.objects.filter(id=business_plan_history_by_datetime[0].id).update(plan_validity=False,plan_status='expire',current_active=True,days_to_expire=diff.days,minutes_to_expire=int(diff.total_seconds() / 60.0))
            business_plan_history_details = BusinessPlanHistory.objects.filter(id=business_plan_history_by_datetime[0].id).first()
    
    elif len(business_plan_history_by_datetime) > 1:
        
        business_plan_history_current_active = business_plan_history_by_datetime.filter(current_active=True).first()
        if business_plan_history_current_active != None:
            diff = None
            try:
                diff = datetime.strptime(str(business_plan_history_current_active.plan_expire_datetime), '%Y-%m-%d %H:%M:%S.%f+00:00') - datetime.strptime(str(datetime.now()), '%Y-%m-%d %H:%M:%S.%f')
            except Exception as e:
                diff = datetime.strptime(str(business_plan_history_current_active.plan_expire_datetime), '%Y-%m-%d %H:%M:%S+00:00') - datetime.strptime(str(datetime.now()), '%Y-%m-%d %H:%M:%S.%f')
            if int(diff.total_seconds() / 60.0) > 0:
                plan_working = True
                BusinessPlanHistory.objects.filter(id=business_plan_history_current_active.id).update(plan_validity=True,plan_status='active',current_active=True,days_to_expire=diff.days,minutes_to_expire=int(diff.total_seconds() / 60.0))
                business_plan_history_details = BusinessPlanHistory.objects.filter(id=business_plan_history_current_active.id).first()
            else:
                plan_working = False
                business_plan_history_current_pending = business_plan_history_by_datetime.filter(plan_status='pending').first()
                if business_plan_history_current_pending != None:
                    try:
                        diff = datetime.strptime(str(business_plan_history_current_pending.plan_expire_datetime), '%Y-%m-%d %H:%M:%S.%f+00:00') - datetime.strptime(str(datetime.now()), '%Y-%m-%d %H:%M:%S.%f')
                    except Exception as e:
                        diff = datetime.strptime(str(business_plan_history_current_pending.plan_expire_datetime), '%Y-%m-%d %H:%M:%S+00:00') - datetime.strptime(str(datetime.now()), '%Y-%m-%d %H:%M:%S.%f')
                    if int(diff.total_seconds() / 60.0) > 0:
                        plan_working = True
                        BusinessPlanHistory.objects.filter(id=business_plan_history_current_pending.id).update(plan_validity=True,plan_status='active',current_active=True,days_to_expire=diff.days,minutes_to_expire=int(diff.total_seconds() / 60.0))
                        business_plan_history_details = BusinessPlanHistory.objects.filter(id=business_plan_history_current_pending.id).first()
                    else:
                        BusinessPlanHistory.objects.filter(id=business_plan_history_current_pending.id).update(plan_validity=False,plan_status='expire',current_active=True,days_to_expire=diff.days,minutes_to_expire=int(diff.total_seconds() / 60.0))
                        business_plan_history_details = BusinessPlanHistory.objects.filter(id=business_plan_history_current_pending.id).first()
                else:
                    BusinessPlanHistory.objects.filter(id=business_plan_history_current_active.id).update(plan_validity=False,plan_status='expire',current_active=True,days_to_expire=diff.days,minutes_to_expire=int(diff.total_seconds() / 60.0))
                    business_plan_history_details = BusinessPlanHistory.objects.filter(id=business_plan_history_current_active.id).first()
    
    business_pricing_tier = BusinessPricingTier.objects.filter(business_plan_history_id=business_plan_history_details.id).all()
    product_detail = business_pricing_tier.filter(category_name='Product').values('id','uuid','quantity','default_product_id','default_product_id__product_name','plan_feature_pricing_category_id','category_name','plan_feature_pricing_tier_id','plan_pricing_description').all()
    plans_pricing_tier = []
    desired_product_names = ['Gate Site', 'Train Site', 'In and Out Object Site', 'Occupancy management site']
    for product_data in product_detail:
        if product_data['default_product_id__product_name'] in desired_product_names:
        # if product_name in desired_product_names:
        
                camera_detail = business_pricing_tier.filter(default_product_id=product_data['default_product_id'], category_name='Camera').values('id','uuid','quantity','default_product_id','plan_feature_pricing_category_id','category_name','plan_feature_pricing_tier_id','plan_pricing_description').first()
                online_dashboard_detail = business_pricing_tier.filter(default_product_id=product_data['default_product_id'], category_name='Online Dashboard').values('id','uuid','default_product_id','plan_feature_pricing_category_id','category_name','plan_feature_pricing_tier_id','plan_pricing_description').first()
                online_data_backup_detail = business_pricing_tier.filter(default_product_id=product_data['default_product_id'], category_name='Online Data Backup').values('id','uuid','backup_days_id','backup_days','default_product_id','plan_feature_pricing_category_id','category_name','plan_feature_pricing_tier_id','plan_pricing_description').first()
                offline_dashboard_detail = business_pricing_tier.filter(default_product_id=product_data['default_product_id'], category_name='Offline Dashboard').values('id','uuid','default_product_id','plan_feature_pricing_category_id','category_name','plan_feature_pricing_tier_id','plan_pricing_description').first()
                offline_data_backup_detail = business_pricing_tier.filter(default_product_id=product_data['default_product_id'], category_name='Offline Data Backup').values('id','uuid','backup_days_id','backup_days','default_product_id','plan_feature_pricing_category_id','category_name','plan_feature_pricing_tier_id','plan_pricing_description').first()
                product_feature_detail = business_pricing_tier.filter(default_product_id=product_data['default_product_id'], category_name='Feature').values('id','uuid','default_product_id','default_product_id__product_name','default_product_feature_id','default_product_feature_id__feature','plan_feature_pricing_category_id','category_name','plan_feature_pricing_tier_id','plan_pricing_description').all()

                
                plans_pricing_tier.append({
                    'camera_detail': camera_detail,
                    'online_dashboard_detail': online_dashboard_detail,
                    'online_data_backup_detail': online_data_backup_detail,
                    'offline_dashboard_detail': offline_dashboard_detail,
                    'offline_data_backup_detail': offline_data_backup_detail,
                    'product_detail': product_data,
                    'product_feature_detail': product_feature_detail
                })
        # if product_data['default_product_id__product_name'] == 'Gate Site':
       
        #     camera_detail = business_pricing_tier.filter(default_product_id=product_data['default_product_id'],category_name='Camera').values('id','uuid','quantity','default_product_id','plan_feature_pricing_category_id','category_name','plan_feature_pricing_tier_id','plan_pricing_description').first()
        #     # default_product_id = camera_detail.get('default_product_id')
        #     # print("Default Product ID:", default_product_id)
          
        #     print("cd", camera_detail)
        #     # parking_slot_detail = business_pricing_tier.filter(default_product_id=product_data['default_product_id'],category_name='Parking Slot').values('id','uuid','quantity','default_product_id','plan_feature_pricing_category_id','category_name','plan_feature_pricing_tier_id','plan_pricing_description').first()
        #     online_dashboard_detail = business_pricing_tier.filter(default_product_id=product_data['default_product_id'],category_name='Online Dashboard').values('id','uuid','default_product_id','plan_feature_pricing_category_id','category_name','plan_feature_pricing_tier_id','plan_pricing_description').first()
        #     online_data_backup_detail = business_pricing_tier.filter(default_product_id=product_data['default_product_id'],category_name='Online Data Backup').values('id','uuid','backup_days_id','backup_days','default_product_id','plan_feature_pricing_category_id','category_name','plan_feature_pricing_tier_id','plan_pricing_description').first()
        #     offline_dashboard_detail = business_pricing_tier.filter(default_product_id=product_data['default_product_id'],category_name='Offline Dashboard').values('id','uuid','default_product_id','plan_feature_pricing_category_id','category_name','plan_feature_pricing_tier_id','plan_pricing_description').first()
        #     offline_data_backup_detail = business_pricing_tier.filter(default_product_id=product_data['default_product_id'],category_name='Offline Data Backup').values('id','uuid','backup_days_id','backup_days','default_product_id','plan_feature_pricing_category_id','category_name','plan_feature_pricing_tier_id','plan_pricing_description').first()
        #     product_feature_detail = business_pricing_tier.filter(default_product_id=product_data['default_product_id'],category_name='Feature').values('id','uuid','default_product_id','default_product_id__product_name','default_product_feature_id','default_product_feature_id__feature','plan_feature_pricing_category_id','category_name','plan_feature_pricing_tier_id','plan_pricing_description').all()
        #     plans_pricing_tier.append({
        #         'camera_detail':camera_detail,
        #         #'parking_slot_detail':parking_slot_detail,
        #         'online_dashboard_detail':online_dashboard_detail,
        #         'online_data_backup_detail':online_data_backup_detail,
        #         'offline_dashboard_detail':offline_dashboard_detail,
        #         'offline_data_backup_detail':offline_data_backup_detail,
        #         'product_detail':product_data,
        #         'product_feature_detail':product_feature_detail
        #     })
    
    
    user_role_maps = UserRoleMapping.objects.filter(user=user_detail['id']).values('id','role').first()
   # TimeZoneLoc = pytz.timezone(company_details['timezones'])
    # diff = None
    # try:
    #     diff = datetime.strptime(str(business_details['plan_expire_datetime']), '%Y-%m-%d %H:%M:%S.%f+00:00') - datetime.strptime(str(datetime.now()), '%Y-%m-%d %H:%M:%S.%f')
    # except Exception as e:
    #     diff = datetime.strptime(str(business_details['plan_expire_datetime']), '%Y-%m-%d %H:%M:%S+00:00') - datetime.strptime(str(datetime.now()), '%Y-%m-%d %H:%M:%S.%f')
    # if int(diff.total_seconds() / 60.0) > 0:
    #     BusinessDetail.objects.filter(id=user_detail['business_detail_id']).update(plan_validity=True,days_to_expire=diff.days,minutes_to_expire=int(diff.total_seconds() / 60.0))
    # else:
    #     BusinessDetail.objects.filter(id=user_detail['business_detail_id']).update(plan_validity=False,days_to_expire=diff.days,minutes_to_expire=int(diff.total_seconds() / 60.0))
    
    # business_details = BusinessDetail.objects.filter(id=user_detail['business_detail_id']).values('id','business_name','business_type','business_logo','country','uses_type','plan_validity','timezones','currency__currency_symbol').first()  ##'anpr_check_allowed','blacklist_check_allowed','plan_start_datetime','plan_expire_datetime','days_to_expire','minutes_to_expire'
    role_detail = Roles.objects.filter(id=user_role_maps['role']).values('id','role_name').last()
    permissions = Permission.objects.filter(
        role=user_role_maps['role'],
            menu_page__menu_name=menu_name,
            action__action_name=action
        ).order_by('menu_page').distinct('menu_page').values(
            'id', 'role', 'role__role_name', 'menu_page', 'menu_page__menu_name', 'action__action_name'
        ).first()
    data = {'user_detail':user_detail,'company_detail':company_details,'business_plan_history_detail':business_plan_history_details,'plans_detail':plans_pricing_tier,'role_detail':role_detail,'permission':permissions}
    return data  

class WindowsLogin(APIView):
    permission_classes = (AllowAny,)

    def post(self, request, format=None):
        serializer = UserLoginSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        email = serializer.data.get('email')
        password = serializer.data.get('password')
        print(email, password)
        user = authenticate(email=email, password=password)

        if user:
            if user.is_active:
                getSites = Sites.objects.filter(user=user.id).values('id', 'site_name', 'user','user_login_or_not','active','company_detail_id__plan_expire_datetime').first()

                if getSites is not None:
                    if getSites['user_login_or_not'] is False:
                        if getSites['active'] is True:
                            # Check allowed_status for site_product and site_feature
                            # site_product_allowed = SiteProductAllowed.objects.filter(site=getSites['id']).first()
                            # site_feature_allowed = SiteFeatureAllowed.objects.filter(site_product_allowed=site_product_allowed.id).first()

                            # if site_product_allowed and site_feature_allowed:
                            #     if site_product_allowed.allowed_status and site_feature_allowed.allowed_status:
                            #         TimeZoneLoc = pytz.timezone('Asia/Kolkata')
                            #         diff = datetime.strptime(str(getSites['company_detail_id__plan_expire_datetime']),
                            #                                  '%Y-%m-%d %H:%M:%S.%f+00:00') - datetime.strptime(
                            #             str(datetime.now()), '%Y-%m-%d %H:%M:%S.%f')

                            #         if int(diff.total_seconds() / 60.0) > 0:
                            #             Sites.objects.filter(id=getSites['id']).update(
                            #                 plan_validity=True, days_to_expire=diff.days, user_login_or_not=True)
                            #         else:
                            Sites.objects.filter(id=getSites['id']).update(user_login_or_not=True)
                            user_detail = get_user_data(user.id)
                            update_sites = Sites.objects.filter(user=user.id).first()
                            # .values('id', 'site_name', 'user__email',
                            # 'company_detail_id',
                            # 'company_detail_id__plan_start_datetime',
                            # 'company_detail_id__plan_expire_datetime',
                            # 'days_to_expire',
                            # 'minute_to_expire',
                            # 'plan_validity', 'company_detail_id__timezones',
                            # 'active', 'user_login_or_not',
                            # 'skip_frame',
                            # 'company_detail_id__delete_previous_data_after_day_cloud',
                            # 'company_detail_id__delete_previous_data_after_day_on_premises')
                            sites_serializer = SitesSerializer(update_sites)
                            refresh = RefreshToken.for_user(user)
                            
                            user_detail['refresh'] = str(refresh)
                            user_detail['access'] = str(refresh.access_token)
                            user_detail['sites'] = sites_serializer.data
                            # print(user_detail)
                            return JsonResponse(user_detail, status=status.HTTP_200_OK)
                            #     else:
                            #         res = {"code": 400, "message": "Site or its features are not allowed."}
                            #         return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)
                            # else:
                            #     res = {"code": 400, "message": "Site or its features are not allowed."}
                            #     return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)
                        else:
                            res = {"code": 400, "message": "Your Sites is not active."}
                            return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)
                    else:
                        res = {"code": 400, "message": "Your sites account is already logged in to another system. Please logout first."}
                        return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)
                else:
                    res = {"code": 400, "message": "Your account is not valid for the Windows application."}
                    return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)
            else:
                res = {"code": 400, "message": "Account is not active."}
                return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)
        else:
            res = {"code": 400, "message": "Invalid username and password."}
            return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)

class WindowsLogout(APIView):
    permission_classes = (IsAuthenticated,)
    def post(self, request, format=None):
        getSites = Sites.objects.filter(user=request.user.id).values('id','site_name').first()
        if getSites != None:
                updateSites = Sites.objects.filter(user=request.user.id).update(user_login_or_not=False)
                res = {"code": 200, "submit": "Your account are logout successfully."}
                return JsonResponse(res, status=status.HTTP_200_OK)
        else:
            res = {"code": 400, "submit": "Your account is not valid for windows application."}
            return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)


class WindowsGetUserDetail(APIView):
    permission_classes = (IsAuthenticated,)
    def get(self, request, format=None):
        getSites = Sites.objects.filter(user=request.user.id).values('id', 'site_name', 'user','user_login_or_not','active','company_detail_id','company_detail_id__plan_expire_datetime').first()
        if getSites != None:
            Sites.objects.filter(id=getSites['id']).update(user_login_or_not=True)

            application_active = request.GET.get('application_active',None)
            if application_active ==None:
                application_active = False
            if application_active != None:
                if application_active == 'true':
                    application_active = True
                else:
                    application_active=False
            get_active_log = WindowsSitesActiveLog.objects.filter(sites_id=getSites['id']).values('id','sites','last_active_datetime').last()
            if get_active_log == None:
                insert_active_log = WindowsSitesActiveLog.objects.create(sites_id=getSites['id'],company_detail_id=CompanyDetail.objects.get(id=getSites['company_detail_id']), last_active_datetime=datetime.now(),application_open=application_active,active=True,email_sent=False)
                insert_active_log.save()
            else:
                last_active_datetime = get_active_log['last_active_datetime']
                diff = datetime.strptime(str(last_active_datetime), '%Y-%m-%d %H:%M:%S.%f+00:00') - datetime.strptime(str(datetime.now()), '%Y-%m-%d %H:%M:%S.%f')
                if int(diff.total_seconds() / 60.0) >= 15:
                    insert_deactive_log =  WindowsDeactiveLog.objects.create(sites_id=getSites['id'],company_detail_id=getSites['company_detail_id'],start_datetime=last_active_datetime,end_datetime=timezone.now())
                    insert_deactive_log.save()
                update_active_log = WindowsSitesActiveLog.objects.filter(sites_id=getSites['id']).update(last_active_datetime=datetime.now(),application_open=application_active,active=True,email_sent=False)
            user_detail = get_user_data(request.user.id)
            update_sites = Sites.objects.filter(user=request.user.id).first()
            sites_serializer = SitesSerializer(update_sites)
            user_detail['sites'] = sites_serializer.data

            # print(user_detail)
            return JsonResponse(user_detail, status=status.HTTP_200_OK)
        else:
            res = {"code": 400, "submit": "Your account is not valid for windows application."}
            return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)




# class WindowsLogin(APIView):
#     permission_classes = (AllowAny,)
#     def post(self, request, format=None):
#         serializer = UserLoginSerializer(data=request.data)
#         serializer.is_valid(raise_exception=True)
#         email = serializer.data.get('email')
#         password = serializer.data.get('password')
#         print(email,password)
#         user = authenticate(email=email,password=password)
#         if user:
#             if user.is_active:
#                 getSites = Sites.objects.filter(user=user.id).values('id','site_name','user','company_detail').first()
#                 if getSites != None:
#                     if getSites['user_login_or_not'] == False:
#                         if getSites['active'] == True:
#                             TimeZoneLoc = pytz.timezone('Asia/Kolkata')
#                             diff = datetime.strptime(str(getSites['plan_expire_datetime']), '%Y-%m-%d %H:%M:%S.%f+00:00') - datetime.strptime(str(datetime.now()), '%Y-%m-%d %H:%M:%S.%f')
#                             if int(diff.total_seconds() / 60.0) > 0:
#                                 Sites.objects.filter(id=getSites['id']).update(plan_validity=True,days_to_expire=diff.days,user_login_or_not=True)
#                             else:
#                                 Sites.objects.filter(id=getSites['id']).update(plan_validity=False,days_to_expire=diff.days,user_login_or_not=True)   
#                             update_sites = Sites.objects.filter(user=user.id).values('id','site_name','user','company_detail_id','plan_start_datetime','plan_expire_datetime','days_to_expire','plan_validity','timezones','active','user_login_or_not','skip_frame','delete_previous_data_after_day').first()
#                             refresh = RefreshToken.for_user(user)
#                             user_detail = get_user_data(user.id)
#                             user_detail['refresh'] = str(refresh)
#                             user_detail['access'] = str(refresh.access_token)
#                             user_detail['sites'] = getSites
#                             # print(user_detail)
#                             return JsonResponse(user_detail, status=status.HTTP_200_OK)
#                         else:
#                             res = {"code": 400, "message": "Your Sites is not active."}
#                             return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)
#                     else:
#                         res = {"code": 400, "message": "Your sites account is already login in other system. Please logout first. "}
#                         return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)
#                 else:
#                     res = {"code": 400, "message": "Your account is not valid for windows application."}
#                     return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)
#             else:
#                 res = {"code": 400, "message": "Account was not active."}
#                 return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)
#         else:
#             res = {"code": 400, "message": "Invalid Username and Password."}
#             return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)

class GetUserDetail(APIView):
    permission_classes = (IsAuthenticated,)
    # authentication_classes = (TokenAuthentication,)
    
    def get(self, request, format=None):
        try:
            token = request.META.get('HTTP_AUTHORIZATION', " ").split(' ')[1]
            if token != '':
                data = {'token': token}
                print("data:",data)
                valid_data = TokenBackend(algorithm='HS256').decode(token,verify=False)
                print(valid_data)
                user = valid_data['user_id']
                print("User:",user,request.user.id)
                request.user = user
                print("request.user1:",request.user)
            else:
                Response({"result": {},"message": "Invalid Token."}, status=status.HTTP_201_CREATED)
        except ValidationError as v:
            print("validation error", v)
        user_detail = get_user_data(request.user)
        return Response(user_detail)

    
class AddUserEmailView(APIView):
    permission_classes = (IsAuthenticated,)
    pagination_class = LimitOffsetPagination

    def get(self, request, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        user_detail_page = get_user_data_page(request.user.id,'add user email','view')
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            # if 'add user email' in user_detail_page['permission'].keys():
            #     if 'view' in user_detail_page['permission']['add user email']:
            #         AccessToPage = True
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                limit = int(request.GET.get('limit',10))
                offset = int(request.GET.get('offset',0))
                add_user_email_detail = AddUserEmail.objects.filter(company_detail_id = user_detail_page['company_detail']['id']).order_by('-id').all()[offset:limit+offset]  ##.values('id','licence_plate_number','licence_plate_image','confidence_licence_plate','datetime','speed','speed_violation','lane_change','driver_seat_belt','driver_seat_belt_image','confidence_driver_seat_belt','passanger_seat_belt','passanger_seat_belt_image','confidence_passanger_seat_belt','driver_mobile','driver_mobile_image','confidence_driver_mobile','passanger_mobile','passanger_mobile_image','confidence_passanger_mobile','vehicle_type','vehicle_direction','country','camera_name','created_by','created_datetime','updated_by','updated_datetime')
                add_user_email_detail_count = AddUserEmail.objects.filter(company_detail_id = user_detail_page['company_detail']['id']).order_by('-id').count()
                serializer = AddUserEmailSerializer(add_user_email_detail, many=True)
                return Response({"count":add_user_email_detail_count, "results":serializer.data})
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def post(self, request, format=None):
        user_detail_page = get_user_data_page(request.user.id,'add user email','create')  
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            # if 'add user email' in user_detail_page['permission'].keys():
            #     if 'create' in user_detail_page['permission']['add user email']:
            #         AccessToPage = True
            if AccessToPage == True:
                limit = int(request.GET.get('limit',10))
                offset = int(request.GET.get('offset',0))
                get_data = request.data
                get_data['company_detail_id'] = user_detail_page['company_detail']['id']
                print(get_data)
                serializer = AddUserEmailSerializer(data=get_data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class UserEmailDetailView(APIView):
    permission_classes = (IsAuthenticated,)
    def get_object(self, id):
        try:
            return AddUserEmail.objects.get(pk=id)
        except AddUserEmail.DoesNotExist:
            raise Http404
    def get(self, request,id, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        user_detail_page = get_user_data_page(request.user.id,'add user email','view')  
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            # if 'add user email' in user_detail_page['permission'].keys():
            #     if 'view' in user_detail_page['permission']['add user email']:
            #         AccessToPage = True
            if AccessToPage == True:
                sites = self.get_object(id)
                serializer = AddUserEmailSerializer(sites)
                return Response(serializer.data)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
    def put(self, request, id, format=None): 
        user_detail_page = get_user_data_page(request.user.id,'add user email','update')  
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            # if 'add user email' in user_detail_page['permission'].keys():
            #     if 'update' in user_detail_page['permission']['add user email']:
            #         AccessToPage = True
            if AccessToPage == True:
                add_user_email = self.get_object(id)
                get_data = request.data
                get_data['company_detail_id'] = user_detail_page['company_detail']['id']
                serializer = AddUserEmailSerializer(add_user_email, data=get_data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)  
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
     
    def delete(self, request,id, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        user_detail_page = get_user_data_page(request.user.id,'add user email','delete')  
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            # if 'add user email' in user_detail_page['permission'].keys():
            #     if 'delete' in user_detail_page['permission']['add user email']:
            #         AccessToPage = True
            if AccessToPage == True:
                add_user_email = self.get_object(id)
                add_user_email.delete()
                return Response(status=status.HTTP_204_NO_CONTENT)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
 
class SiteView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, format=None):
        limit = int(request.GET.get('limit',10))
        offset = int(request.GET.get('offset',0))
        # print("request.user",request.user,request.user.id,type(request.user.id))
        user_detail_page = get_user_data_page(request.user.id,'sites','view')  
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            # if 'sites' in user_detail_page['permission'].keys():
            #     if 'view' in user_detail_page['permission']['sites']:
            #         AccessToPage = True
            if AccessToPage == True:
                sites_detail = Sites.objects.filter(company_detail_id = user_detail_page['company_detail']['id']).all()[offset:limit+offset]
                sites_count = Sites.objects.filter(company_detail_id = user_detail_page['company_detail']['id']).count()
                serializer = SitesSerializer(sites_detail, many=True)

                return Response({"count":sites_count, "results":serializer.data})
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
    
    # def post(self, request, format=None):
    #     user_detail_page = get_user_data_page(request.user.id,'sites','create')  
    #     if user_detail_page['company_detail']['plan_validity'] == True:
    #         AccessToPage = False
    #         if user_detail_page['permission'] != None:
    #             AccessToPage = True
    #         # if 'sites' in user_detail_page['permission'].keys():
    #         #     if 'create' in user_detail_page['permission']['sites']:
    #         #         AccessToPage = True
    #         if AccessToPage == True:
    #             get_data = request.data
    #             get_data['company_detail'] = user_detail_page['company_detail']['id']
    #             serializer = SitesSerializer(data=get_data)
    #             if serializer.is_valid():
    #                 serializer.save()
    #                 return Response(serializer.data, status=status.HTTP_201_CREATED)
    #             else:
    #                 return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    #         else:
    #             return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
    #     else:
    #         return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def post(self, request, format=None):
        user_detail_page = get_user_data_page(request.user.id, 'sites', 'create')
        if user_detail_page['company_detail']['plan_validity']:
            AccessToPage = False
            if user_detail_page['permission'] is not None:
                AccessToPage = True

            if AccessToPage:
                get_data = request.data
                get_data['company_detail_id'] = user_detail_page['company_detail']['id']
                site_product_allow = get_data.pop('site_product_allow')
                product_id=[]
                feature_id=[]
                serializer = SitesSerializer(data=get_data, context={'request': request})
                if serializer.is_valid():
                    site_instance = serializer.save()
                    for product in site_product_allow:
                        product_data = {
                            "product_allowed":product['product_allowed'],
                            "allowed_status":product['allowed_status'],
                            "company_detail_id":user_detail_page['company_detail']['id'],
                            "site":site_instance.id
                        }
                        site_product_allowed_serializer = SiteProductAllowedSerializer(data=product_data)
                        if site_product_allowed_serializer.is_valid():
                            site_product_instance = site_product_allowed_serializer.save()
                            product_id.append(site_product_instance.id)
                        else:
                            site_instance.delete()
                            for product_instance in product_id:
                                SiteProductAllowed.objects.filter(id=product_instance['id']).delete()
                            return Response(site_product_allowed_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                        for feature in product['site_product_feature_allow']:
                            feature_data = {
                                'feature_allowed': feature['feature_allowed'],
                                'allowed_status': feature['allowed_status'],
                                'site_product_allowed': site_product_allowed_serializer.instance.id,
                                'company_detail_id': user_detail_page['company_detail']['id'],
                                'site': site_instance.id
                            }
                            for sub_feature in feature['sub_features']:
                                feature_data = {
                                'feature_allowed': sub_feature['feature_allowed'],
                                'allowed_status': sub_feature['allowed_status'],
                                'site_product_allowed': site_product_allowed_serializer.instance.id,
                                'company_detail_id': user_detail_page['company_detail']['id'],
                                'site': site_instance.id
                                }
                                site_feature_allowed_serializer = SiteFeatureAllowedSerializer(data=feature_data)
                                if site_feature_allowed_serializer.is_valid():
                                    site_feature_instance = site_feature_allowed_serializer.save()
                                    feature_id.append(site_feature_instance.id)
                                else:
                                    site_instance.delete()
                                    for product_instance in product_id:
                                        SiteProductAllowed.objects.filter(id=product_instance['id']).delete()
                                    for feature_instance in feature_id:
                                        SiteFeatureAllowed.objects.filter(id=feature_instance['id']).delete()
                                    return Response(site_feature_allowed_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

                            site_feature_allowed_serializer = SiteFeatureAllowedSerializer(data=feature_data)
                            if site_feature_allowed_serializer.is_valid():
                                site_feature_instance = site_feature_allowed_serializer.save()
                                feature_id.append(site_feature_instance.id)
                            else:
                                site_instance.delete()
                                for product_instance in product_id:
                                    SiteProductAllowed.objects.filter(id=product_instance['id']).delete()
                                for feature_instance in feature_id:
                                    SiteFeatureAllowed.objects.filter(id=feature_instance['id']).delete()
                                return Response(site_feature_allowed_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                else:
                    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "You don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "Account validity has expired."}, status=status.HTTP_400_BAD_REQUEST)
    
       
class SitesDetailView(APIView):
    permission_classes = (IsAuthenticated,)
    def get_object(self, id):
        try:
            return Sites.objects.get(pk=id)
        except Sites.DoesNotExist:
            raise Http404
    def get(self, request,id, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        user_detail_page = get_user_data_page(request.user.id,'sites','view')  
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            # if 'sites' in user_detail_page['permission'].keys():
            #     if 'view' in user_detail_page['permission']['sites']:
            #         AccessToPage = True
            if AccessToPage == True:
                sites = self.get_object(id)
                serializer = SitesSerializer(sites)
                return Response(serializer.data)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


    def put(self, request, id, format=None):
        user_detail_page = get_user_data_page(request.user.id, 'sites', 'update')
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True

            if AccessToPage == True:
                site = self.get_object(id)
                get_data = request.data
                get_data['company_detail_id'] = user_detail_page['company_detail']['id']
                site_product_allow = get_data.pop('site_product_allow')
                product_id=[]
                feature_id=[]
                serializer = SitesSerializer(site, data=get_data)
                if serializer.is_valid():
                    site_instance = serializer.save()
                    for product in site_product_allow:
                        product_data = {
                            "product_allowed":product['product_allowed'],
                            "allowed_status":product['allowed_status'],
                            "company_detail_id":user_detail_page['company_detail']['id'],
                            "site":site_instance.id
                        }
                        site_product =  SiteProductAllowed.objects.get(pk=product['id'])
                        
                        site_product_allowed_serializer = SiteProductAllowedSerializer(site_product,data=product_data)
                        if site_product_allowed_serializer.is_valid():
                            site_product_instance = site_product_allowed_serializer.save()
                            product_id.append(site_product_instance.id)
                        else:
                            site_instance.delete()
                            for product_instance in product_id:
                                SiteProductAllowed.objects.filter(id=product_instance['id']).delete()
                            return Response(site_product_allowed_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                        for feature in product['site_product_feature_allow']:
                            feature_data = {
                                'feature_allowed': feature['feature_allowed'],
                                'allowed_status': feature['allowed_status'],
                                'site_product_allowed': site_product_allowed_serializer.instance.id,
                                'company_detail_id': user_detail_page['company_detail']['id'],
                                'site': site_instance.id
                            }
                            for sub_feature in feature['sub_features']:
                                feature_data = {
                                'feature_allowed': sub_feature['feature_allowed'],
                                'allowed_status': sub_feature['allowed_status'],
                                'site_product_allowed': site_product_allowed_serializer.instance.id,
                                'company_detail_id': user_detail_page['company_detail']['id'],
                                'site': site_instance.id
                                }
                                site_feature =  SiteFeatureAllowed.objects.get(pk=sub_feature['id'])
                                site_feature_allowed_serializer = SiteFeatureAllowedSerializer(site_feature,data=feature_data)
                                if site_feature_allowed_serializer.is_valid():
                                    site_feature_instance = site_feature_allowed_serializer.save()
                                    feature_id.append(site_feature_instance.id)
                                else:
                                    site_instance.delete()
                                    for product_instance in product_id:
                                        SiteProductAllowed.objects.filter(id=product_instance['id']).delete()
                                    for feature_instance in feature_id:
                                        SiteFeatureAllowed.objects.filter(id=feature_instance['id']).delete()
                                    return Response(site_feature_allowed_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                            
                            site_feature =  SiteFeatureAllowed.objects.get(pk=feature['id'])
                            site_feature_allowed_serializer = SiteFeatureAllowedSerializer(data=feature_data)
                            if site_feature_allowed_serializer.is_valid():
                                site_feature_instance = site_feature_allowed_serializer.save()
                                feature_id.append(site_feature_instance.id)
                            else:
                                site_instance.delete()
                                for product_instance in product_id:
                                    SiteProductAllowed.objects.filter(id=product_instance['id']).delete()
                                for feature_instance in feature_id:
                                    SiteFeatureAllowed.objects.filter(id=feature_instance['id']).delete()
                                return Response(site_feature_allowed_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                else:
                    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "You don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "Account validity has expired."}, status=status.HTTP_400_BAD_REQUEST)
          
       
    # def put(self, request, id, format=None):
    #     user_detail_page = get_user_data_page(request.user.id, 'sites', 'update')
    #     if user_detail_page['company_detail']['plan_validity'] == True:
    #         AccessToPage = False
    #         if user_detail_page['permission'] != None:
    #             AccessToPage = True

    #         if AccessToPage == True:
    #             site = self.get_object(id)
    #             serializer = SitesSerializer(site, data=request.data)
    #             if serializer.is_valid():
    #                 site_instance = serializer.save()

    #                 # Update SiteProductAllowed
    #                 site_product_allowed_data = {
    #                     'default_product': request.data['default_product'],
    #                     'allowed_status': request.data['allowed_status'],
    #                     'company_detail_id': user_detail_page['company_detail']['id'],
    #                     'site': site_instance.id
    #                 }
    #                 site_product_allowed_serializer = SiteProductAllowedSerializer(
    #                     site.site_product_allowed.all(),
    #                     data=site_product_allowed_data,
    #                     many=True
    #                 )
    #                 if site_product_allowed_serializer.is_valid():
    #                     site_product_allowed_serializer.save()
    #                 else:
    #                     return Response(site_product_allowed_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    #                 # Update SiteFeatureAllowed
    #                 default_product_features = DefaultProductFeature.objects.filter(
    #                     default_product=request.data['default_product']
    #                 )
    #                 for feature in default_product_features:
    #                     site_feature_allowed_data = {
    #                         'default_product_feature': feature,
    #                         'allowed_status': request.data['allowed_status'],
    #                         'product_allowed': site_product_allowed_serializer.instance,
    #                         'company_detail_id': user_detail_page['company_detail']['id'],
    #                         'site': site_instance.id
    #                     }
    #                     site_feature_allowed_serializer = SiteFeatureAllowedSerializer(
    #                         site.site_feature_allowed.all(),
    #                         data=site_feature_allowed_data,
    #                         many=True
    #                     )
    #                     if site_feature_allowed_serializer.is_valid():
    #                         site_feature_allowed_serializer.save()
    #                     else:
    #                         return Response(site_feature_allowed_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    #                 return Response(serializer.data)
    #             return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    #         else:
    #             return Response({"detail": "You don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
    #     else:
    #         return Response({"detail": "Account validity has expired."}, status=status.HTTP_400_BAD_REQUEST)
        
    
    # def put(self, request, id, format=None): 
    #     user_detail_page = get_user_data_page(request.user.id,'sites','update')  
    #     if user_detail_page['company_detail']['plan_validity'] == True:
    #         AccessToPage = False
    #         if user_detail_page['permission'] != None:
    #             AccessToPage = True
    #         # if 'sites' in user_detail_page['permission'].keys():
    #         #     if 'update' in user_detail_page['permission']['sites']:
    #         #         AccessToPage = True
    #         if AccessToPage == True:
    #             sites = self.get_object(id)
    #             serializer = SitesSerializer(sites, data=request.data)
    #             if serializer.is_valid():
    #                 serializer.save()
    #                 return Response(serializer.data)
    #             return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)  
    #         else:
    #             return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
    #     else:
    #         return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
     
    def delete(self, request,id, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        user_detail_page = get_user_data_page(request.user.id,'sites','delete')  
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            # if 'sites' in user_detail_page['permission'].keys():
            #     if 'delete' in user_detail_page['permission']['sites']:
            #         AccessToPage = True
            if AccessToPage == True:
                sites = self.get_object(id)
                sites.delete()
                return Response(status=status.HTTP_204_NO_CONTENT)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class GetCompanyProductAndFeatureDetail(APIView):
    permission_classes = (IsAuthenticated,)
    def get(self, request, format=None):
        user_detail_page = get_user_data_page(request.user.id,'sites','view')  
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                product_allowed = ProductAllowed.objects.filter(company_detail_id=user_detail_page['company_detail']['id']).values('id','default_product','allowed_status','default_product__product_name')
                product_allowed_data = []
                for product in product_allowed:
                    feature_allowed_data = []
                    feature_allowed = FeatureAllowed.objects.filter(company_detail_id=user_detail_page['company_detail']['id'],product_allowed=product['id']).values('id','default_product_feature','default_product_feature__parent_feature','allowed_status','product_allowed','default_product_feature__feature')
                    for feature in feature_allowed:
                        feature_data = {
                            'id': feature['id'],
                            'default_product_feature': feature['default_product_feature'],
                            'default_product_feature__parent_feature': feature['default_product_feature__parent_feature'],
                            'allowed_status': feature['allowed_status'],
                            'product_allowed': feature['product_allowed'],
                            'default_product_feature__feature': feature['default_product_feature__feature']
                        }
                        feature_allowed_data.append(feature_data)
                    product_data = {
                        'id': product['id'],
                        'default_product': product['default_product'],
                        'allowed_status': product['allowed_status'],
                        'default_product__product_name': product['default_product__product_name'],
                        'feature_allowed': feature_allowed_data
                    }
                    product_allowed_data.append(product_data)

                return Response(product_allowed_data)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
                

class RoleDropdownView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        user_detail_page = get_user_data(request.user.id)
        if user_detail_page['company_detail']['plan_validity'] == True:
            roles = Roles.objects.filter(company_detail_id = user_detail_page['company_detail']['id']).all()  ##.values('id','licence_plate_number','licence_plate_image','confidence_licence_plate','datetime','speed','speed_violation','lane_change','driver_seat_belt','driver_seat_belt_image','confidence_driver_seat_belt','passanger_seat_belt','passanger_seat_belt_image','confidence_passanger_seat_belt','driver_mobile','driver_mobile_image','confidence_driver_mobile','passanger_mobile','passanger_mobile_image','confidence_passanger_mobile','vehicle_type','vehicle_direction','country','camera_name','created_by','created_datetime','updated_by','updated_datetime')
            serializer = RolesSerializer(roles, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

class UserEmailView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, format=None):
        # print("request.user",request.user,request.user.id,type(request.user.id))
        user_detail_page = get_user_data(request.user.id)
        if user_detail_page['company_detail']['plan_validity'] == True:
            roles = User.objects.filter(company_detail_id = user_detail_page['company_detail']['id']).all()  ##.values('id','licence_plate_number','licence_plate_image','confidence_licence_plate','datetime','speed','speed_violation','lane_change','driver_seat_belt','driver_seat_belt_image','confidence_driver_seat_belt','passanger_seat_belt','passanger_seat_belt_image','confidence_passanger_seat_belt','driver_mobile','driver_mobile_image','confidence_driver_mobile','passanger_mobile','passanger_mobile_image','confidence_passanger_mobile','vehicle_type','vehicle_direction','country','camera_name','created_by','created_datetime','updated_by','updated_datetime')
            serializer = UserEmailSerializer(roles, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


# class RolesAndPermissionView(APIView):
#     permission_classes = (IsAuthenticated,)

#     def get_user_action(self, method):
#         if method == 'GET':
#             return 'view'
#         elif method == 'POST':
#             return 'create'
#         elif method == 'PUT':
#             return 'update'
#         elif method == 'DELETE':
#             return 'delete'
#         else:
#             return 'unknown'

#     def get(self, request):

#         limit = int(request.GET.get('limit', 10))
#         offset = int(request.GET.get('offset', 0))

#         user_detail_page = get_user_data_page(request.user.id,'roles_permission','view')  
#         if user_detail_page['company_detail']['plan_validity'] == True:
#             AccessToPage = False
#             if user_detail_page['permission'] != None:
#                 AccessToPage = True
#             if AccessToPage == True:
#                     roles = Roles.objects.all()
#                     permissions = []

#                     for role in roles:
#                         role_data = {'role_name': role.role_name, 'permissions': []}
#                         role_permissions = role.permission_set.all()

#                         for permission in role_permissions:
#                             permission_data = {
#                                 'menu_name': permission.menu_page_id.menu_name,
#                                 'action': permission.action_id.action_name,
#                                 'user_action': self.get_user_action(request.method)  
#                             }
#                             role_data['permissions'].append(permission_data)

#                         permissions.append(role_data)
#                         permissions = permissions[offset:offset+limit]

#                     return Response(permissions)
#             else:
#                 return Response({"detail": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

#         else:
#             return Response({"detail": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


#     def post(self, request):
#         user_detail_page = get_user_data_page(request.user.id,'roles_permission','create')  
#         if user_detail_page['company_detail']['plan_validity'] == True:
#             AccessToPage = False
#             if user_detail_page['permission'] != None:
#                 AccessToPage = True
#             if AccessToPage == True:
#                 data = request.data
#                 serializer = PermissionSerializer(data=data)
#                 if serializer.is_valid():
#                     serializer.save()
#                     return Response(serializer.data, status=status.HTTP_201_CREATED)
#                 return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
#             else:
#                 return Response({"detail": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

#         else:
#             return Response({"detail": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


# class RolesAndPermissionDetailView(APIView):
#     permission_classes = (IsAuthenticated,)

#     def get_user_action(self, method):
#         if method == 'GET':
#             return 'view'
#         elif method == 'POST':
#             return 'create'
#         elif method == 'PUT':
#             return 'update'
#         elif method == 'DELETE':
#             return 'delete'
#         else:
#             return 'unknown'

#     def get(self, request,id, format=None):
#         user_detail_page = get_user_data_page(request.user.id,'roles_permission','view')  
#         if user_detail_page['company_detail']['plan_validity'] == True:
#             AccessToPage = False
#             if user_detail_page['permission'] != None:
#                 AccessToPage = True
#             if AccessToPage == True:
#                 try:
#                     role = Roles.objects.get(pk=id)
#                 except Roles.DoesNotExist:
#                     return Response({"detail": "ID not found."}, status=status.HTTP_404_NOT_FOUND)

#                 role_data = {'role_name': role.role_name, 'permissions': []}
#                 role_permissions = role.permission_set.all()

#                 for permission in role_permissions:
#                     permission_data = {
#                         'menu_name': permission.menu_page_id.menu_name,
#                         'action': permission.action_id.action_name,
#                         'user_action': self.get_user_action(request.method)
#                     }
#                     role_data['permissions'].append(permission_data)

#                 return Response(role_data)
#             else:
#                 return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
#         else:
#             return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

#     def put(self, request,id, format=None):
#         user_detail_page = get_user_data_page(request.user.id,'roles_permission','update')  
#         if user_detail_page['company_detail']['plan_validity'] == True:
#             AccessToPage = False
#             if user_detail_page['permission'] != None:
#                 AccessToPage = True
#             if AccessToPage == True:
#                 try:
#                     role = Roles.objects.get(pk=id)
#                 except Roles.DoesNotExist:
#                     return Response({"detail": "Role not found."}, status=status.HTTP_404_NOT_FOUND)

#                 # current_actions = role.permission_set.values_list('action_id__action_name', flat=True)

#                 # for data in request.data:
#                 #     action = data
#                 #     if action not in current_actions:
#                 #         #raise ValidationError(f"Invalid action: {action}")
#                 #         return Response({"detail": "You don`t have permissions to provide this action."}, status=status.HTTP_400_BAD_REQUEST)

#                 queryset = role.permission_set.first()
#                 serializer = PermissionSerializer(queryset,  data=request.data)
#                 if serializer.is_valid():
#                     serializer.save()
#                     return Response(serializer.data, status=status.HTTP_200_OK)
#                 print(serializer.errors)
#                 return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
#             else:
#                 return Response({"detail": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

#         else:
#             return Response({"detail": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


#     def delete(self, request,id, format=None):
#         user_detail_page = get_user_data_page(request.user.id,'roles_permission','delete')  
#         if user_detail_page['company_detail']['plan_validity'] == True:
#             AccessToPage = False
#             if user_detail_page['permission'] != None:
#                 AccessToPage = True
#             if AccessToPage == True:
#                 try:
#                     role = Roles.objects.get(id=id)
#                 except Roles.DoesNotExist:
#                     return Response({"detail": "Role not found."}, status=status.HTTP_404_NOT_FOUND)

#                 role.permission_set.all().delete()
#                 return Response(status=status.HTTP_204_NO_CONTENT)
#             else:
#                 return Response({"detail": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

#         else:
#             return Response({"detail": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)



class RolesAndPermissionView(APIView):
    permission_classes = (IsAuthenticated,)


    def get(self, request):
        limit = int(request.GET.get('limit', 10))
        offset = int(request.GET.get('offset', 0))

        user_detail_page = get_user_data_page(request.user.id,'roles_permission','view')  
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                roles = Roles.objects.filter(company_detail_id = user_detail_page['company_detail']['id']).all()
                permissions = []

                for role in roles:
                    role_data = {'role': role.id, 'role_name': role.role_name, 'permissions': []}
                    role_permissions = role.permission_set.all()

                    for permission in role_permissions:
                        menu_page = permission.menu_page.id
                        menu_name = permission.menu_page.menu_name
                        action_name = permission.action.action_name

                        # Check if the menu already exists in the permissions list
                        menu_exists = next((menu for menu in role_data['permissions'] if menu['menu_page'] == menu_page), None)

                        if menu_exists:
                            # Check if the action already exists for this menu
                            action_exists = next((act for act in menu_exists['action'] if act['action'] == permission.action.id), None)

                            if not action_exists:
                                menu_exists['action'].append({
                                    'action': permission.action.id,
                                    'action_name': action_name
                                })
                        else:
                            role_data['permissions'].append({
                                'menu_page': menu_page,
                                'menu_name': menu_name,
                                'action': [{
                                    'action': permission.action.id,
                                    'action_name': action_name
                                }]
                            })

                    permissions.append(role_data)

                total_count = len(roles)
                permissions = permissions[offset:offset + limit]
                

                return Response({"count": total_count, "results": permissions})
            else:
                return Response({"submit": "You don't have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"submit": "Account validity has expired."}, status=status.HTTP_400_BAD_REQUEST)




    def post(self, request):
        user_detail_page = get_user_data_page(request.user.id,'roles_permission','view')  
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                    
                data = request.data
                data['company_detail_id'] = user_detail_page['company_detail']['id']
                role_serializer = RolesSerializer(data=data)
                
                if role_serializer.is_valid():
                    role = role_serializer.save()
                else:
                    return Response(role_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                
                permissions_data = data.get('permission')
                if not permissions_data:
                    return Response({"submit": "Permission data is missing or empty."}, status=status.HTTP_400_BAD_REQUEST)

                # Create Permissions for the Role
                for permission_data in permissions_data:
                    permission_serializer = PermissionSerializer(data={
                        'role': role.id,
                        'menu_page': permission_data.get('menu_page'),
                        'action': permission_data.get('action')
                    })
                    if permission_serializer.is_valid():
                        permission_serializer.save()
                    else:
                        # If any permission data is invalid, delete the created role and return error response
                        print("deleted")
                        role.delete()
                        return Response(permission_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                print(permission_serializer.data)
                return Response({"submit": f"Role '{role.role_name}' with permissions has been created."}, status=status.HTTP_201_CREATED)
                    
            else:
                return Response({"submit": "You don't have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity has expired."}, status=status.HTTP_400_BAD_REQUEST)

class RolesAndPermissionDetailView(APIView):
    permission_classes = (IsAuthenticated,)

    # def get_user_action(self, method):
    #     if method == 'GET':
    #         return 'view'
    #     elif method == 'POST':
    #         return 'create'
    #     elif method == 'PUT':
    #         return 'update'
    #     elif method == 'DELETE':
    #         return 'delete'
    #     else:
    #         return 'unknown'

    def get(self, request, id, format=None):
        user_detail_page = get_user_data_page(request.user.id,'roles_permission','view')  
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                try:
                    company_detail_id = request.user.company_detail_id
                    role = Roles.objects.get(pk=id, company_detail_id=company_detail_id)
                except Roles.DoesNotExist:
                    return Response({"submit": "ID not found."}, status=status.HTTP_404_NOT_FOUND)

                role_data = {'role': role.id, 'role_name': role.role_name, 'permissions': []}
                role_permissions = role.permission_set.all()

                for permission in role_permissions:
                    menu_name = permission.menu_page.menu_name
                    action_name = permission.action.action_name
                    menu_page = permission.menu_page.id

                    # Find if the menu already exists in permissions list
                    menu_exists = next((menu for menu in role_data['permissions'] if menu['menu_page'] == menu_page), None)

                    if menu_exists:
                            # Check if the action already exists for this menu
                            action_exists = next((act for act in menu_exists['action'] if act['action'] == permission.action.id), None)

                            if not action_exists:
                                menu_exists['action'].append({
                                    'action': permission.action.id,
                                    'action_name': action_name
                                })
                    else:
                        # If menu doesn't exist, create a new menu entry and add action_name to it
                        role_data['permissions'].append({
                            'menu_page': menu_page,
                            'menu_name': menu_name,
                            'action': [{
                                'action': permission.action.id,
                                'action_name': action_name
                            }]
                        })

                return Response(role_data)
            else:
                return Response({"submit": "You don't have permission to access."}, status=status.HTTP_403_FORBIDDEN)
        else:
            return Response({"submit": "Account validity has expired."}, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request,id, format=None):
        user_detail_page = get_user_data_page(request.user.id,'roles_permission','view')  
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                try:
                    company_detail_id = request.user.company_detail_id
                    role = Roles.objects.get(pk=id, company_detail_id=company_detail_id)
                except Roles.DoesNotExist:
                    return Response({"submit": "Role not found."}, status=status.HTTP_404_NOT_FOUND)
                

                # Check if role_name is "Admin" or "Visitor"
                if role.role_name in ["Admin"]:
                    return Response({"submit": f"The role '{role.role_name}' cannot be updated."}, status=status.HTTP_400_BAD_REQUEST)
                
                if role.id == user_detail_page['role_detail']['id']:
                    raise PermissionDenied({"submit":"You cannot change your own role name."})

                role = request.data.get('role')
                role_name = request.data.get('role_name')
                prev_permissions_data = request.data.get('prev_permission', [])
                new_permissions_data = request.data.get('new_permission', [])

                # Update the role_name if provided
                if role_name:
                    role.role_name = role_name
                    role.save()

                # Process previous permissions
                for prev_permission_data in prev_permissions_data:
                    menu_page = prev_permission_data.get('menu_page')
                    action = prev_permission_data.get('action')
                    permission = Permission.objects.filter(role=role, menu_page=menu_page, action=action).first()

                    if permission:
                        permission.delete()

                # Process new permissions
                for new_permission_data in new_permissions_data:
                    menu_page = new_permission_data.get('menu_page')
                    action = new_permission_data.get('action')
                    permission_data = {
                        'role': role,
                        'menu_page': menu_page,
                        'action': action
                    }
                    permission_serializer = PermissionSerializer(data=permission_data)

                    if permission_serializer.is_valid():
                        permission_serializer.save()
                        print(permission_serializer)
                    else:
                        return Response(permission_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                    
                return Response({"submit": f"Role '{role_name}' permissions have been updated."}, status=status.HTTP_200_OK)

            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request,id, format=None):
        user_detail_page = get_user_data_page(request.user.id,'roles_permission','view')  
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                try:
                    company_detail_id = request.user.company_detail_id
                    role = Roles.objects.get(pk=id, company_detail_id=company_detail_id)
                except Roles.DoesNotExist:
                    return Response({"submit": "Role not found."}, status=status.HTTP_404_NOT_FOUND)
                
                # Check if action_perform is True for the role and allowed is True for the permissions
                if not role.permission_set.filter(allowed=True).exists():
                    return Response({"submit": "You don't have permissions to delete this role."}, status=status.HTTP_400_BAD_REQUEST)

                # Check if the role is assigned to some user
                assigned_users = AddUserEmail.objects.filter(role=id)
                if assigned_users.exists():
                    return Response({"submit": "Cannot delete this role. It is assigned to some user."}, status=status.HTTP_400_BAD_REQUEST)
                
                # Check if the role is referenced by UserRoleMapping
                if UserRoleMapping.objects.filter(role=id).exists():
                    return Response({"submit": "Cannot delete this role. It is referenced by UserRoleMapping."}, status=status.HTTP_400_BAD_REQUEST)

                # Check if the role_name is "Admin" or "Visitor"
                if role.role_name in ["Admin"]:
                    return Response({"submit": f"The role '{role.role_name}' cannot be deleted."}, status=status.HTTP_400_BAD_REQUEST)

                # Delete the associated permissions first
                Permission.objects.filter(role=id).delete()

                # Now, delete the role
                role.delete()

                return Response({"submit": f"Role '{role.role_name}' and its permissions have been deleted."}, status=status.HTTP_204_NO_CONTENT)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

class GetRolesAndPermissionView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request):
        user_detail_page = get_user_data_page(request.user.id,'roles_permission','view')  
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                user_role = get_user_data['role_detail']['id']

                # Fetch the role that belongs to the logged-in user
                role = Roles.objects.filter(id=user_role, company_detail_id = get_user_data['company_detail']['id']).first()

                if role is not None:
                    # Create a dictionary to store permissions
                    permissions_dict = {}

                    role_permissions = role.permission_set.select_related('menu_page', 'action').all()

                    for permission in role_permissions:
                        menu_page = permission.menu_page.id
                        menu_name = permission.menu_page.menu_name
                        action = permission.action.id
                        action_name = permission.action.action_name

                        if menu_page not in permissions_dict:
                            permissions_dict[menu_page] = {
                                'menu_page': menu_page,
                                'menu_name': menu_name,
                                'action': []
                            }

                        # Check if the action already exists for this menu
                        action_exists = next((act for act in permissions_dict[menu_page]['action'] if act['action'] == action), None)

                        if not action_exists:
                            permissions_dict[menu_page]['action'].append({
                                'action': action,
                                'action_name': action_name
                            })

                    # Convert the permissions_dict to a list of permissions
                    permissions = list(permissions_dict.values())

                    return Response({'role_name' : role.role_name,'permission': permissions})
                else:
                    return Response({"submit": "Role not found."}, status=status.HTTP_404_NOT_FOUND)
            else:
                return Response({"submit": "You don't have permissions to access."}, status=status.HTTP_403_FORBIDDEN)
        else:
            return Response({"submit": "Account validity has expired."}, status=status.HTTP_400_BAD_REQUEST)
        

#OTP view

class SendOTP(APIView):
    def post(self, request):
        email = request.data.get('email')
        
        if not email:
            return Response({"error": "Email is required."}, status=status.HTTP_400_BAD_REQUEST)
        
        if User.objects.filter(email=email).exists():
            # Generate a random 6-digit OTP
            print(User.objects.get(email=email).is_verified)
            if User.objects.get(email=email).is_verified == False:
                otp = ''.join([str(random.randint(0, 9)) for _ in range(6)])

                user = User.objects.filter(email=email).first()

                # Store OTP in your database
                otp_instance, created = OTP.objects.get_or_create(user=user, email=email, defaults={'otp': otp, 'otp_validity': datetime.now()})
                if not created:
                    otp_instance.otp = otp
                    otp_instance.otp_validity = datetime.now()
                    otp_instance.save()

                # Send OTP via email
                # subject = 'OTP Verification for VMS'
                # message = f'Your OTP is: {otp}'
                # from_email = 'anprsolutionsllp@gmail.com'
                # recipient_list = [email]
                
                # send_mail(subject, message, from_email, recipient_list)
                context = {'otp': otp}
                email_html = render_to_string('otp_emails.html', context)
                send_mail(
                    'OTP Verification for VMS',
                    '',
                    'anprsolutionsllp@gmail.com',
                    [email],
                    html_message=email_html,
                    fail_silently=False,
                )

                return Response({"submit": "OTP sent successfully."}, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "Your email is already verified."})
        else:
            return Response({"email": "Email not found."}, status=status.HTTP_400_BAD_REQUEST)


class VerifyOTP(APIView):

    def post(self, request):
        email = request.data.get('email')
        otp = request.data.get('otp')

        if not email or not otp:
            return Response({"submit": "Email and OTP are required."}, status=status.HTTP_400_BAD_REQUEST)
        
        user = User.objects.filter(email=email).first()

        if user:
            otp_model = OTP.objects.filter(email=email).last()
            if otp_model.otp == otp:
                # current_time = datetime.now()
                # time_difference = (current_time - otp_model.otp_validity).total_seconds() / 60
                # print("time", time_difference)
                # if time_difference > 11:
                diff = None
                try:
                    diff = datetime.strptime(str(datetime.now()), '%Y-%m-%d %H:%M:%S.%f') - datetime.strptime(str(otp_model.otp_validity), '%Y-%m-%d %H:%M:%S.%f+00:00')
                except Exception as e:
                    diff = datetime.strptime(str(datetime.now()), '%Y-%m-%d %H:%M:%S.%f') - datetime.strptime(str(otp_model.otp_validity), '%Y-%m-%d %H:%M:%S+00:00') 

                print(int(diff.total_seconds() / 60.0))
                if int(diff.total_seconds() / 60.0) <= 10:
                    otp_model.is_verified = True
                    user.is_verified = True
                    otp_model.save()
                    user.save()
                    return Response({"submit": "OTP verified successfully."}, status=status.HTTP_200_OK)
                else:
                    return Response({"submit": "OTP expired."}, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "Invalid OTP."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"submit": "This email is not registered."}, status=status.HTTP_400_BAD_REQUEST)


# DropDown
class SitesDropDownView(APIView):

    def get(self, request):
    
        company_detail_id = request.user.company_detail_id
      
        sites = Sites.objects.filter(company_detail_id=company_detail_id)
        sites_serializer = SitesListSerializer(sites, many=True)
        return Response(sites_serializer.data)
    

class SendEmailNotificationView(APIView):
    permission_classes = (IsAuthenticated,)
    
    def get(self, request, format=None):
        # Get query parameters
        limit = int(request.GET.get('limit', 10))
        offset = int(request.GET.get('offset', 0))
        
        user_detail_page = get_user_data_page(
            request.user.id, 'email', 'view')
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:

                email = SendMailNotification.objects.filter(company_detail_id = user_detail_page['company_detail']['id'])[offset:limit+offset]
                email_count = SendMailNotification.objects.filter(company_detail_id = user_detail_page['company_detail']['id']).count()
                
                # Serialize data
                serializer = SendMailNotificationSerializer(email, many=True)
                
                # Return response
                return Response({'count': email_count, 'results': serializer.data})
            
            else:
                return Response({"detail": "You don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "Account validity has expired."}, status=status.HTTP_400_BAD_REQUEST)

    def post(self, request, format=None):
        user_detail_page = get_user_data_page(request.user.id, 'email', 'create')
        

        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:   
                get_data = request.data
                get_data['company_detail_id'] = user_detail_page['company_detail']['id']
                serializer = SendMailNotificationSerializer(data=get_data)
                
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                else:
                    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                
            else:
                return Response({"detail": "You don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "Account validity has expired."}, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, uuid, format=None):
        user_detail_page = get_user_data_page(request.user.id, 'email', 'update')
        
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                
                email= SendMailNotification.objects.get(uuid=uuid) 
                get_data = request.data
                get_data['company_detail_id'] = user_detail_page['company_detail']['id']
                serializer =SendMailNotificationSerializer(email, get_data)
                
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                else:
                    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                
            else:
                return Response({"detail": "You don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "Account validity has expired."}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, uuid, format=None):
        user_detail_page = get_user_data_page(request.user.id, 'email', 'delete')
        
        
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                
                email= SendMailNotification.objects.get(uuid=uuid)
                email.delete()
                return Response(status=status.HTTP_204_NO_CONTENT)
                
            else:
                return Response({"detail": "You don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "Account validity has expired."}, status=status.HTTP_400_BAD_REQUEST)
    

class SitesWorkingNotifyAdminUser(APIView):
    def get(self, request):
        logs_to_notify = WindowsSitesActiveLog.objects.filter(
            last_active_datetime__lte=timezone.now() - timezone.timedelta(minutes=3),
            email_sent=False
        )
        for log in logs_to_notify:
            log_id = log.id
           
            get_business_email =SendMailNotification.objects.filter(company_detail_id=log.company_detail_id)
            email_list = get_business_email.values_list('email',flat=True)
            if len(email_list) > 0:
                subject = 'GunnyBag Counting Aplication:: PC Shutdown/No Internet Notification'
                get_sites_detail = WindowsSitesActiveLog.objects.filter(id=log_id).values('last_active_datetime','sites__site_name').first()
                timezones = 'Asia/Kolkata'  # Replace with your desired timezone
                # value = datetime.strptime(get_sites_detail['last_active_datetime'], '%Y-%m-%d %H:%M:%S.%f%z')
                # last_active_datetime = value.astimezone(timezones)
                last_active_datetime = timezone.now()
                last_active_datetime = last_active_datetime.astimezone(pytz.timezone(timezones)).strftime("%d-%m-%Y %I:%M %p")
                print("last active datetime:",last_active_datetime)
                html_message = render_to_string('sites_emails.html', {'site_name': get_sites_detail['sites__site_name'],
                'last_active_datetime': str(last_active_datetime),'user_timezone':timezones})
                # message = f"Local Site {get_sites_name['sites__site_name']} is Offline"

                from_email = 'anprsolutionsllp@gmail.com'

                send_mail(subject, '', from_email, email_list,html_message=html_message)
            log.active=False
            log.application_open=True
            log.email_sent = True
            log.save()
        return Response({"detail": "Updated Successfully."}, status=status.HTTP_200_OK)


class FreeTrailView(APIView):
    permission_classes = (AllowAny,)
    def get(self, request):
        products = DefaultProduct.objects.all()
        serializer = DefaultProductSerializer(products, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
    def post(self, request):        
        data = request.data
        total_price = 0.0
        days_total_price = 0.0
        discount_amount = 0.0
        total_price_after_discount = 0.0
        days_total_price_after_discount = 0.0
        total_price_after_tax = 0.0
        total_tax_in_currency = 0.0
        total_tax_percentage = 0.0  
        days_total_price_after_tax = 0.0
        if 'user_detail' not in data or 'email' not in data['user_detail']:
            return Response({'error': 'Email is required in user_detail'}, status=status.HTTP_400_BAD_REQUEST)

        email = data['user_detail']['email']

        #print(data)
        currency_detail = Currency.objects.filter(currency_type=request.data['currency_type']).values('id','currency_type','currency_symbol').first()

        # business_detail = {
        #     'business_name': request.data['business_name'],
        #     'country': request.data['country'],
        #     'uses_type': 'free trail',
        #     'currency': currency_detail['id']
        # }
        created_objects = []
        company_detail = data['company_detail']
        company_serializer = CompanyDetailSerializer(data=company_detail)
        company_id = None
        if company_serializer.is_valid():
            company_obj = company_serializer.save()
            company_id = company_obj.id
            #created_objects.append(business_obj)
            created_objects.insert(0, company_obj)
        else:
            for obj in reversed(created_objects):
                    obj.delete()
            return Response(company_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        # if business_serializer.is_valid():
        #     business_obj = business_serializer.save()
        #     business_id = business_obj.id
        # else:
        #     return Response(business_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        role_detail = {'role_name': 'Admin', 'company_detail_id': company_id}
        role_serializer = RolesSerializer(data=role_detail)
        if role_serializer.is_valid():
            role_obj = role_serializer.save()
            role_id = role_obj.id
            #created_objects.append(role_obj)
            created_objects.insert(1, role_obj)
        else:
            # for obj in created_objects:
            #     obj.delete()
            #created_objects[0].delete()
            for obj in reversed(created_objects):
                    obj.delete()
            return Response(role_serializer.errors, status=status.HTTP_400_BAD_REQUEST)


        # role_detail = {'role_name': 'Admin', 'business_detail_id': business_id}

        # role_serializer = RolesSerializer(data=role_detail)
        # role_id = None
        # if role_serializer.is_valid():
        #     role_obj = role_serializer.save()
        #     role_id = role_obj.id
        # else:
        #     BusinessDetail.objects.filter(id=business_id).delete()
        #     return Response(role_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        permission_ids = []
        get_menu_data = MenuPage.objects.exclude(is_menu_type__is_menu_visible='SuperAdmin').all().values('id', 'menu_name')
        for menu in get_menu_data:
            #get_menu_action_data = MenuActionMap.objects.filter(menu_page=menu['id']).values('id', 'menu_page', 'action').all()
            get_menu_action_data = MenuActionMap.objects.filter(menu_page=menu['id'], plan_id=1).values('id', 'menu_page', 'action').all()

            for menu_action in get_menu_action_data:
                # permission_serializer = PermissionSerializer(data={'role': role_id, 'menu_page': menu_action['menu_page'], 'action': menu_action['action']})
                # if permission_serializer.is_valid():
                #     permission_obj = permission_serializer.save()
                #     permission_ids.append(permission_obj.id)
                # else:
                #     BusinessDetail.objects.filter(id=business_id).delete()
                #     Roles.objects.filter(id=role_id).delete()
                #     AddUserEmail.objects.filter(id=add_user_email_id).delete()
                #     for permission_id in permission_ids:
                #         Permission.objects.filter(id=permission_id).delete()
                #     return Response(permission_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

                permission_serializer = PermissionSerializer(data={'role': role_id, 'menu_page': menu_action['menu_page'], 'action': menu_action['action']})
                if permission_serializer.is_valid():
                    permission_obj = permission_serializer.save()
                    permission_ids.append(permission_obj.id)
                    #created_objects.append(permission_obj)
                    created_objects.insert(2, permission_obj)
                else:
                    # for obj in created_objects:
                    #     obj.delete()
                    # role_obj.delete()
                    # business_obj.delete()
                    for obj in reversed(created_objects):
                        obj.delete()
                    return Response(permission_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        
        # add_user_email_serializer = AddUserEmailSerializer(data={'email': data['user_detail']['email'], 'role': role_id, 'business_detail_id': business_id})
        # add_user_email_id = None
        # if add_user_email_serializer.is_valid():
        #     add_user_email_obj = add_user_email_serializer.save()
        #     add_user_email_id = add_user_email_obj.id
        # else:
        #     for permission_id in permission_ids:
        #         Permission.objects.filter(id=permission_id).delete()
        #     Roles.objects.filter(id=role_id).delete()
        #     BusinessDetail.objects.filter(id=business_id).delete()
        #     return Response(add_user_email_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        add_user_email_serializer = AddUserEmailSerializer(data={'email': data['user_detail']['email'], 'role': role_id, 'company_detail_id': company_id})
        add_user_email_id = None
        if add_user_email_serializer.is_valid():
            add_user_email_obj = add_user_email_serializer.save()
            add_user_email_id = add_user_email_obj.id
            #created_objects.append(add_user_email_obj)
            created_objects.insert(3, add_user_email_obj)
        else:
            # for obj in created_objects:
            #     obj.delete()
            # for obj in created_objects[:3]:
            #     obj.delete()
            for obj in reversed(created_objects):
                    obj.delete()
            return Response(add_user_email_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        # add_user_emails = AddUserEmail.objects.filter(email=request.data['email']).values('email','role','business_detail_id').first()
        # if add_user_emails != None:
        #     business_detail_id = add_user_emails.get('business_detail_id')
        get_company_detail = CompanyDetail.objects.filter(id=company_id).first() 
        
        print("Request data:", data)
        user_data = {
            'email': email,
            'phone_number': data['user_detail'].get('phone_number', None),
            'password': data['user_detail'].get('password', None),
            'password2': data['user_detail'].get('password2', None),
            'company_detail_id': company_id,
            'user_login_or_not': False,
            'is_superuser': False,
            'is_active': False
        }
        print("User data:", user_data)

        serializer = UserSerializer(data=user_data)

        #serializer = UserSerializer(data={'email':request.data['email'],'phone_number':request.data['phone_number'],'password':request.data['password'],'password2':request.data['password2'],'business_detail_id': business_id,'user_login_or_not':False,'is_superuser':False,'is_active':False})
        #user_id = None
        # if serializer.is_valid():
        #     obj = serializer.save()
        #     user_id = obj.id
        # else:
        #     print("Serializer errors:", serializer.errors)
        #     AddUserEmail.objects.filter(id=add_user_email_id).delete()
        #     for permission_id in permission_ids:
        #         Permission.objects.filter(id=permission_id).delete()
        #     Roles.objects.filter(id=role_id).delete()
        #     BusinessDetail.objects.filter(id=business_id).delete()
        #     return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        if serializer.is_valid():
            obj = serializer.save()
            user_id = obj.id
            #created_objects.append(obj)
            created_objects.insert(4, obj)
        else:
            # for obj in created_objects:
            #     obj.delete()
            # for obj in created_objects[:4]:
            #     obj.delete()
            for obj in reversed(created_objects):
                     obj.delete()
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        user_role_map_serializer = UserRoleMappingSerializer(data={'user':user_id,'role':role_id,'company_detail_id': company_id})
        user_role_map_id = None
        # if user_role_map_serializer.is_valid():
        #     obj = user_role_map_serializer.save()
        #     user_role_map_id = obj.id
        # else:
        #     User.objects.filter(id=user_id).delete()
        #     AddUserEmail.objects.filter(id=add_user_email_id).delete()
        #     for permission_id in permission_ids:
        #         Permission.objects.filter(id=permission_id).delete()
        #     Roles.objects.filter(id=role_id).delete()
        #     BusinessDetail.objects.filter(id=business_id).delete()
        #     #return Response(user_role_map_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        #     return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        if user_role_map_serializer.is_valid():
            obj = user_role_map_serializer.save()
            #created_objects.append(obj)
            user_role_map_id = obj.id
            created_objects.insert(5, obj)
        else:
            # for obj in created_objects:
            #     obj.delete()
            # for obj in created_objects[:5]:
            #     obj.delete()
            for obj in reversed(created_objects):
                    obj.delete()
            return Response(user_role_map_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        plans_detail = data['plans_detail']
        # product_names = ['Gate Site', 'Train Site', 'In and Out Object Site', 'Occupancy management site']
        max_allowed_products = 2

        selected_products = [product for product in plans_detail['plan_product'] if product['selected']]
        if len(selected_products) > max_allowed_products:
            raise ValueError("You can select a maximum of 2 products at a time.")
        elif len(selected_products) < max_allowed_products:
            raise ValueError("You must select exactly 2 products.")
        
        valid_products = []
        for product in selected_products:
            product_id = product['product_id']
            product_name = product['product_name']

            product_exists = DefaultProduct.objects.filter(id=product_id, product_name=product_name).exists()
            if not product_exists:
                raise ValueError(f"Product '{product_name}' with ID '{product_id}' does not exist in the database.")
            valid_products.append(product)
        plans_data = []
        for product_data in valid_products:

            product_name = product_data['product_name']
            product_id = product_data['product_id']

            get_plan = Plans.objects.filter(id=plans_detail['id'],plan_name='free trail').first()
            print("get_plan",get_plan)
            if get_plan != None:
                id = get_plan.id
                plan_name = get_plan.plan_name
                get_plan_days_and_discount = PlanDaysAndDiscount.objects.filter(plan_id=id,default_select=True).first()

                if get_plan_days_and_discount != None:
                    plans_data= []
                    plan_days = get_plan_days_and_discount.plan_days
                    parking_product_data = PlanFeaturePricingTier.objects.filter(plan_id=id,pricing_feature_category_id__category_name="Product",default_product_id__product_name= product_name).values('id','uuid','default_product_id','default_product_id__product_name','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                    all_product_total_price = 0.0
                    if parking_product_data != None:

                        plan_features_pricing_tier_camera = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Camera').values('id','uuid','min_quantity','max_quantity','default_quantity','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                        camera_quantity = 1
                        if plan_features_pricing_tier_camera != None:
                            camera_quantity = plan_features_pricing_tier_camera['default_quantity']
                        
                        product_data_json = {}
                        # product_data_json['id'] = parking_product_data['id']
                        # product_data_json['product_name'] = 'Parking Management'

                        product_selected_exist = True
                        default_product_price = 0.0
                        default_product_price_days = 0.0
                        plans_data.append({
                            'price':default_product_price,
                            'days_price':default_product_price_days,
                            'currency_id':currency_detail['id'],
                            'default_product_id':parking_product_data['default_product_id'],
                            'plan_feature_pricing_category_id':parking_product_data['pricing_feature_category_id'],
                            'category_name':parking_product_data['pricing_feature_category_id__category_name'],
                            'plan_id':id,
                            'plan_feature_pricing_tier_id':parking_product_data['id'],
                            'company_detail_id':company_id,
                            'plan_pricing_description':parking_product_data['plan_pricing_description']
                        })
                        
                        default_parking_product_feature_data = PlanFeaturePricingTier.objects.filter(plan_id=id,pricing_feature_category_id__category_name="Feature",default_product_id__product_name=product_name,is_encluded_plan_feature_id__isnull=False,default_product_feature_id__isnull=False).values('id','uuid','default_product_id','default_product_id__product_name','default_product_feature_id','default_product_feature_id__feature','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').all()
                        product_data_json['plan_product_feature_default'] = []
                        for default_product_feature in default_parking_product_feature_data:
                            plans_data.append({
                                'price':0.0,
                                'days_price':0.0,
                                'currency_id':currency_detail['id'],
                                'default_product_id':parking_product_data['default_product_id'],
                                'default_product_feature_id':default_product_feature['default_product_feature_id'],
                                'plan_feature_pricing_category_id':default_product_feature['pricing_feature_category_id'],
                                'category_name':default_product_feature['pricing_feature_category_id__category_name'],
                                'plan_id':id,
                                'plan_feature_pricing_tier_id':default_product_feature['id'],
                                'company_detail_id':company_id,
                                'plan_pricing_description':default_product_feature['plan_pricing_description']
                            })
                            
                        parking_product_feature_data = PlanFeaturePricingTier.objects.filter(plan_id=id,pricing_feature_category_id__category_name="Feature",default_product_id__product_name=product_name,is_encluded_plan_feature_id__isnull=True,default_product_feature_id__isnull=False).values('id','uuid','default_product_id','default_product_id__product_name','default_product_feature_id','default_product_feature_id__feature','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').all()
                        product_data_json['plan_product_feature'] = []
                        default_product_feature_price = 0.0
                        for product_feature in parking_product_feature_data:
                            plan_feature_days_price_product_feature = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=product_feature['id'],currency_id=currency_detail['id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                            # if plan_feature_days_price_product_feature['default_selected'] == True:
                               
                            for backup in plan_feature_days_price_product_feature:
                                # Check if the default is selected
                                if backup['default_selected']:
                                    product_feature_price = 0.0
                                    product_feature_price_days = 0.0
                                    plans_data.append({
                                        'price':0.0,
                                        'days_price':0.0,
                                        'currency_id':currency_detail['id'],
                                        'default_product_id':parking_product_data['default_product_id'],
                                        'default_product_feature_id':product_feature['default_product_feature_id'],
                                        'plan_feature_pricing_category_id':product_feature['pricing_feature_category_id'],
                                        'category_name':product_feature['pricing_feature_category_id__category_name'],
                                        'plan_id':id,
                                        'plan_feature_pricing_tier_id':product_feature['id'],
                                        'company_detail_id':company_id,
                                        'plan_pricing_description':product_feature['plan_pricing_description']
                                    })
                                

                        plan_feature_days_price_camera = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_camera['id'],currency_id=currency_detail['id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol').first()
                        camera_price = plan_days * camera_quantity * plan_feature_days_price_camera['days_price']
                        camera_price_days = camera_quantity * plan_feature_days_price_camera['days_price']
                        plans_data.append({
                            'quantity':camera_quantity,
                            'price':camera_price,
                            'days_price':camera_price_days,
                            'currency_id':currency_detail['id'],
                            'default_product_id':parking_product_data['default_product_id'],
                            'plan_feature_pricing_category_id':plan_features_pricing_tier_camera['pricing_feature_category_id'],
                            'category_name':plan_features_pricing_tier_camera['pricing_feature_category_id__category_name'],
                            'plan_id':id,
                            'plan_feature_pricing_tier_id':plan_features_pricing_tier_camera['id'],
                            'company_detail_id':company_id,
                            'plan_pricing_description':plan_features_pricing_tier_camera['plan_pricing_description']
                        })
                        # plan_features_pricing_tier_parking_slot = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Parking Slot').values('id','uuid','min_quantity','max_quantity','default_quantity','default_product_id','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                        # parking_slot = 1
                        # if plan_features_pricing_tier_parking_slot != None:
                        #     parking_slot = plan_features_pricing_tier_parking_slot['default_quantity']
                        # default_parking_slot_price = 0.0
                        # praking_slot_days_price = 0.0
                        # plans_data.append({
                        #     'quantity':parking_slot,
                        #     'price':default_parking_slot_price,
                        #     'days_price':praking_slot_days_price,
                        #     'currency_id':currency_detail['id'],
                        #     'default_product_id':parking_product_data['default_product_id'],
                        #     'plan_feature_pricing_category_id':plan_features_pricing_tier_parking_slot['pricing_feature_category_id'],
                        #     'category_name':plan_features_pricing_tier_parking_slot['pricing_feature_category_id__category_name'],
                        #     'plan_id':id,
                        #     'plan_feature_pricing_tier_id':plan_features_pricing_tier_parking_slot['id'],
                        #     'business_detail_id':business_id,
                        #     'plan_pricing_description':plan_features_pricing_tier_parking_slot['plan_pricing_description']
                        # })
                        
                        plan_features_pricing_tier_online_dashboard = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Online Dashboard').values('id','uuid','default_product_id','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                        online_dashboard_price = 0.0
                        days_online_dashboard_price = 0.0
                        plans_data.append({
                            'quantity':camera_quantity,
                            'price':online_dashboard_price,
                            'days_price':days_online_dashboard_price,
                            'currency_id':currency_detail['id'],
                            'default_product_id':parking_product_data['default_product_id'],
                            'plan_feature_pricing_category_id':plan_features_pricing_tier_online_dashboard['pricing_feature_category_id'],
                            'category_name':plan_features_pricing_tier_online_dashboard['pricing_feature_category_id__category_name'],
                            'plan_id':id,
                            'plan_feature_pricing_tier_id':plan_features_pricing_tier_online_dashboard['id'],
                            'company_detail_id':company_id,
                            'plan_pricing_description':plan_features_pricing_tier_online_dashboard['plan_pricing_description']
                        })

                        plan_features_pricing_tier_online_dashboard_data_backup = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Online Data Backup').values('id','uuid','default_product_id','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                        plan_feature_days_price_online_dashboard_data_backup = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard['id'],currency_id=currency_detail['id'],default_selected=True).values('id','uuid','backup_days_id','backup_days_id__days','backup_days_id__category','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').first()
                        online_data_backup_price = 0.0
                        days_online_data_backup_price = 0.0
                        plans_data.append({
                            'backup_days_id':plan_feature_days_price_online_dashboard_data_backup['backup_days_id'],
                            'backup_days':plan_feature_days_price_online_dashboard_data_backup['backup_days_id__days'],
                            'quantity':camera_quantity,
                            'price':online_data_backup_price,
                            'days_price':days_online_data_backup_price,
                            'currency_id':currency_detail['id'],
                            'default_product_id':parking_product_data['default_product_id'],
                            'plan_feature_pricing_category_id':plan_features_pricing_tier_online_dashboard_data_backup['pricing_feature_category_id'],
                            'category_name':plan_features_pricing_tier_online_dashboard_data_backup['pricing_feature_category_id__category_name'],
                            'plan_id':id,
                            'plan_feature_pricing_tier_id':plan_features_pricing_tier_online_dashboard_data_backup['id'],
                            'company_detail_id':company_id,
                            'plan_pricing_description':plan_features_pricing_tier_online_dashboard_data_backup['plan_pricing_description']
                        })

                        plan_features_pricing_tier_offline_dashboard = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Offline Dashboard').values('id','uuid','default_product_id','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                        offline_dashboard_price = 0.0
                        days_offline_dashboard_price = 0.0
                        plans_data.append({
                            'quantity':camera_quantity,
                            'price':offline_dashboard_price,
                            'days_price':days_offline_dashboard_price,
                            'currency_id':currency_detail['id'],
                            'default_product_id':parking_product_data['default_product_id'],
                            'plan_feature_pricing_category_id':plan_features_pricing_tier_offline_dashboard['pricing_feature_category_id'],
                            'category_name':plan_features_pricing_tier_offline_dashboard['pricing_feature_category_id__category_name'],
                            'plan_id':id,
                            'plan_feature_pricing_tier_id':plan_features_pricing_tier_offline_dashboard['id'],
                            'company_detail_id':company_id,
                            'plan_pricing_description':plan_features_pricing_tier_offline_dashboard['plan_pricing_description']
                        })

                        plan_features_pricing_tier_offline_dashboard_data_backup = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Offline Data Backup').values('id','uuid','default_product_id','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                        plan_feature_days_price_offline_dashboard_data_backup = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_offline_dashboard['id'],currency_id=currency_detail['id'],default_selected=True).values('id','uuid','backup_days_id','backup_days_id__days','backup_days_id__category','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').first()
                        offline_data_backup_price = 0.0
                        days_offline_data_backup_price = 0.0
                        plans_data.append({
                            'backup_days_id':plan_feature_days_price_offline_dashboard_data_backup['backup_days_id'],
                            'backup_days':plan_feature_days_price_offline_dashboard_data_backup['backup_days_id__days'],
                            'quantity':camera_quantity,
                            'price':offline_data_backup_price,
                            'days_price':days_offline_data_backup_price,
                            'currency_id':currency_detail['id'],
                            'default_product_id':parking_product_data['default_product_id'],
                            'plan_feature_pricing_category_id':plan_features_pricing_tier_offline_dashboard_data_backup['pricing_feature_category_id'],
                            'category_name':plan_features_pricing_tier_offline_dashboard_data_backup['pricing_feature_category_id__category_name'],
                            'plan_id':id,
                            'plan_feature_pricing_tier_id':plan_features_pricing_tier_offline_dashboard_data_backup['id'],
                            'company_detail_id':company_id,
                            'plan_pricing_description':plan_features_pricing_tier_offline_dashboard_data_backup['plan_pricing_description']
                        })
                        
                    plan_start_datetime = timezone.datetime.now()
                    plan_expire_datetime = timezone.datetime.now() + timedelta(days=get_plan_days_and_discount.plan_days)
                    time_diff = plan_expire_datetime - plan_start_datetime
                    total_minutes = int(time_diff.total_seconds()/60)
                    total_days = time_diff.days

                    #get_plan_pricing = PlanPricing.objects.filter(plan_id=get_plan.id,currency_id=currency_detail['id']).values('id','country_type_id','country_type_id__country')
                    get_plan_pricing = PlanPricing.objects.filter(plan_id=get_plan.id, currency_id=currency_detail['id']).first()

                
                    business_plan_history = {
                        'plan_name':get_plan.plan_name,
                        'price':total_price,
                        'price_after_discount':total_price_after_discount,
                        'price_after_tax':total_price_after_tax,
                        'days_price':days_total_price,
                        'days_price_after_discount': days_total_price_after_discount,
                        'days_price_after_tax': days_total_price_after_tax,
                        'currency_id':currency_detail['id'],
                        'currency_type':currency_detail['currency_type'],
                        'currency_symbol':currency_detail['currency_symbol'],
                        'country_category_id':get_plan_pricing.country_type_id.id,
                        'country_type':get_plan_pricing.country_type_id.country,
                        'plan_id':get_plan.id,
                        'plan_days_and_discount_id':get_plan_days_and_discount.id,
                        'plan_days':get_plan_days_and_discount.plan_days,
                        'discount_in_percentage':get_plan_days_and_discount.discount_percentage,
                        'discount_in_currency': discount_amount,
                        'total_discount': total_price_after_discount,
                        'total_tax_in_percentage':total_tax_percentage,
                        'total_tax_in_currency':total_tax_in_currency,
                        'buy_datetime':timezone.datetime.now(),
                        'plan_start_datetime':timezone.datetime.now(),
                        #'plan_expire_datetime': datetime.datetime.now()+get_plan_days_and_discount.plan_days,
                        'plan_expire_datetime': timezone.datetime.now() + timedelta(days=get_plan_days_and_discount.plan_days),
                        'minutes_to_expire':total_minutes,
                        'days_to_expire':total_days,
                        'plan_validity':True,
                        'plan_status':'active',
                        'current_active':True,
                        'plan_type':'Free Trail',
                        'company_detail_id':company_id,
                        'payment_status': True
                    }
                    # if get_plan_pricing:
                    #     business_plan_history['country_category_id'] = get_plan_pricing.country_type_id
                    #     business_plan_history['country_type'] = get_plan_pricing.country_type_id__country
                    business_plan_history_serializer = BusinessPlanHistorySerializer(data=business_plan_history)
                    business_plan_history_id = None
                    if business_plan_history_serializer.is_valid():
                        business_plan_history_obj = business_plan_history_serializer.save()
                        business_plan_history_id = business_plan_history_obj.id
                    else:
                        for obj in reversed(created_objects):
                                    obj.delete()
                        UserRoleMapping.objects.filter(id=user_role_map_id).delete()
                        User.objects.filter(id=user_id).delete()
                        AddUserEmail.objects.filter(id=add_user_email_id).delete()
                        for permission_id in permission_ids:
                            Permission.objects.filter(id=permission_id).delete()
                        Roles.objects.filter(id=role_id).delete()
                        CompanyDetail.objects.filter(id=company_id).delete()
                        return Response(business_plan_history_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                    business_pricing_tier_ids = []
                    for plans in plans_data:
                        plans['business_plan_history_id'] = business_plan_history_id
                        business_pricing_tier_serializer = BusinessPricingTierSerializer(data=plans)
                        business_pricing_tier_id = None
                        if business_pricing_tier_serializer.is_valid():
                            business_pricing_tier_obj = business_pricing_tier_serializer.save()
                            business_pricing_tier_id = business_pricing_tier_obj.id
                            business_pricing_tier_ids.append(business_pricing_tier_id)
                        else:
                            for obj in reversed(created_objects):
                                    obj.delete()
                            for business_pricing_id in business_pricing_tier_ids:
                                BusinessPricingTier.objects.filter(id=business_pricing_id).delete()
                            BusinessPlanHistory.objects.filter(id=business_plan_history_id).delete()
                            UserRoleMapping.objects.filter(id=user_role_map_id)
                            User.objects.filter(id=user_id).delete()
                            AddUserEmail.objects.filter(id=add_user_email_id).delete()
                            for permission_id in permission_ids:
                                Permission.objects.filter(id=permission_id).delete()
                            Roles.objects.filter(id=role_id).delete()
                            CompanyDetail.objects.filter(id=company_id).delete()
                            return Response(business_pricing_tier_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                    return Response({"detail": "Plans processed successfully."}, status=status.HTTP_201_CREATED)

                
                else:
                    for obj in reversed(created_objects):
                                    obj.delete()
                    return Response({"detail": "Plans days doesn't exist."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                for obj in reversed(created_objects):
                                    obj.delete()
                return Response({"detail": "Plans not exist."}, status=status.HTTP_400_BAD_REQUEST)
            
class BuyPlanView(APIView):
    permission_classes = (AllowAny,)
    #template_name = 'autopay.html'

    # def get(self, request, *args, **kwargs):
    #     return render(request, self.template_name)
    def post(self, request):
        all_product_total_price = 0.0
        default_product_price = 0.0
        default_product_price_days=0.0
        total_price_after_discount = 0.0        
        total_price = 0.0
        default_product_feature_price = 0.0
        total_tax_in_currency = 0.0
        total_tax_percentage = 0.0
        days_total_price=0.0
        discount_amount=0.0
        data = request.data
        # currency_type = request.data.get('currency_type')
        # currency_detail = Currency.objects.filter(currency_type=currency_type).values('id', 'currency_type', 'currency_symbol').first()
        currency_detail = Currency.objects.filter(currency_type=request.data['currency_type']).values('id','currency_type','currency_symbol').first()
        
        company_detail = data['company_detail']
        created_objects = []

        
            # Business Serializer
        company_serializer = CompanyDetailSerializer(data=company_detail)
        if company_serializer.is_valid():
            company_obj = company_serializer.save()
            company_id = company_obj.id
            #created_objects.append(business_obj)
            created_objects.insert(0, company_obj)
        else:
            for obj in reversed(created_objects):
                    obj.delete()
            return Response(company_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        # Role Serializer
        role_detail = {'role_name': 'Admin', 'company_detail_id': company_id}
        role_serializer = RolesSerializer(data=role_detail)
        if role_serializer.is_valid():
            role_obj = role_serializer.save()
            role_id = role_obj.id
            #created_objects.append(role_obj)
            created_objects.insert(1, role_obj)
        else:
            # for obj in created_objects:
            #     obj.delete()
            #created_objects[0].delete()
            for obj in reversed(created_objects):
                    obj.delete()
            return Response(role_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        # Permission Serializer
        permission_ids = []
        
        get_menu_data = MenuPage.objects.exclude(is_menu_type__is_menu_visible='SuperAdmin').all().values('id', 'menu_name')
        for menu in get_menu_data:
            #get_menu_action_data = MenuActionMap.objects.filter(menu_page=menu['id']).values('id', 'menu_page', 'action').all()
            get_menu_action_data = MenuActionMap.objects.filter(menu_page=menu['id']).values('id', 'menu_page', 'action').all()

            for menu_action in get_menu_action_data:
                permission_serializer = PermissionSerializer(data={'role': role_id, 'menu_page': menu_action['menu_page'], 'action': menu_action['action']})
                if permission_serializer.is_valid():
                    permission_obj = permission_serializer.save()
                    permission_ids.append(permission_obj.id)
                    #created_objects.append(permission_obj)
                    created_objects.insert(2, permission_obj)
                else:
                    # for obj in created_objects:
                    #     obj.delete()
                    # role_obj.delete()
                    # business_obj.delete()
                    for obj in reversed(created_objects):
                        obj.delete()
                    return Response(permission_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        # Add User Email Serializer
        add_user_email_serializer = AddUserEmailSerializer(data={'email': data['user_detail']['email'], 'role': role_id, 'company_detail_id': company_id})
        if add_user_email_serializer.is_valid():
            add_user_email_obj = add_user_email_serializer.save()
            add_user_email_id = add_user_email_obj.id
            #created_objects.append(add_user_email_obj)
            created_objects.insert(3, add_user_email_obj)
        else:
            # for obj in created_objects:
            #     obj.delete()
            # for obj in created_objects[:3]:
            #     obj.delete()
            for obj in reversed(created_objects):
                    obj.delete()
            return Response(add_user_email_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        # User Serializer
        serializer = UserSerializer(data={
            'email': request.data['user_detail']['email'],
            'phone_number': request.data['user_detail']['phone_number'],
            'password': request.data['user_detail']['password'],
            'password2': request.data['user_detail']['password2'],
            'company_detail_id': company_id,
            'user_login_or_not': False,
            'is_superuser': False,
            'is_active': False
        })
        if serializer.is_valid():
            obj = serializer.save()
            user_id = obj.id
            #created_objects.append(obj)
            created_objects.insert(4, obj)
        else:
            # for obj in created_objects:
            #     obj.delete()
            # for obj in created_objects[:4]:
            #     obj.delete()
            for obj in reversed(created_objects):
                     obj.delete()
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        # UserRoleMapping Serializer
        user_role_map_serializer = UserRoleMappingSerializer(data={'user':user_id,'role':role_id,'company_detail_id': company_id})
        if user_role_map_serializer.is_valid():
            obj = user_role_map_serializer.save()
            #created_objects.append(obj)
            user_role_map_id = obj.id
            created_objects.insert(5, obj)
        else:
            # for obj in created_objects:
            #     obj.delete()
            # for obj in created_objects[:5]:
            #     obj.delete()
            for obj in reversed(created_objects):
                    obj.delete()
            return Response(user_role_map_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        plans_detail = data['plans_detail']
        # selected_products = [product for product in plans_detail['plan_product'] if product['selected']]
        # selected_products = plans_detail['products']
        selected_products = plans_detail['plan_product']
        valid_products = []
        for product in selected_products:
            product_id = product['product_id']
            product_name = product['product_name']
            print("product_names",product_name)
            product_exists = DefaultProduct.objects.filter(id=product_id, product_name=product_name).exists()
            if not product_exists:
                for obj in reversed(created_objects):
                    obj.delete()
                return Response({'error': f"Product '{product_name}' with ID '{product_id}' does not exist in the database."}, status=status.HTTP_400_BAD_REQUEST)
            valid_products.append(product)
            print("valid product:",valid_products)

        products = ['Gate Site', 'Train Site', 'In and Out Object Site', 'Occupancy management site']
        plans_data = []

        for product_name in products:
            product_data = next((product for product in valid_products if product['product_name'] == product_name), None)
            print("product_data",product_data)
            if product_data is None:
                continue

            # product_exists = DefaultProduct.objects.filter(id=product_id, product_name=product_name).exists()
            # if not product_exists:
            #     raise ValueError(f"Product '{product_name}' with ID '{product_id}' does not exist in the database.")
            # valid_products.append(product)
        # plans_data = []
        # for product_data in valid_products:
            # product_name = product_data['product_name']
            get_plan = Plans.objects.filter(id=plans_detail['id'],plan_name=plans_detail['plan_name']).first()
            if get_plan != None:
                id = get_plan.id
                plan_name = get_plan.plan_name
                #get_plan_days_and_discount = PlanDaysAndDiscount.objects.filter(plan_id=id,id=plans_detail['plan_days_id'],default_select=True).first()
                get_plan_days_and_discount = PlanDaysAndDiscount.objects.filter(plan_id=id,default_select=True).first()

                if get_plan_days_and_discount != None:
                    plans_data= []
                    plan_days = get_plan_days_and_discount.plan_days
                    parking_product_data = PlanFeaturePricingTier.objects.filter(
                            plan_id=id,
                            pricing_feature_category_id__category_name="Product",
                            default_product_id__product_name=product_name,
                            id=data['plans_detail']['plan_product'][0]['plan_feature_pricing_tier_id'],
                            show_plan_pricing=True
                        ).values('id', 'uuid', 'default_product_id', 'default_product_id__product_name', 'pricing_feature_category_id', 'pricing_feature_category_id__category_name', 'plan_id', 'plan_pricing_description', 'show_plan_pricing').first()
                    if parking_product_data != None:
                        #plan_features_pricing_tier_camera = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data.default_product_id,pricing_feature_category_id__category_name='Camera').values('id','uuid','min_quantity','max_quantity','default_quantity','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                        plan_features_pricing_tier_camera = PlanFeaturePricingTier.objects.filter(
                            plan_id=id,
                            default_product_id=parking_product_data['default_product_id'],
                            pricing_feature_category_id__category_name='Camera'
                        ).first()
                        #print(plan_features_pricing_tier_camera)
                        # if parking_product_data is not None:
                        #     print(parking_product_data['default_product_id'])
                        # else:
                        #     print("No matching record found.")
                        product_data = plans_detail['plan_product'][0]
                        #product_data = data['plans_detail']['plan_product'][0]
                        
                        camera_quantity = product_data['plan_camera_detail']['camera_quantity']

                        parking_product_data = PlanFeaturePricingTier.objects.filter(plan_id=id,pricing_feature_category_id__category_name="Product",default_product_id__product_name=product_name,id=data['plans_detail']['plan_product'][0]['plan_feature_pricing_tier_id'],show_plan_pricing=True).values('id','uuid','default_product_id','default_product_id__product_name','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                        print("parking product data:", parking_product_data)
                        #all_product_total_price = 0.0
                        if parking_product_data != None:
                            #print(data)
                            plan_feature_days_price_product = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=parking_product_data['id'],currency_id=currency_detail['id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                            plan_feature_days_price_product_instance = plan_feature_days_price_product.first()

                            if plan_feature_days_price_product_instance:
                                default_product_price = plan_days * camera_quantity * plan_feature_days_price_product_instance['days_price']
                                default_product_price_days = camera_quantity * plan_feature_days_price_product_instance['days_price']
                            else:
                                #print("error in defaultproductprice")
                                default_product_price = 0 
                                default_product_price_days = 0
                            product_selected_exist = True
                        # default_product_price = plan_days * camera_quantity * plan_feature_days_price_product['days_price']
                            #default_product_price_days = camera_quantity * plan_feature_days_price_product['days_price']
                            #default_product_price_days = camera_quantity * plan_feature_days_price_product_instance.days_price
                            print("Value of plan_feature_pricing_category_id1:",
                                parking_product_data['pricing_feature_category_id'])

                            plans_data.append({
                                'price':default_product_price,
                                'days_price':default_product_price_days,
                                'currency_id':currency_detail['id'],
                                'default_product_id':parking_product_data['default_product_id'],
                                'plan_feature_pricing_category_id':parking_product_data['pricing_feature_category_id'],
                                'category_name':parking_product_data['pricing_feature_category_id__category_name'],
                                'plan_id':id,
                                'plan_feature_pricing_tier_id':parking_product_data['id'],
                                'company_detail_id':company_id,
                                'plan_pricing_description':parking_product_data['plan_pricing_description']
                            })
                            default_parking_product_feature_data = PlanFeaturePricingTier.objects.filter(plan_id=id,pricing_feature_category_id__category_name="Feature",default_product_id__product_name=product_name,is_encluded_plan_feature_id__isnull=False,default_product_feature_id__isnull=False).values('id','uuid','default_product_id','default_product_id__product_name','default_product_feature_id','default_product_feature_id__feature','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').all()

                            for default_product_feature in default_parking_product_feature_data:
                                print("Value of plan_feature_pricing_category_id2:",
                                    default_product_feature['pricing_feature_category_id'])
                                plans_data.append({
                                    'price':0.0,
                                    'days_price':0.0,
                                    'currency_id':currency_detail['id'],
                                    'default_product_id':parking_product_data['default_product_id'],
                                    'default_product_feature_id':default_product_feature['default_product_feature_id'],
                                    'plan_feature_pricing_category_id':default_product_feature['pricing_feature_category_id'],
                                    'category_name':default_product_feature['pricing_feature_category_id__category_name'],
                                    'plan_id':id,
                                    'plan_feature_pricing_tier_id':default_product_feature['id'],
                                    'company_detail_id':company_id,
                                    'plan_pricing_description':default_product_feature['plan_pricing_description']
                                })

                            parking_product_feature_data = PlanFeaturePricingTier.objects.filter(plan_id=id,pricing_feature_category_id__category_name="Feature",default_product_id__product_name=product_name,is_encluded_plan_feature_id__isnull=True,default_product_feature_id__isnull=False).values('id','uuid','default_product_id','default_product_id__product_name','default_product_feature_id','default_product_feature_id__feature','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').all()
                        
                            for product_feature in parking_product_feature_data:
                                plan_feature_days_price_product_feature = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=product_feature['id'],currency_id=currency_detail['id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                                plan_feature_days_price_product_feature_instance = plan_feature_days_price_product_feature.first()  
                                if plan_feature_days_price_product_feature_instance:
                                    product_feature_price = plan_days * camera_quantity * plan_feature_days_price_product_feature_instance['days_price']
                                    product_feature_price_days = camera_quantity * plan_feature_days_price_product_feature_instance['days_price']
                                else:
                                    
                                    product_feature_price = 0  
                                # product_feature_price = plan_days * camera_quantity * plan_feature_days_price_product_feature_instance['days_price']
                                # product_feature_price_days = camera_quantity * plan_feature_days_price_product_feature_instance['days_price']
                                default_selected = False
                                feature_plan_selected = [feature_plan for feature_plan in product_data['plan_feature_detail'] if feature_plan['plan_feature_pricing_tier_id']==product_feature['id'] and feature_plan['selected']==True]
                                if len(feature_plan_selected) > 0:

                                    default_selected = True
                                    default_product_feature_price += product_feature_price
                                    print("Value of plan_feature_pricing_category_id3:",
                                    product_feature['pricing_feature_category_id'])
                                    plans_data.append({
                                        'price':product_feature_price,
                                        'days_price':product_feature_price_days,
                                        'currency_id':currency_detail['id'],
                                        'default_product_id':parking_product_data['default_product_id'],
                                        'default_product_feature_id':product_feature['default_product_feature_id'],
                                        'plan_feature_pricing_category_id':product_feature['pricing_feature_category_id'],
                                        'category_name':product_feature['pricing_feature_category_id__category_name'],
                                        'plan_id':id,
                                        'plan_feature_pricing_tier_id':product_feature['id'],
                                        'company_detail_id':company_id,
                                        'plan_pricing_description':product_feature['plan_pricing_description']
                                    })
                            


                            plan_feature_days_price_camera = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_camera.id,currency_id=currency_detail['id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol').first()
                            #print("plan_feature_days_price_camera:", plan_feature_days_price_camera)  

                            # print("get_plan_days_and_discount.id:", get_plan_days_and_discount.id)
                            # print("plan_features_pricing_tier_camera.id:", plan_features_pricing_tier_camera.id)
                        

                            camera_price = plan_days * camera_quantity * plan_feature_days_price_camera['days_price']
                            camera_price_days = camera_quantity * plan_feature_days_price_camera['days_price']
                            print("Value of plan_feature_pricing_category_id4:",
                                    plan_features_pricing_tier_camera.pricing_feature_category_id)
                            plans_data.append({
                                'quantity':camera_quantity,
                                'price':camera_price,
                                'days_price':camera_price_days,
                                'currency_id':currency_detail['id'],
                                'plan_feature_pricing_category_id':plan_features_pricing_tier_camera.pricing_feature_category_id.pk,
                                'category_name':plan_features_pricing_tier_camera.pricing_feature_category_id.category_name,
                                'plan_id':id,
                                'plan_feature_pricing_tier_id':plan_features_pricing_tier_camera.id,
                                'company_detail_id':company_id,
                                'plan_pricing_description':plan_features_pricing_tier_camera.plan_pricing_description
                            })
                            
                            if product_data['plan_online_dashboard']['selected'] == False and product_data['plan_offline_dashboard']['selected'] == False:
                                UserRoleMapping.objects.filter(id=user_role_map_id).delete()
                                User.objects.filter(id=user_id).delete()
                                AddUserEmail.objects.filter(id=add_user_email_id).delete()
                                for permission_id in permission_ids:
                                    Permission.objects.filter(id=permission_id).delete()
                                Roles.objects.filter(id=role_id).delete()
                                CompanyDetail.objects.filter(id=company_id).delete()
                                return Response({'detail':'please select any one dashboard type.'},status.HTTP_400_BAD_REQUEST)
                            online_dashboard_price = 0.0
                            online_data_backup_price = 0.0
                            if product_data['plan_online_dashboard']['selected'] == True:
                                plan_features_pricing_tier_online_dashboard = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Online Dashboard').values('id','uuid','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                                print("plan feature pricint tier od:",plan_features_pricing_tier_online_dashboard)
                                plan_feature_days_price_online_dashboard = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard['id'],currency_id=currency_detail['id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').first()
                                online_dashboard_price = plan_days * camera_quantity * plan_feature_days_price_online_dashboard['days_price']
                                days_online_dashboard_price = camera_quantity * plan_feature_days_price_online_dashboard['days_price']
                                print("Value of plan_feature_pricing_category_id6:",
                                plan_features_pricing_tier_online_dashboard['pricing_feature_category_id'])
                                plans_data.append({
                                    'quantity':camera_quantity,
                                    'price':online_dashboard_price,
                                    'days_price':days_online_dashboard_price,
                                    'currency_id':currency_detail['id'],
                                    'plan_feature_pricing_category_id':plan_features_pricing_tier_online_dashboard['pricing_feature_category_id'],
                                    'category_name':plan_features_pricing_tier_online_dashboard['pricing_feature_category_id__category_name'],
                                    'plan_id':id,
                                    'plan_feature_pricing_tier_id':plan_features_pricing_tier_online_dashboard['id'],
                                    'company_detail_id':company_id,
                                    'plan_pricing_description':plan_features_pricing_tier_online_dashboard['plan_pricing_description']
                                })

                                plan_features_pricing_tier_online_dashboard_data_backup = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Online Data Backup').values('id','uuid','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                                print("plan_features_pricing_tier_online_dashboard_data_backup",plan_features_pricing_tier_online_dashboard_data_backup)
                                plan_feature_days_price_online_dashboard_data_backup = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard['id'],currency_id=currency_detail['id'],backup_days_id=product_data['plan_online_data_backup']['backup_id']).values('id','uuid','backup_days_id','backup_days_id__days','backup_days_id__category','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').first()
                                print("plan_feature_days_price_online_dashboard_data_backup",plan_feature_days_price_online_dashboard_data_backup)
                                online_data_backup_price = plan_feature_days_price_online_dashboard_data_backup['backup_days_id__days'] * camera_quantity * plan_feature_days_price_online_dashboard_data_backup['days_price']
                                
                                days_online_data_backup_price = camera_quantity * plan_feature_days_price_online_dashboard_data_backup['days_price']
                                print("Value of plan_feature_pricing_category_id7:",
                                plan_features_pricing_tier_online_dashboard_data_backup['pricing_feature_category_id'])
                                plans_data.append({
                                    'backup_days_id':plan_feature_days_price_online_dashboard_data_backup['backup_days_id'],
                                    'backup_days':plan_feature_days_price_online_dashboard_data_backup['backup_days_id__days'],
                                    'quantity':camera_quantity,
                                    'price':online_data_backup_price,
                                    'days_price':days_online_data_backup_price,
                                    'currency_id':currency_detail['id'],
                                    'plan_feature_pricing_category_id':plan_features_pricing_tier_online_dashboard_data_backup['pricing_feature_category_id'],
                                    'category_name':plan_features_pricing_tier_online_dashboard_data_backup['pricing_feature_category_id__category_name'],
                                    'plan_id':id,
                                    'plan_feature_pricing_tier_id':plan_features_pricing_tier_online_dashboard_data_backup['id'],
                                    'company_detail_id':company_id,
                                    'plan_pricing_description':plan_features_pricing_tier_online_dashboard_data_backup['plan_pricing_description']
                                })

                            offline_dashboard_price = 0.0
                            offline_data_backup_price = 0.0
                            if product_data['plan_offline_dashboard']['selected'] == True:
                                plan_features_pricing_tier_offline_dashboard = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Offline Dashboard').values('id','uuid','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                                plan_feature_days_price_offline_dashboard = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_offline_dashboard['id'],currency_id=currency_detail['id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').first()
                                offline_dashboard_price = plan_days * camera_quantity * plan_feature_days_price_offline_dashboard['days_price']
                                days_offline_dashboard_price = camera_quantity * plan_feature_days_price_offline_dashboard['days_price']
                                print("Value of plan_feature_pricing_category_id8:",
                                plan_features_pricing_tier_offline_dashboard['pricing_feature_category_id'])
                                
                                plans_data.append({
                                    'quantity':camera_quantity,
                                    'price':offline_dashboard_price,
                                    'days_price':days_offline_dashboard_price,
                                    'currency_id':currency_detail['id'],
                                    'plan_feature_pricing_category_id':plan_features_pricing_tier_offline_dashboard['pricing_feature_category_id'],
                                    'category_name':plan_features_pricing_tier_offline_dashboard['pricing_feature_category_id__category_name'],
                                    'plan_id':id,
                                    'plan_feature_pricing_tier_id':plan_features_pricing_tier_offline_dashboard['id'],
                                    'company_detail_id':company_id,
                                    'plan_pricing_description':plan_features_pricing_tier_offline_dashboard['plan_pricing_description']
                                })

                                plan_features_pricing_tier_offline_dashboard_data_backup = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Offline Data Backup').values('id','uuid','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                                plan_feature_days_price_offline_dashboard_data_backup = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_offline_dashboard['id'],currency_id=currency_detail['id'],backup_days_id=product_data['plan_offline_data_backup']['backup_id']).values('id','uuid','backup_days_id','backup_days_id__days','backup_days_id__category','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').first()
                                offline_data_backup_price = plan_feature_days_price_offline_dashboard_data_backup['backup_days_id__days'] * camera_quantity * plan_feature_days_price_offline_dashboard_data_backup['days_price']
                                days_offline_data_backup_price = camera_quantity * plan_feature_days_price_offline_dashboard_data_backup['days_price']
                                print("Value of plan_feature_pricing_category_id9:",
                                plan_features_pricing_tier_offline_dashboard_data_backup['pricing_feature_category_id'])
                                plans_data.append({
                                    'backup_days_id':plan_feature_days_price_offline_dashboard_data_backup['backup_days_id'],
                                    'backup_days':plan_feature_days_price_offline_dashboard_data_backup['backup_days_id__days'],
                                    'quantity':camera_quantity,
                                    'price':offline_data_backup_price,
                                    'days_price':days_offline_data_backup_price,
                                    'currency_id':currency_detail['id'],
                                    'plan_feature_pricing_category_id':plan_features_pricing_tier_offline_dashboard_data_backup['pricing_feature_category_id'],
                                    'category_name':plan_features_pricing_tier_offline_dashboard_data_backup['pricing_feature_category_id__category_name'],
                                    'plan_id':id,
                                    'plan_feature_pricing_tier_id':plan_features_pricing_tier_offline_dashboard_data_backup['id'],
                                    'company_detail_id':company_id,
                                    'plan_pricing_description':plan_features_pricing_tier_offline_dashboard_data_backup['plan_pricing_description']
                                })

                                
                    
                        if product_selected_exist == False:
                            UserRoleMapping.objects.filter(id=user_role_map_id).delete()
                            User.objects.filter(id=user_id).delete()
                            AddUserEmail.objects.filter(id=add_user_email_id).delete()
                            for permission_id in permission_ids:
                                Permission.objects.filter(id=permission_id).delete()
                            Roles.objects.filter(id=role_id).delete()
                            CompanyDetail.objects.filter(id=company_id).delete()
                            return Response({'detail':'please select any one dashboard type.'},status.HTTP_400_BAD_REQUEST)
                        total_price = camera_price + online_dashboard_price + online_data_backup_price + offline_dashboard_price + offline_data_backup_price + default_product_price + default_product_feature_price
                        all_product_total_price+=total_price
                        days_total_price = all_product_total_price / plan_days
                        discount_amount = (all_product_total_price * get_plan_days_and_discount.discount_percentage)/100
                        total_price_after_discount = all_product_total_price - discount_amount
                        business_coupon = None
                        if plans_detail['coupon_code'] != None:
                            print(type(plans_detail))
                            print(type(plans_data))
                            print(plans_detail)
                            print(type(plans_detail['coupon_code']))
                            print(plans_data)
                            get_coupon = Coupon.objects.filter(code=plans_detail['coupon_code'],currency_id=currency_detail['id'],plan_buy_days__gte=plan_days,coupon_expiry_datetime__gte= datetime.now(),is_active=True).values('id','uuid','code','description','discount_type','discount_value','currency_id','currency_id__currency_type').first()
                            if get_coupon != None:
                                total_coupon_amount = 0.0
                                if get_coupon['discount_type'] == 'percentage':
                                    total_coupon_amount =  (all_product_total_price * get_coupon['discount_value'])/100
                                elif get_coupon['discount_type'] == 'fixed amount':
                                    total_coupon_amount = all_product_total_price - get_coupon['discount_value']
                                total_price_after_discount -= total_coupon_amount

                                business_coupon ={
                                    'coupon_code':get_coupon['code'],
                                    'description':get_coupon['description'],
                                    'discount_type':get_coupon['discount_type'],
                                    'discount_value':get_coupon['discount_value'],
                                    'coupon_id':get_coupon['id'],
                                    'total_coupon_amount':total_coupon_amount,
                                    'company_detail_id':company_id
                                }
                            else:
                                
                                UserRoleMapping.objects.filter(id=user_role_map_id).delete()
                                User.objects.filter(id=user_id).delete()
                                AddUserEmail.objects.filter(id=add_user_email_id).delete()
                                for permission_id in permission_ids:
                                    Permission.objects.filter(id=permission_id).delete()
                                Roles.objects.filter(id=role_id).delete()
                                CompanyDetail.objects.filter(id=company_id).delete()
                                return Response({'detail':"coupon code is not valid."},status.HTTP_400_BAD_REQUEST)
                    days_total_price_after_discount = total_price_after_discount / plan_days
                    plan_pricing_tax_detail = PlanPricingTax.objects.filter(plan_pricing_id = get_plan_days_and_discount.plan_pricing_id).values('id','uuid','plan_pricing_id','tax_percentage_detail_id','tax_percentage_detail_id__tax_percentage','tax_percentage_detail_id__tax_type')
                    tax_detail = []
                    total_price_after_tax = total_price_after_discount
                    for pricing_tax in plan_pricing_tax_detail:
                        tax_amount = (total_price_after_discount*pricing_tax['tax_percentage_detail_id__tax_percentage'])/100
                        total_price_after_tax += tax_amount
                        tax_detail.append({
                            'tax_percentage_detail_id':pricing_tax['tax_percentage_detail_id'],
                            'tax_percentage':pricing_tax['tax_percentage_detail_id__tax_percentage'],
                            'tax_type':pricing_tax['tax_percentage_detail_id__tax_type'],
                            'tax_amount':tax_amount,
                            'company_detail_id':company_id
                        })
                        total_tax_percentage+=pricing_tax['tax_percentage_detail_id__tax_percentage']
                        total_tax_in_currency+=tax_amount
                    days_total_price_after_tax = total_price_after_tax / plan_days
                    plan_start_datetime = timezone.datetime.now()
                    plan_expire_datetime = timezone.datetime.now()+timezone.timedelta(days=get_plan_days_and_discount.plan_days)
                    time_diff = plan_expire_datetime - plan_start_datetime
                    total_minutes = int(time_diff.total_seconds()/60)
                    total_days = time_diff.days
                    #get_plan_pricing = PlanPricing.objects.filter(plan_id=get_plan.id,currency_id=currency_detail.id).values('id','country_type_id','country_type_id__country')
                    #get_plan_pricing = PlanPricing.objects.filter(plan_id=get_plan[0]['id'], currency_id=currency_detail['id']).values('id', 'country_type_id', 'country_type_id__country')
                    get_plan_pricing = PlanPricing.objects.filter(plan_id=get_plan.id, currency_id=currency_detail['id']).first()
                    now = timezone.now()
                    plan_expire_datetime = now + timezone.timedelta(days=get_plan_days_and_discount.plan_days)

                    business_plan_history = {
                        'plan_name':get_plan.plan_name,
                        'price':total_price,
                        'price_after_discount':total_price_after_discount,
                        'price_after_tax':total_price_after_tax,
                        'days_price':days_total_price,
                        'days_price_after_discount': days_total_price_after_discount,
                        'days_price_after_tax': days_total_price_after_tax,
                        'currency_id':currency_detail['id'],
                        'currency_type':currency_detail['currency_type'],
                        'currency_symbol':currency_detail['currency_symbol'],
                        'country_category_id':get_plan_pricing.country_type_id.id,
                        #'country_category_id': country_category_instance.pk,
                        #'country_type':get_plan_pricing.country_type_id__country,
                        #'country_type': str(get_plan_pricing.country_type_id),
                        #'country_category_id':get_plan_pricing.country_type_id,
                        'country_type':get_plan_pricing.country_type_id.country,
                        #'country_type':get_plan_pricing.country_type_id,
                        'plan_id':get_plan.id,
                        'plan_days_and_discount_id':get_plan_days_and_discount.id,
                        'plan_days':get_plan_days_and_discount.plan_days,
                        'discount_in_percentage':get_plan_days_and_discount.discount_percentage,
                        'discount_in_currency': discount_amount,
                        'total_discount': total_price_after_discount,
                        'total_tax_in_percentage':total_tax_percentage,
                        'total_tax_in_currency':total_tax_in_currency,
                        #'buy_datetime':timezone.datetime.now(),
                        'buy_datetime': timezone.datetime.now(),
                        #'plan_start_datetime':timezone.datetime.now(),
                        'plan_start_datetime': timezone.datetime.now(),
                        #'plan_expire_datetime':timezone.datetime.now()+get_plan_days_and_discount.plan_days,
                        'plan_expire_datetime': timezone.datetime.now() + timezone.timedelta(days=get_plan_days_and_discount.plan_days),
                        #'plan_expire_datetime': str(plan_expire_datetime),
                        'minutes_to_expire':total_minutes,
                        'days_to_expire':total_days,
                        'plan_validity':True,
                        'plan_status':'active',
                        'current_active':True,
                        'plan_type':'Buy Plan',
                        'company_detail_id':company_id
                    }
                    
                    #print(business_plan_history)
                    #request.session['business_plan_history'] = business_plan_history
                        #return JsonResponse({'An ERROR OCCURRED': str(e)}, status=500)
        #def save_and_update_database(self, event_data):
                    business_plan_history_serializer = BusinessPlanHistorySerializer(data=business_plan_history)
                    business_plan_history_id = None
                    if business_plan_history_serializer.is_valid():
                        business_plan_history_obj = business_plan_history_serializer.save()
                        business_plan_history_id = business_plan_history_obj.id

                        # business_plan_history['id'] = business_plan_history_id
                        # request.session['business_plan_history'] = business_plan_history
                        # print("bph",business_plan_history)

                    else:
                        UserRoleMapping.objects.filter(id=user_role_map_id).delete()
                        User.objects.filter(id=user_id).delete()
                        AddUserEmail.objects.filter(id=add_user_email_id).delete()
                        for permission_id in permission_ids:
                            Permission.objects.filter(id=permission_id).delete()
                        Roles.objects.filter(id=role_id).delete()
                        CompanyDetail.objects.filter(id=company_id).delete()
                        return Response(business_plan_history_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                    
                    business_pricing_tax_ids = []
                    for business_pricing_tax in tax_detail:
                        business_pricing_tax['business_plan_history_id'] = business_plan_history_id
                        business_pricing_tax_serializer = BusinessPlanPricingTaxSerializer(data=business_pricing_tax)
                        business_pricing_tax_id = None
                        if business_pricing_tax_serializer.is_valid():
                            business_pricing_tax_obj = business_pricing_tax_serializer.save()
                            business_pricing_tax_id = business_pricing_tax_obj.id
                            business_pricing_tax_ids.append(business_pricing_tax_id)
                        else:
                            BusinessPlanHistory.objects.filter(id=business_plan_history_id).delete()
                            UserRoleMapping.objects.filter(id=user_role_map_id).delete()
                            User.objects.filter(id=user_id).delete()
                            AddUserEmail.objects.filter(id=add_user_email_id).delete()
                            for permission_id in permission_ids:
                                Permission.objects.filter(id=permission_id).delete()
                            Roles.objects.filter(id=role_id).delete()
                            CompanyDetail.objects.filter(id=company_id).delete()
                            return Response(business_plan_history_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                    business_plan_coupon_id = None
                    business_coupon = None
                    if business_coupon != None:
                        business_coupon['business_plan_history_id'] = business_plan_history_id
                        business_coupon_serializer = BusinessPlanCoupon(data=business_coupon)
                        if business_coupon_serializer.is_valid():
                            business_coupon_obj = business_coupon_serializer.save()
                            business_plan_coupon_id = business_coupon_obj.id
                        else:
                            for business_plan_pricing_tax_id in business_pricing_tax_ids:
                                BusinessPlanPricingTax.objects.filter(id=business_plan_pricing_tax_id).delete()
                            for business_pricing_id in business_pricing_tier_ids:
                                BusinessPricingTier.objects.filter(id=business_pricing_id).delete()
                            BusinessPlanHistory.objects.filter(id=business_plan_history_id).delete()
                            UserRoleMapping.objects.filter(id=user_role_map_id).delete()
                            User.objects.filter(id=user_id).delete()
                            AddUserEmail.objects.filter(id=add_user_email_id).delete()
                            for permission_id in permission_ids:
                                Permission.objects.filter(id=permission_id).delete()
                            Roles.objects.filter(id=role_id).delete()
                            CompanyDetail.objects.filter(id=company_id).delete()
                    
                    business_pricing_tier_ids = []
                    for plans in plans_data:
                        plans['business_plan_history_id'] = business_plan_history_id
                        business_pricing_tier_serializer = BusinessPricingTierSerializer(data=plans)
                        business_pricing_tier_id = None
                        if business_pricing_tier_serializer.is_valid():
                            business_pricing_tier_obj = business_pricing_tier_serializer.save()
                            business_pricing_tier_id = business_pricing_tier_obj.id
                            business_pricing_tier_ids.append(business_pricing_tier_id)
                        else:
                            if business_plan_coupon_id != None:
                                BusinessPlanCoupon.objects.filter(id=business_plan_coupon_id).delete()
                            for business_plan_pricing_tax_id in business_pricing_tax_ids:
                                BusinessPlanPricingTax.objects.filter(id=business_plan_pricing_tax_id).delete()
                            for business_pricing_id in business_pricing_tier_ids:
                                BusinessPricingTier.objects.filter(id=business_pricing_id).delete()
                            BusinessPlanHistory.objects.filter(id=business_plan_history_id).delete()
                            UserRoleMapping.objects.filter(id=user_role_map_id).delete()
                            User.objects.filter(id=user_id).delete()
                            AddUserEmail.objects.filter(id=add_user_email_id).delete()
                            for permission_id in permission_ids:
                                Permission.objects.filter(id=permission_id).delete()
                            Roles.objects.filter(id=role_id).delete()
                            CompanyDetail.objects.filter(id=company_id).delete()
                            return Response(business_pricing_tier_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                else:
                    # if business_plan_coupon_id != None:
                    #     BusinessPlanCoupon.objects.filter(id=business_plan_coupon_id).delete()
                    # for business_plan_pricing_tax_id in business_pricing_tax_ids:
                    #     BusinessPlanPricingTax.objects.filter(id=business_plan_pricing_tax_id).delete()
                    # for business_pricing_id in business_pricing_tier_ids:
                    #     BusinessPricingTier.objects.filter(id=business_pricing_id).delete()
                    # BusinessPlanHistory.objects.filter(id=business_plan_history_id).delete()
                    UserRoleMapping.objects.filter(id=user_role_map_id).delete()
                    User.objects.filter(id=user_id).delete()
                    AddUserEmail.objects.filter(id=add_user_email_id).delete()
                    for permission_id in permission_ids:
                        Permission.objects.filter(id=permission_id).delete()
                    Roles.objects.filter(id=role_id).delete()
                    CompanyDetail.objects.filter(id=company_id).delete()
                    return Response({"detail": "Plans days doesn't exist."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                # if business_plan_coupon_id != None:
                #     BusinessPlanCoupon.objects.filter(id=business_plan_coupon_id).delete()
                # for business_plan_pricing_tax_id in business_pricing_tax_ids:
                #     BusinessPlanPricingTax.objects.filter(id=business_plan_pricing_tax_id).delete()
                # for business_pricing_id in business_pricing_tier_ids:
                #     BusinessPricingTier.objects.filter(id=business_pricing_id).delete()
                # BusinessPlanHistory.objects.filter(id=business_plan_history_id).delete()
                UserRoleMapping.objects.filter(id=user_role_map_id).delete()
                User.objects.filter(id=user_id).delete()
                AddUserEmail.objects.filter(id=add_user_email_id).delete()
                for permission_id in permission_ids:
                    Permission.objects.filter(id=permission_id).delete()
                Roles.objects.filter(id=role_id).delete()
                CompanyDetail.objects.filter(id=company_id).delete()
                return Response({"detail": "Plans not exist."}, status=status.HTTP_400_BAD_REQUEST)
            # try:
            try:


                user = User.objects.get(id=user_id)
                
                email = user.email
                phone_number = user.phone_number


                autopay_option = request.POST.get('autopay_option', None)

                
                if autopay_option == 'enable':
                    
                    response = create_subscription(request, business_plan_history, email, phone_number)


                #logger.info(f"create_subscription response: {response}")


                #return response

                    if not response.get('success', False):

                        print("Error details:")
                        # traceback.print_exc()

                        # # for obj in created_objects:
                        # #     obj.delete()
                        
                        
                        # logger.info(f"create_subscription response: {response}")

                        return response
                    
                    return JsonResponse({'An ERROR OCCURRED': response.get('message', 'Failed to create subscription')}, status=500)
            
            
                api_response_data, payment_session_id = process_cashfree_payment(request, business_plan_history, email, phone_number)

                if api_response_data is None:
                    for obj in reversed(created_objects):
                        obj.delete()
                    return JsonResponse({'An ERROR OCCURRED': 'No data returned'}, status=500)
                
                if payment_session_id:
                
                    # return JsonResponse({'payment_session_id': payment_session_id})
                    # return Response(api_response_data)
                    # response_data = {
                    #     'api_response_data': api_response_data,
                    #     'payment_session_id': payment_session_id
                    # }
                    # return Response(response_data)
                    return render(request, 'checkout.html', {'payment_session_id': payment_session_id})
                else:
                    
                    
                    for obj in reversed(created_objects):
                        obj.delete()
                    return JsonResponse({'An ERROR OCCURRED': 'Payment session ID not found'}, status=500)


            #         #serialized_data = serializers.serialize('json', [api_response_data])
            
            
            #     user = User.objects.get(id=user_id)
                
            #     email = user.email
            #     phone_number = user.phone_number


            #     autopay_option = request.POST.get('autopay_option', None)

                
            #     if autopay_option == 'enable':
                    
            #         response = create_subscription(request, business_plan_history, email, phone_number)


            #     #logger.info(f"create_subscription response: {response}")


            #     #return response

            #         if not response.get('success', False):

            #             print("Error details:")
            #             traceback.print_exc()

            #             # for obj in created_objects:
            #             #     obj.delete()
            #             for obj in reversed(created_objects):
            #                 obj.delete()
                        
            #             logger.info(f"create_subscription response: {response}")

            #             return response
                    
            #         return JsonResponse({'An ERROR OCCURRED': response.get('message', 'Failed to create subscription')}, status=500)

            #     # api_response_data = create_payment_link(request, business_plan_history, email, phone_number)
            #     # if api_response_data is None:
            #     #     for obj in reversed(created_objects):
            #     #         obj.delete()
            #     #     return JsonResponse({'An ERROR OCCURRED': 'No data returned'}, status=500)
                
            #     # else:
            #     #     return api_response_data

                
            #     api_response_data, payment_session_id = process_cashfree_payment(request, business_plan_history, email, phone_number)

            #     if api_response_data is None:
            #         for obj in reversed(created_objects):
            #             obj.delete()
            #         return JsonResponse({'An ERROR OCCURRED': 'No data returned'}, status=500)
                
            #     if payment_session_id:
                
            #         # return JsonResponse({'payment_session_id': payment_session_id})
            #         # return Response(api_response_data)
            #         # response_data = {
            #         #     'api_response_data': api_response_data,
            #         #     'payment_session_id': payment_session_id
            #         # }
            #         # return Response(response_data)
            #         return render(request, 'checkout.html', {'payment_session_id': payment_session_id})
            #     else:
            #         for obj in reversed(created_objects):
            #             obj.delete()
            #         return JsonResponse({'An ERROR OCCURRED': 'Payment session ID not found'}, status=500)

            # #         #serialized_data = serializers.serialize('json', [api_response_data])
            
            except Exception as e:
                # for obj in created_objects:
                #     obj.delete()
                for obj in reversed(created_objects):
                        obj.delete()
                return JsonResponse({'AN ERROR OCCURRED': str(e)}, status=500)

    # @csrf_exempt
    # def cashfree_notify_view(request):
    #     try:
            
    #         return cashfree_notify(request)

    #     except Exception as e:
    #         return JsonResponse({'error': str(e)}, status=500)
        
    
        #return Response({"detail": "Buy plan request successful"}, status=status.HTTP_201_CREATED)
    
   
    def put(self, request,id,format=None):
        # user_detail_page = get_user_data_page_plans(request.user.id,'upgrade_plan','view')
        # AccessToPage = False
        # if user_detail_page['permission'] != None:
        #     AccessToPage = True
        # if AccessToPage == True:
            data = request.data
            all_product_total_price = 0.0
            default_product_price = 0.0
            default_product_price_days=0.0
            total_price_after_discount = 0.0        
            total_price = 0.0
            default_product_feature_price = 0.0
            total_tax_in_currency = 0.0
            total_tax_percentage = 0.0
            days_total_price=0.0
            discount_amount=0.0
            camera_price_days=0.0
            camera_price=0.0
            default_online_dashboard_backup_price=0.0
            default_offline_dashboard_backup_price=0.0
            
           # print(data)
            plans_data = {}
            plans_detail = data['plans_detail']
            selected_products = plans_detail['plan_product']
            # valid_products = []
            # product_data_list = []
            # selected_products = plans_detail['products']
            print("selected products:",selected_products)
            for product in selected_products:
                # product_id = product['product_id']
                product_id = product['product_id']
                product_name = product['product_name']
                # product_name = product['product_name']
                print("product_names",product_name)
        
            plan_days = data['plan_days_id']
            plans_detail = data['plans_detail']
            print("Initial plans_detail:", plans_detail)

          
            plan_products = plans_detail['plan_product']
            currency_detail = Currency.objects.filter(currency_type=request.data['currency_type']).values('id','currency_type','currency_symbol').first()
            get_plan = Plans.objects.filter(id=plans_detail['id'],plan_name=plans_detail['plan_name']).first()
            #get_plan = Plans.objects.filter(id=id).first()
            #print(get_plan)
            id = get_plan.id
            plan_name = get_plan.plan_name
            get_plan_days_and_discount_all = PlanDaysAndDiscount.objects.filter(plan_id=id).all()
            plans_data['plan_days']= []
            plan_days = 0
           
            for plan_days_detail in get_plan_days_and_discount_all:
                selected = False
                if data['plan_days_id'] == plan_days_detail.id:
                    selected = True
                    plan_days = plan_days_detail.plan_days
                    plan_pricing_id = plan_days_detail.plan_pricing_id.id
                    print("plan_days_detail",plan_days_detail)
                    plans_data['plan_days'].append({
                    #'id':plan_days_detail.id,
                            'plan_days':plan_days_detail.plan_days,
                            'discount_percentage':plan_days_detail.discount_percentage,
                            'category':plan_days_detail.category,
                            'default_select':selected,
                            #'plan_pricing_id':plan_days_detail.plan_pricing_id
                            #'plan_pricing_id': plan_pricing_id
                            
                        })
            # selected_products = plans_detail['products']
            get_plan_days_and_discount = PlanDaysAndDiscount.objects.filter(plan_id=id,id=data['plan_days_id']).first()
            plans_data['product_data'] = []
            if get_plan_days_and_discount != None:
                plan_days = get_plan_days_and_discount.plan_days
                product_data = plans_detail['plan_product'][0]
               
                product_data_list = []
                parking_product_data_list = []
                all_parking_product_data = []
                for product in selected_products:
                    product_name = product['product_name']
                    print("Processing product name:", product_name)
                    plan_feature_pricing_tier_id = product['plan_feature_pricing_tier_id']
                    print("Processing plan features name:", plan_feature_pricing_tier_id)
                    camera_detail_list = []
                    camera_quantity = product['plan_camera_detail']['camera_quantity']
                    print("Camera quantity for product:", camera_quantity)
                    # camera_quantity = product_data['plan_camera_detail']['camera_quantity']
                    parking_product_data = PlanFeaturePricingTier.objects.filter(
                        plan_id=id,
                        pricing_feature_category_id__category_name="Product",
                        default_product_id__product_name=product_name,
                        id=plan_feature_pricing_tier_id,
                        show_plan_pricing=True
                    ).values(
                        'id', 'uuid', 'default_product_id', 'default_product_id__product_name',
                        'pricing_feature_category_id', 'pricing_feature_category_id__category_name',
                        'plan_id', 'plan_pricing_description', 'show_plan_pricing'
                    ).all()

                    for item in parking_product_data:
                        all_parking_product_data.append(item)
                    print("All parking product data:", all_parking_product_data)

                
                for parking_product_data in all_parking_product_data:
                    print("Processing parking product data:", parking_product_data)
                    
                    plan_feature_days_price_product = PlanFeatureDaysPrice.objects.filter(
                        plans_id=id,
                        plan_days_and_discount_id=get_plan_days_and_discount.id,
                        plan_feature_pricing_tier_id=parking_product_data['id'],
                        currency_id=data['currency_type_id']
                    ).values(
                        'id', 'uuid', 'backup_days_id', 'plan_days_and_discount_id',
                        'days_price', 'currency_id', 'currency_id__currency_symbol', 'default_selected'
                    ).all()

                    print("Plan feature days price product:", plan_feature_days_price_product)
                    plan_feature_days_price_product_instance = plan_feature_days_price_product.first()

                    if plan_feature_days_price_product_instance:
                        default_product_price = plan_days * camera_quantity * plan_feature_days_price_product_instance['days_price']
                        default_product_price_days = camera_quantity * plan_feature_days_price_product_instance['days_price']
                    else:
                        default_product_price = 0
                        default_product_price_days = 0

                    product_selected_exist = True

                    product_data_json = {
                        'product_name': parking_product_data['default_product_id__product_name'],
                        'plan_product': [{
                            'days_price': default_product_price_days,
                            'price': default_product_price,
                            'default_selected': product_selected_exist,
                            'plan_pricing_description': parking_product_data['plan_pricing_description'],
                        }]
                    }
                    total_price += default_product_price
                    product_data_list.append(product_data_json)
                    print("Product data JSON:", product_data_json)
                    # default_parking_product_feature_data = PlanFeaturePricingTier.objects.filter(plan_id=id,pricing_feature_category_id__category_name="Feature",default_product_id__product_name=product_name,is_encluded_plan_feature_id__isnull=False,default_product_feature_id__isnull=False).values('id','uuid','default_product_id','default_product_id__product_name','default_product_feature_id','default_product_feature_id__feature','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').all()
                    # product_data_json['plan_product_feature_default'] = []
                    # for default_product_feature in default_parking_product_feature_data:
                    #     product_data_json['plan_product_feature_default'].append({
                    #         # 'id':default_product_feature['id'],
                    #         # 'uuid':default_product_feature['uuid'],
                    #         # 'default_product_feature_id':default_product_feature['default_product_feature_id'],
                    #         # 'pricing_feature_category_id':default_product_feature['pricing_feature_category_id'],
                    #         # 'category_name':default_product_feature['pricing_feature_category_id__category_name'],
                    #         'feature_name':default_product_feature['default_product_feature_id__feature'],
                    #         'plan_pricing_description':default_product_feature['plan_pricing_description'],       
                    #     })
                    # parking_product_feature_data = PlanFeaturePricingTier.objects.filter(plan_id=id,pricing_feature_category_id__category_name="Feature",default_product_id__product_name=product_name,is_encluded_plan_feature_id__isnull=False,default_product_feature_id__isnull=False).values('id','uuid','default_product_id','default_product_id__product_name','default_product_feature_id','default_product_feature_id__feature','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').all()
                    # print("parking_product_feature_data",parking_product_feature_data)
                    # product_data_json['plan_product_feature'] = []
                    # default_product_feature_price = 0.0
                    # for product_feature in parking_product_feature_data:
                    #     # plan_feature_days_price_product_feature = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=product_feature['id'],currency_id=data['currency_type_id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                    #     # product_feature_price = plan_days * camera_quantity * plan_feature_days_price_product_feature['days_price']
                    #     # product_feature_price_days = camera_quantity * plan_feature_days_price_product_feature['days_price']
                    #     # default_selected = False
                    #     plan_feature_days_price_product_feature = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=product_feature['id'],currency_id=currency_detail['id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                    #     plan_feature_days_price_product_feature_instance = plan_feature_days_price_product_feature.first()  
                    #     if plan_feature_days_price_product_feature_instance:
                    #         product_feature_price = plan_days * camera_quantity * plan_feature_days_price_product_feature_instance['days_price']
                    #         product_feature_price_days = camera_quantity * plan_feature_days_price_product_feature_instance['days_price']
                    #     else:
                            
                    #         product_feature_price = 0  
                    #     # product_feature_price = plan_days * camera_quantity * plan_feature_days_price_product_feature_instance['days_price']
                    #     # product_feature_price_days = camera_quantity * plan_feature_days_price_product_feature_instance['days_price']
                    #     default_selected = False
                    #     feature_plan_selected = [feature_plan for feature_plan in product_data['plan_feature_detail'] if feature_plan['plan_feature_pricing_tier_id']==product_feature['id'] and feature_plan['selected']==True]
                    #     if len(feature_plan_selected) > 0:
                    #         default_selected = True
                    #         default_product_feature_price += product_feature_price
                    #     product_data_json['plan_product_feature'].append({
                    #         # 'id':product_feature['id'],
                    #         # 'uuid':product_feature['uuid'],
                    #         'days_price':product_feature_price_days,
                    #         'price': product_feature_price,
                    #         'currency_symbol':plan_feature_days_price_product_instance['currency_id__currency_symbol'],
                    #         # 'default_product_feature_id':product_feature['default_product_feature_id'],
                    #         'feature_name':product_feature['default_product_feature_id__feature'],
                    #         # 'pricing_feature_category_id':product_feature['pricing_feature_category_id'],
                    #         #'category_name':product_feature['pricing_feature_category_id__category_name'],
                    #         'default_selected':default_selected,
                    #         # 'plan_id':product_feature['plan_id'],
                    #         'plan_pricing_description':product_feature['plan_pricing_description'],
                    #         #'show_plan_pricing':product_feature['show_plan_pricing']
                    #     })
                    product_data_json['plan_camera_detail'] = []
                    default_product_ids = [item['default_product_id'] for item in all_parking_product_data]
                # for parking_product_instance in all_parking_product_data:

                #         default_product_id = parking_product_instance['default_product_id']
                    print("deafult product",default_product_ids)
            
                    plan_features_pricing_tier_cameras = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id__in=default_product_ids,pricing_feature_category_id__category_name='Camera').values('id','uuid', 'default_product_id' , 'min_quantity','max_quantity','default_quantity','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').all()
                    print("plan_features_pricing_tier_cameras",plan_features_pricing_tier_cameras)
                    print(list(plan_features_pricing_tier_cameras))
                    if isinstance(plan_features_pricing_tier_cameras, dict):
   
                        plan_features_pricing_tier_cameras = [plan_features_pricing_tier_cameras]
                    else:
                        
                        pass
                    plan_features_pricing_tier_camera_dict = {item['default_product_id']: item for item in plan_features_pricing_tier_cameras}
                    product_camera_detail_list = []
                    default_camera_price = 0.0
                    product_data_json['plan_camera_detail']= []
                    total_camera_price = 0
                    total_camera_price_days = 0
                    total_camera_quantity = 0
                    camera_detail_list = []
                    
                    
                    # for product in plan_products:
                    for parking_product_instance in all_parking_product_data:
                        default_product_id = parking_product_instance['default_product_id']
                        print("default product", default_product_id)

                        product_camera_detail_list = []
                        camera_quantity = product_data['plan_camera_detail']['camera_quantity']
                        # camera_quantity = product['plan_camera_detail']['camera_quantity']
                        
                        plan_features_pricing_tier_camera = plan_features_pricing_tier_camera_dict.get(default_product_id)
                        print("plan_features_pricing_tier_camera",plan_features_pricing_tier_camera)
                        print(f"Processing product with plan_feature_pricing_tier_id: {product['plan_feature_pricing_tier_id']}, camera_quantity: {camera_quantity}")
                        plan_feature_days_price_camera = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=data['plan_days_id'],plan_feature_pricing_tier_id=plan_features_pricing_tier_camera['id'],currency_id=data['currency_type_id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol').first()

                        
                        default_camera_price = plan_days * camera_quantity * plan_feature_days_price_camera['days_price']
                        default_camera_price_days = camera_quantity * plan_feature_days_price_camera['days_price']
                        default_selected = camera_quantity == product['plan_camera_detail']['camera_quantity']

                    
                        total_camera_price += default_camera_price
                        total_camera_price_days += default_camera_price_days
                        total_camera_quantity += camera_quantity

                    
                                
                    camera_detail_list.append({
                        'camera_quantity': camera_quantity,
                        'days_price': default_camera_price_days,
                        'price': default_camera_price,
                        'currency_symbol': plan_feature_days_price_camera['currency_id__currency_symbol'],
                        'category_name':plan_features_pricing_tier_camera['pricing_feature_category_id__category_name'],
                        'default_selected': default_selected,
                        'plan_pricing_description':plan_features_pricing_tier_camera['plan_pricing_description'],
                    })

                    total_camera_quantity = sum(detail['camera_quantity'] for detail in camera_detail_list)
                    total_price += default_camera_price
                    product_data_json['plan_camera_detail'].append({
                            'days_price': default_camera_price_days,
                            'total_camera_price': total_camera_price,
                            'total_camera_price_days': total_camera_price_days,
                            'total_camera_quantity': total_camera_quantity,
                            'currency_symbol': plan_feature_days_price_camera['currency_id__currency_symbol'],
                            'default_selected': default_selected,
                            'plan_pricing_description':plan_features_pricing_tier_camera['plan_pricing_description'],
                            #'camera_details': camera_detail_list
                    })
                    print("product_camera_detail_list",product_camera_detail_list)
                # for camera in range(plan_features_pricing_tier_camera['min_quantity'],plan_features_pricing_tier_camera['max_quantity']+1):
                #     plan_feature_days_price_camera = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=data['plan_days_id'],plan_feature_pricing_tier_id=plan_features_pricing_tier_camera['id'],currency_id=data['currency_type_id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol').first()
                #     camera_price = plan_days * camera * plan_feature_days_price_camera['days_price']
                #     camera_price_days = camera * plan_feature_days_price_camera['days_price']
                #     default_selected = False
                #     if camera_quantity == camera:
                #         default_camera_price = camera_price
                #         default_selected = True
                #     product_data_json['plan_camera_detail'].append({
                #         # 'id':plan_features_pricing_tier_camera['id'],
                #         # 'uuid':plan_features_pricing_tier_camera['uuid'],
                #         'camera_quantity':camera,
                #         'days_price':camera_price_days,
                #         'price': camera_price,
                #         'currency_symbol':plan_feature_days_price_camera['currency_id__currency_symbol'],
                #         #'pricing_feature_category_id':plan_features_pricing_tier_camera['pricing_feature_category_id'],
                #         #'category_name':plan_features_pricing_tier_camera['pricing_feature_category_id__category_name'],
                #         'default_selected':default_selected,
                #         #'plan_id':plan_features_pricing_tier_camera['plan_id'],
                #         'plan_pricing_description':plan_features_pricing_tier_camera['plan_pricing_description'],
                #         #'show_plan_pricing':plan_features_pricing_tier_camera['show_plan_pricing']
                #     })
                

                    if product_data['plan_online_dashboard']['selected'] == False and data['plan_offline_dashboard']['selected'] == False: 
                        return Response({'detail':'please select any one dashboard type.'},status.HTTP_400_BAD_REQUEST)
                    product_data_json['plan_online_dashboard'] = []
                    plan_features_pricing_tier_online_dashboards = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id__in=default_product_ids,pricing_feature_category_id__category_name='Online Dashboard').values('id','uuid','default_product_id', 'pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').all()
                    print("plan_features_pricing_tier_online_dashboards",plan_features_pricing_tier_online_dashboards)
                    
                    if isinstance(plan_features_pricing_tier_online_dashboards, dict):
   
                        plan_features_pricing_tier_online_dashboards = [plan_features_pricing_tier_online_dashboards]
                    else:
                        
                        pass
                    plan_features_pricing_tier_online_dashboard_dict = {item['default_product_id']: item for item in plan_features_pricing_tier_online_dashboards}
                    
                    for parking_product_instance in all_parking_product_data:
                        default_product_id = parking_product_instance['default_product_id']
                        print("default product", default_product_id)
                        plan_features_pricing_tier_online_dashboard = plan_features_pricing_tier_online_dashboard_dict.get(default_product_id)
                        print("plan_features_pricing_tier_online_dashboard",plan_features_pricing_tier_online_dashboard)
                        # plan_features_pricing_tier_online_dashboard = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=default_product_id,pricing_feature_category_id__category_name='Online Dashboard').values('id','uuid','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                        plan_feature_days_price_online_dashboard = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard['id'],currency_id=data['currency_type_id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').first()
                        online_dashboard_price = plan_days * camera_quantity * plan_feature_days_price_online_dashboard['days_price']
                        online_dashboard_price_days = camera_quantity * plan_feature_days_price_online_dashboard['days_price']
                        default_online_dashboard_price = 0.0
                        if product_data['plan_online_dashboard']['selected'] == True:
                            default_online_dashboard_price = online_dashboard_price
                    total_price += online_dashboard_price
                    product_data_json['plan_online_dashboard'].append({
                            # 'id':plan_features_pricing_tier_online_dashboard['id'],
                            # 'uuid':plan_features_pricing_tier_online_dashboard['uuid'],
                            #'camera_quantity':camera_quantity,
                            'plan_days':plan_days,
                            'days_price':online_dashboard_price_days,
                            'price': online_dashboard_price,
                            'currency_symbol':plan_feature_days_price_online_dashboard['currency_id__currency_symbol'],
                            # 'pricing_feature_category_id':plan_features_pricing_tier_online_dashboard['pricing_feature_category_id'],
                            #'category_name':plan_features_pricing_tier_online_dashboard['pricing_feature_category_id__category_name'],
                            'default_selected':product_data['plan_online_dashboard']['selected'],
                            # 'plan_id':plan_features_pricing_tier_online_dashboard['plan_id'],
                            'plan_pricing_description':plan_features_pricing_tier_online_dashboard['plan_pricing_description'],
                            # 'show_plan_pricing':plan_features_pricing_tier_online_dashboard['show_plan_pricing']
                        })

                    # product_data_json['plan_online_dashboard_data_backup'] = []
                    # plan_features_pricing_tier_online_dashboard_data_backup = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Online Data Backup').values('id','uuid','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                    # plan_feature_days_price_online_dashboard_data_backup = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard['id'],currency_id=data['currency_type_id']).values('id','uuid','backup_days_id','backup_days_id__days','backup_days_id__category','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                    # print("plan_feature_days_price_online_dashboard_data_backup",plan_feature_days_price_online_dashboard_data_backup)
                    # default_online_dashboard_backup_price = 0.0
                    # for online_data_backup in plan_feature_days_price_online_dashboard_data_backup:
                    #     online_data_backup_price = online_data_backup['backup_days_id__days'] * camera_quantity * online_data_backup['days_price']
                    #     online_data_backup_price_days = camera_quantity * online_data_backup['days_price']

                    #     default_selected = False
                    #     if product_data['plan_online_data_backup']['backup_id'] == online_data_backup['id'] and data['plan_online_dashboard']['selected'] == True:
                    #         default_online_dashboard_backup_price = online_data_backup_price
                    #         default_selected = True
                    #     product_data_json['plan_online_dashboard_data_backup'].append({
                    #          'id':plan_features_pricing_tier_online_dashboard_data_backup['id'],
                    #         # 'uuid':plan_features_pricing_tier_online_dashboard_data_backup['uuid'],
                    #         # 'camera_quantity':camera_quantity,
                    #         # "backup_id":online_data_backup['id'],
                    #         'backup_days':online_data_backup['backup_days_id__days'],
                    #         # 'backup_category':online_data_backup['backup_days_id__category'],
                    #         'days_price':online_data_backup_price_days,
                    #         'price': online_data_backup_price,
                    #         'currency_symbol':online_data_backup['currency_id__currency_symbol'],
                    #         # 'pricing_feature_category_id':plan_features_pricing_tier_online_dashboard_data_backup['pricing_feature_category_id'],
                    #         # 'category_name':plan_features_pricing_tier_online_dashboard_data_backup['pricing_feature_category_id__category_name'],
                    #         'default_selected':online_data_backup['default_selected'],
                    #         # 'plan_id':plan_features_pricing_tier_online_dashboard_data_backup['plan_id'],
                    #         'plan_pricing_description':plan_features_pricing_tier_online_dashboard_data_backup['plan_pricing_description'],
                    #         # 'show_plan_pricing':plan_features_pricing_tier_online_dashboard_data_backup['show_plan_pricing']
                    #     })
                    # product_data_json['plan_online_dashboard_data_backup'] = []
                    # plan_features_pricing_tier_online_dashboard_data_backup = PlanFeaturePricingTier.objects.filter(
                    #             plan_id=id, 
                    #             pricing_feature_category_id__category_name='Online Data Backup'
                    #              ).first()
                    product_data_json['plan_online_dashboard_data_backup'] = []

                    plan_features_pricing_tier_online_dashboard_data_backups = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id__in=default_product_ids,pricing_feature_category_id__category_name='Online Data Backup').values('id','uuid','default_product_id', 'pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').all()
                    print("plan_features_pricing_tier_online_dashboard_data_backup",plan_features_pricing_tier_online_dashboard_data_backups)
                    
                    if isinstance(plan_features_pricing_tier_online_dashboard_data_backups, dict):
   
                        plan_features_pricing_tier_online_dashboard_data_backups = [plan_features_pricing_tier_online_dashboard_data_backups]
                    else:
                        
                        pass
                    plan_features_pricing_tier_online_dashboard_data_backup_dict = {item['default_product_id']: item for item in plan_features_pricing_tier_online_dashboard_data_backups}
                    for parking_product_instance in all_parking_product_data:
                        default_product_id = parking_product_instance['default_product_id']
                        print("default product", default_product_id)
                        plan_features_pricing_tier_online_dashboard_data_backup = plan_features_pricing_tier_online_dashboard_data_backup_dict.get(default_product_id)

                        # plan_features_pricing_tier_online_dashboard_data_backup = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=default_product_id,pricing_feature_category_id__category_name='Online Data Backup').values('id','uuid','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                        if plan_features_pricing_tier_online_dashboard_data_backup:
                            # online_data_backup = PlanFeatureDaysPrice.objects.filter(
                            #     plans_id=plans_data['id'],
                            #     plan_days_and_discount_id=plan_features_pricing_tier_online_dashboard_data_backup.id,  
                            #     plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard_data_backup.id,
                            #     currency_id=currency_type_id
                            # ).first()
                            # online_data_backup = PlanFeatureDaysPrice.objects.filter(
                            #     plans_id=id,
                            #     plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard_data_backup.id,
                            #     currency_id=data['currency_type_id']
                            # ).all()
                            online_data_backup = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard_data_backup['id'],currency_id=data['currency_type_id']).all()

                            print("online data backup", online_data_backup)

                            # if online_data_backup:
                            #     online_data_backup_price_days = plan_days * online_data_backup.days_price
                            #     online_data_backup_price = plan_days * online_data_backup_price_days
                            if online_data_backup:
                                for backup in online_data_backup:
                                    # online_data_backup_price_days = plan_days * backup.days_price
                                    # online_data_backup_price = plan_days * online_data_backup_price_days
                                    # online_data_backup_price = online_data_backup['backup_days_id__days'] * camera_quantity * online_data_backup['days_price']
                                    # online_data_backup_price_days = camera_quantity * online_data_backup['days_price']
                                    defautlt_online_dashboard_backup_price_days = camera_quantity * backup.days_price
                                    default_online_dashboard_backup_price = backup.backup_days_id.days * camera_quantity * backup.days_price
                                    default_selected = backup.default_selected
                                    # default_selected = False
                                    print("backup",backup)
                                # if product_data['plan_online_data_backup']['backup_id'] == online_data_backup['id'] and data['plan_online_dashboard']['selected'] == True:
                                #     default_online_dashboard_backup_price = online_data_backup_price
                                #     default_selected = True
                                    # default_selected = False
                                    # if (
                                    #     product_data['plan_online_data_backup']['backup_id'] == backup.id and
                                    #     data['plan_online_dashboard']['selected']
                                    # ):
                                    #     default_online_dashboard_backup_price = online_data_backup_price
                                    #     default_selected = True
                                    # if plan_features_pricing_tier_online_dashboard_data_backup.default_quantity == backup.backup_days_id.days:
                                    #     default_selected = True
                                    #     default_online_dashboard_backup_price = online_data_backup_price
                                    total_price += default_online_dashboard_backup_price
                                    product_data_json['plan_online_dashboard_data_backup'].append({
                                        'id': backup.id,
                                        'backup_days': backup.backup_days_id.days,
                                        'days_price': defautlt_online_dashboard_backup_price_days,
                                        'price': default_online_dashboard_backup_price,
                                        'currency_symbol': backup.currency_id.currency_symbol,
                                        'default_selected': default_selected,
                                        'plan_pricing_description': plan_features_pricing_tier_online_dashboard_data_backup['plan_pricing_description'],
                                    })

                    product_data_json['plan_offline_dashboard'] = []
                    plan_features_pricing_tier_offline_dashboards = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id__in=default_product_ids,pricing_feature_category_id__category_name='Offline Dashboard').values('id','uuid','default_product_id', 'pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').all()
                    print("plan_features_pricing_tier_offline_dashboards",plan_features_pricing_tier_offline_dashboards)
                    
                    if isinstance(plan_features_pricing_tier_offline_dashboards, dict):
   
                        plan_features_pricing_tier_offline_dashboards = [plan_features_pricing_tier_offline_dashboards]
                    else:
                        
                        pass
                    plan_features_pricing_tier_offline_dashboard_dict = {item['default_product_id']: item for item in plan_features_pricing_tier_offline_dashboards}

                    for parking_product_instance in all_parking_product_data:
                        default_product_id = parking_product_instance['default_product_id']
                        print("default product", default_product_id)
                        plan_features_pricing_tier_offline_dashboard = plan_features_pricing_tier_offline_dashboard_dict.get(default_product_id)
                        # plan_features_pricing_tier_offline_dashboard = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=default_product_id,pricing_feature_category_id__category_name='Offline Dashboard').values('id','uuid','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                        plan_feature_days_price_offline_dashboard = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_offline_dashboard['id'],currency_id=data['currency_type_id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').first()
                        offline_dashboard_price = plan_days * camera_quantity * plan_feature_days_price_offline_dashboard['days_price']
                        offline_dashboard_price_days = camera_quantity * plan_feature_days_price_offline_dashboard['days_price']
                        default_offline_dashboard_price = 0.0
                        if product_data['plan_offline_dashboard']['selected'] == True:
                            default_offline_dashboard_price = offline_dashboard_price
                    total_price += offline_dashboard_price
                    product_data_json['plan_offline_dashboard'].append({
                            # 'id':plan_features_pricing_tier_offline_dashboard['id'],
                            # 'uuid':plan_features_pricing_tier_offline_dashboard['uuid'],
                            # 'camera_quantity':camera_quantity,
                            'plan_days':plan_days,
                            'days_price':offline_dashboard_price_days,
                            'price': offline_dashboard_price,
                            'currency_symbol':plan_feature_days_price_offline_dashboard['currency_id__currency_symbol'],
                            # 'pricing_feature_category_id':plan_features_pricing_tier_offline_dashboard['pricing_feature_category_id'],
                            # 'category_name':plan_features_pricing_tier_offline_dashboard['pricing_feature_category_id__category_name'],
                            'default_selected':product_data['plan_offline_dashboard']['selected'],
                            # 'plan_id':plan_features_pricing_tier_offline_dashboard['plan_id'],
                            'plan_pricing_description':plan_features_pricing_tier_offline_dashboard['plan_pricing_description'],
                            # 'show_plan_pricing':plan_features_pricing_tier_offline_dashboard['show_plan_pricing']
                        })

                    print("product data:", product_data_json)
                    product_data_json['plan_offline_dashboard_data_backup'] = []
                    plan_features_pricing_tier_offline_dashboard_data_backups = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id__in=default_product_ids,pricing_feature_category_id__category_name='Offline Data Backup').values('id','uuid','default_product_id', 'pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').all()
                    print("plan_features_pricing_tier_offline_dashboard_data_backup",plan_features_pricing_tier_offline_dashboard_data_backups)
                    
                    if isinstance(plan_features_pricing_tier_offline_dashboard_data_backups, dict):
   
                        plan_features_pricing_tier_offline_dashboard_data_backups = [plan_features_pricing_tier_offline_dashboard_data_backups]
                    else:
                        
                        pass
                    plan_features_pricing_tier_offline_dashboard_data_backup_dict = {item['default_product_id']: item for item in plan_features_pricing_tier_offline_dashboard_data_backups}
                    for parking_product_instance in all_parking_product_data:
                        default_product_id = parking_product_instance['default_product_id']
                        print("default product", default_product_id)
                        plan_features_pricing_tier_offline_dashboard_data_backup = plan_features_pricing_tier_offline_dashboard_data_backup_dict.get(default_product_id)
                        # plan_features_pricing_tier_offline_dashboard_data_backup = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=default_product_id,pricing_feature_category_id__category_name='Offline Data Backup').values('id','uuid','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                        if plan_features_pricing_tier_offline_dashboard_data_backup:
                            # online_data_backup = PlanFeatureDaysPrice.objects.filter(
                            #     plans_id=plans_data['id'],
                            #     plan_days_and_discount_id=plan_features_pricing_tier_online_dashboard_data_backup.id,  
                            #     plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard_data_backup.id,
                            #     currency_id=currency_type_id
                            # ).first()
                            # online_data_backup = PlanFeatureDaysPrice.objects.filter(
                            #     plans_id=id,
                            #     plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard_data_backup.id,
                            #     currency_id=data['currency_type_id']
                            # ).all()
                            offline_data_backup = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_offline_dashboard_data_backup['id'],currency_id=data['currency_type_id']).all()

                            print("offline data backup", offline_data_backup)

                            # if online_data_backup:
                            #     online_data_backup_price_days = plan_days * online_data_backup.days_price
                            #     online_data_backup_price = plan_days * online_data_backup_price_days
                            if offline_data_backup:
                                for backup in offline_data_backup:
                                    default_offline_dashboard_backup_price_days = camera_quantity * backup.days_price
                                    default_offline_dashboard_backup_price = backup.backup_days_id.days * camera_quantity * backup.days_price
                                    default_selected = backup.default_selected
                                    # default_selected = False
                                    print("backup",backup)
                                # if product_data['plan_online_data_backup']['backup_id'] == online_data_backup['id'] and data['plan_online_dashboard']['selected'] == True:
                                #     default_online_dashboard_backup_price = online_data_backup_price
                                #     default_selected = True
                                    # default_selected = False
                                    # if (
                                    #     product_data['plan_online_data_backup']['backup_id'] == backup.id and
                                    #     data['plan_online_dashboard']['selected']
                                    # ):
                                    #     default_online_dashboard_backup_price = online_data_backup_price
                                    #     default_selected = True
                                    # if plan_features_pricing_tier_online_dashboard_data_backup.default_quantity == backup.backup_days_id.days:
                                    #     default_selected = True
                                    #     default_online_dashboard_backup_price = online_data_backup_price
                                    total_price += default_offline_dashboard_backup_price
                                    product_data_json['plan_offline_dashboard_data_backup'].append({
                                        'id': backup.id,
                                        'backup_days': backup.backup_days_id.days,
                                        'days_price': default_offline_dashboard_backup_price_days,
                                        'price': default_offline_dashboard_backup_price,
                                        'currency_symbol': backup.currency_id.currency_symbol,
                                        'default_selected': default_selected,
                                        'plan_pricing_description': plan_features_pricing_tier_offline_dashboard_data_backup['plan_pricing_description'],
                                    })
                    # product_data_json['plan_offline_dashboard_data_backup'] = []
                    # plan_features_pricing_tier_offline_dashboard_data_backup = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Offline Data Backup').values('id','uuid','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                    # plan_feature_days_price_offline_dashboard_data_backup = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_offline_dashboard['id'],currency_id=data['currency_type_id']).values('id','uuid','backup_days_id','backup_days_id__days','backup_days_id__category','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                    # default_offline_dashboard_backup_price = 0.0
                    # for offline_data_backup in plan_feature_days_price_offline_dashboard_data_backup:
                    #     offline_data_backup_price = offline_data_backup['backup_days_id__days'] * camera_quantity * offline_data_backup['days_price']
                    #     offline_data_backup_price_days = camera_quantity * offline_data_backup['days_price']
                    #     default_selected = False
                    #     if product_data['plan_offline_data_backup']['backup_id'] == offline_data_backup['id'] and data['plan_offline_dashboard']['selected'] == True:
                    #         default_offline_dashboard_backup_price = offline_data_backup_price
                    #         default_selected = True
                    #     product_data_json['plan_offline_dashboard_data_backup'].append({
                    #         'id':plan_features_pricing_tier_offline_dashboard_data_backup['id'],
                    #         # 'uuid':plan_features_pricing_tier_offline_dashboard_data_backup['uuid'],
                    #         # 'camera_quantity':camera_quantity,
                    #         'backup_days':offline_data_backup['backup_days_id__days'],
                    #         # 'backup_category':offline_data_backup['backup_days_id__category'],
                    #         'days_price':offline_data_backup_price_days,
                    #         'price': offline_data_backup_price,
                    #         'currency_symbol':offline_data_backup['currency_id__currency_symbol'],
                    #         # 'pricing_feature_category_id':plan_features_pricing_tier_offline_dashboard_data_backup['pricing_feature_category_id'],
                    #         'category_name':plan_features_pricing_tier_offline_dashboard_data_backup['pricing_feature_category_id__category_name'],
                    #         'default_selected':default_selected,
                    #         # 'plan_id':plan_features_pricing_tier_offline_dashboard_data_backup['plan_id'],
                    #         'plan_pricing_description':plan_features_pricing_tier_offline_dashboard_data_backup['plan_pricing_description'],
                    #         # 'show_plan_pricing':plan_features_pricing_tier_offline_dashboard_data_backup['show_plan_pricing']
                    #     })
                    # plan_features_pricing_tier_offline_dashboard_data_backup = PlanFeaturePricingTier.objects.filter(
                    #             plan_id=id, 
                    #             pricing_feature_category_id__category_name='Offline Data Backup'
                    #              ).first()

                    # if plan_features_pricing_tier_offline_dashboard_data_backup:
                    #     # online_data_backup = PlanFeatureDaysPrice.objects.filter(
                    #     #     plans_id=plans_data['id'],
                    #     #     plan_days_and_discount_id=plan_features_pricing_tier_online_dashboard_data_backup.id,  
                    #     #     plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard_data_backup.id,
                    #     #     currency_id=currency_type_id
                    #     # ).first()
                    #     offline_data_backup = PlanFeatureDaysPrice.objects.filter(
                    #         plans_id=id,
                    #         plan_feature_pricing_tier_id=plan_features_pricing_tier_offline_dashboard_data_backup.id,
                    #         currency_id=data['currency_type_id']
                    #     ).all()

                    
                    #     product_data_json['plan_offline_dashboard_data_backup'] = []

                    #     # if online_data_backup:
                    #     #     online_data_backup_price_days = plan_days * online_data_backup.days_price
                    #     #     online_data_backup_price = plan_days * online_data_backup_price_days
                    #     if offline_data_backup:
                    #         for backup in offline_data_backup:
                    #             offline_data_backup_price_days = plan_days * backup.days_price
                    #             offline_data_backup_price = plan_days * offline_data_backup_price_days
                                
                    #             default_selected = False
                    #             if plan_features_pricing_tier_offline_dashboard_data_backup.default_quantity == backup.backup_days_id.days:
                    #                 default_selected = True
                    #                 default_offline_dashboard_backup_price = offline_data_backup_price
                                
                    #             product_data_json['plan_offline_dashboard_data_backup'].append({
                    #                 'id': backup.id,
                    #                 'backup_days': backup.backup_days_id.days,
                    #                 'days_price': offline_data_backup_price_days,
                    #                 'price': offline_data_backup_price,
                    #                 'currency_symbol': backup.currency_id.currency_symbol,
                    #                 'default_selected': default_selected,
                    #                 'plan_pricing_description': plan_features_pricing_tier_offline_dashboard_data_backup.plan_pricing_description,
                    #             })
                    # total_price = default_camera_price + default_online_dashboard_price + default_online_dashboard_backup_price + default_offline_dashboard_price + default_offline_dashboard_backup_price + default_product_price+default_product_feature_price
                    # print(default_camera_price)
                    # print(default_online_dashboard_price)
                    # print(default_online_dashboard_backup_price)
                    # print(default_offline_dashboard_price)
                    # print(default_offline_dashboard_backup_price)
                    # print(default_product_price)
                    # print(default_product_feature_price)
                    
                    all_product_total_price+=total_price
                    plans_data['product_data'].append(product_data_json)
                discount_amount = (all_product_total_price * get_plan_days_and_discount.discount_percentage)/100
                total_price_after_discount = all_product_total_price - discount_amount
                if plans_detail['coupon_code'] != None:
                    get_coupon = Coupon.objects.filter(code=plans_detail['coupon_code'],currency_id=data['currency_type_id'],plan_buy_days__gte=plan_days,coupon_expiry_datetime__gte= timezone.datetime.now(),is_active=True).values('id','uuid','code','description','discount_type','discount_value','currency_id','currency_id__currency_type').first()
                    if get_coupon != None:
                        total_coupon_amount = 0.0
                        if get_coupon['discount_type'] == 'percentage':
                            total_coupon_amount =  (all_product_total_price * get_coupon['discount_value'])/100
                        elif get_coupon['discount_type'] == 'fixed amount':
                            total_coupon_amount = all_product_total_price - get_coupon['discount_value']
                        total_price_after_discount -= total_coupon_amount

                        plans_data['coupon_code'] ={
                            # 'id':get_coupon['id'],
                            # 'uuid':get_coupon['uuid'],
                            'code':get_coupon['code'],
                            'description':get_coupon['description'],
                            'discount_type':get_coupon['discount_type'],
                            'discount_value':get_coupon['discount_value'],
                            # 'currency_id':get_coupon['currency_id'],
                            'total_coupon_amount':total_coupon_amount
                        }

                    else:
                        return Response({'detail':"coupon code is not valid."},status.HTTP_400_BAD_REQUEST)

                plan_pricing_tax_detail = PlanPricingTax.objects.filter(plan_pricing_id = get_plan_days_and_discount.plan_pricing_id).values('id','uuid','plan_pricing_id','tax_percentage_detail_id','tax_percentage_detail_id__tax_percentage','tax_percentage_detail_id__tax_type')
                tax_detail = []
                total_price_after_tax = total_price_after_discount
                for pricing_tax in plan_pricing_tax_detail:
                    tax_amount = (total_price_after_discount*pricing_tax['tax_percentage_detail_id__tax_percentage'])/100
                    total_price_after_tax += tax_amount
                    tax_detail.append({
                        # 'id':pricing_tax['id'],
                        # 'uuid':pricing_tax['uuid'],
                        # 'tax_percentage_detail_id':pricing_tax['tax_percentage_detail_id'],
                        'tax_percentage':pricing_tax['tax_percentage_detail_id__tax_percentage'],
                        'tax_type':pricing_tax['tax_percentage_detail_id__tax_type'],
                        'tax_amount':tax_amount
                    })
                plans_data['plan_pricing'] ={
                    'total_price':total_price,
                    'discount_percent':get_plan_days_and_discount.discount_percentage,
                    'discount_amount':discount_amount,
                    'total_price_after_discount':total_price_after_discount,
                    'total_price_after_tax':total_price_after_tax,
                    'tax_detail':tax_detail
                }
                
                return Response(plans_data, status=status.HTTP_200_OK)   
        # else:
        #     return Response({"detail": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

class PlanPricingView:
    def __init__(self, total_price, discount_amount, total_price_after_discount, total_price_after_tax, tax_detail):
        self.total_price = total_price
        self.discount_amount = discount_amount
        self.total_price_after_discount = total_price_after_discount
        self.total_price_after_tax = total_price_after_tax
        self.tax_detail = tax_detail

    def to_dict(self):
        return {
            'total_price': self.total_price,
            'discount_amount': self.discount_amount,
            'total_price_after_discount': self.total_price_after_discount,
            'total_price_after_tax': self.total_price_after_tax,
            'tax_detail': self.tax_detail,
        }


class GetBuyPlanDetail(APIView):
    permission_classes = (AllowAny,)

    def get(self, request, id):
        default_camera_price = 0.0
        currency_type_id = request.GET.get('currency', 1)
        print("currencytypeid:", currency_type_id)
        plans_data = {}
        get_plan = Plans.objects.filter(id=id).first()
        plans_data['id'] = get_plan.id
        plans_data['plan_name'] = get_plan.plan_name
        get_plan_days_and_discount_all = PlanDaysAndDiscount.objects.filter(plan_id=id).all()
        plans_data['plan_days'] = []

        for plan_days_detail in get_plan_days_and_discount_all:
            plan_days = 30
            default_selected = False
            if plan_days == plan_days_detail.plan_days:
                default_selected = True
                plans_data['plan_days'].append({
                    'plan_days': plan_days_detail.plan_days,
                    'discount_percentage': plan_days_detail.discount_percentage,
                })
                print("pd", plans_data)

        get_plan_days_and_discount = PlanDaysAndDiscount.objects.filter(plan_id=id, default_select=True).first()
        plans_data['product_data'] = []
        if get_plan_days_and_discount is not None:
            plan_days = get_plan_days_and_discount.plan_days
            print("PLAN DAYS:", plan_days)

            desired_product_names = ['Gate Site', 'Train Site', 'In and Out Object Site', 'Occupancy management site']
            all_product_total_price = 0.0

            for product_name in desired_product_names:
                product_data_json = {}
                product_data_json['product_name'] = product_name

                parking_product_data = PlanFeaturePricingTier.objects.filter(
                    plan_id=id, pricing_feature_category_id__category_name="Product",
                    default_product_id__product_name=product_name
                ).values(
                    'id', 'uuid', 'default_product_id', 'default_product_id__product_name',
                    'pricing_feature_category_id', 'pricing_feature_category_id__category_name',
                    'plan_id', 'plan_pricing_description', 'show_plan_pricing'
                ).first()

                if parking_product_data is not None:
                    plan_feature_days_price_product = PlanFeatureDaysPrice.objects.filter(
                        plans_id=id, plan_days_and_discount_id=get_plan_days_and_discount.id,
                        plan_feature_pricing_tier_id=parking_product_data['id'], currency_id=currency_type_id
                    ).values(
                        'id', 'uuid', 'backup_days_id', 'plan_days_and_discount_id', 'days_price',
                        'currency_id', 'currency_id__currency_symbol', 'default_selected'
                    ).all()

                    plan_feature_days_price_product_instance = plan_feature_days_price_product.first()

                    if plan_feature_days_price_product_instance:
                        default_product_price = plan_days * plan_feature_days_price_product_instance['days_price']
                        default_product_price_days = plan_feature_days_price_product_instance['days_price']
                    else:
                        default_product_price = 0
                        default_product_price_days = 0

                    product_data_json['plan_product'] = {
                        'days_price': default_product_price_days,
                        'price': default_product_price,
                        'currency_symbol': plan_feature_days_price_product_instance['currency_id__currency_symbol'],
                    }

                    default_parking_product_feature_data = PlanFeaturePricingTier.objects.filter(
                        plan_id=id, pricing_feature_category_id__category_name="Feature",
                        default_product_id__product_name=product_name,
                        is_encluded_plan_feature_id__isnull=False,
                        default_product_feature_id__isnull=False
                    ).values(
                        'id', 'uuid', 'default_product_id', 'default_product_id__product_name',
                        'default_product_feature_id', 'default_product_feature_id__feature',
                        'pricing_feature_category_id', 'pricing_feature_category_id__category_name',
                        'plan_id', 'plan_pricing_description', 'show_plan_pricing'
                    ).all()

                    product_data_json['plan_product_feature_default'] = []
                    for default_product_feature in default_parking_product_feature_data:
                        product_data_json['plan_product_feature_default'].append({
                            'category_name': default_product_feature['pricing_feature_category_id__category_name'],
                            'feature_name': default_product_feature['default_product_feature_id__feature'],
                            'plan_pricing_description': default_product_feature['plan_pricing_description'],
                        })

                    parking_product_feature_data = PlanFeaturePricingTier.objects.filter(
                        plan_id=id, pricing_feature_category_id__category_name="Feature",
                        default_product_id__product_name=product_name,
                        is_encluded_plan_feature_id__isnull=True,
                        default_product_feature_id__isnull=False
                    ).values(
                        'id', 'uuid', 'default_product_id', 'default_product_id__product_name',
                        'default_product_feature_id', 'default_product_feature_id__feature',
                        'pricing_feature_category_id', 'pricing_feature_category_id__category_name',
                        'plan_id', 'plan_pricing_description', 'show_plan_pricing'
                    ).all()

                    product_data_json['plan_product_feature'] = []
                    default_product_feature_price = 0.0

                    for product_feature in parking_product_feature_data:
                        plan_feature_days_price_product_feature = PlanFeatureDaysPrice.objects.filter(
                            plans_id=id, plan_days_and_discount_id=get_plan_days_and_discount.id,
                            plan_feature_pricing_tier_id=product_feature['id'], currency_id=currency_type_id
                        ).values(
                            'id', 'uuid', 'backup_days_id', 'plan_days_and_discount_id', 'days_price',
                            'currency_id', 'currency_id__currency_symbol', 'default_selected'
                        ).all()

                        plan_feature_days_price_product_feature_instance = plan_feature_days_price_product_feature.first()

                        if plan_feature_days_price_product_feature_instance:
                            product_feature_price = plan_days * plan_feature_days_price_product_feature_instance['days_price']
                            product_feature_price_days = plan_feature_days_price_product_feature_instance['days_price']
                        else:
                            product_feature_price = 0

                        default_product_feature_price += product_feature_price

                        product_data_json['plan_product_feature'].append({
                            'days_price': product_feature_price_days,
                            'price': product_feature_price,
                            'currency_symbol': plan_feature_days_price_product_feature_instance['currency_id__currency_symbol'],
                            'feature_name': product_feature['default_product_feature_id__feature'],
                            'plan_pricing_description': product_feature['plan_pricing_description'],
                        })
                        product_data_json['plan_camera_detail'] = []

                        # plan_feature_pricing_tier_camera = PlanFeaturePricingTier.objects.filter(
                        #     plan_id=plans_data['id'],
                        #     pricing_feature_category_id__category_name='Camera'
                        # ).first()
                        plan_features_pricing_tier_camera = PlanFeaturePricingTier.objects.filter(plan_id=plans_data['id'], pricing_feature_category_id__category_name='Camera').first()

                        camera_quantity = plan_features_pricing_tier_camera.default_quantity
                        if plan_features_pricing_tier_camera:
                            plan_feature_days_price_camera = PlanFeatureDaysPrice.objects.filter(
                                plans_id=plans_data['id'],
                                plan_days_and_discount_id=get_plan_days_and_discount_all.first().id,
                                plan_feature_pricing_tier_id=plan_features_pricing_tier_camera.id,
                                currency_id=currency_type_id
                            ).first()

                            if plan_feature_days_price_camera:
                                
                                    total_quantity = 0
                                    total_days_price = 0
                                    total_price = 0

                                   
                                    for camera in range(plan_features_pricing_tier_camera.min_quantity, plan_features_pricing_tier_camera.max_quantity + 1):
                                        print(f"Allowed quantity of cameras: {camera}")

                                       
                                        camera_price = plan_days * camera * plan_feature_days_price_camera.days_price
                                        camera_price_days = camera * plan_feature_days_price_camera.days_price

                                      
                                        total_quantity += camera
                                        total_days_price += camera_price_days
                                        total_price += camera_price

                                    
                                    product_data_json['plan_camera_detail'].append({
                                        'quantity': camera_quantity,
                                        'days_price': total_days_price,
                                        'price': camera_price,
                                        'currency_symbol': plan_feature_days_price_camera.currency_id.currency_symbol,
                                        'plan_pricing_description': plan_features_pricing_tier_camera.plan_pricing_description,
                                    })
                        product_data_json['plan_online_dashboard'] = []
                        plan_features_pricing_tier_online_dashboard = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Online Dashboard').values('id','uuid','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                        plan_feature_days_price_online_dashboard = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard['id'],currency_id=currency_type_id).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').first()
                        online_dashboard_price = plan_days * camera_quantity * plan_feature_days_price_online_dashboard['days_price']
                        online_dashboard_price_days = camera_quantity * plan_feature_days_price_online_dashboard['days_price']
                        default_selected = False
                        default_online_dashboard_price = 0.0
                        #if user_detail_page['plans_detail']['online_dashboard_detail'] != None:
                        online_dashboard_exists = False
                        # for plan_detail in user_detail_page['plans_detail']:
                        #     if 'online_dashboard_detail' in plan_detail:
                        #         online_dashboard_exists = True
                        #         break

                        
                        default_selected = True
                        default_online_dashboard_price = online_dashboard_price
                        product_data_json['plan_online_dashboard'].append({
                                # 'id':plan_features_pricing_tier_online_dashboard['id'],
                                # 'uuid':plan_features_pricing_tier_online_dashboard['uuid'],
                                #'camera_quantity':camera_quantity,
                                'plan_days':plan_days,
                                'days_price':online_dashboard_price_days,
                                'price': online_dashboard_price,
                                'currency_symbol':plan_feature_days_price_online_dashboard['currency_id__currency_symbol'],
                                # 'pricing_feature_category_id':plan_features_pricing_tier_online_dashboard['pricing_feature_category_id'],
                                # 'category_name':plan_features_pricing_tier_online_dashboard['pricing_feature_category_id__category_name'],
                                'default_selected':default_selected,
                                # 'plan_id':plan_features_pricing_tier_online_dashboard['plan_id'],
                                'plan_pricing_description':plan_features_pricing_tier_online_dashboard['plan_pricing_description'],
                                # 'show_plan_pricing':plan_features_pricing_tier_online_dashboard['show_plan_pricing']
                        
                            })    
                        plan_features_pricing_tier_online_dashboard_data_backup = PlanFeaturePricingTier.objects.filter(
                                plan_id=plans_data['id'], 
                                pricing_feature_category_id__category_name='Online Data Backup'
                                 ).first()

                        if plan_features_pricing_tier_online_dashboard_data_backup:
                            # online_data_backup = PlanFeatureDaysPrice.objects.filter(
                            #     plans_id=plans_data['id'],
                            #     plan_days_and_discount_id=plan_features_pricing_tier_online_dashboard_data_backup.id,  
                            #     plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard_data_backup.id,
                            #     currency_id=currency_type_id
                            # ).first()
                            online_data_backup = PlanFeatureDaysPrice.objects.filter(
                                plans_id=plans_data['id'],
                                plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard_data_backup.id,
                                currency_id=currency_type_id
                            ).all()

                            print("online data backup", online_data_backup)
                            product_data_json['plan_online_dashboard_data_backup'] = []

                            # if online_data_backup:
                            #     online_data_backup_price_days = plan_days * online_data_backup.days_price
                            #     online_data_backup_price = plan_days * online_data_backup_price_days
                            if online_data_backup:
                                for backup in online_data_backup:
                                    online_data_backup_price_days = plan_days * backup.days_price
                                    online_data_backup_price = plan_days * online_data_backup_price_days
                                    
                                    default_selected = False
                                    if plan_features_pricing_tier_online_dashboard_data_backup.default_quantity == backup.backup_days_id.days:
                                        default_selected = True
                                        default_online_dashboard_backup_price = online_data_backup_price
                                    
                                    product_data_json['plan_online_dashboard_data_backup'].append({
                                        'id': backup.id,
                                        'backup_days': backup.backup_days_id.days,
                                        'days_price': online_data_backup_price_days,
                                        'price': online_data_backup_price,
                                        'currency_symbol': backup.currency_id.currency_symbol,
                                        'default_selected': default_selected,
                                        'plan_pricing_description': plan_features_pricing_tier_online_dashboard_data_backup.plan_pricing_description,
                                    })    
                        product_data_json['plan_offline_dashboard'] = []
                        plan_features_pricing_tier_offline_dashboard = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Offline Dashboard').values('id','uuid','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                        plan_feature_days_price_offline_dashboard = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_offline_dashboard['id'],currency_id=currency_type_id).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').first()
                        offline_dashboard_price = plan_days * camera_quantity * plan_feature_days_price_offline_dashboard['days_price']
                        offline_dashboard_price_days = camera_quantity * plan_feature_days_price_offline_dashboard['days_price']
                        default_selected = False
                        default_offline_dashboard_price = 0.0
                        # if user_detail_page['plans_detail']['offline_dashboard_detail'] != None:
                        offline_dashboard_exists = False
                        # for plan_detail in user_detail_page['plans_detail']:
                        #     if 'offline_dashboard_detail' in plan_detail:
                        #         offline_dashboard_exists = True
                        #         break

                    
                        default_selected = True
                        default_offline_dashboard_price = offline_dashboard_price
                        product_data_json['plan_offline_dashboard'].append({
                                # 'id':plan_features_pricing_tier_offline_dashboard['id'],
                                # 'uuid':plan_features_pricing_tier_offline_dashboard['uuid'],
                                #'camera_quantity':camera_quantity,
                                'plan_days':plan_days,
                                'days_price':offline_dashboard_price_days,
                                'price': offline_dashboard_price,
                                'currency_symbol':plan_feature_days_price_offline_dashboard['currency_id__currency_symbol'],
                                # 'pricing_feature_category_id':plan_features_pricing_tier_offline_dashboard['pricing_feature_category_id'],
                                # 'category_name':plan_features_pricing_tier_offline_dashboard['pricing_feature_category_id__category_name'],
                                'default_selected':default_selected,
                                # 'plan_id':plan_features_pricing_tier_offline_dashboard['plan_id'],
                                'plan_pricing_description':plan_features_pricing_tier_offline_dashboard['plan_pricing_description'],
                                # 'show_plan_pricing':plan_features_pricing_tier_offline_dashboard['show_plan_pricing']
                            })     
                        plan_features_pricing_tier_offline_dashboard_data_backup = PlanFeaturePricingTier.objects.filter(
                                plan_id=plans_data['id'], 
                                pricing_feature_category_id__category_name='Offline Data Backup'
                                 ).first()

                        if plan_features_pricing_tier_offline_dashboard_data_backup:
                            # online_data_backup = PlanFeatureDaysPrice.objects.filter(
                            #     plans_id=plans_data['id'],
                            #     plan_days_and_discount_id=plan_features_pricing_tier_online_dashboard_data_backup.id,  
                            #     plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard_data_backup.id,
                            #     currency_id=currency_type_id
                            # ).first()
                            offline_data_backup = PlanFeatureDaysPrice.objects.filter(
                                plans_id=plans_data['id'],
                                plan_feature_pricing_tier_id=plan_features_pricing_tier_offline_dashboard_data_backup.id,
                                currency_id=currency_type_id
                            ).all()

                            
                            product_data_json['plan_offline_dashboard_data_backup'] = []

                            # if online_data_backup:
                            #     online_data_backup_price_days = plan_days * online_data_backup.days_price
                            #     online_data_backup_price = plan_days * online_data_backup_price_days
                            if offline_data_backup:
                                for backup in offline_data_backup:
                                    offline_data_backup_price_days = plan_days * backup.days_price
                                    offline_data_backup_price = plan_days * offline_data_backup_price_days
                                    
                                    default_selected = False
                                    if plan_features_pricing_tier_offline_dashboard_data_backup.default_quantity == backup.backup_days_id.days:
                                        default_selected = True
                                        default_offline_dashboard_backup_price = offline_data_backup_price
                                    
                                    product_data_json['plan_offline_dashboard_data_backup'].append({
                                        'id': backup.id,
                                        'backup_days': backup.backup_days_id.days,
                                        'days_price': offline_data_backup_price_days,
                                        'price': offline_data_backup_price,
                                        'currency_symbol': backup.currency_id.currency_symbol,
                                        'default_selected': default_selected,
                                        'plan_pricing_description': plan_features_pricing_tier_offline_dashboard_data_backup.plan_pricing_description,
                                    })

                    total_price = camera_price + online_dashboard_price + offline_dashboard_price + offline_data_backup_price + online_data_backup_price  +default_product_price + default_product_feature_price
                    all_product_total_price += total_price
                    plans_data['product_data'].append(product_data_json)

            discount_amount = (all_product_total_price * get_plan_days_and_discount.discount_percentage) / 100
            total_price_after_discount = all_product_total_price - discount_amount
            plans_data['coupon_code'] = None

            plan_pricing_tax_detail = PlanPricingTax.objects.filter(
                plan_pricing_id=get_plan_days_and_discount.plan_pricing_id
            ).values(
                'id', 'uuid', 'plan_pricing_id', 'tax_percentage_detail_id',
                'tax_percentage_detail_id__tax_percentage', 'tax_percentage_detail_id__tax_type'
            )

            tax_detail = []
            total_price_after_tax = total_price_after_discount

            for pricing_tax in plan_pricing_tax_detail:
                tax_amount = (total_price_after_discount * pricing_tax['tax_percentage_detail_id__tax_percentage']) / 100
                total_price_after_tax += tax_amount
                tax_detail.append({
                    'tax_percentage': pricing_tax['tax_percentage_detail_id__tax_percentage'],
                    'tax_type': pricing_tax['tax_percentage_detail_id__tax_type'],
                    'tax_amount': tax_amount
                })

            plan_pricing = PlanPricingView(
                total_price=all_product_total_price,
                discount_amount=discount_amount,
                total_price_after_discount=total_price_after_discount,
                total_price_after_tax=total_price_after_tax,
                tax_detail=tax_detail
            )

            response_data = {
                'plan_pricing': plan_pricing.to_dict(),
                'product_data': plans_data['product_data']
            }

            return JsonResponse(response_data, status=status.HTTP_200_OK)

        return JsonResponse({'error': 'No plan days and discount found'}, status=status.HTTP_404_NOT_FOUND)



class UpgradePlanView(APIView):
    permission_classes = (IsAuthenticated,)
    def calculate_remaining_days(self, existing_plan):
        now = timezone.now()
        remaining_days = (existing_plan.plan_expire_datetime - now).days
        return max(0, remaining_days)

    
    def calculate_pro_rated_refund(self, existing_plan, remaining_days):
        original_price = existing_plan.price_after_tax  
        total_days = existing_plan.plan_days  
        daily_rate = original_price / total_days
        return daily_rate * remaining_days
    def calculate_remaining_value(self, existing_plan):
        now = timezone.now()
        remaining_days = (existing_plan.plan_expire_datetime - now).days
        remaining_days = max(0, remaining_days)
        original_price = existing_plan.price_after_tax  
        total_days = existing_plan.plan_days  
        daily_rate = original_price / total_days
        remaining_value = daily_rate * remaining_days
        return remaining_value

  

    def post(self, request):
        user_detail_page = get_user_data_page_plans(request.user.id,'upgrade_plan','create')  
        print("udp",user_detail_page)
        default_product_feature_price = 0.0
        all_product_total_price = 0.0
        total_tax_in_currency = 0.0
        total_tax_percentage = 0.0
        default_product_price = 0.0
        default_product_price_days=0.0
        total_price_after_discount = 0.0        
        total_price = 0.0
        
        total_tax_in_currency = 0.0
        total_tax_percentage = 0.0
        days_total_price=0.0
        discount_amount=0.0
        
        company_id = user_detail_page['company_detail']['id']
        user = request.user
        AccessToPage = False
        if user_detail_page['permission'] != None:
            AccessToPage = True
        if AccessToPage == True:
            #plans_detail =  request.data
            data = request.data
            currency_detail = Currency.objects.filter(currency_type=request.data['currency_type']).values('id','currency_type','currency_symbol').first()
            #get_plan = Plans.objects.filter(id=plans_detail['id'],plan_name=plans_detail['plan_name']).first()
            plans_detail = data['plans_detail']
            # selected_products = plans_detail['products']
            selected_products = plans_detail['plan_product']
            valid_products = []
            for product in selected_products:
                product_id = product['product_id']
                product_name = product['product_name']
                print("product_names", product_name)
                product_exists = DefaultProduct.objects.filter(id=product_id, product_name=product_name).exists()
                if not product_exists:
                    # for obj in reversed(created_objects):
                    #     obj.delete()
                    return Response({'error': f"Product '{product_name}' with ID '{product_id}' does not exist in the database."}, status=status.HTTP_400_BAD_REQUEST)
                valid_products.append(product)
                print("valid product:",valid_products)

            products = ['Gate Site', 'Train Site', 'In and Out Object Site', 'Occupancy management site']
            plans_data = []

            for product_name in products:
                product_data = next((product for product in valid_products if product['product_name'] == product_name), None)
                print("product_data",product_data)
                if product_data is None:
                    continue
                get_plan = Plans.objects.filter(id=plans_detail['id'],plan_name=plans_detail['plan_name']).first()
                if get_plan != None:
                    id = get_plan.id
                    plan_name = get_plan.plan_name
                    get_plan_days_and_discount = PlanDaysAndDiscount.objects.filter(plan_id=id,id=plans_detail['plan_days_id'],default_select=True).first()
                    if get_plan_days_and_discount != None:
                        plans_data= []
                        plan_days = get_plan_days_and_discount.plan_days
                        product_data = plans_detail['plan_product'][0]
                        camera_quantity = product_data['plan_camera_detail']['camera_quantity']
                        parking_product_data = PlanFeaturePricingTier.objects.filter(plan_id=id,pricing_feature_category_id__category_name="Product",default_product_id__product_name=product_name,id=product_data['plan_feature_pricing_tier_id'],show_plan_pricing=True).values('id','uuid','default_product_id','default_product_id__product_name','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                        print("parking_product_data",parking_product_data)
                        if parking_product_data != None:
                            plan_features_pricing_tier_camera = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Camera').values('id','uuid','min_quantity','max_quantity','default_quantity','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                            plan_feature_days_price_product = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=parking_product_data['id'],currency_id=currency_detail['id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                            plan_feature_days_price_product_instance = plan_feature_days_price_product.first()

                            if plan_feature_days_price_product_instance:
                                default_product_price = plan_days * camera_quantity * plan_feature_days_price_product_instance['days_price']
                                default_product_price_days = camera_quantity * plan_feature_days_price_product_instance['days_price']
                            else:
                                #print("error in defaultproductprice")
                                default_product_price = 0 
                                default_product_price_days = 0
                            product_selected_exist = True
                        # product_selected_exist = True
                            # default_product_price = plan_days * camera_quantity * plan_feature_days_price_product['days_price']
                            # default_product_price_days = camera_quantity * plan_feature_days_price_product['days_price']
                            plans_data.append({
                                'price':default_product_price,
                                'days_price':default_product_price_days,
                                'currency_id':currency_detail['id'],
                                'default_product_id':parking_product_data['default_product_id'],
                                'plan_feature_pricing_category_id':parking_product_data['pricing_feature_category_id'],
                                'category_name':parking_product_data['pricing_feature_category_id__category_name'],
                                'plan_id':id,
                                'plan_feature_pricing_tier_id':parking_product_data['id'],
                                'company_detail_id':user_detail_page['company_detail']['id'],
                                'plan_pricing_description':parking_product_data['plan_pricing_description']
                            })
                            default_parking_product_feature_data = PlanFeaturePricingTier.objects.filter(plan_id=id,pricing_feature_category_id__category_name="Feature",default_product_id__product_name=product_name,is_encluded_plan_feature_id__isnull=False,default_product_feature_id__isnull=False).values('id','uuid','default_product_id','default_product_id__product_name','default_product_feature_id','default_product_feature_id__feature','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').all()
                            for default_product_feature in default_parking_product_feature_data:
                                plans_data.append({
                                    'price':0.0,
                                    'days_price':0.0,
                                    'currency_id':currency_detail['id'],
                                    'default_product_id':parking_product_data['default_product_id'],
                                    'default_product_feature_id':default_product_feature['default_product_feature_id'],
                                    'plan_feature_pricing_category_id':default_product_feature['pricing_feature_category_id'],
                                    'category_name':default_product_feature['pricing_feature_category_id__category_name'],
                                    'plan_id':id,
                                    'plan_feature_pricing_tier_id':default_product_feature['id'],
                                    'company_detail_id':user_detail_page['company_detail']['id'],
                                    'plan_pricing_description':default_product_feature['plan_pricing_description']
                                })
                            parking_product_feature_data = PlanFeaturePricingTier.objects.filter(plan_id=id,pricing_feature_category_id__category_name="Feature",default_product_id__product_name=product_name,is_encluded_plan_feature_id__isnull=True,default_product_feature_id__isnull=False).values('id','uuid','default_product_id','default_product_id__product_name','default_product_feature_id','default_product_feature_id__feature','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').all()
                            for product_feature in parking_product_feature_data:
                                #plan_feature_days_price_product_feature = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount['id'],plan_feature_pricing_tier_id=product_feature['id'],currency_id=currency_detail['id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                                plan_feature_days_price_product_feature = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=product_feature['id'],currency_id=currency_detail['id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                                plan_feature_days_price_product_feature_instance = plan_feature_days_price_product_feature.first()  
                                if plan_feature_days_price_product_feature_instance:
                                    product_feature_price = plan_days * camera_quantity * plan_feature_days_price_product_feature_instance['days_price']
                                    product_feature_price_days = camera_quantity * plan_feature_days_price_product_feature_instance['days_price']
                                else:
                                    
                                    product_feature_price = 0  
                                # product_feature_price = plan_days * camera_quantity * plan_feature_days_price_product_feature_instance['days_price']
                                # product_feature_price_days = camera_quantity * plan_feature_days_price_product_feature_instance['days_price']
                                default_selected = False
                            
                                product_feature_price = plan_days * camera_quantity * plan_feature_days_price_product_feature_instance['days_price']
                                product_feature_price_days = camera_quantity * plan_feature_days_price_product_feature_instance['days_price']
                                default_selected = False
                                feature_plan_selected = [feature_plan for feature_plan in product_data['plan_feature_detail'] if feature_plan['plan_feature_pricing_tier_id']==product_feature['id'] and feature_plan['selected']==True]
                                if len(feature_plan_selected) > 0:
                                    default_selected = True
                                    default_product_feature_price += product_feature_price
                                    plans_data.append({
                                        'price':product_feature_price,
                                        'days_price':product_feature_price_days,
                                        'currency_id':currency_detail['id'],
                                        'default_product_id':parking_product_data['default_product_id'],
                                        'default_product_feature_id':product_feature['default_product_feature_id'],
                                        'plan_feature_pricing_category_id':product_feature['pricing_feature_category_id'],
                                        'category_name':product_feature['pricing_feature_category_id__category_name'],
                                        'plan_id':id,
                                        'plan_feature_pricing_tier_id':product_feature['id'],
                                        'company_detail_id':user_detail_page['company_detail']['id'],
                                        'plan_pricing_description':product_feature['plan_pricing_description']
                                    })
                            plan_feature_days_price_camera = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_camera['id'],currency_id=currency_detail['id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol').first()
                            camera_price = plan_days * camera_quantity * plan_feature_days_price_camera['days_price']
                            camera_price_days = camera_quantity * plan_feature_days_price_camera['days_price']
                            plans_data.append({
                                'quantity':camera_quantity,
                                'price':camera_price,
                                'days_price':camera_price_days,
                                'currency_id':currency_detail['id'],
                                'plan_feature_pricing_category_id':plan_features_pricing_tier_camera['pricing_feature_category_id'],
                                'category_name':plan_features_pricing_tier_camera['pricing_feature_category_id__category_name'],
                                'plan_id':id,
                                'plan_feature_pricing_tier_id':plan_features_pricing_tier_camera['id'],
                                'company_detail_id':user_detail_page['company_detail']['id'],
                                'plan_pricing_description':plan_features_pricing_tier_camera['plan_pricing_description']
                            })
                            # plan_features_pricing_tier_parking_slot = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Violation surveillance').values('id','uuid','min_quantity','max_quantity','default_quantity','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                            # parking_slot = product_data['plan_parking_slot_detail']['parking_slot']
                            # if parking_slot < plan_features_pricing_tier_parking_slot['min_quantity'] or parking_slot > plan_features_pricing_tier_parking_slot['max_quantity']:
                            #     BusinessDetail.objects.filter(id=user_detail_page['business_detail']['id']).delete()
                            #     return Response({'detail':'please select any one dashboard type.'},status.HTTP_400_BAD_REQUEST)
                            # # for camera in range(plan_features_pricing_tier_camera['min_quantity'],plan_features_pricing_tier_camera['max_quantity']+1):
                            # plan_feature_days_price_parking_slot = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_camera['id'],currency_id=currency_detail['id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol').first()
                            # default_parking_slot_price = plan_days * parking_slot * plan_feature_days_price_parking_slot['days_price']
                            # praking_slot_days_price = parking_slot * plan_feature_days_price_parking_slot['days_price']
                            # plans_data.append({
                            #     'quantity':parking_slot,
                            #     'price':default_parking_slot_price,
                            #     'days_price':praking_slot_days_price,
                            #     'currency_id':currency_detail['id'],
                            #     'default_product_id':parking_product_data['default_product_id'],
                            #     'plan_feature_pricing_category_id':plan_features_pricing_tier_parking_slot['pricing_feature_category_id'],
                            #     'category_name':plan_features_pricing_tier_parking_slot['pricing_feature_category_id__category_name'],
                            #     'plan_id':id,
                            #     'plan_feature_pricing_tier_id':plan_features_pricing_tier_parking_slot['id'],
                            #     'business_detail_id':user_detail_page['business_detail']['id'],
                            #     'plan_pricing_description':plan_features_pricing_tier_parking_slot['plan_pricing_description']
                            # })
                            if product_data['plan_online_dashboard']['selected'] == False and product_data['plan_offline_dashboard']['selected'] == False:
                                return Response({'detail':'please select any one dashboard type.'},status.HTTP_400_BAD_REQUEST)
                            online_dashboard_price = 0.0
                            online_data_backup_price = 0.0
                            if product_data['plan_online_dashboard']['selected'] == True:
                                plan_features_pricing_tier_online_dashboard = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Online Dashboard').values('id','uuid','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                                plan_feature_days_price_online_dashboard = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard['id'],currency_id=currency_detail['id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').first()
                                online_dashboard_price = plan_days * camera_quantity * plan_feature_days_price_online_dashboard['days_price']
                                days_online_dashboard_price = camera_quantity * plan_feature_days_price_online_dashboard['days_price']
                                plans_data.append({
                                    'quantity':camera_quantity,
                                    'price':online_dashboard_price,
                                    'days_price':days_online_dashboard_price,
                                    'currency_id':currency_detail['id'],
                                    'plan_feature_pricing_category_id':plan_features_pricing_tier_online_dashboard['pricing_feature_category_id'],
                                    'category_name':plan_features_pricing_tier_online_dashboard['pricing_feature_category_id__category_name'],
                                    'plan_id':id,
                                    'plan_feature_pricing_tier_id':plan_features_pricing_tier_online_dashboard['id'],
                                    'company_detail_id':user_detail_page['company_detail']['id'],
                                    'plan_pricing_description':plan_features_pricing_tier_online_dashboard['plan_pricing_description']
                                })
                                plan_features_pricing_tier_online_dashboard_data_backup = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Online Data Backup').values('id','uuid','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                                plan_feature_days_price_online_dashboard_data_backup = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard['id'],currency_id=currency_detail['id'],backup_days_id=product_data['plan_online_data_backup']['backup_id']).values('id','uuid','backup_days_id','backup_days_id__days','backup_days_id__category','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').first()
                                online_data_backup_price = plan_feature_days_price_online_dashboard_data_backup['backup_days_id__days'] * camera_quantity * plan_feature_days_price_online_dashboard_data_backup['days_price']
                                days_online_data_backup_price = camera_quantity * plan_feature_days_price_online_dashboard_data_backup['days_price']
                                plans_data.append({
                                    'backup_days_id':plan_feature_days_price_online_dashboard_data_backup['backup_days_id'],
                                    'backup_days':plan_feature_days_price_online_dashboard_data_backup['backup_days_id__days'],
                                    'quantity':camera_quantity,
                                    'price':online_data_backup_price,
                                    'days_price':days_online_data_backup_price,
                                    'currency_id':currency_detail['id'],
                                    'plan_feature_pricing_category_id':plan_features_pricing_tier_online_dashboard_data_backup['pricing_feature_category_id'],
                                    'category_name':plan_features_pricing_tier_online_dashboard_data_backup['pricing_feature_category_id__category_name'],
                                    'plan_id':id,
                                    'plan_feature_pricing_tier_id':plan_features_pricing_tier_online_dashboard_data_backup['id'],
                                    'company_detail_id':user_detail_page['company_detail']['id'],
                                    'plan_pricing_description':plan_features_pricing_tier_online_dashboard_data_backup['plan_pricing_description']
                                })
                            offline_dashboard_price = 0.0
                            offline_data_backup_price = 0.0
                            if product_data['plan_offline_dashboard']['selected'] == True:
                                plan_features_pricing_tier_offline_dashboard = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Offline Dashboard').values('id','uuid','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                                plan_feature_days_price_offline_dashboard = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_offline_dashboard['id'],currency_id=currency_detail['id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').first()
                                offline_dashboard_price = plan_days * camera_quantity * plan_feature_days_price_offline_dashboard['days_price']
                                days_offline_dashboard_price = camera_quantity * plan_feature_days_price_offline_dashboard['days_price']
                                plans_data.append({
                                    'quantity':camera_quantity,
                                    'price':offline_dashboard_price,
                                    'days_price':days_offline_dashboard_price,
                                    'currency_id':currency_detail['id'],
                                    'plan_feature_pricing_category_id':plan_features_pricing_tier_offline_dashboard['pricing_feature_category_id'],
                                    'category_name':plan_features_pricing_tier_offline_dashboard['pricing_feature_category_id__category_name'],
                                    'plan_id':id,
                                    'plan_feature_pricing_tier_id':plan_features_pricing_tier_offline_dashboard['id'],
                                    'company_detail_id':user_detail_page['company_detail']['id'],
                                    'plan_pricing_description':plan_features_pricing_tier_offline_dashboard['plan_pricing_description']
                                })
                                plan_features_pricing_tier_offline_dashboard_data_backup = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Offline Data Backup').values('id','uuid','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                                plan_feature_days_price_offline_dashboard_data_backup = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_offline_dashboard['id'],currency_id=currency_detail['id'],backup_days_id=product_data['plan_offline_data_backup']['backup_id']).values('id','uuid','backup_days_id','backup_days_id__days','backup_days_id__category','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').first()
                                offline_data_backup_price = plan_feature_days_price_offline_dashboard_data_backup['backup_days_id__days'] * camera_quantity * plan_feature_days_price_offline_dashboard_data_backup['days_price']
                                days_offline_data_backup_price = camera_quantity * plan_feature_days_price_offline_dashboard_data_backup['days_price']
                                plans_data.append({
                                    'backup_days_id':plan_feature_days_price_offline_dashboard_data_backup['backup_days_id'],
                                    'backup_days':plan_feature_days_price_offline_dashboard_data_backup['backup_days_id__days'],
                                    'quantity':camera_quantity,
                                    'price':offline_data_backup_price,
                                    'days_price':days_offline_data_backup_price,
                                    'currency_id':currency_detail['id'],
                                    'plan_feature_pricing_category_id':plan_features_pricing_tier_offline_dashboard_data_backup['pricing_feature_category_id'],
                                    'category_name':plan_features_pricing_tier_offline_dashboard_data_backup['pricing_feature_category_id__category_name'],
                                    'plan_id':id,
                                    'plan_feature_pricing_tier_id':plan_features_pricing_tier_offline_dashboard_data_backup['id'],
                                    'company_detail_id':user_detail_page['company_detail']['id'],
                                    'plan_pricing_description':plan_features_pricing_tier_offline_dashboard_data_backup['plan_pricing_description']
                                })
                            if product_selected_exist == False:
                                return Response({'detail':'please select any one dashboard type.'},status.HTTP_400_BAD_REQUEST)
                            total_price = camera_price+ online_dashboard_price + online_data_backup_price + offline_dashboard_price + offline_data_backup_price + default_product_price + default_product_feature_price
                            all_product_total_price+=total_price
                        days_total_price = all_product_total_price / plan_days
                        discount_amount = (all_product_total_price * get_plan_days_and_discount.discount_percentage)/100
                        total_price_after_discount = all_product_total_price - discount_amount
                        business_coupon = None
                        if plans_detail['coupon_code'] != None:
                            get_coupon = Coupon.objects.filter(code=plans_detail['coupon_code'],currency_id=currency_detail['id'],plan_buy_days__gte=plan_days,coupon_expiry_datetime__gte= timezone.datetime.now(),is_active=True).values('id','uuid','code','description','discount_type','discount_value','currency_id','currency_id__currency_type').first()
                            if get_coupon != None:
                                total_coupon_amount = 0.0
                                if get_coupon['discount_type'] == 'percentage':
                                    total_coupon_amount =  (all_product_total_price * get_coupon['discount_value'])/100
                                elif get_coupon['discount_type'] == 'fixed amount':
                                    total_coupon_amount = all_product_total_price - get_coupon['discount_value']
                                total_price_after_discount -= total_coupon_amount
                                business_coupon ={
                                    'coupon_code':get_coupon['code'],
                                    'description':get_coupon['description'],
                                    'discount_type':get_coupon['discount_type'],
                                    'discount_value':get_coupon['discount_value'],
                                    'coupon_id':get_coupon['id'],
                                    'total_coupon_amount':total_coupon_amount,
                                    'company_detail_id':user_detail_page['company_detail']['id']
                                }
                            else:
                                return Response({'detail':"coupon code is not valid."},status.HTTP_400_BAD_REQUEST)
                        days_total_price_after_discount = total_price_after_discount / plan_days
                        plan_pricing_tax_detail = PlanPricingTax.objects.filter(plan_pricing_id = get_plan_days_and_discount.plan_pricing_id).values('id','uuid','plan_pricing_id','tax_percentage_detail_id','tax_percentage_detail_id__tax_percentage','tax_percentage_detail_id__tax_type')
                        tax_detail = []
                        total_price_after_tax = total_price_after_discount
                        for pricing_tax in plan_pricing_tax_detail:
                            tax_amount = (total_price_after_discount*pricing_tax['tax_percentage_detail_id__tax_percentage'])/100
                            total_price_after_tax += tax_amount
                            tax_detail.append({
                                'tax_percentage_detail_id':pricing_tax['tax_percentage_detail_id'],
                                'tax_percentage':pricing_tax['tax_percentage_detail_id__tax_percentage'],
                                'tax_type':pricing_tax['tax_percentage_detail_id__tax_type'],
                                'tax_amount':tax_amount,
                                'company_detail_id':user_detail_page['company_detail']['id']
                            })
                            total_tax_percentage+=pricing_tax['tax_percentage_detail_id__tax_percentage']
                            total_tax_in_currency+=tax_amount
                        days_total_price_after_tax = total_price_after_tax / plan_days
                        plan_start_datetime = timezone.datetime.now()
                        #plan_expire_datetime = timezone.datetime.now()+get_plan_days_and_discount.plan_days
                        plan_expire_datetime = timezone.now() + timedelta(days=get_plan_days_and_discount.plan_days)
                        plan_start_datetime = timezone.make_aware(plan_start_datetime)
                        time_diff = plan_expire_datetime - plan_start_datetime
                        total_minutes = time_diff.total_seconds()/60
                        total_days = time_diff.days
                        #get_plan_pricing = PlanPricing.objects.filter(plan_id=get_plan.id,currency_id=currency_detail['id']).values('id','country_type_id','country_type_id__country')
                        get_plan_pricing = PlanPricing.objects.filter(plan_id=get_plan.id, currency_id=currency_detail['id']).first()
                        try:
                            # Fetch the existing plan
                            existing_plan_id = request.data.get('existing_plan_id')
                            existing_plan = BusinessPlanHistory.objects.get(id=existing_plan_id)

                            # Calculate remaining days and pro-rated refund
                            # remaining_days = self.calculate_remaining_days(existing_plan)
                            # pro_rated_refund = self.calculate_pro_rated_refund(existing_plan, remaining_days)
                            remaining_value = self.calculate_remaining_value(existing_plan)
                        except :
                            return Response({'error': 'Invalid existing_plan_id'}, status=status.HTTP_400_BAD_REQUEST)

                        # Extracting new plan details from the request data
                        plans_detail = request.data.get('plans_detail')
                        plan_days_id = plans_detail.get('plan_days_id')
                        currency_type_id = request.data.get('currency_type_id')
                        country_category_id = request.data.get('country_category_id')
                        # business_id = request.user.businessdetail.id  
                        #user_detail_page = request.user.user_detail_page  # Assuming user_detail_page is linked to the user
                        currency_id = user_detail_page['company_detail']['id'] 

                        try:
                            
                            plan_days_instance = PlanDaysAndDiscount.objects.get(id=plan_days_id)
                            currency_instance = Currency.objects.get(id=currency_type_id)
                            country_instance = CountryCategory.objects.get(id=country_category_id)

                            
                            total_days = plan_days_instance.plan_days
                            discount_percentage = plan_days_instance.discount_percentage
                            currency_symbol = currency_instance.currency_symbol
                            country_type = country_instance.country

                        
                            #total_price = sum(item['price'] for item in plans_detail['plan_product'])  # Sum of all product prices
                            discount_amount = (total_price * discount_percentage) / 100
                            total_price_after_discount = total_price - discount_amount
                        # total_tax_percentage = 20
                            tax_percentage_instance = TaxPercentageDetail.objects.first()

                            total_tax_percentage = tax_percentage_instance.tax_percentage if tax_percentage_instance else None

                            total_tax_in_currency = total_price_after_discount * (total_tax_percentage / 100)
                            total_price_after_tax = total_price_after_discount + total_tax_in_currency

                            total_minutes = total_days * 24 * 60

                        
                            business_plan_history = {
                                'plan_name': get_plan.plan_name,
                                'price': total_price,
                                'price_after_discount': total_price_after_discount,
                                'price_after_tax': total_price_after_tax,
                                'days_price': total_price / total_days,
                                'days_price_after_discount': total_price_after_discount / total_days,
                                'days_price_after_tax': total_price_after_tax / total_days,
                                'currency_id': currency_detail['id'],
                                'currency_type': request.data.get('currency_type'),
                                'currency_symbol': currency_symbol,
                                'country_category_id': get_plan_pricing.country_type_id.id,
                                'country_type': country_type,
                                'plan_id': get_plan.id,
                                'plan_days_and_discount_id': get_plan_days_and_discount.id,
                                'plan_days': total_days,
                                'discount_in_percentage': discount_percentage,
                                'discount_in_currency': discount_amount,
                                'total_discount': total_price_after_discount,
                                'total_tax_in_percentage': total_tax_percentage,
                                'total_tax_in_currency': total_tax_in_currency,
                                'buy_datetime': timezone.now(),
                                'plan_start_datetime': timezone.now(),
                                'plan_expire_datetime': timezone.now() + timezone.timedelta(days=total_days),
                                'minutes_to_expire': total_minutes,
                                'days_to_expire': total_days,
                                'plan_validity': True,
                                'plan_status': 'pending',
                                'current_active': False,
                                'plan_type': 'Upgrade Plan',
                                #'currency_detail': currency_id,
                                'company_detail_id':company_id
                            }

                        
                            refund_amount = remaining_value
                            # business_plan_history['price'] = max(0, business_plan_history['price'] - refund_amount)
                            # business_plan_history['price_after_discount'] = max(0, business_plan_history['price_after_discount'] - refund_amount)
                            business_plan_history['price_after_tax'] = max(0, business_plan_history['price_after_tax'] - refund_amount)

                            print("refund amount:",refund_amount)
                            

                        except (PlanDaysAndDiscount.DoesNotExist, Currency.DoesNotExist, CountryCategory.DoesNotExist, CompanyDetail.DoesNotExist) as e:
                            return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)

                        # try:
                        #     existing_plan_id = request.data.get('existing_plan_id')
                        #     existing_plan = BusinessPlanHistory.objects.get(id=existing_plan_id)

                        #     remaining_days = self.calculate_remaining_days(existing_plan)
                        #     pro_rated_refund = self.calculate_pro_rated_refund(existing_plan, remaining_days)

                        #     # Subtract the pro-rated refund from the new plan's price
                        #     business_plan_history['price'] -= pro_rated_refund
                        #     business_plan_history['price_after_discount'] -= pro_rated_refund
                        #     business_plan_history['price_after_tax'] -= pro_rated_refund

                        #     # Ensure prices do not go below zero
                        #     business_plan_history['price'] = max(0, business_plan_history['price'])
                        #     business_plan_history['price_after_discount'] = max(0, business_plan_history['price_after_discount'])
                        #     business_plan_history['price_after_tax'] = max(0, business_plan_history['price_after_tax'])

                        # except BusinessPlanHistory.DoesNotExist:
                        #     return Response({'error': 'Invalid existing_plan_id'}, status=status.HTTP_400_BAD_REQUEST)



                        # business_plan_history = {
                        #     'plan_name':get_plan.plan_name,
                        #     'price':total_price,
                        #     'price_after_discount':total_price_after_discount,
                        #     'price_after_tax':total_price_after_tax,
                        #     'days_price':days_total_price,
                        #     'days_price_after_discount': days_total_price_after_discount,
                        #     'days_price_after_tax': days_total_price_after_tax,
                        #     'currency_id':currency_detail['id'],
                        #     'currency_type':currency_detail['currency_type'],
                        #     'currency_symbol':currency_detail['currency_symbol'],
                        #     # 'country_category_id':get_plan_pricing.country_type_id,
                        #     # 'country_type':get_plan_pricing.country_type_id__country,
                        #     'country_category_id':get_plan_pricing.country_type_id.id,
                        #     'country_type':get_plan_pricing.country_type_id.country,
                        #     'plan_id':get_plan.id,
                        #     'plan_days_and_discount_id':get_plan_days_and_discount.id,
                        #     'plan_days':get_plan_days_and_discount.plan_days,
                        #     'discount_in_percentage':get_plan_days_and_discount.discount_percentage,
                        #     'discount_in_currency': discount_amount,
                        #     'total_discount': total_price_after_discount,
                        #     'total_tax_in_percentage':total_tax_percentage,
                        #     'total_tax_in_currency':total_tax_in_currency,
                        #     'buy_datetime':timezone.datetime.now(),
                        #     'plan_start_datetime':timezone.datetime.now(),
                        #     #'plan_expire_datetime': datetime.datetime.now()+get_plan_days_and_discount['plan_days'],
                        #     'plan_expire_datetime': timezone.datetime.now() + timezone.timedelta(days=get_plan_days_and_discount.plan_days),
                        #     'minutes_to_expire':total_minutes,
                        #     'days_to_expire':total_days,
                        #     'plan_validity':True,
                        #     'plan_status':'pending',
                        #     'current_active':False,
                        #     'plan_type':'Upgrade Plan',
                        #     #'business_detail_id':user_detail_page['business_detail']['id']
                        #     'business_detail_id':business_id
                        # }
                        print("business plan history:",business_plan_history)
                        if 'currency_id' in business_plan_history:
                            currency_id = business_plan_history['currency_id']
                            
                            try:
                                
                                currency_instance = Currency.objects.get(id=currency_id)
                            except Currency.DoesNotExist:
                                
                                return Response({'error': 'Invalid currency_id'}, status=status.HTTP_400_BAD_REQUEST)
                        else:
                            
                            return Response({'error': 'currency_id is missing'}, status=status.HTTP_400_BAD_REQUEST)

                        
                        business_plan_history['currency_id'] = currency_instance
                        
                        if 'country_category_id' in business_plan_history:
                            country_category_id = business_plan_history['country_category_id']
                            try:
                                
                                country_category_instance = CountryCategory.objects.get(id=country_category_id)
                            except CountryCategory.DoesNotExist:
                                
                                return Response({'error': 'Invalid country_category_id'}, status=status.HTTP_400_BAD_REQUEST)
                        else:
                            
                            return Response({'error': 'country_category_id is missing'}, status=status.HTTP_400_BAD_REQUEST)

                        
                        business_plan_history['country_category_id'] = country_category_instance

                        if 'plan_id' in business_plan_history:
                            plan_id = business_plan_history['plan_id']
                            try:
                            
                                plan_instance = Plans.objects.get(id=plan_id)
                            except Plans.DoesNotExist:
                                
                                return Response({'error': 'Invalid plan_id'}, status=status.HTTP_400_BAD_REQUEST)
                        else:
                            
                            return Response({'error': 'plan_id is missing'}, status=status.HTTP_400_BAD_REQUEST)

                        
                        business_plan_history['plan_id'] = plan_instance

                        if 'plan_days_and_discount_id' in business_plan_history:
                            plan_days_and_discount_id = business_plan_history['plan_days_and_discount_id']
                            try:
                            
                                plan_days_and_discount_instance = PlanDaysAndDiscount.objects.get(id=plan_days_and_discount_id)
                            except PlanDaysAndDiscount.DoesNotExist:
                            
                                return Response({'error': 'Invalid plan_days_and_discount_id'}, status=status.HTTP_400_BAD_REQUEST)
                        else:
                            
                            return Response({'error': 'plan_days_and_discount_id is missing'}, status=status.HTTP_400_BAD_REQUEST)

                        
                        business_plan_history['plan_days_and_discount_id'] = plan_days_and_discount_instance

                        if 'company_detail_id' in business_plan_history:
                            company_detail_id = business_plan_history['company_detail_id']
                            print("company id :",company_detail_id)
                            try:
                                
                                company_detail_instance = CompanyDetail.objects.get(id=company_detail_id)
                            except CompanyDetail.DoesNotExist:
                                
                                return Response({'error': 'Invalid business_detail_id'}, status=status.HTTP_400_BAD_REQUEST)
                        else:
                        
                            return Response({'error': 'business_detail_id is missing'}, status=status.HTTP_400_BAD_REQUEST)

                        
                        business_plan_history['company_detail_id'] = company_detail_instance


                        try:
                            
                            existing_plan_id = request.data.get('existing_plan_id')
                            print("existing id ", existing_plan_id)
                        
                            #product_data = request.data.get('product_data')
                            print("PLANs DATA:",plans_data)
                            #print(business_plan_history)
                        
                            existing_plan_details = extract_existing_plan_details(existing_plan_id, product_data)
                            updated_plan_details = extract_updated_plan_details(plans_data, product_data,business_plan_history)

                            #print("Product Data:", product_data)
                            
                            with transaction.atomic():
                            
                                if is_valid_upgrade(existing_plan_details, updated_plan_details):
                                    existing_plan = BusinessPlanHistory.objects.get(id=existing_plan_id)
                                    existing_plan.current_active = False
                                    existing_plan.save()
                                    print("existing planss", existing_plan)
                                    updated_plan = BusinessPlanHistory(**business_plan_history)
                                    updated_plan.current_active = True
                                    updated_plan.save()
                                    #print("business plan history:",business_plan_history)
                                    #business_plan_history_id=updated_plan
                                    
                                    update_related_models(existing_plan_id, updated_plan_details,updated_plan)
                                    business_plan_history_instance = BusinessPlanHistory.objects.get(
                                    plan_name=business_plan_history['plan_name'],
                                    price_after_tax=business_plan_history['price_after_tax'],
                                    
                                )

                                    try:


                                        #user = User.objects.get(id=user_id)
                                        
                                        email = request.user.email
                                        print(email)
                                        phone_number = request.user.phone_number


                                        autopay_option = request.POST.get('autopay_option', None)

                                        
                                        if autopay_option == 'enable':
                                            
                                            response = create_subscription(request, business_plan_history, email, phone_number)


                                        #logger.info(f"create_subscription response: {response}")
                        
                        
                                        #return response

                                            if not response.get('success', False):

                                                print("Error details:")
                                                # traceback.print_exc()

                                                # # for obj in created_objects:
                                                # #     obj.delete()
                                                
                                                
                                                # logger.info(f"create_subscription response: {response}")
                            
                                                return response
                                            
                                            return JsonResponse({'An ERROR OCCURRED': response.get('message', 'Failed to create subscription')}, status=500)
                                    
                                    
                                        api_response_data, payment_session_id = process_cashfree_payment_upgrade(request, business_plan_history, email, phone_number)

                                        if api_response_data is None:
                                            
                                            return JsonResponse({'An ERROR OCCURRED': 'No data returned'}, status=500)
                                        
                                        if payment_session_id:
                                        
                                            # return JsonResponse({'payment_session_id': payment_session_id})
                                            # return Response(api_response_data)
                                            # response_data = {
                                            #     'api_response_data': api_response_data,
                                            #     'payment_session_id': payment_session_id
                                            # }
                                            # return Response(response_data)
                                            return render(request, 'checkout.html', {'payment_session_id': payment_session_id})
                                        else:
                                            
                                            return JsonResponse({'An ERROR OCCURRED': 'Payment session ID not found'}, status=500)

                                    #         #serialized_data = serializers.serialize('json', [api_response_data])
                                    
                                    except Exception as e:
                                        # for obj in created_objects:
                                        #     obj.delete()
                                        
                                        return JsonResponse({'AN ERROR OCCURRED': str(e)}, status=500)
                                                
                                        

                                    
                                else:
                                    return Response({'error': 'Invalid upgrade request'}, status=status.HTTP_400_BAD_REQUEST)

                        # except ObjectDoesNotExist:
                        #     return Response({'error': 'BusinessPlanHistory does not exist'}, status=status.HTTP_400_BAD_REQUEST)

                        except Exception as e:
                            return Response({'error': f'Upgrade and payment failed: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
                                    
                        #             return Response({'message': 'Upgrade successful'}, status=status.HTTP_200_OK)
                        #         else:
                        #             return Response({'error': 'Invalid upgrade request'}, status=status.HTTP_400_BAD_REQUEST)
                        # except Exception as e:
                        #     return Response({'error': f'Upgrade failed: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
            
                    # business_plan_history_serializer = BusinessPlanHistorySerializer(data=business_plan_history)
                    # business_plan_history_id = None
                    # if business_plan_history_serializer.is_valid():
                    #     business_plan_history_obj = business_plan_history_serializer.save()
                    #     business_plan_history_id = business_plan_history_obj.id
                    # else:
                    #     return Response(business_plan_history_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                    # business_pricing_tax_ids = []
                    # for business_pricing_tax in tax_detail:
                    #     business_pricing_tax['business_plan_history_id'] = business_plan_history_id
                    #     business_pricing_tax_serializer = BusinessPlanPricingTaxSerializer(data=business_pricing_tax)
                    #     business_pricing_tax_id = None
                    #     if business_pricing_tax_serializer.is_valid():
                    #         business_pricing_tax_obj = business_pricing_tax_serializer.save()
                    #         business_pricing_tax_id = business_pricing_tax_obj.id
                    #         business_pricing_tax_ids.append(business_pricing_tax_id)
                    #     else:
                    #         return Response(business_plan_history_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                    # business_plan_coupon_id = None
                    # if business_coupon != None:
                    #     business_coupon['business_plan_history_id'] = business_plan_history_id
                    #     business_coupon_serializer = BusinessPlanCoupon(data=business_coupon)
                    #     if business_coupon_serializer.is_valid():
                    #         business_coupon_obj = business_coupon_serializer.save()
                    #         business_plan_coupon_id = business_coupon_obj.id
                    #     else:
                    #         for business_plan_pricing_tax_id in business_pricing_tax_ids:
                    #             BusinessPlanPricingTax.objects.filter(id=business_plan_pricing_tax_id).delete()
                    #         for business_pricing_id in business_pricing_tier_ids:
                    #             BusinessPricingTier.objects.filter(id=business_pricing_id).delete()
                    #         BusinessPlanHistory.objects.filter(id=business_plan_history_id).delete()
                    # business_pricing_tier_ids = []
                    # for plans in plans_data:
                    #     plans['business_plan_history_id'] = business_plan_history_id
                    #     business_pricing_tier_serializer = BusinessPricingTierSerializer(data=plans)
                    #     business_pricing_tier_id = None
                    #     if business_pricing_tier_serializer.is_valid():
                    #         business_pricing_tier_obj = business_pricing_tier_serializer.save()
                    #         business_pricing_tier_id = business_pricing_tier_obj.id
                    #         business_pricing_tier_ids.append(business_pricing_tier_id)
                    #     else:
                    #         if business_plan_coupon_id != None:
                    #             BusinessPlanCoupon.objects.filter(id=business_plan_coupon_id).delete()
                    #         for business_plan_pricing_tax_id in business_pricing_tax_ids:
                    #             BusinessPlanPricingTax.objects.filter(id=business_plan_pricing_tax_id).delete()
                    #         for business_pricing_id in business_pricing_tier_ids:
                    #             BusinessPricingTier.objects.filter(id=business_pricing_id).delete()
                    #         BusinessPlanHistory.objects.filter(id=business_plan_history_id).delete()
                    #         return Response(business_pricing_tier_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                    
                
                    else:
                        return Response({"detail": "Plans days doesn't exist."}, status=status.HTTP_400_BAD_REQUEST)
                else:
                    return Response({"detail": "Plans not exist."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)
        

        
    def put(self, request,id,format=None):
        user_detail_page = get_user_data_page_plans(request.user.id,'upgrade_plan','view')
        AccessToPage = False
        if user_detail_page['permission'] != None:
            AccessToPage = True
        if AccessToPage == True:
            data = request.data
            print(data)
            plans_data = {}
            plans_detail = data['plans_detail']
            selected_products = plans_detail['plan_product']
            # valid_products = []
            # product_data_list = []
            # selected_products = plans_detail['products']
            print("selected products:",selected_products)
            for product in selected_products:
                # product_id = product['product_id']
                product_id = product['product_id']
                product_name = product['product_name']
                # product_name = product['product_name']
                print("product_names",product_name)
            currency_detail = Currency.objects.filter(currency_type=request.data['currency_type']).values('id','currency_type','currency_symbol').first()
            get_plan = Plans.objects.filter(id=plans_detail['id'],plan_name=plans_detail['plan_name']).first()
            #get_plan = Plans.objects.filter(id=id).first()
            #print(get_plan)
            id = get_plan.id
            plan_name = get_plan.plan_name
            get_plan_days_and_discount_all = PlanDaysAndDiscount.objects.filter(plan_id=id).all()
            plans_data['plan_days']= []
            plan_days = 0
            total_price=0
            total_price_after_discount=0
            final_online_data_dashboard_price=0.0
            final_offline_data_dashboard_price=0.0
            all_product_total_price=0.0
            discount_amount=0
            for plan_days_detail in get_plan_days_and_discount_all:
                selected = False
                if data['plan_days_id'] == plan_days_detail.id:
                    selected = True
                    plan_days = plan_days_detail.plan_days
                    plan_pricing_id = plan_days_detail.plan_pricing_id.id
                plans_data['plan_days'].append({
                   # 'id':plan_days_detail.id,
                    'plan_days':plan_days_detail.plan_days,
                    'discount_percentage':plan_days_detail.discount_percentage,
                    'category':plan_days_detail.category,
                    'default_select':selected,
                    #'plan_pricing_id':plan_days_detail.plan_pricing_id
                   # 'plan_pricing_id': plan_pricing_id
                    
                })
            get_plan_days_and_discount = PlanDaysAndDiscount.objects.filter(plan_id=id,id=data['plan_days_id']).first()
            plans_data['product_data'] = []
            if get_plan_days_and_discount != None:
                plan_days = get_plan_days_and_discount.plan_days
                product_data = plans_detail['plan_product'][0]
                product_data_list = []
                parking_product_data_list = []
                all_parking_product_data = []
                for product in selected_products:
                    product_name = product['product_name']
                    print("Processing product name:", product_name)
                    plan_feature_pricing_tier_id = product['plan_feature_pricing_tier_id']
                    print("Processing plan features name:", plan_feature_pricing_tier_id)
                    camera_detail_list = []
                    camera_quantity = product['plan_camera_detail']['camera_quantity']
                    print("Camera quantity for product:", camera_quantity)
                    # camera_quantity = product_data['plan_camera_detail']['camera_quantity']
                    parking_product_data = PlanFeaturePricingTier.objects.filter(
                        plan_id=id,
                        pricing_feature_category_id__category_name="Product",
                        default_product_id__product_name=product_name,
                        id=plan_feature_pricing_tier_id,
                        show_plan_pricing=True
                    ).values(
                        'id', 'uuid', 'default_product_id', 'default_product_id__product_name',
                        'pricing_feature_category_id', 'pricing_feature_category_id__category_name',
                        'plan_id', 'plan_pricing_description', 'show_plan_pricing'
                    ).all()

                    for item in parking_product_data:
                        all_parking_product_data.append(item)
                    print("All parking product data:", all_parking_product_data)

                
                for parking_product_data in all_parking_product_data:
                    print("Processing parking product data:", parking_product_data)
                    
                    plan_feature_days_price_product = PlanFeatureDaysPrice.objects.filter(
                        plans_id=id,
                        plan_days_and_discount_id=get_plan_days_and_discount.id,
                        plan_feature_pricing_tier_id=parking_product_data['id'],
                        currency_id=data['currency_type_id']
                    ).values(
                        'id', 'uuid', 'backup_days_id', 'plan_days_and_discount_id',
                        'days_price', 'currency_id', 'currency_id__currency_symbol', 'default_selected'
                    ).all()

                    print("Plan feature days price product:", plan_feature_days_price_product)
                    plan_feature_days_price_product_instance = plan_feature_days_price_product.first()

                    if plan_feature_days_price_product_instance:
                        default_product_price = plan_days * camera_quantity * plan_feature_days_price_product_instance['days_price']
                        default_product_price_days = camera_quantity * plan_feature_days_price_product_instance['days_price']
                    else:
                        default_product_price = 0
                        default_product_price_days = 0

                    product_selected_exist = True

                    product_data_json = {
                        'product_name': parking_product_data['default_product_id__product_name'],
                        'plan_product': [{
                            'days_price': default_product_price_days,
                            'price': default_product_price,
                            'default_selected': product_selected_exist,
                            'plan_pricing_description': parking_product_data['plan_pricing_description'],
                        }]
                    }
                    total_price += default_product_price
                    product_data_list.append(product_data_json)
                    print("Product data JSON:", product_data_json)
                # parking_product_data = PlanFeaturePricingTier.objects.filter(plan_id=id,pricing_feature_category_id__category_name="Product",default_product_id__product_name='Violation surveillance',id=plans_detail['plan_product'][0]['plan_feature_pricing_tier_id'],show_plan_pricing=True).values('id','uuid','default_product_id','default_product_id__product_name','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                # print("parkingpdata",parking_product_data)
                # all_product_total_price = 0.0
                # if parking_product_data != None:
                #     camera_quantity = product_data['plan_camera_detail']['camera_quantity']
                #     product_data_json = {}
                #    # product_data_json['id'] = parking_product_data['id']
                #     product_data_json['product_name'] = parking_product_data['default_product_id__product_name']

                #     plan_feature_days_price_product = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=parking_product_data['id'],currency_id=data['currency_type_id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                #     plan_feature_days_price_product_instance = plan_feature_days_price_product.first()

                #     if plan_feature_days_price_product_instance:
                #            default_product_price = plan_days * camera_quantity * plan_feature_days_price_product_instance['days_price']
                #            default_product_price_days = camera_quantity * plan_feature_days_price_product_instance['days_price']
                #     else:
                #         #print("error in defaultproductprice")
                #             default_product_price = 0 
                #             default_product_price_days = 0
                #     product_selected_exist = True
                #     # product_selected_exist = True
                #     # default_product_price = plan_days * camera_quantity * plan_feature_days_price_product['days_price']
                #     # default_product_price_days = camera_quantity * plan_feature_days_price_product['days_price']

                #     product_data_json['plan_product']={
                #         # 'id':parking_product_data['id'],
                #         # 'uuid':parking_product_data['uuid'],
                #         'days_price':default_product_price_days,
                #         'price': default_product_price,
                #         #'currency_symbol':plan_feature_days_price_product_instance['currency_id__currency_symbol'],
                #        # 'currency_id':currency_detail['id'],
                #         #'pricing_feature_category_id':parking_product_data['pricing_feature_category_id'],
                #         #'category_name':parking_product_data['pricing_feature_category_id__category_name'],
                #        # 'default_selected':product_selected_exist,
                #         #'plan_id':parking_product_data['plan_id'],
                #         'plan_pricing_description':parking_product_data['plan_pricing_description'],
                #         #'show_plan_pricing':parking_product_data['show_plan_pricing']
                #     }

                    # default_parking_product_feature_data = PlanFeaturePricingTier.objects.filter(plan_id=id,pricing_feature_category_id__category_name="Feature",default_product_id__product_name='Violation surveillance',is_encluded_plan_feature_id__isnull=False,default_product_feature_id__isnull=False).values('id','uuid','default_product_id','default_product_id__product_name','default_product_feature_id','default_product_feature_id__feature','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').all()
                    # product_data_json['plan_product_feature_default'] = []
                    # for default_product_feature in default_parking_product_feature_data:
                    #     product_data_json['plan_product_feature_default'].append({
                    #         # 'id':default_product_feature['id'],
                    #         # 'uuid':default_product_feature['uuid'],
                    #         # 'default_product_feature_id':default_product_feature['default_product_feature_id'],
                    #         # 'pricing_feature_category_id':default_product_feature['pricing_feature_category_id'],
                    #         'category_name':default_product_feature['pricing_feature_category_id__category_name'],
                    #         'feature_name':default_product_feature['default_product_feature_id__feature'],
                    #         'plan_pricing_description':default_product_feature['plan_pricing_description'],       
                    #     })
                    # parking_product_feature_data = PlanFeaturePricingTier.objects.filter(plan_id=id,pricing_feature_category_id__category_name="Feature",default_product_id__product_name='Violation surveillance',is_encluded_plan_feature_id__isnull=True,default_product_feature_id__isnull=False).values('id','uuid','default_product_id','default_product_id__product_name','default_product_feature_id','default_product_feature_id__feature','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').all()
                    # product_data_json['plan_product_feature'] = []
                    # default_product_feature_price = 0.0
                    # for product_feature in parking_product_feature_data:
                    #     # plan_feature_days_price_product_feature = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=product_feature['id'],currency_id=data['currency_type_id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                    #     # product_feature_price = plan_days * camera_quantity * plan_feature_days_price_product_feature['days_price']
                    #     # product_feature_price_days = camera_quantity * plan_feature_days_price_product_feature['days_price']
                    #     # default_selected = False
                    #     plan_feature_days_price_product_feature = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=product_feature['id'],currency_id=currency_detail['id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                    #     plan_feature_days_price_product_feature_instance = plan_feature_days_price_product_feature.first()  
                    #     if plan_feature_days_price_product_feature_instance:
                    #         product_feature_price = plan_days * camera_quantity * plan_feature_days_price_product_feature_instance['days_price']
                    #         product_feature_price_days = camera_quantity * plan_feature_days_price_product_feature_instance['days_price']
                    #     else:
                            
                    #         product_feature_price = 0  
                    #     # product_feature_price = plan_days * camera_quantity * plan_feature_days_price_product_feature_instance['days_price']
                    #     # product_feature_price_days = camera_quantity * plan_feature_days_price_product_feature_instance['days_price']
                    #     default_selected = False
                        
                    #     product_feature_price = plan_days * camera_quantity * plan_feature_days_price_product_feature_instance['days_price']
                    #     product_feature_price_days = camera_quantity * plan_feature_days_price_product_feature_instance['days_price']
                    #     default_selected = False
                    #     feature_plan_selected = [feature_plan for feature_plan in product_data['plan_feature_detail'] if feature_plan['plan_feature_pricing_tier_id']==product_feature['id'] and feature_plan['selected']==True]
                    #     if len(feature_plan_selected) > 0:
                    #         default_selected = True
                    #         default_product_feature_price += product_feature_price
                    #         plans_data.append({
                    #             'price':product_feature_price,
                    #             'days_price':product_feature_price_days,
                    #             'currency_id':currency_detail['id'],
                    #             # 'default_product_id':parking_product_data['default_product_id'],
                    #             # 'default_product_feature_id':product_feature['default_product_feature_id'],
                    #             # 'plan_feature_pricing_category_id':product_feature['pricing_feature_category_id'],
                    #             'category_name':product_feature['pricing_feature_category_id__category_name'],
                    #            # 'plan_id':id,
                    #             #'plan_feature_pricing_tier_id':product_feature['id'],
                    #             #'business_detail_id':user_detail_page['business_detail']['id'],
                    #             'plan_pricing_description':product_feature['plan_pricing_description']
                    #         })
                    existing_plan_id = request.data.get('existing_plan_id')
                    #existing_plan = BusinessPlanHistory.objects.get(id=existing_plan_id)
                    existing_plan = BusinessPlanHistory.objects.get(id=existing_plan_id)
                    # try:
                    #     remaining_value = self.calculate_remaining_value(existing_plan)
                    # except BusinessPlanHistory.DoesNotExist:
                    #     return JsonResponse({'error': 'Invalid existing_plan_id'}, status=status.HTTP_400_BAD_REQUEST)
                    # refund_amount = remaining_value
                    product_data_json['plan_camera_detail']= []
                    default_product_ids = [item['default_product_id'] for item in all_parking_product_data]
                # for parking_product_instance in all_parking_product_data:

                #         default_product_id = parking_product_instance['default_product_id']
                    print("deafult product",default_product_ids)
            
                    plan_features_pricing_tier_cameras = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id__in=default_product_ids,pricing_feature_category_id__category_name='Camera').values('id','uuid', 'default_product_id' , 'min_quantity','max_quantity','default_quantity','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').all()
                    print("plan_features_pricing_tier_cameras",plan_features_pricing_tier_cameras)
                    # print(list(plan_features_pricing_tier_cameras))
                    if isinstance(plan_features_pricing_tier_cameras, dict):
   
                        plan_features_pricing_tier_cameras = [plan_features_pricing_tier_cameras]
                    else:
                        
                        pass

                    
                    plan_features_pricing_tier_camera_dict = {item['default_product_id']: item for item in plan_features_pricing_tier_cameras}
                    for parking_product_instance in all_parking_product_data:
                        default_product_id = parking_product_instance['default_product_id']
                        print("default product", default_product_id)

                        product_camera_detail_list = []
                        camera_quantity = product_data['plan_camera_detail']['camera_quantity']
                        # camera_quantity = product['plan_camera_detail']['camera_quantity']
                        
                        plan_features_pricing_tier_camera = plan_features_pricing_tier_camera_dict.get(default_product_id)
                        print("plan_features_pricing_tier_camera",plan_features_pricing_tier_camera)
                        print(f"Processing product with plan_feature_pricing_tier_id: {product['plan_feature_pricing_tier_id']}, camera_quantity: {camera_quantity}")
                    
                    
                    # plan_features_pricing_tier_camera = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Camera').values('id','uuid','min_quantity','max_quantity','default_quantity','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                    # print("plan_features_pricing_tier_camera",plan_features_pricing_tier_camera)
                        default_camera_price = 0.0
                        for camera in range(plan_features_pricing_tier_camera['min_quantity'],plan_features_pricing_tier_camera['max_quantity']+1):
                            plan_feature_days_price_camera = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=data['plan_days_id'],plan_feature_pricing_tier_id=plan_features_pricing_tier_camera['id'],currency_id=data['currency_type_id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol').first()
                            print("plan_feature_days_price_camera",plan_feature_days_price_camera)
                            camera_price_days = camera * plan_feature_days_price_camera['days_price']
                            default_selected = False
                            if camera_quantity == camera:
                                camera_price = plan_days * camera * plan_feature_days_price_camera['days_price']
                                default_camera_price = camera_price
                                default_selected = True
                                existing_camera_quantity = BusinessPricingTier.objects.filter(
                                business_plan_history_id=existing_plan.id,
                                category_name='Camera'
                                ).first()
                                if existing_camera_quantity:
                                    existing_camera_quantity_value = existing_camera_quantity.quantity
                                else:
                                    # Handle the case where no existing camera quantity data is found
                                    existing_camera_quantity_value = 0
                                if camera < existing_camera_quantity_value:
                                    return Response({'detail': 'You cannot decrease the camera quantity.'}, status=status.HTTP_400_BAD_REQUEST)
                                # camera_detail_list.append({
                                #     'camera_quantity': camera_quantity,
                                #     'days_price': camera_price_days,
                                #     'price': default_camera_price,
                                #     'currency_symbol': plan_feature_days_price_camera['currency_id__currency_symbol'],
                                #     'category_name':plan_features_pricing_tier_camera['pricing_feature_category_id__category_name'],
                                #     'default_selected': default_selected,
                                #     'plan_pricing_description':plan_features_pricing_tier_camera['plan_pricing_description'],
                                # })

                                # total_camera_quantity = sum(detail['camera_quantity'] for detail in camera_detail_list)
                                total_price += default_camera_price
                                # product_data_json['plan_camera_detail'].append({
                                #         'days_price': default_camera_price_days,
                                #         'total_camera_price': total_camera_price,
                                #         'total_camera_price_days': total_camera_price_days,
                                #         'total_camera_quantity': total_camera_quantity,
                                #         'currency_symbol': plan_feature_days_price_camera['currency_id__currency_symbol'],
                                #         'default_selected': default_selected,
                                #         'plan_pricing_description':plan_features_pricing_tier_camera['plan_pricing_description'],
                                #         #'camera_details': camera_detail_list
                                # })
                                product_data_json['plan_camera_detail'].append({
                                # 'id':plan_features_pricing_tier_camera['id'],
                                # 'uuid':plan_features_pricing_tier_camera['uuid'],
                                'camera_quantity':camera,
                                'days_price':camera_price_days,
                                'price': camera_price,
                                'currency_symbol':plan_feature_days_price_camera['currency_id__currency_symbol'],
                                #'pricing_feature_category_id':plan_features_pricing_tier_camera['pricing_feature_category_id'],
                                #'category_name':plan_features_pricing_tier_camera['pricing_feature_category_id__category_name'],
                            # 'default_selected':default_selected,
                                #'plan_id':plan_features_pricing_tier_camera['plan_id'],
                                'plan_pricing_description':plan_features_pricing_tier_camera['plan_pricing_description'],
                            # 'show_plan_pricing':plan_features_pricing_tier_camera['show_plan_pricing']
                            })
                        break

                    # plan_features_pricing_tier_parking_slot = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Parking Slot').values('id','uuid','min_quantity','max_quantity','default_quantity','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                    # parking_slot = product_data['plan_parking_slot_detail']['parking_slot']
                    # if parking_slot < plan_features_pricing_tier_parking_slot['min_quantity'] or parking_slot > plan_features_pricing_tier_parking_slot['max_quantity']:
                    #     return Response({'detail':'please select any one dashboard type.'},status.HTTP_400_BAD_REQUEST)
                    # # for camera in range(plan_features_pricing_tier_camera['min_quantity'],plan_features_pricing_tier_camera['max_quantity']+1):
                    # plan_feature_days_price_parking_slot = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_camera['id'],currency_id=data['currency_type_id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol').first()
                    # default_parking_slot_price = plan_days * parking_slot * plan_feature_days_price_parking_slot['days_price']
                    # praking_days_price = parking_slot * plan_feature_days_price_parking_slot['days_price']
                    # default_selected = True
                    # existing_parking_slots = BusinessPricingTier.objects.filter(
                    #     business_plan_history_id=existing_plan.id,
                    #     category_name='Parking Slot'
                    # ).first()
                    # if existing_parking_slots:
                    #     existing_parking_slot_quantity = existing_parking_slots.quantity
                    # else:
                    #     # Handle the case where no existing parking slot data is found
                    #     existing_parking_slot_quantity = 0
                    # if parking_slot < existing_parking_slot_quantity:
                    #     return Response({'detail': 'You cannot decrease the parking slot quantity.'}, status=status.HTTP_400_BAD_REQUEST)
                    # product_data_json['plan_parking_slots']={
                    #     # 'id':plan_features_pricing_tier_parking_slot['id'],
                    #     # 'uuid':plan_features_pricing_tier_parking_slot['uuid'],
                    #     'parking_slot':parking_slot,
                    #     'days_price':praking_days_price,
                    #     'price': default_parking_slot_price,
                    #     'currency_symbol':plan_feature_days_price_parking_slot['currency_id__currency_symbol'],
                    #     # 'pricing_feature_category_id':plan_features_pricing_tier_parking_slot['pricing_feature_category_id'],
                    #     #'category_name':plan_features_pricing_tier_parking_slot['pricing_feature_category_id__category_name'],
                    #     # 'default_selected':default_selected,
                    #     # 'plan_id':plan_features_pricing_tier_parking_slot['plan_id'],
                    #     'plan_pricing_description':plan_features_pricing_tier_parking_slot['plan_pricing_description'],
                    #     # 'show_plan_pricing':plan_features_pricing_tier_parking_slot['show_plan_pricing']
                    # }

                    if product_data['plan_online_dashboard']['selected'] == False and data['plan_offline_dashboard']['selected'] == False: 
                        return Response({'detail':'please select any one dashboard type.'},status.HTTP_400_BAD_REQUEST)
                    product_data_json['plan_online_dashboard'] = []
                    plan_features_pricing_tier_online_dashboards = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id__in=default_product_ids,pricing_feature_category_id__category_name='Online Dashboard').values('id','uuid','default_product_id', 'pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').all()
                    print("plan_features_pricing_tier_online_dashboards",plan_features_pricing_tier_online_dashboards)
                    
                    if isinstance(plan_features_pricing_tier_online_dashboards, dict):
   
                        plan_features_pricing_tier_online_dashboards = [plan_features_pricing_tier_online_dashboards]
                    else:
                        
                        pass
                    plan_features_pricing_tier_online_dashboard_dict = {item['default_product_id']: item for item in plan_features_pricing_tier_online_dashboards}
                    
                    for parking_product_instance in all_parking_product_data:
                        default_product_id = parking_product_instance['default_product_id']
                        print("default product", default_product_id)
                        plan_features_pricing_tier_online_dashboard = plan_features_pricing_tier_online_dashboard_dict.get(default_product_id)
                        print("plan_features_pricing_tier_online_dashboard",plan_features_pricing_tier_online_dashboard)
                        # plan_features_pricing_tier_online_dashboard = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=default_product_id,pricing_feature_category_id__category_name='Online Dashboard').values('id','uuid','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                        plan_feature_days_price_online_dashboard = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard['id'],currency_id=data['currency_type_id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').first()
                        online_dashboard_price = plan_days * camera_quantity * plan_feature_days_price_online_dashboard['days_price']
                        online_dashboard_price_days = camera_quantity * plan_feature_days_price_online_dashboard['days_price']
                        default_online_dashboard_price = 0.0
                        if product_data['plan_online_dashboard']['selected'] == True:
                            default_online_dashboard_price = online_dashboard_price
                    total_price += online_dashboard_price
                    product_data_json['plan_online_dashboard'].append({
                            # 'id':plan_features_pricing_tier_online_dashboard['id'],
                            # 'uuid':plan_features_pricing_tier_online_dashboard['uuid'],
                            #'camera_quantity':camera_quantity,
                            'plan_days':plan_days,
                            'days_price':online_dashboard_price_days,
                            'price': online_dashboard_price,
                            'currency_symbol':plan_feature_days_price_online_dashboard['currency_id__currency_symbol'],
                            # 'pricing_feature_category_id':plan_features_pricing_tier_online_dashboard['pricing_feature_category_id'],
                            #'category_name':plan_features_pricing_tier_online_dashboard['pricing_feature_category_id__category_name'],
                            'default_selected':product_data['plan_online_dashboard']['selected'],
                            # 'plan_id':plan_features_pricing_tier_online_dashboard['plan_id'],
                            'plan_pricing_description':plan_features_pricing_tier_online_dashboard['plan_pricing_description'],
                            # 'show_plan_pricing':plan_features_pricing_tier_online_dashboard['show_plan_pricing']
                        })
                    # plan_features_pricing_tier_online_dashboard = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Online Dashboard').values('id','uuid','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                    # plan_feature_days_price_online_dashboard = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard['id'],currency_id=data['currency_type_id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').first()
                    # online_dashboard_price = plan_days * camera_quantity * plan_feature_days_price_online_dashboard['days_price']
                    # online_dashboard_price_days = camera_quantity * plan_feature_days_price_online_dashboard['days_price']
                    # default_online_dashboard_price = 0.0
                    # if product_data['plan_online_dashboard']['selected'] == True:
                    #     default_online_dashboard_price = online_dashboard_price
                    # product_data_json['plan_online_dashboard'].append({
                    #         # 'id':plan_features_pricing_tier_online_dashboard['id'],
                    #         # 'uuid':plan_features_pricing_tier_online_dashboard['uuid'],
                    #         # 'camera_quantity':camera_quantity,
                    #         'plan_days':plan_days,
                    #         'days_price':online_dashboard_price_days,
                    #         'price': online_dashboard_price,
                    #         'currency_symbol':plan_feature_days_price_online_dashboard['currency_id__currency_symbol'],
                    #         # 'pricing_feature_category_id':plan_features_pricing_tier_online_dashboard['pricing_feature_category_id'],
                    #         # 'category_name':plan_features_pricing_tier_online_dashboard['pricing_feature_category_id__category_name'],
                    #        # 'default_selected':product_data['plan_online_dashboard']['selected'],
                    #         # 'plan_id':plan_features_pricing_tier_online_dashboard['plan_id'],
                    #         'plan_pricing_description':plan_features_pricing_tier_online_dashboard['plan_pricing_description'],
                    #         # 'show_plan_pricing':plan_features_pricing_tier_online_dashboard['show_plan_pricing']
                    #     })

                    product_data_json['plan_online_dashboard_data_backup'] = []
                    plan_features_pricing_tier_online_dashboard_data_backups = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id__in=default_product_ids,pricing_feature_category_id__category_name='Online Data Backup').values('id','uuid','default_product_id', 'pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').all()
                    print("plan_features_pricing_tier_online_dashboard_data_backup",plan_features_pricing_tier_online_dashboard_data_backups)
                    
                    if isinstance(plan_features_pricing_tier_online_dashboard_data_backups, dict):
   
                        plan_features_pricing_tier_online_dashboard_data_backups = [plan_features_pricing_tier_online_dashboard_data_backups]
                    else:
                        
                        pass
                    plan_features_pricing_tier_online_dashboard_data_backup_dict = {item['default_product_id']: item for item in plan_features_pricing_tier_online_dashboard_data_backups}
                    for parking_product_instance in all_parking_product_data:
                        default_product_id = parking_product_instance['default_product_id']
                        print("default product", default_product_id)
                        plan_features_pricing_tier_online_dashboard_data_backup = plan_features_pricing_tier_online_dashboard_data_backup_dict.get(default_product_id)

                        # plan_features_pricing_tier_online_dashboard_data_backup = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=default_product_id,pricing_feature_category_id__category_name='Online Data Backup').values('id','uuid','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                        if plan_features_pricing_tier_online_dashboard_data_backup:
                            # online_data_backup = PlanFeatureDaysPrice.objects.filter(
                            #     plans_id=plans_data['id'],
                            #     plan_days_and_discount_id=plan_features_pricing_tier_online_dashboard_data_backup.id,  
                            #     plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard_data_backup.id,
                            #     currency_id=currency_type_id
                            # ).first()
                            # online_data_backup = PlanFeatureDaysPrice.objects.filter(
                            #     plans_id=id,
                            #     plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard_data_backup.id,
                            #     currency_id=data['currency_type_id']
                            # ).all()
                            online_data_backup = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard_data_backup['id'],currency_id=data['currency_type_id']).all()

                            print("online data backup", online_data_backup)

                            # if online_data_backup:
                            #     online_data_backup_price_days = plan_days * online_data_backup.days_price
                            #     online_data_backup_price = plan_days * online_data_backup_price_days
                            if online_data_backup:
                                for backup in online_data_backup:
                                    # online_data_backup_price_days = plan_days * backup.days_price
                                    # online_data_backup_price = plan_days * online_data_backup_price_days
                                    # online_data_backup_price = online_data_backup['backup_days_id__days'] * camera_quantity * online_data_backup['days_price']
                                    # online_data_backup_price_days = camera_quantity * online_data_backup['days_price']
                                    defautlt_online_dashboard_backup_price_days = camera_quantity * backup.days_price
                                    default_online_dashboard_backup_price = backup.backup_days_id.days * camera_quantity * backup.days_price
                                    default_selected = backup.default_selected
                                    # default_selected = False
                                    print("backup",backup)
                                # if product_data['plan_online_data_backup']['backup_id'] == online_data_backup['id'] and data['plan_online_dashboard']['selected'] == True:
                                #     default_online_dashboard_backup_price = online_data_backup_price
                                #     default_selected = True
                                    # default_selected = False
                                    # if (
                                    #     product_data['plan_online_data_backup']['backup_id'] == backup.id and
                                    #     data['plan_online_dashboard']['selected']
                                    # ):
                                    #     default_online_dashboard_backup_price = online_data_backup_price
                                    #     default_selected = True
                                    # if plan_features_pricing_tier_online_dashboard_data_backup.default_quantity == backup.backup_days_id.days:
                                    #     default_selected = True
                                    #     default_online_dashboard_backup_price = online_data_backup_price
                                    total_price += default_online_dashboard_backup_price
                                    product_data_json['plan_online_dashboard_data_backup'].append({
                                        'id': backup.id,
                                        'backup_days': backup.backup_days_id.days,
                                        'days_price': defautlt_online_dashboard_backup_price_days,
                                        'price': default_online_dashboard_backup_price,
                                        'currency_symbol': backup.currency_id.currency_symbol,
                                        'default_selected': default_selected,
                                        'plan_pricing_description': plan_features_pricing_tier_online_dashboard_data_backup['plan_pricing_description'],
                                    })
                    # plan_features_pricing_tier_online_dashboard_data_backup = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Online Data Backup').values('id','uuid','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                    # if plan_features_pricing_tier_online_dashboard_data_backup:
                    #     # online_data_backup = PlanFeatureDaysPrice.objects.filter(
                    #     #     plans_id=plans_data['id'],
                    #     #     plan_days_and_discount_id=plan_features_pricing_tier_online_dashboard_data_backup.id,  
                    #     #     plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard_data_backup.id,
                    #     #     currency_id=currency_type_id
                    #     # ).first()
                    #     # online_data_backup = PlanFeatureDaysPrice.objects.filter(
                    #     #     plans_id=id,
                    #     #     plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard_data_backup.id,
                    #     #     currency_id=data['currency_type_id']
                    #     # ).all()
                    #     online_data_backup = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard_data_backup['id'],currency_id=data['currency_type_id']).all()

                    #     print("online data backup", online_data_backup)
                        
                    #     # if online_data_backup:
                    #     #     online_data_backup_price_days = plan_days * online_data_backup.days_price
                    #     #     online_data_backup_price = plan_days * online_data_backup_price_days
                    #     if online_data_backup:
                    #         for backup in online_data_backup:
                    #             default_online_dashboard_backup_price_days = camera_quantity * backup.days_price
                    #             default_online_dashboard_backup_price = backup.backup_days_id.days * camera_quantity * backup.days_price
                    #             default_selected = backup.default_selected
                    #             # default_selected = False
                    #             print("backup",backup)
                    #         # if product_data['plan_online_data_backup']['backup_id'] == online_data_backup['id'] and data['plan_online_dashboard']['selected'] == True:
                    #         #     default_online_dashboard_backup_price = online_data_backup_price
                    #         #     default_selected = True
                    #             # default_selected = False
                    #             # if (
                    #             #     product_data['plan_online_data_backup']['backup_id'] == backup.id and
                    #             #     data['plan_online_dashboard']['selected']
                    #             # ):
                    #             #     default_online_dashboard_backup_price = online_data_backup_price
                    #             #     default_selected = True
                    #             # if plan_features_pricing_tier_online_dashboard_data_backup.default_quantity == backup.backup_days_id.days:
                    #             #     default_selected = True
                    #             #     default_online_dashboard_backup_price = online_data_backup_price
                            
                    #             if default_selected:
                    #                 final_online_data_dashboard_price = default_online_dashboard_backup_price
                    #                 print("final_online_dashboard_price",final_online_data_dashboard_price)
                    #             product_data_json['plan_online_dashboard_data_backup'].append({
                    #                 'id': backup.id,
                    #                 'backup_days': backup.backup_days_id.days,
                    #                 'days_price': default_online_dashboard_backup_price_days,
                    #                 'price': final_online_data_dashboard_price,
                    #                 'currency_symbol': backup.currency_id.currency_symbol,
                    #                 'default_selected': default_selected,
                    #                 'plan_pricing_description': plan_features_pricing_tier_online_dashboard_data_backup['plan_pricing_description'],
                    #             })

                    product_data_json['plan_offline_dashboard'] = []
                    plan_features_pricing_tier_offline_dashboards = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id__in=default_product_ids,pricing_feature_category_id__category_name='Offline Dashboard').values('id','uuid','default_product_id', 'pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').all()
                    print("plan_features_pricing_tier_offline_dashboards",plan_features_pricing_tier_offline_dashboards)
                    
                    if isinstance(plan_features_pricing_tier_offline_dashboards, dict):
   
                        plan_features_pricing_tier_offline_dashboards = [plan_features_pricing_tier_offline_dashboards]
                    else:
                        
                        pass
                    plan_features_pricing_tier_offline_dashboard_dict = {item['default_product_id']: item for item in plan_features_pricing_tier_offline_dashboards}

                    for parking_product_instance in all_parking_product_data:
                        default_product_id = parking_product_instance['default_product_id']
                        print("default product", default_product_id)
                        plan_features_pricing_tier_offline_dashboard = plan_features_pricing_tier_offline_dashboard_dict.get(default_product_id)
                        # plan_features_pricing_tier_offline_dashboard = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=default_product_id,pricing_feature_category_id__category_name='Offline Dashboard').values('id','uuid','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                        plan_feature_days_price_offline_dashboard = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_offline_dashboard['id'],currency_id=data['currency_type_id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').first()
                        offline_dashboard_price = plan_days * camera_quantity * plan_feature_days_price_offline_dashboard['days_price']
                        offline_dashboard_price_days = camera_quantity * plan_feature_days_price_offline_dashboard['days_price']
                        default_offline_dashboard_price = 0.0
                        if product_data['plan_offline_dashboard']['selected'] == True:
                            default_offline_dashboard_price = offline_dashboard_price
                    total_price += offline_dashboard_price
                    product_data_json['plan_offline_dashboard'].append({
                            # 'id':plan_features_pricing_tier_offline_dashboard['id'],
                            # 'uuid':plan_features_pricing_tier_offline_dashboard['uuid'],
                            # 'camera_quantity':camera_quantity,
                            'plan_days':plan_days,
                            'days_price':offline_dashboard_price_days,
                            'price': offline_dashboard_price,
                            'currency_symbol':plan_feature_days_price_offline_dashboard['currency_id__currency_symbol'],
                            # 'pricing_feature_category_id':plan_features_pricing_tier_offline_dashboard['pricing_feature_category_id'],
                            # 'category_name':plan_features_pricing_tier_offline_dashboard['pricing_feature_category_id__category_name'],
                            'default_selected':product_data['plan_offline_dashboard']['selected'],
                            # 'plan_id':plan_features_pricing_tier_offline_dashboard['plan_id'],
                            'plan_pricing_description':plan_features_pricing_tier_offline_dashboard['plan_pricing_description'],
                            # 'show_plan_pricing':plan_features_pricing_tier_offline_dashboard['show_plan_pricing']
                        })

                    print("product data:", product_data_json)
                    # plan_features_pricing_tier_offline_dashboard = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Offline Dashboard').values('id','uuid','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                    # plan_feature_days_price_offline_dashboard = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_offline_dashboard['id'],currency_id=data['currency_type_id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').first()
                    # offline_dashboard_price = plan_days * camera_quantity * plan_feature_days_price_offline_dashboard['days_price']
                    # offline_dashboard_price_days = camera_quantity * plan_feature_days_price_offline_dashboard['days_price']
                    # default_offline_dashboard_price = 0.0
                    # if product_data['plan_offline_dashboard']['selected'] == True:
                    #     default_offline_dashboard_price = offline_dashboard_price
                    # product_data_json['plan_offline_dashboard'].append({
                    #         # 'id':plan_features_pricing_tier_offline_dashboard['id'],
                    #         # 'uuid':plan_features_pricing_tier_offline_dashboard['uuid'],
                    #         # 'camera_quantity':camera_quantity,
                    #         'plan_days':plan_days,
                    #         'days_price':offline_dashboard_price_days,
                    #         'price': offline_dashboard_price,
                    #         'currency_symbol':plan_feature_days_price_offline_dashboard['currency_id__currency_symbol'],
                    #         # 'pricing_feature_category_id':plan_features_pricing_tier_offline_dashboard['pricing_feature_category_id'],
                    #         # 'category_name':plan_features_pricing_tier_offline_dashboard['pricing_feature_category_id__category_name'],
                    #         #'default_selected':product_data['plan_offline_dashboard']['selected'],
                    #         # 'plan_id':plan_features_pricing_tier_offline_dashboard['plan_id'],
                    #         'plan_pricing_description':plan_features_pricing_tier_offline_dashboard['plan_pricing_description'],
                    #         # 'show_plan_pricing':plan_features_pricing_tier_offline_dashboard['show_plan_pricing']
                    #     })

                    product_data_json['plan_offline_dashboard_data_backup'] = []
                    plan_features_pricing_tier_offline_dashboard_data_backups = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id__in=default_product_ids,pricing_feature_category_id__category_name='Offline Data Backup').values('id','uuid','default_product_id', 'pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').all()
                    print("plan_features_pricing_tier_offline_dashboard_data_backup",plan_features_pricing_tier_offline_dashboard_data_backups)
                    
                    if isinstance(plan_features_pricing_tier_offline_dashboard_data_backups, dict):
   
                        plan_features_pricing_tier_offline_dashboard_data_backups = [plan_features_pricing_tier_offline_dashboard_data_backups]
                    else:
                        
                        pass
                    plan_features_pricing_tier_offline_dashboard_data_backup_dict = {item['default_product_id']: item for item in plan_features_pricing_tier_offline_dashboard_data_backups}
                    for parking_product_instance in all_parking_product_data:
                        default_product_id = parking_product_instance['default_product_id']
                        print("default product", default_product_id)
                        plan_features_pricing_tier_offline_dashboard_data_backup = plan_features_pricing_tier_offline_dashboard_data_backup_dict.get(default_product_id)
                        # plan_features_pricing_tier_offline_dashboard_data_backup = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=default_product_id,pricing_feature_category_id__category_name='Offline Data Backup').values('id','uuid','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                        if plan_features_pricing_tier_offline_dashboard_data_backup:
                            # online_data_backup = PlanFeatureDaysPrice.objects.filter(
                            #     plans_id=plans_data['id'],
                            #     plan_days_and_discount_id=plan_features_pricing_tier_online_dashboard_data_backup.id,  
                            #     plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard_data_backup.id,
                            #     currency_id=currency_type_id
                            # ).first()
                            # online_data_backup = PlanFeatureDaysPrice.objects.filter(
                            #     plans_id=id,
                            #     plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard_data_backup.id,
                            #     currency_id=data['currency_type_id']
                            # ).all()
                            offline_data_backup = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_offline_dashboard_data_backup['id'],currency_id=data['currency_type_id']).all()

                            print("offline data backup", offline_data_backup)

                            # if online_data_backup:
                            #     online_data_backup_price_days = plan_days * online_data_backup.days_price
                            #     online_data_backup_price = plan_days * online_data_backup_price_days
                            if offline_data_backup:
                                for backup in offline_data_backup:
                                    default_offline_dashboard_backup_price_days = camera_quantity * backup.days_price
                                    default_offline_dashboard_backup_price = backup.backup_days_id.days * camera_quantity * backup.days_price
                                    default_selected = backup.default_selected
                                    # default_selected = False
                                    print("backup",backup)
                                # if product_data['plan_online_data_backup']['backup_id'] == online_data_backup['id'] and data['plan_online_dashboard']['selected'] == True:
                                #     default_online_dashboard_backup_price = online_data_backup_price
                                #     default_selected = True
                                    # default_selected = False
                                    # if (
                                    #     product_data['plan_online_data_backup']['backup_id'] == backup.id and
                                    #     data['plan_online_dashboard']['selected']
                                    # ):
                                    #     default_online_dashboard_backup_price = online_data_backup_price
                                    #     default_selected = True
                                    # if plan_features_pricing_tier_online_dashboard_data_backup.default_quantity == backup.backup_days_id.days:
                                    #     default_selected = True
                                    #     default_online_dashboard_backup_price = online_data_backup_price
                                    total_price += default_offline_dashboard_backup_price
                                    product_data_json['plan_offline_dashboard_data_backup'].append({
                                        'id': backup.id,
                                        'backup_days': backup.backup_days_id.days,
                                        'days_price': default_offline_dashboard_backup_price_days,
                                        'price': default_offline_dashboard_backup_price,
                                        'currency_symbol': backup.currency_id.currency_symbol,
                                        'default_selected': default_selected,
                                        'plan_pricing_description': plan_features_pricing_tier_offline_dashboard_data_backup['plan_pricing_description'],
                                    })
                    # plan_features_pricing_tier_offline_dashboard_data_backup = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Offline Data Backup').values('id','uuid','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                    # if plan_features_pricing_tier_offline_dashboard_data_backup:
                    #     # online_data_backup = PlanFeatureDaysPrice.objects.filter(
                    #     #     plans_id=plans_data['id'],
                    #     #     plan_days_and_discount_id=plan_features_pricing_tier_online_dashboard_data_backup.id,  
                    #     #     plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard_data_backup.id,
                    #     #     currency_id=currency_type_id
                    #     # ).first()
                    #     # online_data_backup = PlanFeatureDaysPrice.objects.filter(
                    #     #     plans_id=id,
                    #     #     plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard_data_backup.id,
                    #     #     currency_id=data['currency_type_id']
                    #     # ).all()
                    #     offline_data_backup = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_offline_dashboard_data_backup['id'],currency_id=data['currency_type_id']).all()

                    #     print("offline data backup", offline_data_backup)

                    #     # if online_data_backup:
                    #     #     online_data_backup_price_days = plan_days * online_data_backup.days_price
                    #     #     online_data_backup_price = plan_days * online_data_backup_price_days
                    #     if offline_data_backup:
                    #         for backup in offline_data_backup:
                    #             default_offline_dashboard_backup_price_days = camera_quantity * backup.days_price
                    #             default_offline_dashboard_backup_price = backup.backup_days_id.days * camera_quantity * backup.days_price
                    #             default_selected = backup.default_selected
                    #             # default_selected = False 
                    #             print("backup",backup)
                    #         # if product_data['plan_online_data_backup']['backup_id'] == online_data_backup['id'] and data['plan_online_dashboard']['selected'] == True:
                    #         #     default_online_dashboard_backup_price = online_data_backup_price
                    #         #     default_selected = True
                    #             # default_selected = False
                    #             # if (
                    #             #     product_data['plan_online_data_backup']['backup_id'] == backup.id and
                    #             #     data['plan_online_dashboard']['selected']
                    #             # ):
                    #             #     default_online_dashboard_backup_price = online_data_backup_price
                    #             #     default_selected = True
                    #             # if plan_features_pricing_tier_online_dashboard_data_backup.default_quantity == backup.backup_days_id.days:
                    #             #     default_selected = True
                    #             #     default_online_dashboard_backup_price = online_data_backup_price
                    #             if default_selected:
                    #                 final_offline_data_dashboard_price = default_offline_dashboard_backup_price
                    #                 print("final_offline_dashboard_price",final_offline_data_dashboard_price)
                    #             product_data_json['plan_offline_dashboard_data_backup'].append({
                    #                 'id': backup.id,
                    #                 'backup_days': backup.backup_days_id.days,
                    #                 'days_price': default_offline_dashboard_backup_price_days,
                    #                 'price': final_offline_data_dashboard_price,
                    #                 'currency_symbol': backup.currency_id.currency_symbol,
                    #                 'default_selected': default_selected,
                    #                 'plan_pricing_description': plan_features_pricing_tier_offline_dashboard_data_backup['plan_pricing_description'],
                    #             })
                    
                    # total_price = camera_price + online_dashboard_price +final_online_data_dashboard_price + offline_dashboard_price + final_offline_data_dashboard_price + default_product_price+default_product_feature_price
                    all_product_total_price+=total_price
                    print("total_price",total_price)
                    # existing_plan_id = data.get('existing_plan_id')
                    # try:
                    #     existing_plan = BusinessPlanHistory.objects.get(id=existing_plan_id)
                    #     remaining_value = self.calculate_remaining_value(existing_plan)
                    # except BusinessPlanHistory.DoesNotExist:
                    #     return JsonResponse({'error': 'Invalid existing_plan_id'}, status=status.HTTP_400_BAD_REQUEST)

                   
                    # refund_amount = min(remaining_value, total_price)

                    # default_camera_price = sum(product['plan_camera_detail']['camera_quantity'] * 10 for product in plans_detail['plan_product'])
                    # default_online_dashboard_price = sum(100 for product in plans_detail['plan_product'] if product['plan_online_dashboard']['selected'])
                    # default_online_dashboard_backup_price = sum(50 for product in plans_detail['plan_product'] if product['plan_online_data_backup']['backup_id'])
                    # default_offline_dashboard_price = sum(80 for product in plans_detail['plan_product'] if product['plan_offline_dashboard']['selected'])
                    # default_offline_dashboard_backup_price = sum(30 for product in plans_detail['plan_product'] if product['plan_offline_data_backup']['backup_id'])
                    # default_product_price = sum(product['plan_camera_detail']['camera_quantity'] * 5 for product in plans_detail['plan_product'])
                    # default_product_feature_price = 0  
                    
                    # total_price = (
                    #     default_camera_price + 
                    #     default_online_dashboard_price + 
                    #     default_online_dashboard_backup_price + 
                    #     default_offline_dashboard_price + 
                    #     default_offline_dashboard_backup_price + 
                    #     default_product_price + 
                    #     default_product_feature_price
                    # )

                    print("total price",total_price)
                    # existing_plan_id = data.get('existing_plan_id')
                    try:
                        existing_plan = BusinessPlanHistory.objects.get(id=existing_plan_id)
                        remaining_value = self.calculate_remaining_value(existing_plan)
                    except BusinessPlanHistory.DoesNotExist:
                        return JsonResponse({'error': 'Invalid existing_plan_id'}, status=status.HTTP_400_BAD_REQUEST)

                    
                    refund_amount = remaining_value

                    adjusted_total_price = max(0, total_price - refund_amount)
                   
                   
                    plans_data['product_data'].append(product_data_json)
                    discount_amount = (adjusted_total_price * get_plan_days_and_discount.discount_percentage)/100
                    total_price_after_discount = adjusted_total_price - discount_amount
                    if plans_detail['coupon_code'] != None:
                        get_coupon = Coupon.objects.filter(code=plans_detail['coupon_code'],currency_id=data['currency_type_id'],plan_buy_days__gte=plan_days,coupon_expiry_datetime__gte= timezone.datetime.now(),is_active=True).values('id','uuid','code','description','discount_type','discount_value','currency_id','currency_id__currency_type').first()
                        if get_coupon != None:
                            total_coupon_amount = 0.0
                            if get_coupon['discount_type'] == 'percentage':
                                total_coupon_amount =  (all_product_total_price * get_coupon['discount_value'])/100
                            elif get_coupon['discount_type'] == 'fixed amount':
                                total_coupon_amount = all_product_total_price - get_coupon['discount_value']
                            total_price_after_discount -= total_coupon_amount

                        plans_data['coupon_code'] ={
                            # 'id':get_coupon['id'],
                            # 'uuid':get_coupon['uuid'],
                            'code':get_coupon['code'],
                            'description':get_coupon['description'],
                            'discount_type':get_coupon['discount_type'],
                            'discount_value':get_coupon['discount_value'],
                            # 'currency_id':get_coupon['currency_id'],
                            'total_coupon_amount':total_coupon_amount
                        }

                    else:
                        return Response({'detail':"coupon code is not valid."},status.HTTP_400_BAD_REQUEST)

                plan_pricing_tax_detail = PlanPricingTax.objects.filter(plan_pricing_id = get_plan_days_and_discount.plan_pricing_id).values('id','uuid','plan_pricing_id','tax_percentage_detail_id','tax_percentage_detail_id__tax_percentage','tax_percentage_detail_id__tax_type')
                tax_detail = []
                total_price_after_tax = total_price_after_discount
                for pricing_tax in plan_pricing_tax_detail:
                    tax_amount = (total_price_after_discount*pricing_tax['tax_percentage_detail_id__tax_percentage'])/100
                    total_price_after_tax += tax_amount
                    tax_detail.append({
                        # 'id':pricing_tax['id'],
                        # 'uuid':pricing_tax['uuid'],
                        # 'tax_percentage_detail_id':pricing_tax['tax_percentage_detail_id'],
                        'tax_percentage':pricing_tax['tax_percentage_detail_id__tax_percentage'],
                        'tax_type':pricing_tax['tax_percentage_detail_id__tax_type'],
                        'tax_amount':tax_amount
                    })
                plans_data['plan_pricing'] ={
                    'total_price':total_price,
                    'refund_amount':refund_amount,
                    'adjusted_total_amount': adjusted_total_price,
                    'discount_percent':get_plan_days_and_discount.discount_percentage,
                    'discount_amount':discount_amount,
                    'total_price_after_discount':total_price_after_discount,
                    'total_price_after_tax':total_price_after_tax,
                    'tax_detail':tax_detail
                }
                    
            return Response(plans_data, status=status.HTTP_200_OK)
        else:
            return Response({"detail": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)
        
class GetUpgradePlanDetail(APIView):
    permission_classes = (AllowAny,)
    def get(self, request,existing_plan_id):
            currency_type_id = request.GET.get('currency', 1)
            print("currencytypeid:", currency_type_id)
            plans_data = {}
                
            try:
                    existing_plan = BusinessPlanHistory.objects.get(id=existing_plan_id)
                    print(existing_plan)
            except BusinessPlanHistory.DoesNotExist:
                    return Response({'error': 'Existing plan not found'}, status=404)
        # user_detail_page = get_user_data_page_plans(request.user.id,'upgrade_plan','view')  
        # print("udp", user_detail_page)
        # AccessToPage = False
        # if user_detail_page['permission'] != None:
        #     AccessToPage = True
        # if AccessToPage == True:
            # currency_type_id = request.GET.get('currency',4)
            # print("currencytypeid:", currency_type_id)
            # plans_data = {}
            default_online_dashboard_backup_price=0.0
            default_offline_dashboard_backup_price=0.0
            get_plan = existing_plan.plan_id
            print(get_plan)
            plans_data['id'] = get_plan.id
            print(plans_data)
            plans_data['plan_name'] = get_plan.plan_name
            get_plan_days_and_discount_all = PlanDaysAndDiscount.objects.filter(plan_id=get_plan.id).all()
            print(get_plan_days_and_discount_all)
            plans_data['plan_days']= []

            for plan_days_detail in get_plan_days_and_discount_all:
                # plan_days = user_detail_page['business_plan_history_detail'].plan_days
                # default_selected = False
                default_selected = existing_plan.plan_days == plan_days_detail.plan_days
                print(default_selected)
                #if plan_days == plan_days_detail.plan_days:
                    #default_selected = True
                # plan_days_and_discount_id = user_detail_page['business_plan_history_detail']['plan_days_and_discount_id']
                plans_data['plan_days'].append({
                   # 'id':plan_days_detail.id,
                    'plan_days':plan_days_detail.plan_days,
                    'discount_percentage':plan_days_detail.discount_percentage,
                    'category':plan_days_detail.category,
                    #'default_select':default_selected,
                   # 'plan_pricing_id':plan_days_detail.plan_pricing_id
                })
                print(plans_data)
                get_plan_days_and_discount = PlanDaysAndDiscount.objects.filter(plan_id=get_plan.id,default_select=True).first()
                plans_data['product_data'] = []
                if get_plan_days_and_discount != None:
                    plan_days = get_plan_days_and_discount.plan_days
                    print("PLAN DAYS:", plan_days)
                    desired_product_names = ['Gate Site', 'Train Site', 'In and Out Object Site', 'Occupancy management site']
                all_product_total_price = 0.0

                for product_name in desired_product_names:
                    product_data_json = {}
                    product_data_json['product_name'] = product_name

                    parking_product_data = PlanFeaturePricingTier.objects.filter(
                        plan_id=get_plan.id, pricing_feature_category_id__category_name="Product",
                        default_product_id__product_name=product_name
                    ).values(
                        'id', 'uuid', 'default_product_id', 'default_product_id__product_name',
                        'pricing_feature_category_id', 'pricing_feature_category_id__category_name',
                        'plan_id', 'plan_pricing_description', 'show_plan_pricing'
                    ).first()

                    if parking_product_data is not None:
                        plan_feature_days_price_product = PlanFeatureDaysPrice.objects.filter(
                            plans_id=get_plan.id, plan_days_and_discount_id=get_plan_days_and_discount.id,
                            plan_feature_pricing_tier_id=parking_product_data['id'], currency_id=currency_type_id
                        ).values(
                            'id', 'uuid', 'backup_days_id', 'plan_days_and_discount_id', 'days_price',
                            'currency_id', 'currency_id__currency_symbol', 'default_selected'
                        ).all()

                        plan_feature_days_price_product_instance = plan_feature_days_price_product.first()

                        if plan_feature_days_price_product_instance:
                            default_product_price = plan_days * plan_feature_days_price_product_instance['days_price']
                            default_product_price_days = plan_feature_days_price_product_instance['days_price']
                        else:
                            default_product_price = 0
                            default_product_price_days = 0

                        product_data_json['plan_product'] = {
                            'days_price': default_product_price_days,
                            'price': default_product_price,
                            'currency_symbol': plan_feature_days_price_product_instance['currency_id__currency_symbol'],
                        }

                        default_parking_product_feature_data = PlanFeaturePricingTier.objects.filter(
                            plan_id=get_plan.id, pricing_feature_category_id__category_name="Feature",
                            default_product_id__product_name=product_name,
                            is_encluded_plan_feature_id__isnull=False,
                            default_product_feature_id__isnull=False
                        ).values(
                            'id', 'uuid', 'default_product_id', 'default_product_id__product_name',
                            'default_product_feature_id', 'default_product_feature_id__feature',
                            'pricing_feature_category_id', 'pricing_feature_category_id__category_name',
                            'plan_id', 'plan_pricing_description', 'show_plan_pricing'
                        ).all()

                        product_data_json['plan_product_feature_default'] = []
                        for default_product_feature in default_parking_product_feature_data:
                            product_data_json['plan_product_feature_default'].append({
                                'category_name': default_product_feature['pricing_feature_category_id__category_name'],
                                'feature_name': default_product_feature['default_product_feature_id__feature'],
                                'plan_pricing_description': default_product_feature['plan_pricing_description'],
                            })

                        parking_product_feature_data = PlanFeaturePricingTier.objects.filter(
                            plan_id=get_plan.id, pricing_feature_category_id__category_name="Feature",
                            default_product_id__product_name=product_name,
                            is_encluded_plan_feature_id__isnull=True,
                            default_product_feature_id__isnull=False
                        ).values(
                            'id', 'uuid', 'default_product_id', 'default_product_id__product_name',
                            'default_product_feature_id', 'default_product_feature_id__feature',
                            'pricing_feature_category_id', 'pricing_feature_category_id__category_name',
                            'plan_id', 'plan_pricing_description', 'show_plan_pricing'
                        ).all()

                        product_data_json['plan_product_feature'] = []
                        default_product_feature_price = 0.0

                        for product_feature in parking_product_feature_data:
                            plan_feature_days_price_product_feature = PlanFeatureDaysPrice.objects.filter(
                                plans_id=get_plan.id, plan_days_and_discount_id=get_plan_days_and_discount.id,
                                plan_feature_pricing_tier_id=product_feature['id'], currency_id=currency_type_id
                            ).values(
                                'id', 'uuid', 'backup_days_id', 'plan_days_and_discount_id', 'days_price',
                                'currency_id', 'currency_id__currency_symbol', 'default_selected'
                            ).all()

                            plan_feature_days_price_product_feature_instance = plan_feature_days_price_product_feature.first()

                            if plan_feature_days_price_product_feature_instance:
                                product_feature_price = plan_days * plan_feature_days_price_product_feature_instance['days_price']
                                product_feature_price_days = plan_feature_days_price_product_feature_instance['days_price']
                            else:
                                product_feature_price = 0

                            default_product_feature_price += product_feature_price

                            product_data_json['plan_product_feature'].append({
                                'days_price': product_feature_price_days,
                                'price': product_feature_price,
                                'currency_symbol': plan_feature_days_price_product_feature_instance['currency_id__currency_symbol'],
                                'feature_name': product_feature['default_product_feature_id__feature'],
                                'plan_pricing_description': product_feature['plan_pricing_description'],
                            })
                            product_data_json['plan_camera_detail'] = []

                            # plan_feature_pricing_tier_camera = PlanFeaturePricingTier.objects.filter(
                            #     plan_id=plans_data['id'],
                            #     pricing_feature_category_id__category_name='Camera'
                            # ).first()
                            plan_features_pricing_tier_camera = PlanFeaturePricingTier.objects.filter(plan_id=plans_data['id'], pricing_feature_category_id__category_name='Camera').first()

                            camera_quantity = plan_features_pricing_tier_camera.default_quantity
                            if plan_features_pricing_tier_camera:
                                plan_feature_days_price_camera = PlanFeatureDaysPrice.objects.filter(
                                    plans_id=plans_data['id'],
                                    plan_days_and_discount_id=get_plan_days_and_discount_all.first().id,
                                    plan_feature_pricing_tier_id=plan_features_pricing_tier_camera.id,
                                    currency_id=currency_type_id
                                ).first()

                                if plan_feature_days_price_camera:
                                    
                                        total_quantity = 0
                                        total_days_price = 0
                                        total_price = 0

                                    
                                        for camera in range(plan_features_pricing_tier_camera.min_quantity, plan_features_pricing_tier_camera.max_quantity + 1):
                                            print(f"Allowed quantity of cameras: {camera}")

                                        
                                            camera_price = plan_days * camera * plan_feature_days_price_camera.days_price
                                            camera_price_days = camera * plan_feature_days_price_camera.days_price

                                        
                                            total_quantity += camera
                                            total_days_price += camera_price_days
                                            total_price += camera_price

                                        
                                        product_data_json['plan_camera_detail'].append({
                                            'quantity': camera_quantity,
                                            'days_price': total_days_price,
                                            'price': camera_price,
                                            'currency_symbol': plan_feature_days_price_camera.currency_id.currency_symbol,
                                            'plan_pricing_description': plan_features_pricing_tier_camera.plan_pricing_description,
                                        })
                            product_data_json['plan_online_dashboard'] = []
                            plan_features_pricing_tier_online_dashboard = PlanFeaturePricingTier.objects.filter(plan_id=get_plan.id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Online Dashboard').values('id','uuid','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                            plan_feature_days_price_online_dashboard = PlanFeatureDaysPrice.objects.filter(plans_id=get_plan.id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard['id'],currency_id=currency_type_id).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').first()
                            online_dashboard_price = plan_days * camera_quantity * plan_feature_days_price_online_dashboard['days_price']
                            online_dashboard_price_days = camera_quantity * plan_feature_days_price_online_dashboard['days_price']
                            default_selected = False
                            default_online_dashboard_price = 0.0
                            #if user_detail_page['plans_detail']['online_dashboard_detail'] != None:
                            online_dashboard_exists = False
                            # for plan_detail in user_detail_page['plans_detail']:
                            #     if 'online_dashboard_detail' in plan_detail:
                            #         online_dashboard_exists = True
                            #         break

                            
                            default_selected = True
                            default_online_dashboard_price = online_dashboard_price
                            product_data_json['plan_online_dashboard'].append({
                                    # 'id':plan_features_pricing_tier_online_dashboard['id'],
                                    # 'uuid':plan_features_pricing_tier_online_dashboard['uuid'],
                                    #'camera_quantity':camera_quantity,
                                    'plan_days':plan_days,
                                    'days_price':online_dashboard_price_days,
                                    'price': online_dashboard_price,
                                    'currency_symbol':plan_feature_days_price_online_dashboard['currency_id__currency_symbol'],
                                    # 'pricing_feature_category_id':plan_features_pricing_tier_online_dashboard['pricing_feature_category_id'],
                                    # 'category_name':plan_features_pricing_tier_online_dashboard['pricing_feature_category_id__category_name'],
                                    'default_selected':default_selected,
                                    # 'plan_id':plan_features_pricing_tier_online_dashboard['plan_id'],
                                    'plan_pricing_description':plan_features_pricing_tier_online_dashboard['plan_pricing_description'],
                                    # 'show_plan_pricing':plan_features_pricing_tier_online_dashboard['show_plan_pricing']
                            
                                })    
                            plan_features_pricing_tier_online_dashboard_data_backup = PlanFeaturePricingTier.objects.filter(
                                    plan_id=plans_data['id'], 
                                    pricing_feature_category_id__category_name='Online Data Backup'
                                    ).first()

                            if plan_features_pricing_tier_online_dashboard_data_backup:
                                # online_data_backup = PlanFeatureDaysPrice.objects.filter(
                                #     plans_id=plans_data['id'],
                                #     plan_days_and_discount_id=plan_features_pricing_tier_online_dashboard_data_backup.id,  
                                #     plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard_data_backup.id,
                                #     currency_id=currency_type_id
                                # ).first()
                                online_data_backup = PlanFeatureDaysPrice.objects.filter(
                                    plans_id=plans_data['id'],
                                    plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard_data_backup.id,
                                    currency_id=currency_type_id
                                ).all()

                                print("online data backup", online_data_backup)
                                product_data_json['plan_online_dashboard_data_backup'] = []

                                # if online_data_backup:
                                #     online_data_backup_price_days = plan_days * online_data_backup.days_price
                                #     online_data_backup_price = plan_days * online_data_backup_price_days
                                if online_data_backup:
                                    for backup in online_data_backup:
                                        online_data_backup_price_days = plan_days * backup.days_price
                                        online_data_backup_price = plan_days * online_data_backup_price_days
                                        
                                        default_selected = False
                                        if plan_features_pricing_tier_online_dashboard_data_backup.default_quantity == backup.backup_days_id.days:
                                            default_selected = True
                                            default_online_dashboard_backup_price = online_data_backup_price
                                        
                                        product_data_json['plan_online_dashboard_data_backup'].append({
                                            'id': backup.id,
                                            'backup_days': backup.backup_days_id.days,
                                            'days_price': online_data_backup_price_days,
                                            'price': online_data_backup_price,
                                            'currency_symbol': backup.currency_id.currency_symbol,
                                            'default_selected': default_selected,
                                            'plan_pricing_description': plan_features_pricing_tier_online_dashboard_data_backup.plan_pricing_description,
                                        })    
                            product_data_json['plan_offline_dashboard'] = []
                            plan_features_pricing_tier_offline_dashboard = PlanFeaturePricingTier.objects.filter(plan_id=get_plan.id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Offline Dashboard').values('id','uuid','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                            plan_feature_days_price_offline_dashboard = PlanFeatureDaysPrice.objects.filter(plans_id=get_plan.id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_offline_dashboard['id'],currency_id=currency_type_id).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').first()
                            offline_dashboard_price = plan_days * camera_quantity * plan_feature_days_price_offline_dashboard['days_price']
                            offline_dashboard_price_days = camera_quantity * plan_feature_days_price_offline_dashboard['days_price']
                            default_selected = False
                            default_offline_dashboard_price = 0.0
                            # if user_detail_page['plans_detail']['offline_dashboard_detail'] != None:
                            offline_dashboard_exists = False
                            # for plan_detail in user_detail_page['plans_detail']:
                            #     if 'offline_dashboard_detail' in plan_detail:
                            #         offline_dashboard_exists = True
                            #         break

                        
                            default_selected = True
                            default_offline_dashboard_price = offline_dashboard_price
                            product_data_json['plan_offline_dashboard'].append({
                                    # 'id':plan_features_pricing_tier_offline_dashboard['id'],
                                    # 'uuid':plan_features_pricing_tier_offline_dashboard['uuid'],
                                    #'camera_quantity':camera_quantity,
                                    'plan_days':plan_days,
                                    'days_price':offline_dashboard_price_days,
                                    'price': offline_dashboard_price,
                                    'currency_symbol':plan_feature_days_price_offline_dashboard['currency_id__currency_symbol'],
                                    # 'pricing_feature_category_id':plan_features_pricing_tier_offline_dashboard['pricing_feature_category_id'],
                                    # 'category_name':plan_features_pricing_tier_offline_dashboard['pricing_feature_category_id__category_name'],
                                    'default_selected':default_selected,
                                    # 'plan_id':plan_features_pricing_tier_offline_dashboard['plan_id'],
                                    'plan_pricing_description':plan_features_pricing_tier_offline_dashboard['plan_pricing_description'],
                                    # 'show_plan_pricing':plan_features_pricing_tier_offline_dashboard['show_plan_pricing']
                                })     
                            plan_features_pricing_tier_offline_dashboard_data_backup = PlanFeaturePricingTier.objects.filter(
                                    plan_id=plans_data['id'], 
                                    pricing_feature_category_id__category_name='Offline Data Backup'
                                    ).first()

                            if plan_features_pricing_tier_offline_dashboard_data_backup:
                                # online_data_backup = PlanFeatureDaysPrice.objects.filter(
                                #     plans_id=plans_data['id'],
                                #     plan_days_and_discount_id=plan_features_pricing_tier_online_dashboard_data_backup.id,  
                                #     plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard_data_backup.id,
                                #     currency_id=currency_type_id
                                # ).first()
                                offline_data_backup = PlanFeatureDaysPrice.objects.filter(
                                    plans_id=plans_data['id'],
                                    plan_feature_pricing_tier_id=plan_features_pricing_tier_offline_dashboard_data_backup.id,
                                    currency_id=currency_type_id
                                ).all()

                                
                                product_data_json['plan_offline_dashboard_data_backup'] = []

                                # if online_data_backup:
                                #     online_data_backup_price_days = plan_days * online_data_backup.days_price
                                #     online_data_backup_price = plan_days * online_data_backup_price_days
                                if offline_data_backup:
                                    for backup in offline_data_backup:
                                        offline_data_backup_price_days = plan_days * backup.days_price
                                        offline_data_backup_price = plan_days * offline_data_backup_price_days
                                        
                                        default_selected = False
                                        if plan_features_pricing_tier_offline_dashboard_data_backup.default_quantity == backup.backup_days_id.days:
                                            default_selected = True
                                            default_offline_dashboard_backup_price = offline_data_backup_price
                                        
                                        product_data_json['plan_offline_dashboard_data_backup'].append({
                                            'id': backup.id,
                                            'backup_days': backup.backup_days_id.days,
                                            'days_price': offline_data_backup_price_days,
                                            'price': offline_data_backup_price,
                                            'currency_symbol': backup.currency_id.currency_symbol,
                                            'default_selected': default_selected,
                                            'plan_pricing_description': plan_features_pricing_tier_offline_dashboard_data_backup.plan_pricing_description,
                                        })

                        total_price = camera_price + online_dashboard_price + offline_dashboard_price + offline_data_backup_price + online_data_backup_price  +default_product_price + default_product_feature_price
                        all_product_total_price += total_price
                        plans_data['product_data'].append(product_data_json)

                discount_amount = (all_product_total_price * get_plan_days_and_discount.discount_percentage) / 100
                total_price_after_discount = all_product_total_price - discount_amount
                plans_data['coupon_code'] = None

                plan_pricing_tax_detail = PlanPricingTax.objects.filter(
                    plan_pricing_id=get_plan_days_and_discount.plan_pricing_id
                ).values(
                    'id', 'uuid', 'plan_pricing_id', 'tax_percentage_detail_id',
                    'tax_percentage_detail_id__tax_percentage', 'tax_percentage_detail_id__tax_type'
                )

                tax_detail = []
                total_price_after_tax = total_price_after_discount

                for pricing_tax in plan_pricing_tax_detail:
                    tax_amount = (total_price_after_discount * pricing_tax['tax_percentage_detail_id__tax_percentage']) / 100
                    total_price_after_tax += tax_amount
                    tax_detail.append({
                        'tax_percentage': pricing_tax['tax_percentage_detail_id__tax_percentage'],
                        'tax_type': pricing_tax['tax_percentage_detail_id__tax_type'],
                        'tax_amount': tax_amount
                    })

                plan_pricing = PlanPricingView(
                    total_price=all_product_total_price,
                    discount_amount=discount_amount,
                    total_price_after_discount=total_price_after_discount,
                    total_price_after_tax=total_price_after_tax,
                    tax_detail=tax_detail
                )

                response_data = {
                    'plan_pricing': plan_pricing.to_dict(),
                    'product_data': plans_data['product_data']
                }

                return JsonResponse(response_data, status=status.HTTP_200_OK)

            return JsonResponse({'error': 'No plan days and discount found'}, status=status.HTTP_404_NOT_FOUND)  
        # else:
        #     return Response({"detail": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

class RenewPlanView(APIView):
    permission_classes = (IsAuthenticated,)
    def post(self, request):
        user_detail_page = get_user_data_page_plans(request.user.id,'upgrade_plan','create')  
        AccessToPage = False
        if user_detail_page['permission'] != None:
            AccessToPage = True
        if AccessToPage == True:
            #plans_detail =  request.data
            data = request.data
            total_price=0.0
            total_tax_in_currency = 0.0
            total_tax_percentage = 0.0
            all_product_total_price = 0.0
            default_product_feature_price = 0.0
            online_dashboard_price = 0.0
            online_data_backup_price = 0.0
            offline_dashboard_price = 0.0
            offline_data_backup_price = 0.0
            currency_detail = Currency.objects.filter(currency_type=request.data['currency_type']).values('id','currency_type','currency_symbol').first()
            #currency_detail = Currency.objects.filter(currency_type=request.data['currency_type']).values('id','currency_type','currency_symbol').first()
            plans_detail = data['plans_detail']
            selected_products = plans_detail['plan_product']
            valid_products = []
            for product in selected_products:
                product_id = product['product_id']
                product_name = product['product_name']
                print("product_names", product_name)
                product_exists = DefaultProduct.objects.filter(id=product_id, product_name=product_name).exists()
                if not product_exists:
                    # for obj in reversed(created_objects):
                    #     obj.delete()
                    return Response({'error': f"Product '{product_name}' with ID '{product_id}' does not exist in the database."}, status=status.HTTP_400_BAD_REQUEST)
                valid_products.append(product)
                print("valid product:",valid_products)

            products = ['Gate Site', 'Train Site', 'In and Out Object Site', 'Occupancy management site']
            plans_data = []

            for product_name in products:
                product_data = next((product for product in valid_products if product['product_name'] == product_name), None)
                print("product_data",product_data)
                if product_data is None:
                    continue
                get_plan = Plans.objects.filter(id=plans_detail['id'],plan_name=plans_detail['plan_name']).first()
                #get_plan = Plans.objects.filter(id=plans_detail['id'],plan_name=plans_detail['plan_name']).first()
                if get_plan != None:
                    id = get_plan.id
                    plan_name = get_plan.plan_name
                    get_plan_days_and_discount = PlanDaysAndDiscount.objects.filter(plan_id=id,id=plans_detail['plan_days_id'],default_select=True).first()
                    print("gpdad",get_plan_days_and_discount)
                    if get_plan_days_and_discount != None:
                        plans_data= []
                        plan_days = get_plan_days_and_discount.plan_days
                        
                    # plan_features_pricing_tier_camera = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Camera').values('id','uuid','min_quantity','max_quantity','default_quantity','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                        product_data = plans_detail['plan_product'][0]
                        camera_quantity = product_data['plan_camera_detail']['camera_quantity']
                        parking_product_data = PlanFeaturePricingTier.objects.filter(plan_id=id,pricing_feature_category_id__category_name="Product",default_product_id__product_name=product_name,id=product_data['plan_feature_pricing_tier_id'],show_plan_pricing=True).values('id','uuid','default_product_id','default_product_id__product_name','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                        print("ppd",parking_product_data)
                        if parking_product_data != None:
                            
                            plan_features_pricing_tier_camera = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Camera').values('id','uuid','min_quantity','max_quantity','default_quantity','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                            plan_feature_days_price_product = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=parking_product_data['id'],currency_id=currency_detail['id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                            plan_feature_days_price_product_instance = plan_feature_days_price_product.first()

                            if plan_feature_days_price_product_instance:
                                default_product_price = plan_days * camera_quantity * plan_feature_days_price_product_instance['days_price']
                                default_product_price_days = camera_quantity * plan_feature_days_price_product_instance['days_price']
                            else:
                                #print("error in defaultproductprice")
                                default_product_price = 0 
                                default_product_price_days = 0
                            product_selected_exist = True
                            # product_selected_exist = True
                            # default_product_price = plan_days * camera_quantity * plan_feature_days_price_product['days_price']
                            # default_product_price_days = camera_quantity * plan_feature_days_price_product['days_price']
                            plans_data.append({
                                'price':default_product_price,
                                'days_price':default_product_price_days,
                                'currency_id':currency_detail['id'],
                                'default_product_id':parking_product_data['default_product_id'],
                                'plan_feature_pricing_category_id':parking_product_data['pricing_feature_category_id'],
                                'category_name':parking_product_data['pricing_feature_category_id__category_name'],
                                'plan_id':id,
                                'plan_feature_pricing_tier_id':parking_product_data['id'],
                                'company_detail_id':user_detail_page['company_detail']['id'],
                                'plan_pricing_description':parking_product_data['plan_pricing_description']
                            })
                            default_parking_product_feature_data = PlanFeaturePricingTier.objects.filter(plan_id=id,pricing_feature_category_id__category_name="Feature",default_product_id__product_name=product_name,is_encluded_plan_feature_id__isnull=False,default_product_feature_id__isnull=False).values('id','uuid','default_product_id','default_product_id__product_name','default_product_feature_id','default_product_feature_id__feature','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').all()
                            for default_product_feature in default_parking_product_feature_data:
                                plans_data.append({
                                    'price':0.0,
                                    'days_price':0.0,
                                    'currency_id':currency_detail['id'],
                                    'default_product_id':parking_product_data['default_product_id'],
                                    'default_product_feature_id':default_product_feature['default_product_feature_id'],
                                    'plan_feature_pricing_category_id':default_product_feature['pricing_feature_category_id'],
                                    'category_name':default_product_feature['pricing_feature_category_id__category_name'],
                                    'plan_id':id,
                                    'plan_feature_pricing_tier_id':default_product_feature['id'],
                                    'company_detail_id':user_detail_page['company_detail']['id'],
                                    'plan_pricing_description':default_product_feature['plan_pricing_description']
                                })
                            parking_product_feature_data = PlanFeaturePricingTier.objects.filter(plan_id=id,pricing_feature_category_id__category_name="Feature",default_product_id__product_name=product_name,is_encluded_plan_feature_id__isnull=True,default_product_feature_id__isnull=False).values('id','uuid','default_product_id','default_product_id__product_name','default_product_feature_id','default_product_feature_id__feature','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').all()
                            
                            for product_feature in parking_product_feature_data:
                                # plan_feature_days_price_product_feature = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=product_feature['id'],currency_id=plans_detail['currency_type_id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                                # product_feature_price = plan_days * camera_quantity * plan_feature_days_price_product_feature['days_price']
                                # product_feature_price_days = camera_quantity * plan_feature_days_price_product_feature['days_price']
                                plan_feature_days_price_product_feature = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=product_feature['id'],currency_id=currency_detail['id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                                plan_feature_days_price_product_feature_instance = plan_feature_days_price_product_feature.first()  
                                if plan_feature_days_price_product_feature_instance:
                                    product_feature_price = plan_days * camera_quantity * plan_feature_days_price_product_feature_instance['days_price']
                                    product_feature_price_days = camera_quantity * plan_feature_days_price_product_feature_instance['days_price']
                                else:
                                    
                                    product_feature_price = 0  
                                default_selected = False
                                feature_plan_selected = [feature_plan for feature_plan in product_data['plan_feature_detail'] if feature_plan['plan_feature_pricing_tier_id']==product_feature['id'] and feature_plan['selected']==True]
                                if len(feature_plan_selected) > 0:
                                    default_selected = True
                                    default_product_feature_price += product_feature_price
                                    plans_data.append({
                                        'price':product_feature_price,
                                        'days_price':product_feature_price_days,
                                        'currency_id':currency_detail['id'],
                                        'default_product_id':parking_product_data['default_product_id'],
                                        'default_product_feature_id':product_feature['default_product_feature_id'],
                                        'plan_feature_pricing_category_id':product_feature['pricing_feature_category_id'],
                                        'category_name':product_feature['pricing_feature_category_id__category_name'],
                                        'plan_id':id,
                                        'plan_feature_pricing_tier_id':product_feature['id'],
                                        'company_detail_id':user_detail_page['company_detail']['id'],
                                        'plan_pricing_description':product_feature['plan_pricing_description']
                                    })
                            plan_feature_days_price_camera = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_camera['id'],currency_id=currency_detail['id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol').first()
                            camera_price = plan_days * camera_quantity * plan_feature_days_price_camera['days_price']
                            camera_price_days = camera_quantity * plan_feature_days_price_camera['days_price']
                            plans_data.append({
                                'quantity':camera_quantity,
                                'price':camera_price,
                                'days_price':camera_price_days,
                                'currency_id':currency_detail['id'],
                                'plan_feature_pricing_category_id':plan_features_pricing_tier_camera['pricing_feature_category_id'],
                                'category_name':plan_features_pricing_tier_camera['pricing_feature_category_id__category_name'],
                                'plan_id':id,
                                'plan_feature_pricing_tier_id':plan_features_pricing_tier_camera['id'],
                                'company_detail_id':user_detail_page['company_detail']['id'],
                                'plan_pricing_description':plan_features_pricing_tier_camera['plan_pricing_description']
                            })
                            
                            if product_data['plan_online_dashboard']['selected'] == False and product_data['plan_offline_dashboard']['selected'] == False:
                                return Response({'detail':'please select any one dashboard type.'},status.HTTP_400_BAD_REQUEST)
                            
                            if product_data['plan_online_dashboard']['selected'] == True:
                                plan_features_pricing_tier_online_dashboard = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Online Dashboard').values('id','uuid','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                                plan_feature_days_price_online_dashboard = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard['id'],currency_id=currency_detail['id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').first()
                                online_dashboard_price = plan_days * camera_quantity * plan_feature_days_price_online_dashboard['days_price']
                                days_online_dashboard_price = camera_quantity * plan_feature_days_price_online_dashboard['days_price']
                                plans_data.append({
                                    'quantity':camera_quantity,
                                    'price':online_dashboard_price,
                                    'days_price':days_online_dashboard_price,
                                    'currency_id':currency_detail['id'],
                                    'plan_feature_pricing_category_id':plan_features_pricing_tier_online_dashboard['pricing_feature_category_id'],
                                    'category_name':plan_features_pricing_tier_online_dashboard['pricing_feature_category_id__category_name'],
                                    'plan_id':id,
                                    'plan_feature_pricing_tier_id':plan_features_pricing_tier_online_dashboard['id'],
                                    'company_detail_id':user_detail_page['company_detail']['id'],
                                    'plan_pricing_description':plan_features_pricing_tier_online_dashboard['plan_pricing_description']
                                })
                                plan_features_pricing_tier_online_dashboard_data_backup = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Online Data Backup').values('id','uuid','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                                plan_feature_days_price_online_dashboard_data_backup = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard['id'],currency_id=currency_detail['id'],backup_days_id=product_data['plan_online_data_backup']['backup_id']).values('id','uuid','backup_days_id','backup_days_id__days','backup_days_id__category','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').first()
                                online_data_backup_price = plan_feature_days_price_online_dashboard_data_backup['backup_days_id__days'] * camera_quantity * plan_feature_days_price_online_dashboard_data_backup['days_price']
                                days_online_data_backup_price = camera_quantity * plan_feature_days_price_online_dashboard_data_backup['days_price']
                                plans_data.append({
                                    'backup_days_id':plan_feature_days_price_online_dashboard_data_backup['backup_days_id'],
                                    'backup_days':plan_feature_days_price_online_dashboard_data_backup['backup_days_id__days'],
                                    'quantity':camera_quantity,
                                    'price':online_data_backup_price,
                                    'days_price':days_online_data_backup_price,
                                    'currency_id':currency_detail['id'],
                                    'plan_feature_pricing_category_id':plan_features_pricing_tier_online_dashboard_data_backup['pricing_feature_category_id'],
                                    'category_name':plan_features_pricing_tier_online_dashboard_data_backup['pricing_feature_category_id__category_name'],
                                    'plan_id':id,
                                    'plan_feature_pricing_tier_id':plan_features_pricing_tier_online_dashboard_data_backup['id'],
                                    'company_detail_id':user_detail_page['company_detail']['id'],
                                    'plan_pricing_description':plan_features_pricing_tier_online_dashboard_data_backup['plan_pricing_description']
                                })
                            
                            if product_data['plan_offline_dashboard']['selected'] == True:
                                plan_features_pricing_tier_offline_dashboard = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Offline Dashboard').values('id','uuid','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                                plan_feature_days_price_offline_dashboard = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_offline_dashboard['id'],currency_id=currency_detail['id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').first()
                                offline_dashboard_price = plan_days * camera_quantity * plan_feature_days_price_offline_dashboard['days_price']
                                days_offline_dashboard_price = camera_quantity * plan_feature_days_price_offline_dashboard['days_price']
                                plans_data.append({
                                    'quantity':camera_quantity,
                                    'price':offline_dashboard_price,
                                    'days_price':days_offline_dashboard_price,
                                    'currency_id':currency_detail['id'],
                                    'plan_feature_pricing_category_id':plan_features_pricing_tier_offline_dashboard['pricing_feature_category_id'],
                                    'category_name':plan_features_pricing_tier_offline_dashboard['pricing_feature_category_id__category_name'],
                                    'plan_id':id,
                                    'plan_feature_pricing_tier_id':plan_features_pricing_tier_offline_dashboard['id'],
                                    'company_detail_id':user_detail_page['company_detail']['id'],
                                    'plan_pricing_description':plan_features_pricing_tier_offline_dashboard['plan_pricing_description']
                                })
                                plan_features_pricing_tier_offline_dashboard_data_backup = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Offline Data Backup').values('id','uuid','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                                plan_feature_days_price_offline_dashboard_data_backup = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_offline_dashboard['id'],currency_id=currency_detail['id'],backup_days_id=product_data['plan_offline_data_backup']['backup_id']).values('id','uuid','backup_days_id','backup_days_id__days','backup_days_id__category','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').first()
                                offline_data_backup_price = plan_feature_days_price_offline_dashboard_data_backup['backup_days_id__days'] * camera_quantity * plan_feature_days_price_offline_dashboard_data_backup['days_price']
                                days_offline_data_backup_price = camera_quantity * plan_feature_days_price_offline_dashboard_data_backup['days_price']
                                plans_data.append({
                                    'backup_days_id':plan_feature_days_price_offline_dashboard_data_backup['backup_days_id'],
                                    'backup_days':plan_feature_days_price_offline_dashboard_data_backup['backup_days_id__days'],
                                    'quantity':camera_quantity,
                                    'price':offline_data_backup_price,
                                    'days_price':days_offline_data_backup_price,
                                    'currency_id':currency_detail['id'],
                                    'plan_feature_pricing_category_id':plan_features_pricing_tier_offline_dashboard_data_backup['pricing_feature_category_id'],
                                    'category_name':plan_features_pricing_tier_offline_dashboard_data_backup['pricing_feature_category_id__category_name'],
                                    'plan_id':id,
                                    'plan_feature_pricing_tier_id':plan_features_pricing_tier_offline_dashboard_data_backup['id'],
                                    'company_detail_id':user_detail_page['company_detail']['id'],
                                    'plan_pricing_description':plan_features_pricing_tier_offline_dashboard_data_backup['plan_pricing_description']
                                })
                            if product_selected_exist == False:
                                return Response({'detail':'please select any one dashboard type.'},status.HTTP_400_BAD_REQUEST)
                            total_price = camera_price + online_dashboard_price + online_data_backup_price + offline_dashboard_price + offline_data_backup_price + default_product_price + default_product_feature_price
                            all_product_total_price+=total_price
                        days_total_price = all_product_total_price / plan_days
                        discount_amount = (all_product_total_price * get_plan_days_and_discount.discount_percentage)/100
                        total_price_after_discount = all_product_total_price - discount_amount
                        business_coupon = None
                        if plans_detail['coupon_code'] != None:
                            get_coupon = Coupon.objects.filter(code=plans_detail['coupon_code'],currency_id=currency_detail['id'],plan_buy_days__gte=plan_days,coupon_expiry_datetime__gte= timezone.datetime.now(),is_active=True).values('id','uuid','code','description','discount_type','discount_value','currency_id','currency_id__currency_type').first()
                            if get_coupon != None:
                                total_coupon_amount = 0.0
                                if get_coupon['discount_type'] == 'percentage':
                                    total_coupon_amount =  (all_product_total_price * get_coupon['discount_value'])/100
                                elif get_coupon['discount_type'] == 'fixed amount':
                                    total_coupon_amount = all_product_total_price - get_coupon['discount_value']
                                total_price_after_discount -= total_coupon_amount
                                business_coupon ={
                                    'coupon_code':get_coupon['code'],
                                    'description':get_coupon['description'],
                                    'discount_type':get_coupon['discount_type'],
                                    'discount_value':get_coupon['discount_value'],
                                    'coupon_id':get_coupon['id'],
                                    'total_coupon_amount':total_coupon_amount,
                                    'company_detail_id':user_detail_page['company_detail']['id']
                                }
                            else:
                                return Response({'detail':"coupon code is not valid."},status.HTTP_400_BAD_REQUEST)
                        days_total_price_after_discount = total_price_after_discount / plan_days
                        plan_pricing_tax_detail = PlanPricingTax.objects.filter(plan_pricing_id = get_plan_days_and_discount.plan_pricing_id).values('id','uuid','plan_pricing_id','tax_percentage_detail_id','tax_percentage_detail_id__tax_percentage','tax_percentage_detail_id__tax_type')
                        tax_detail = []
                        total_price_after_tax = total_price_after_discount
                        
                        for pricing_tax in plan_pricing_tax_detail:
                            tax_amount = (total_price_after_discount*pricing_tax['tax_percentage_detail_id__tax_percentage'])/100
                            total_price_after_tax += tax_amount
                            tax_detail.append({
                                'tax_percentage_detail_id':pricing_tax['tax_percentage_detail_id'],
                                'tax_percentage':pricing_tax['tax_percentage_detail_id__tax_percentage'],
                                'tax_type':pricing_tax['tax_percentage_detail_id__tax_type'],
                                'tax_amount':tax_amount,
                                'company_detail_id':user_detail_page['company_detail']['id']
                            })
                            total_tax_percentage+=pricing_tax['tax_percentage_detail_id__tax_percentage']
                            total_tax_in_currency+=tax_amount
                        days_total_price_after_tax = total_price_after_tax / plan_days
                        plan_start_datetime = timezone.datetime.now()
                        plan_expire_datetime = timezone.now() + timedelta(days=get_plan_days_and_discount.plan_days)
                        plan_start_datetime = timezone.make_aware(plan_start_datetime)
                        # plan_start_datetime = timezone.datetime.now()
                        # plan_expire_datetime = timezone.datetime.now()+get_plan_days_and_discount.plan_days
                        time_diff = plan_expire_datetime - plan_start_datetime
                        total_minutes = time_diff.total_seconds()/60
                        total_days = time_diff.days
                        get_plan_pricing = PlanPricing.objects.filter(plan_id=get_plan.id, currency_id=currency_detail['id']).first()
                        business_plan_history = {
                            'plan_name':get_plan.plan_name,
                            'price':total_price,
                            'price_after_discount':total_price_after_discount,
                            'price_after_tax':total_price_after_tax,
                            'days_price':days_total_price,
                            'days_price_after_discount': days_total_price_after_discount,
                            'days_price_after_tax': days_total_price_after_tax,
                            'currency_id':currency_detail['id'],
                            'currency_type':currency_detail['currency_type'],
                            'currency_symbol':currency_detail['currency_symbol'],
                            'country_category_id':get_plan_pricing.country_type_id.id,
                            'country_type':get_plan_pricing.country_type_id.country,
                            'plan_id':get_plan.id,
                            'plan_days_and_discount_id':get_plan_days_and_discount.id,
                            'plan_days':get_plan_days_and_discount.plan_days,
                            'discount_in_percentage':get_plan_days_and_discount.discount_percentage,
                            'discount_in_currency': discount_amount,
                            'total_discount': total_price_after_discount,
                            'total_tax_in_percentage':total_tax_percentage,
                            'total_tax_in_currency':total_tax_in_currency,
                            'buy_datetime':timezone.datetime.now(),
                            'plan_start_datetime':timezone.datetime.now(),
                            #'plan_expire_datetime': datetime.datetime.now()+get_plan_days_and_discount['plan_days'],
                            'plan_expire_datetime': timezone.datetime.now() + timezone.timedelta(days=get_plan_days_and_discount.plan_days),
                            'minutes_to_expire':total_minutes,
                            'days_to_expire':total_days,
                            'plan_validity':False,
                            'plan_status':'pending',
                            'current_active':False,
                            'plan_type':'Renew Plan',
                            'company_detail_id':user_detail_page['company_detail']['id']
                        }

                        print("business plan history:",business_plan_history)
                        if 'currency_id' in business_plan_history:
                            currency_id = business_plan_history['currency_id']
                            
                            try:
                                
                                currency_instance = Currency.objects.get(id=currency_id)
                            except Currency.DoesNotExist:
                                
                                return Response({'error': 'Invalid currency_id'}, status=status.HTTP_400_BAD_REQUEST)
                        else:
                            
                            return Response({'error': 'currency_id is missing'}, status=status.HTTP_400_BAD_REQUEST)

                        
                        business_plan_history['currency_id'] = currency_instance
                        
                        if 'country_category_id' in business_plan_history:
                            country_category_id = business_plan_history['country_category_id']
                            try:
                                
                                country_category_instance = CountryCategory.objects.get(id=country_category_id)
                            except CountryCategory.DoesNotExist:
                                
                                return Response({'error': 'Invalid country_category_id'}, status=status.HTTP_400_BAD_REQUEST)
                        else:
                            
                            return Response({'error': 'country_category_id is missing'}, status=status.HTTP_400_BAD_REQUEST)

                        
                        business_plan_history['country_category_id'] = country_category_instance

                        if 'plan_id' in business_plan_history:
                            plan_id = business_plan_history['plan_id']
                            try:
                            
                                plan_instance = Plans.objects.get(id=plan_id)
                            except Plans.DoesNotExist:
                                
                                return Response({'error': 'Invalid plan_id'}, status=status.HTTP_400_BAD_REQUEST)
                        else:
                            
                            return Response({'error': 'plan_id is missing'}, status=status.HTTP_400_BAD_REQUEST)

                        
                        business_plan_history['plan_id'] = plan_instance

                        if 'plan_days_and_discount_id' in business_plan_history:
                            plan_days_and_discount_id = business_plan_history['plan_days_and_discount_id']
                            try:
                            
                                plan_days_and_discount_instance = PlanDaysAndDiscount.objects.get(id=plan_days_and_discount_id)
                            except PlanDaysAndDiscount.DoesNotExist:
                            
                                return Response({'error': 'Invalid plan_days_and_discount_id'}, status=status.HTTP_400_BAD_REQUEST)
                        else:
                            
                            return Response({'error': 'plan_days_and_discount_id is missing'}, status=status.HTTP_400_BAD_REQUEST)

                        
                        business_plan_history['plan_days_and_discount_id'] = plan_days_and_discount_instance

                        if 'company_detail_id' in business_plan_history:
                            company_detail_id = business_plan_history['company_detail_id']
                            try:
                                
                                company_detail_instance = CompanyDetail.objects.get(id=company_detail_id)
                            except CompanyDetail.DoesNotExist:
                                
                                return Response({'error': 'Invalid business_detail_id'}, status=status.HTTP_400_BAD_REQUEST)
                        else:
                        
                            return Response({'error': 'business_detail_id is missing'}, status=status.HTTP_400_BAD_REQUEST)

                        
                        business_plan_history['company_detail_id'] = company_detail_instance


                        try:
                            
                            existing_plan_id = request.data.get('existing_plan_id')
                        
                            #product_data = request.data.get('product_data')
                            print("PLANs DATA:",plans_data)
                            #print(business_plan_history)


                        
                            existing_plan_details = extract_existing_plan_details(existing_plan_id, product_data)
                            updated_plan_details = extract_updated_plan_details(plans_data, product_data,business_plan_history)

                            #print("Product Data:", product_data)
                            
                            with transaction.atomic():
                            
                                if is_valid_upgrade(existing_plan_details, updated_plan_details):
                                    existing_plan = BusinessPlanHistory.objects.get(id=existing_plan_id)
                                    existing_plan.current_active = False
                                    existing_plan.save()
                                    
                                    updated_plan = BusinessPlanHistory(**business_plan_history)
                                    updated_plan.current_active = True
                                    updated_plan.save()
                                    print("updated plan:", updated_plan)
                                    #print("business plan history:",business_plan_history)
                                    #business_plan_history_id=updated_plan
                                    
                                    update_related_models(existing_plan_id, updated_plan_details,updated_plan)
                                    business_plan_history_instance = BusinessPlanHistory.objects.get(
                                    plan_name=business_plan_history['plan_name'],
                                    price_after_tax=business_plan_history['price_after_tax'],
                                    
                                )
                                    try:


                                #user = User.objects.get(id=user_id)
                                
                                        email = request.user.email
                                        phone_number = request.user.phone_number


                                        autopay_option = request.POST.get('autopay_option', None)

                                        
                                        if autopay_option == 'enable':
                                            
                                            response = create_subscription(request, business_plan_history, email, phone_number)


                                        #logger.info(f"create_subscription response: {response}")
                        
                        
                                        #return response

                                            if not response.get('success', False):

                                                print("Error details:")
                                                # traceback.print_exc()

                                                # # for obj in created_objects:
                                                # #     obj.delete()
                                                
                                                
                                                # logger.info(f"create_subscription response: {response}")
                            
                                                return response
                                            
                                            return JsonResponse({'An ERROR OCCURRED': response.get('message', 'Failed to create subscription')}, status=500)
                                    
                                    
                                        api_response_data, payment_session_id = process_cashfree_payment_upgrade(request, business_plan_history, email, phone_number)

                                        if api_response_data is None:
                                            
                                            return JsonResponse({'An ERROR OCCURRED': 'No data returned'}, status=500)
                                        
                                        if payment_session_id:
                                        
                                            # return JsonResponse({'payment_session_id': payment_session_id})
                                            # return Response(api_response_data)
                                            # response_data = {
                                            #     'api_response_data': api_response_data,
                                            #     'payment_session_id': payment_session_id
                                            # }
                                            # return Response(response_data)
                                            return render(request, 'checkout.html', {'payment_session_id': payment_session_id})
                                        else:
                                            
                                            return JsonResponse({'An ERROR OCCURRED': 'Payment session ID not found'}, status=500)

                                    #         #serialized_data = serializers.serialize('json', [api_response_data])
                                    
                                    except Exception as e:
                                        # for obj in created_objects:
                                        #     obj.delete()
                                        
                                        return JsonResponse({'AN ERROR OCCURRED': str(e)}, status=500)

                                
                                # total_price_after_tax = business_plan_history_instance.price_after_tax

                                

                                else:
                                    return Response({'error': 'Invalid renew request'}, status=status.HTTP_400_BAD_REQUEST)

                        except ObjectDoesNotExist:
                            return Response({'error': 'BusinessPlanHistory does not exist'}, status=status.HTTP_400_BAD_REQUEST)

                        except Exception as e:
                            return Response({'error': f'Renewal and payment failed: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
                        #             return Response({'message': 'Renew Plan successful'}, status=status.HTTP_200_OK)
                                    
                        #         else:
                        #             return Response({'error': 'Invalid renew request'}, status=status.HTTP_400_BAD_REQUEST)
                        # except Exception as e:
                        #     return Response({'error': f'Renew failed: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
            
                    # business_plan_history_serializer = BusinessPlanHistorySerializer(data=business_plan_history)
                    # business_plan_history_id = None
                    # if business_plan_history_serializer.is_valid():
                    #     business_plan_history_obj = business_plan_history_serializer.save()
                    #     business_plan_history_id = business_plan_history_obj.id
                    # else:
                    #     return Response(business_plan_history_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                    # business_pricing_tax_ids = []
                    # for business_pricing_tax in tax_detail:
                    #     business_pricing_tax['business_plan_history_id'] = business_plan_history_id
                    #     business_pricing_tax_serializer = BusinessPlanPricingTaxSerializer(data=business_pricing_tax)
                    #     business_pricing_tax_id = None
                    #     if business_pricing_tax_serializer.is_valid():
                    #         business_pricing_tax_obj = business_pricing_tax_serializer.save()
                    #         business_pricing_tax_id = business_pricing_tax_obj.id
                    #         business_pricing_tax_ids.append(business_pricing_tax_id)
                    #     else:
                    #         return Response(business_plan_history_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                    # business_plan_coupon_id = None
                    # if business_coupon != None:
                    #     business_coupon['business_plan_history_id'] = business_plan_history_id
                    #     business_coupon_serializer = BusinessPlanCoupon(data=business_coupon)
                    #     if business_coupon_serializer.is_valid():
                    #         business_coupon_obj = business_coupon_serializer.save()
                    #         business_plan_coupon_id = business_coupon_obj.id
                    #     else:
                    #         for business_plan_pricing_tax_id in business_pricing_tax_ids:
                    #             BusinessPlanPricingTax.objects.filter(id=business_plan_pricing_tax_id).delete()
                    #         for business_pricing_id in business_pricing_tier_ids:
                    #             BusinessPricingTier.objects.filter(id=business_pricing_id).delete()
                    #         BusinessPlanHistory.objects.filter(id=business_plan_history_id).delete()
                    # business_pricing_tier_ids = []
                    # for plans in plans_data:
                    #     plans['business_plan_history_id'] = business_plan_history_id
                    #     business_pricing_tier_serializer = BusinessPricingTierSerializer(data=plans)
                    #     business_pricing_tier_id = None
                    #     if business_pricing_tier_serializer.is_valid():
                    #         business_pricing_tier_obj = business_pricing_tier_serializer.save()
                    #         business_pricing_tier_id = business_pricing_tier_obj.id
                    #         business_pricing_tier_ids.append(business_pricing_tier_id)
                    #     else:
                    #         if business_plan_coupon_id != None:
                    #             BusinessPlanCoupon.objects.filter(id=business_plan_coupon_id).delete()
                    #         for business_plan_pricing_tax_id in business_pricing_tax_ids:
                    #             BusinessPlanPricingTax.objects.filter(id=business_plan_pricing_tax_id).delete()
                    #         for business_pricing_id in business_pricing_tier_ids:
                    #             BusinessPricingTier.objects.filter(id=business_pricing_id).delete()
                    #         BusinessPlanHistory.objects.filter(id=business_plan_history_id).delete()
                    #         return Response(business_pricing_tier_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                    else:
                        return Response({"detail": "Plans days doesn't exist."}, status=status.HTTP_400_BAD_REQUEST)
                else:
                    return Response({"detail": "Plans not exist."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)
            

    def put(self, request,id,format=None):
            user_detail_page = get_user_data_page_plans(request.user.id,'upgrade_plan','view')
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                data = request.data
                print(data)
                plans_data = {}
                plans_detail = data['plans_detail']
                selected_products = plans_detail['plan_product']
                # valid_products = []
                # product_data_list = []
                # selected_products = plans_detail['products']
                print("selected products:",selected_products)
                for product in selected_products:
                    # product_id = product['product_id']
                    product_id = product['product_id']
                    product_name = product['product_name']
                    # product_name = product['product_name']
                    print("product_names",product_name)
                currency_detail = Currency.objects.filter(currency_type=request.data['currency_type']).values('id','currency_type','currency_symbol').first()
                get_plan = Plans.objects.filter(id=plans_detail['id'],plan_name=plans_detail['plan_name']).first()
                #get_plan = Plans.objects.filter(id=id).first()
                #print(get_plan)
                id = get_plan.id
                plan_name = get_plan.plan_name
                get_plan_days_and_discount_all = PlanDaysAndDiscount.objects.filter(plan_id=id).all()
                plans_data['plan_days']= []
                plan_days = 0
                total_price=0
                total_price_after_discount=0
                final_online_data_dashboard_price=0.0
                final_offline_data_dashboard_price=0.0
                all_product_total_price=0.0
                discount_amount=0
                for plan_days_detail in get_plan_days_and_discount_all:
                    selected = False
                    if data['plan_days_id'] == plan_days_detail.id:
                        selected = True
                        plan_days = plan_days_detail.plan_days
                        plan_pricing_id = plan_days_detail.plan_pricing_id.id
                    plans_data['plan_days'].append({
                    # 'id':plan_days_detail.id,
                        'plan_days':plan_days_detail.plan_days,
                        'discount_percentage':plan_days_detail.discount_percentage,
                        'category':plan_days_detail.category,
                        'default_select':selected,
                        #'plan_pricing_id':plan_days_detail.plan_pricing_id
                    # 'plan_pricing_id': plan_pricing_id
                        
                    })
                get_plan_days_and_discount = PlanDaysAndDiscount.objects.filter(plan_id=id,id=data['plan_days_id']).first()
                plans_data['product_data'] = []
                if get_plan_days_and_discount != None:
                    plan_days = get_plan_days_and_discount.plan_days
                    product_data = plans_detail['plan_product'][0]
                    product_data_list = []
                    parking_product_data_list = []
                    all_parking_product_data = []
                    for product in selected_products:
                        product_name = product['product_name']
                        print("Processing product name:", product_name)
                        plan_feature_pricing_tier_id = product['plan_feature_pricing_tier_id']
                        print("Processing plan features name:", plan_feature_pricing_tier_id)
                        camera_detail_list = []
                        camera_quantity = product['plan_camera_detail']['camera_quantity']
                        print("Camera quantity for product:", camera_quantity)
                        # camera_quantity = product_data['plan_camera_detail']['camera_quantity']
                        parking_product_data = PlanFeaturePricingTier.objects.filter(
                            plan_id=id,
                            pricing_feature_category_id__category_name="Product",
                            default_product_id__product_name=product_name,
                            id=plan_feature_pricing_tier_id,
                            show_plan_pricing=True
                        ).values(
                            'id', 'uuid', 'default_product_id', 'default_product_id__product_name',
                            'pricing_feature_category_id', 'pricing_feature_category_id__category_name',
                            'plan_id', 'plan_pricing_description', 'show_plan_pricing'
                        ).all()

                        for item in parking_product_data:
                            all_parking_product_data.append(item)
                        print("All parking product data:", all_parking_product_data)

                    
                    for parking_product_data in all_parking_product_data:
                        print("Processing parking product data:", parking_product_data)
                        
                        plan_feature_days_price_product = PlanFeatureDaysPrice.objects.filter(
                            plans_id=id,
                            plan_days_and_discount_id=get_plan_days_and_discount.id,
                            plan_feature_pricing_tier_id=parking_product_data['id'],
                            currency_id=data['currency_type_id']
                        ).values(
                            'id', 'uuid', 'backup_days_id', 'plan_days_and_discount_id',
                            'days_price', 'currency_id', 'currency_id__currency_symbol', 'default_selected'
                        ).all()

                        print("Plan feature days price product:", plan_feature_days_price_product)
                        plan_feature_days_price_product_instance = plan_feature_days_price_product.first()

                        if plan_feature_days_price_product_instance:
                            default_product_price = plan_days * camera_quantity * plan_feature_days_price_product_instance['days_price']
                            default_product_price_days = camera_quantity * plan_feature_days_price_product_instance['days_price']
                        else:
                            default_product_price = 0
                            default_product_price_days = 0

                        product_selected_exist = True

                        product_data_json = {
                            'product_name': parking_product_data['default_product_id__product_name'],
                            'plan_product': [{
                                'days_price': default_product_price_days,
                                'price': default_product_price,
                                'default_selected': product_selected_exist,
                                'plan_pricing_description': parking_product_data['plan_pricing_description'],
                            }]
                        }
                        total_price += default_product_price
                        product_data_list.append(product_data_json)
                        print("Product data JSON:", product_data_json)
                    # parking_product_data = PlanFeaturePricingTier.objects.filter(plan_id=id,pricing_feature_category_id__category_name="Product",default_product_id__product_name='Violation surveillance',id=plans_detail['plan_product'][0]['plan_feature_pricing_tier_id'],show_plan_pricing=True).values('id','uuid','default_product_id','default_product_id__product_name','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                    # print("parkingpdata",parking_product_data)
                    # all_product_total_price = 0.0
                    # if parking_product_data != None:
                    #     camera_quantity = product_data['plan_camera_detail']['camera_quantity']
                    #     product_data_json = {}
                    #    # product_data_json['id'] = parking_product_data['id']
                    #     product_data_json['product_name'] = parking_product_data['default_product_id__product_name']

                    #     plan_feature_days_price_product = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=parking_product_data['id'],currency_id=data['currency_type_id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                    #     plan_feature_days_price_product_instance = plan_feature_days_price_product.first()

                    #     if plan_feature_days_price_product_instance:
                    #            default_product_price = plan_days * camera_quantity * plan_feature_days_price_product_instance['days_price']
                    #            default_product_price_days = camera_quantity * plan_feature_days_price_product_instance['days_price']
                    #     else:
                    #         #print("error in defaultproductprice")
                    #             default_product_price = 0 
                    #             default_product_price_days = 0
                    #     product_selected_exist = True
                    #     # product_selected_exist = True
                    #     # default_product_price = plan_days * camera_quantity * plan_feature_days_price_product['days_price']
                    #     # default_product_price_days = camera_quantity * plan_feature_days_price_product['days_price']

                    #     product_data_json['plan_product']={
                    #         # 'id':parking_product_data['id'],
                    #         # 'uuid':parking_product_data['uuid'],
                    #         'days_price':default_product_price_days,
                    #         'price': default_product_price,
                    #         #'currency_symbol':plan_feature_days_price_product_instance['currency_id__currency_symbol'],
                    #        # 'currency_id':currency_detail['id'],
                    #         #'pricing_feature_category_id':parking_product_data['pricing_feature_category_id'],
                    #         #'category_name':parking_product_data['pricing_feature_category_id__category_name'],
                    #        # 'default_selected':product_selected_exist,
                    #         #'plan_id':parking_product_data['plan_id'],
                    #         'plan_pricing_description':parking_product_data['plan_pricing_description'],
                    #         #'show_plan_pricing':parking_product_data['show_plan_pricing']
                    #     }

                        # default_parking_product_feature_data = PlanFeaturePricingTier.objects.filter(plan_id=id,pricing_feature_category_id__category_name="Feature",default_product_id__product_name='Violation surveillance',is_encluded_plan_feature_id__isnull=False,default_product_feature_id__isnull=False).values('id','uuid','default_product_id','default_product_id__product_name','default_product_feature_id','default_product_feature_id__feature','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').all()
                        # product_data_json['plan_product_feature_default'] = []
                        # for default_product_feature in default_parking_product_feature_data:
                        #     product_data_json['plan_product_feature_default'].append({
                        #         # 'id':default_product_feature['id'],
                        #         # 'uuid':default_product_feature['uuid'],
                        #         # 'default_product_feature_id':default_product_feature['default_product_feature_id'],
                        #         # 'pricing_feature_category_id':default_product_feature['pricing_feature_category_id'],
                        #         'category_name':default_product_feature['pricing_feature_category_id__category_name'],
                        #         'feature_name':default_product_feature['default_product_feature_id__feature'],
                        #         'plan_pricing_description':default_product_feature['plan_pricing_description'],       
                        #     })
                        # parking_product_feature_data = PlanFeaturePricingTier.objects.filter(plan_id=id,pricing_feature_category_id__category_name="Feature",default_product_id__product_name='Violation surveillance',is_encluded_plan_feature_id__isnull=True,default_product_feature_id__isnull=False).values('id','uuid','default_product_id','default_product_id__product_name','default_product_feature_id','default_product_feature_id__feature','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').all()
                        # product_data_json['plan_product_feature'] = []
                        # default_product_feature_price = 0.0
                        # for product_feature in parking_product_feature_data:
                        #     # plan_feature_days_price_product_feature = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=product_feature['id'],currency_id=data['currency_type_id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                        #     # product_feature_price = plan_days * camera_quantity * plan_feature_days_price_product_feature['days_price']
                        #     # product_feature_price_days = camera_quantity * plan_feature_days_price_product_feature['days_price']
                        #     # default_selected = False
                        #     plan_feature_days_price_product_feature = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=product_feature['id'],currency_id=currency_detail['id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                        #     plan_feature_days_price_product_feature_instance = plan_feature_days_price_product_feature.first()  
                        #     if plan_feature_days_price_product_feature_instance:
                        #         product_feature_price = plan_days * camera_quantity * plan_feature_days_price_product_feature_instance['days_price']
                        #         product_feature_price_days = camera_quantity * plan_feature_days_price_product_feature_instance['days_price']
                        #     else:
                                
                        #         product_feature_price = 0  
                        #     # product_feature_price = plan_days * camera_quantity * plan_feature_days_price_product_feature_instance['days_price']
                        #     # product_feature_price_days = camera_quantity * plan_feature_days_price_product_feature_instance['days_price']
                        #     default_selected = False
                            
                        #     product_feature_price = plan_days * camera_quantity * plan_feature_days_price_product_feature_instance['days_price']
                        #     product_feature_price_days = camera_quantity * plan_feature_days_price_product_feature_instance['days_price']
                        #     default_selected = False
                        #     feature_plan_selected = [feature_plan for feature_plan in product_data['plan_feature_detail'] if feature_plan['plan_feature_pricing_tier_id']==product_feature['id'] and feature_plan['selected']==True]
                        #     if len(feature_plan_selected) > 0:
                        #         default_selected = True
                        #         default_product_feature_price += product_feature_price
                        #         plans_data.append({
                        #             'price':product_feature_price,
                        #             'days_price':product_feature_price_days,
                        #             'currency_id':currency_detail['id'],
                        #             # 'default_product_id':parking_product_data['default_product_id'],
                        #             # 'default_product_feature_id':product_feature['default_product_feature_id'],
                        #             # 'plan_feature_pricing_category_id':product_feature['pricing_feature_category_id'],
                        #             'category_name':product_feature['pricing_feature_category_id__category_name'],
                        #            # 'plan_id':id,
                        #             #'plan_feature_pricing_tier_id':product_feature['id'],
                        #             #'business_detail_id':user_detail_page['business_detail']['id'],
                        #             'plan_pricing_description':product_feature['plan_pricing_description']
                        #         })
                        existing_plan_id = request.data.get('existing_plan_id')
                        #existing_plan = BusinessPlanHistory.objects.get(id=existing_plan_id)
                        existing_plan = BusinessPlanHistory.objects.get(id=existing_plan_id)
                        # try:
                        #     remaining_value = self.calculate_remaining_value(existing_plan)
                        # except BusinessPlanHistory.DoesNotExist:
                        #     return JsonResponse({'error': 'Invalid existing_plan_id'}, status=status.HTTP_400_BAD_REQUEST)
                        # refund_amount = remaining_value
                        product_data_json['plan_camera_detail']= []
                        default_product_ids = [item['default_product_id'] for item in all_parking_product_data]
                    # for parking_product_instance in all_parking_product_data:

                    #         default_product_id = parking_product_instance['default_product_id']
                        print("deafult product",default_product_ids)
                
                        plan_features_pricing_tier_cameras = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id__in=default_product_ids,pricing_feature_category_id__category_name='Camera').values('id','uuid', 'default_product_id' , 'min_quantity','max_quantity','default_quantity','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').all()
                        print("plan_features_pricing_tier_cameras",plan_features_pricing_tier_cameras)
                        # print(list(plan_features_pricing_tier_cameras))
                        if isinstance(plan_features_pricing_tier_cameras, dict):
    
                            plan_features_pricing_tier_cameras = [plan_features_pricing_tier_cameras]
                        else:
                            
                            pass

                        
                        plan_features_pricing_tier_camera_dict = {item['default_product_id']: item for item in plan_features_pricing_tier_cameras}
                        for parking_product_instance in all_parking_product_data:
                            default_product_id = parking_product_instance['default_product_id']
                            print("default product", default_product_id)

                            product_camera_detail_list = []
                            camera_quantity = product_data['plan_camera_detail']['camera_quantity']
                            # camera_quantity = product['plan_camera_detail']['camera_quantity']
                            
                            plan_features_pricing_tier_camera = plan_features_pricing_tier_camera_dict.get(default_product_id)
                            print("plan_features_pricing_tier_camera",plan_features_pricing_tier_camera)
                            print(f"Processing product with plan_feature_pricing_tier_id: {product['plan_feature_pricing_tier_id']}, camera_quantity: {camera_quantity}")
                        
                        
                        # plan_features_pricing_tier_camera = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Camera').values('id','uuid','min_quantity','max_quantity','default_quantity','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                        # print("plan_features_pricing_tier_camera",plan_features_pricing_tier_camera)
                            default_camera_price = 0.0
                            for camera in range(plan_features_pricing_tier_camera['min_quantity'],plan_features_pricing_tier_camera['max_quantity']+1):
                                plan_feature_days_price_camera = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=data['plan_days_id'],plan_feature_pricing_tier_id=plan_features_pricing_tier_camera['id'],currency_id=data['currency_type_id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol').first()
                                print("plan_feature_days_price_camera",plan_feature_days_price_camera)
                                camera_price_days = camera * plan_feature_days_price_camera['days_price']
                                default_selected = False
                                if camera_quantity == camera:
                                    camera_price = plan_days * camera * plan_feature_days_price_camera['days_price']
                                    default_camera_price = camera_price
                                    default_selected = True
                                    existing_camera_quantity = BusinessPricingTier.objects.filter(
                                    business_plan_history_id=existing_plan.id,
                                    category_name='Camera'
                                    ).first()
                                    if existing_camera_quantity:
                                        existing_camera_quantity_value = existing_camera_quantity.quantity
                                    else:
                                        # Handle the case where no existing camera quantity data is found
                                        existing_camera_quantity_value = 0
                                    if camera < existing_camera_quantity_value:
                                        return Response({'detail': 'You cannot decrease the camera quantity.'}, status=status.HTTP_400_BAD_REQUEST)
                                    # camera_detail_list.append({
                                    #     'camera_quantity': camera_quantity,
                                    #     'days_price': camera_price_days,
                                    #     'price': default_camera_price,
                                    #     'currency_symbol': plan_feature_days_price_camera['currency_id__currency_symbol'],
                                    #     'category_name':plan_features_pricing_tier_camera['pricing_feature_category_id__category_name'],
                                    #     'default_selected': default_selected,
                                    #     'plan_pricing_description':plan_features_pricing_tier_camera['plan_pricing_description'],
                                    # })

                                    # total_camera_quantity = sum(detail['camera_quantity'] for detail in camera_detail_list)
                                    total_price += default_camera_price
                                    # product_data_json['plan_camera_detail'].append({
                                    #         'days_price': default_camera_price_days,
                                    #         'total_camera_price': total_camera_price,
                                    #         'total_camera_price_days': total_camera_price_days,
                                    #         'total_camera_quantity': total_camera_quantity,
                                    #         'currency_symbol': plan_feature_days_price_camera['currency_id__currency_symbol'],
                                    #         'default_selected': default_selected,
                                    #         'plan_pricing_description':plan_features_pricing_tier_camera['plan_pricing_description'],
                                    #         #'camera_details': camera_detail_list
                                    # })
                                    product_data_json['plan_camera_detail'].append({
                                    # 'id':plan_features_pricing_tier_camera['id'],
                                    # 'uuid':plan_features_pricing_tier_camera['uuid'],
                                    'camera_quantity':camera,
                                    'days_price':camera_price_days,
                                    'price': camera_price,
                                    'currency_symbol':plan_feature_days_price_camera['currency_id__currency_symbol'],
                                    #'pricing_feature_category_id':plan_features_pricing_tier_camera['pricing_feature_category_id'],
                                    #'category_name':plan_features_pricing_tier_camera['pricing_feature_category_id__category_name'],
                                # 'default_selected':default_selected,
                                    #'plan_id':plan_features_pricing_tier_camera['plan_id'],
                                    'plan_pricing_description':plan_features_pricing_tier_camera['plan_pricing_description'],
                                # 'show_plan_pricing':plan_features_pricing_tier_camera['show_plan_pricing']
                                })
                            break

                        # plan_features_pricing_tier_parking_slot = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Parking Slot').values('id','uuid','min_quantity','max_quantity','default_quantity','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                        # parking_slot = product_data['plan_parking_slot_detail']['parking_slot']
                        # if parking_slot < plan_features_pricing_tier_parking_slot['min_quantity'] or parking_slot > plan_features_pricing_tier_parking_slot['max_quantity']:
                        #     return Response({'detail':'please select any one dashboard type.'},status.HTTP_400_BAD_REQUEST)
                        # # for camera in range(plan_features_pricing_tier_camera['min_quantity'],plan_features_pricing_tier_camera['max_quantity']+1):
                        # plan_feature_days_price_parking_slot = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_camera['id'],currency_id=data['currency_type_id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol').first()
                        # default_parking_slot_price = plan_days * parking_slot * plan_feature_days_price_parking_slot['days_price']
                        # praking_days_price = parking_slot * plan_feature_days_price_parking_slot['days_price']
                        # default_selected = True
                        # existing_parking_slots = BusinessPricingTier.objects.filter(
                        #     business_plan_history_id=existing_plan.id,
                        #     category_name='Parking Slot'
                        # ).first()
                        # if existing_parking_slots:
                        #     existing_parking_slot_quantity = existing_parking_slots.quantity
                        # else:
                        #     # Handle the case where no existing parking slot data is found
                        #     existing_parking_slot_quantity = 0
                        # if parking_slot < existing_parking_slot_quantity:
                        #     return Response({'detail': 'You cannot decrease the parking slot quantity.'}, status=status.HTTP_400_BAD_REQUEST)
                        # product_data_json['plan_parking_slots']={
                        #     # 'id':plan_features_pricing_tier_parking_slot['id'],
                        #     # 'uuid':plan_features_pricing_tier_parking_slot['uuid'],
                        #     'parking_slot':parking_slot,
                        #     'days_price':praking_days_price,
                        #     'price': default_parking_slot_price,
                        #     'currency_symbol':plan_feature_days_price_parking_slot['currency_id__currency_symbol'],
                        #     # 'pricing_feature_category_id':plan_features_pricing_tier_parking_slot['pricing_feature_category_id'],
                        #     #'category_name':plan_features_pricing_tier_parking_slot['pricing_feature_category_id__category_name'],
                        #     # 'default_selected':default_selected,
                        #     # 'plan_id':plan_features_pricing_tier_parking_slot['plan_id'],
                        #     'plan_pricing_description':plan_features_pricing_tier_parking_slot['plan_pricing_description'],
                        #     # 'show_plan_pricing':plan_features_pricing_tier_parking_slot['show_plan_pricing']
                        # }

                        if product_data['plan_online_dashboard']['selected'] == False and data['plan_offline_dashboard']['selected'] == False: 
                            return Response({'detail':'please select any one dashboard type.'},status.HTTP_400_BAD_REQUEST)
                        product_data_json['plan_online_dashboard'] = []
                        plan_features_pricing_tier_online_dashboards = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id__in=default_product_ids,pricing_feature_category_id__category_name='Online Dashboard').values('id','uuid','default_product_id', 'pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').all()
                        print("plan_features_pricing_tier_online_dashboards",plan_features_pricing_tier_online_dashboards)
                        
                        if isinstance(plan_features_pricing_tier_online_dashboards, dict):
    
                            plan_features_pricing_tier_online_dashboards = [plan_features_pricing_tier_online_dashboards]
                        else:
                            
                            pass
                        plan_features_pricing_tier_online_dashboard_dict = {item['default_product_id']: item for item in plan_features_pricing_tier_online_dashboards}
                        
                        for parking_product_instance in all_parking_product_data:
                            default_product_id = parking_product_instance['default_product_id']
                            print("default product", default_product_id)
                            plan_features_pricing_tier_online_dashboard = plan_features_pricing_tier_online_dashboard_dict.get(default_product_id)
                            print("plan_features_pricing_tier_online_dashboard",plan_features_pricing_tier_online_dashboard)
                            # plan_features_pricing_tier_online_dashboard = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=default_product_id,pricing_feature_category_id__category_name='Online Dashboard').values('id','uuid','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                            plan_feature_days_price_online_dashboard = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard['id'],currency_id=data['currency_type_id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').first()
                            online_dashboard_price = plan_days * camera_quantity * plan_feature_days_price_online_dashboard['days_price']
                            online_dashboard_price_days = camera_quantity * plan_feature_days_price_online_dashboard['days_price']
                            default_online_dashboard_price = 0.0
                            if product_data['plan_online_dashboard']['selected'] == True:
                                default_online_dashboard_price = online_dashboard_price
                        total_price += online_dashboard_price
                        product_data_json['plan_online_dashboard'].append({
                                # 'id':plan_features_pricing_tier_online_dashboard['id'],
                                # 'uuid':plan_features_pricing_tier_online_dashboard['uuid'],
                                #'camera_quantity':camera_quantity,
                                'plan_days':plan_days,
                                'days_price':online_dashboard_price_days,
                                'price': online_dashboard_price,
                                'currency_symbol':plan_feature_days_price_online_dashboard['currency_id__currency_symbol'],
                                # 'pricing_feature_category_id':plan_features_pricing_tier_online_dashboard['pricing_feature_category_id'],
                                #'category_name':plan_features_pricing_tier_online_dashboard['pricing_feature_category_id__category_name'],
                                'default_selected':product_data['plan_online_dashboard']['selected'],
                                # 'plan_id':plan_features_pricing_tier_online_dashboard['plan_id'],
                                'plan_pricing_description':plan_features_pricing_tier_online_dashboard['plan_pricing_description'],
                                # 'show_plan_pricing':plan_features_pricing_tier_online_dashboard['show_plan_pricing']
                            })
                        # plan_features_pricing_tier_online_dashboard = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Online Dashboard').values('id','uuid','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                        # plan_feature_days_price_online_dashboard = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard['id'],currency_id=data['currency_type_id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').first()
                        # online_dashboard_price = plan_days * camera_quantity * plan_feature_days_price_online_dashboard['days_price']
                        # online_dashboard_price_days = camera_quantity * plan_feature_days_price_online_dashboard['days_price']
                        # default_online_dashboard_price = 0.0
                        # if product_data['plan_online_dashboard']['selected'] == True:
                        #     default_online_dashboard_price = online_dashboard_price
                        # product_data_json['plan_online_dashboard'].append({
                        #         # 'id':plan_features_pricing_tier_online_dashboard['id'],
                        #         # 'uuid':plan_features_pricing_tier_online_dashboard['uuid'],
                        #         # 'camera_quantity':camera_quantity,
                        #         'plan_days':plan_days,
                        #         'days_price':online_dashboard_price_days,
                        #         'price': online_dashboard_price,
                        #         'currency_symbol':plan_feature_days_price_online_dashboard['currency_id__currency_symbol'],
                        #         # 'pricing_feature_category_id':plan_features_pricing_tier_online_dashboard['pricing_feature_category_id'],
                        #         # 'category_name':plan_features_pricing_tier_online_dashboard['pricing_feature_category_id__category_name'],
                        #        # 'default_selected':product_data['plan_online_dashboard']['selected'],
                        #         # 'plan_id':plan_features_pricing_tier_online_dashboard['plan_id'],
                        #         'plan_pricing_description':plan_features_pricing_tier_online_dashboard['plan_pricing_description'],
                        #         # 'show_plan_pricing':plan_features_pricing_tier_online_dashboard['show_plan_pricing']
                        #     })

                        product_data_json['plan_online_dashboard_data_backup'] = []
                        plan_features_pricing_tier_online_dashboard_data_backups = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id__in=default_product_ids,pricing_feature_category_id__category_name='Online Data Backup').values('id','uuid','default_product_id', 'pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').all()
                        print("plan_features_pricing_tier_online_dashboard_data_backup",plan_features_pricing_tier_online_dashboard_data_backups)
                        
                        if isinstance(plan_features_pricing_tier_online_dashboard_data_backups, dict):
    
                            plan_features_pricing_tier_online_dashboard_data_backups = [plan_features_pricing_tier_online_dashboard_data_backups]
                        else:
                            
                            pass
                        plan_features_pricing_tier_online_dashboard_data_backup_dict = {item['default_product_id']: item for item in plan_features_pricing_tier_online_dashboard_data_backups}
                        for parking_product_instance in all_parking_product_data:
                            default_product_id = parking_product_instance['default_product_id']
                            print("default product", default_product_id)
                            plan_features_pricing_tier_online_dashboard_data_backup = plan_features_pricing_tier_online_dashboard_data_backup_dict.get(default_product_id)

                            # plan_features_pricing_tier_online_dashboard_data_backup = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=default_product_id,pricing_feature_category_id__category_name='Online Data Backup').values('id','uuid','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                            if plan_features_pricing_tier_online_dashboard_data_backup:
                                # online_data_backup = PlanFeatureDaysPrice.objects.filter(
                                #     plans_id=plans_data['id'],
                                #     plan_days_and_discount_id=plan_features_pricing_tier_online_dashboard_data_backup.id,  
                                #     plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard_data_backup.id,
                                #     currency_id=currency_type_id
                                # ).first()
                                # online_data_backup = PlanFeatureDaysPrice.objects.filter(
                                #     plans_id=id,
                                #     plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard_data_backup.id,
                                #     currency_id=data['currency_type_id']
                                # ).all()
                                online_data_backup = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard_data_backup['id'],currency_id=data['currency_type_id']).all()

                                print("online data backup", online_data_backup)

                                # if online_data_backup:
                                #     online_data_backup_price_days = plan_days * online_data_backup.days_price
                                #     online_data_backup_price = plan_days * online_data_backup_price_days
                                if online_data_backup:
                                    for backup in online_data_backup:
                                        # online_data_backup_price_days = plan_days * backup.days_price
                                        # online_data_backup_price = plan_days * online_data_backup_price_days
                                        # online_data_backup_price = online_data_backup['backup_days_id__days'] * camera_quantity * online_data_backup['days_price']
                                        # online_data_backup_price_days = camera_quantity * online_data_backup['days_price']
                                        defautlt_online_dashboard_backup_price_days = camera_quantity * backup.days_price
                                        default_online_dashboard_backup_price = backup.backup_days_id.days * camera_quantity * backup.days_price
                                        default_selected = backup.default_selected
                                        # default_selected = False
                                        print("backup",backup)
                                    # if product_data['plan_online_data_backup']['backup_id'] == online_data_backup['id'] and data['plan_online_dashboard']['selected'] == True:
                                    #     default_online_dashboard_backup_price = online_data_backup_price
                                    #     default_selected = True
                                        # default_selected = False
                                        # if (
                                        #     product_data['plan_online_data_backup']['backup_id'] == backup.id and
                                        #     data['plan_online_dashboard']['selected']
                                        # ):
                                        #     default_online_dashboard_backup_price = online_data_backup_price
                                        #     default_selected = True
                                        # if plan_features_pricing_tier_online_dashboard_data_backup.default_quantity == backup.backup_days_id.days:
                                        #     default_selected = True
                                        #     default_online_dashboard_backup_price = online_data_backup_price
                                        total_price += default_online_dashboard_backup_price
                                        product_data_json['plan_online_dashboard_data_backup'].append({
                                            'id': backup.id,
                                            'backup_days': backup.backup_days_id.days,
                                            'days_price': defautlt_online_dashboard_backup_price_days,
                                            'price': default_online_dashboard_backup_price,
                                            'currency_symbol': backup.currency_id.currency_symbol,
                                            'default_selected': default_selected,
                                            'plan_pricing_description': plan_features_pricing_tier_online_dashboard_data_backup['plan_pricing_description'],
                                        })
                        # plan_features_pricing_tier_online_dashboard_data_backup = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Online Data Backup').values('id','uuid','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                        # if plan_features_pricing_tier_online_dashboard_data_backup:
                        #     # online_data_backup = PlanFeatureDaysPrice.objects.filter(
                        #     #     plans_id=plans_data['id'],
                        #     #     plan_days_and_discount_id=plan_features_pricing_tier_online_dashboard_data_backup.id,  
                        #     #     plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard_data_backup.id,
                        #     #     currency_id=currency_type_id
                        #     # ).first()
                        #     # online_data_backup = PlanFeatureDaysPrice.objects.filter(
                        #     #     plans_id=id,
                        #     #     plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard_data_backup.id,
                        #     #     currency_id=data['currency_type_id']
                        #     # ).all()
                        #     online_data_backup = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard_data_backup['id'],currency_id=data['currency_type_id']).all()

                        #     print("online data backup", online_data_backup)
                            
                        #     # if online_data_backup:
                        #     #     online_data_backup_price_days = plan_days * online_data_backup.days_price
                        #     #     online_data_backup_price = plan_days * online_data_backup_price_days
                        #     if online_data_backup:
                        #         for backup in online_data_backup:
                        #             default_online_dashboard_backup_price_days = camera_quantity * backup.days_price
                        #             default_online_dashboard_backup_price = backup.backup_days_id.days * camera_quantity * backup.days_price
                        #             default_selected = backup.default_selected
                        #             # default_selected = False
                        #             print("backup",backup)
                        #         # if product_data['plan_online_data_backup']['backup_id'] == online_data_backup['id'] and data['plan_online_dashboard']['selected'] == True:
                        #         #     default_online_dashboard_backup_price = online_data_backup_price
                        #         #     default_selected = True
                        #             # default_selected = False
                        #             # if (
                        #             #     product_data['plan_online_data_backup']['backup_id'] == backup.id and
                        #             #     data['plan_online_dashboard']['selected']
                        #             # ):
                        #             #     default_online_dashboard_backup_price = online_data_backup_price
                        #             #     default_selected = True
                        #             # if plan_features_pricing_tier_online_dashboard_data_backup.default_quantity == backup.backup_days_id.days:
                        #             #     default_selected = True
                        #             #     default_online_dashboard_backup_price = online_data_backup_price
                                
                        #             if default_selected:
                        #                 final_online_data_dashboard_price = default_online_dashboard_backup_price
                        #                 print("final_online_dashboard_price",final_online_data_dashboard_price)
                        #             product_data_json['plan_online_dashboard_data_backup'].append({
                        #                 'id': backup.id,
                        #                 'backup_days': backup.backup_days_id.days,
                        #                 'days_price': default_online_dashboard_backup_price_days,
                        #                 'price': final_online_data_dashboard_price,
                        #                 'currency_symbol': backup.currency_id.currency_symbol,
                        #                 'default_selected': default_selected,
                        #                 'plan_pricing_description': plan_features_pricing_tier_online_dashboard_data_backup['plan_pricing_description'],
                        #             })

                        product_data_json['plan_offline_dashboard'] = []
                        plan_features_pricing_tier_offline_dashboards = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id__in=default_product_ids,pricing_feature_category_id__category_name='Offline Dashboard').values('id','uuid','default_product_id', 'pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').all()
                        print("plan_features_pricing_tier_offline_dashboards",plan_features_pricing_tier_offline_dashboards)
                        
                        if isinstance(plan_features_pricing_tier_offline_dashboards, dict):
    
                            plan_features_pricing_tier_offline_dashboards = [plan_features_pricing_tier_offline_dashboards]
                        else:
                            
                            pass
                        plan_features_pricing_tier_offline_dashboard_dict = {item['default_product_id']: item for item in plan_features_pricing_tier_offline_dashboards}

                        for parking_product_instance in all_parking_product_data:
                            default_product_id = parking_product_instance['default_product_id']
                            print("default product", default_product_id)
                            plan_features_pricing_tier_offline_dashboard = plan_features_pricing_tier_offline_dashboard_dict.get(default_product_id)
                            # plan_features_pricing_tier_offline_dashboard = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=default_product_id,pricing_feature_category_id__category_name='Offline Dashboard').values('id','uuid','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                            plan_feature_days_price_offline_dashboard = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_offline_dashboard['id'],currency_id=data['currency_type_id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').first()
                            offline_dashboard_price = plan_days * camera_quantity * plan_feature_days_price_offline_dashboard['days_price']
                            offline_dashboard_price_days = camera_quantity * plan_feature_days_price_offline_dashboard['days_price']
                            default_offline_dashboard_price = 0.0
                            if product_data['plan_offline_dashboard']['selected'] == True:
                                default_offline_dashboard_price = offline_dashboard_price
                        total_price += offline_dashboard_price
                        product_data_json['plan_offline_dashboard'].append({
                                # 'id':plan_features_pricing_tier_offline_dashboard['id'],
                                # 'uuid':plan_features_pricing_tier_offline_dashboard['uuid'],
                                # 'camera_quantity':camera_quantity,
                                'plan_days':plan_days,
                                'days_price':offline_dashboard_price_days,
                                'price': offline_dashboard_price,
                                'currency_symbol':plan_feature_days_price_offline_dashboard['currency_id__currency_symbol'],
                                # 'pricing_feature_category_id':plan_features_pricing_tier_offline_dashboard['pricing_feature_category_id'],
                                # 'category_name':plan_features_pricing_tier_offline_dashboard['pricing_feature_category_id__category_name'],
                                'default_selected':product_data['plan_offline_dashboard']['selected'],
                                # 'plan_id':plan_features_pricing_tier_offline_dashboard['plan_id'],
                                'plan_pricing_description':plan_features_pricing_tier_offline_dashboard['plan_pricing_description'],
                                # 'show_plan_pricing':plan_features_pricing_tier_offline_dashboard['show_plan_pricing']
                            })

                        print("product data:", product_data_json)
                        # plan_features_pricing_tier_offline_dashboard = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Offline Dashboard').values('id','uuid','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                        # plan_feature_days_price_offline_dashboard = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_offline_dashboard['id'],currency_id=data['currency_type_id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').first()
                        # offline_dashboard_price = plan_days * camera_quantity * plan_feature_days_price_offline_dashboard['days_price']
                        # offline_dashboard_price_days = camera_quantity * plan_feature_days_price_offline_dashboard['days_price']
                        # default_offline_dashboard_price = 0.0
                        # if product_data['plan_offline_dashboard']['selected'] == True:
                        #     default_offline_dashboard_price = offline_dashboard_price
                        # product_data_json['plan_offline_dashboard'].append({
                        #         # 'id':plan_features_pricing_tier_offline_dashboard['id'],
                        #         # 'uuid':plan_features_pricing_tier_offline_dashboard['uuid'],
                        #         # 'camera_quantity':camera_quantity,
                        #         'plan_days':plan_days,
                        #         'days_price':offline_dashboard_price_days,
                        #         'price': offline_dashboard_price,
                        #         'currency_symbol':plan_feature_days_price_offline_dashboard['currency_id__currency_symbol'],
                        #         # 'pricing_feature_category_id':plan_features_pricing_tier_offline_dashboard['pricing_feature_category_id'],
                        #         # 'category_name':plan_features_pricing_tier_offline_dashboard['pricing_feature_category_id__category_name'],
                        #         #'default_selected':product_data['plan_offline_dashboard']['selected'],
                        #         # 'plan_id':plan_features_pricing_tier_offline_dashboard['plan_id'],
                        #         'plan_pricing_description':plan_features_pricing_tier_offline_dashboard['plan_pricing_description'],
                        #         # 'show_plan_pricing':plan_features_pricing_tier_offline_dashboard['show_plan_pricing']
                        #     })

                        product_data_json['plan_offline_dashboard_data_backup'] = []
                        plan_features_pricing_tier_offline_dashboard_data_backups = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id__in=default_product_ids,pricing_feature_category_id__category_name='Offline Data Backup').values('id','uuid','default_product_id', 'pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').all()
                        print("plan_features_pricing_tier_offline_dashboard_data_backup",plan_features_pricing_tier_offline_dashboard_data_backups)
                        
                        if isinstance(plan_features_pricing_tier_offline_dashboard_data_backups, dict):
    
                            plan_features_pricing_tier_offline_dashboard_data_backups = [plan_features_pricing_tier_offline_dashboard_data_backups]
                        else:
                            
                            pass
                        plan_features_pricing_tier_offline_dashboard_data_backup_dict = {item['default_product_id']: item for item in plan_features_pricing_tier_offline_dashboard_data_backups}
                        for parking_product_instance in all_parking_product_data:
                            default_product_id = parking_product_instance['default_product_id']
                            print("default product", default_product_id)
                            plan_features_pricing_tier_offline_dashboard_data_backup = plan_features_pricing_tier_offline_dashboard_data_backup_dict.get(default_product_id)
                            # plan_features_pricing_tier_offline_dashboard_data_backup = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=default_product_id,pricing_feature_category_id__category_name='Offline Data Backup').values('id','uuid','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                            if plan_features_pricing_tier_offline_dashboard_data_backup:
                                # online_data_backup = PlanFeatureDaysPrice.objects.filter(
                                #     plans_id=plans_data['id'],
                                #     plan_days_and_discount_id=plan_features_pricing_tier_online_dashboard_data_backup.id,  
                                #     plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard_data_backup.id,
                                #     currency_id=currency_type_id
                                # ).first()
                                # online_data_backup = PlanFeatureDaysPrice.objects.filter(
                                #     plans_id=id,
                                #     plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard_data_backup.id,
                                #     currency_id=data['currency_type_id']
                                # ).all()
                                offline_data_backup = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_offline_dashboard_data_backup['id'],currency_id=data['currency_type_id']).all()

                                print("offline data backup", offline_data_backup)

                                # if online_data_backup:
                                #     online_data_backup_price_days = plan_days * online_data_backup.days_price
                                #     online_data_backup_price = plan_days * online_data_backup_price_days
                                if offline_data_backup:
                                    for backup in offline_data_backup:
                                        default_offline_dashboard_backup_price_days = camera_quantity * backup.days_price
                                        default_offline_dashboard_backup_price = backup.backup_days_id.days * camera_quantity * backup.days_price
                                        default_selected = backup.default_selected
                                        # default_selected = False
                                        print("backup",backup)
                                    # if product_data['plan_online_data_backup']['backup_id'] == online_data_backup['id'] and data['plan_online_dashboard']['selected'] == True:
                                    #     default_online_dashboard_backup_price = online_data_backup_price
                                    #     default_selected = True
                                        # default_selected = False
                                        # if (
                                        #     product_data['plan_online_data_backup']['backup_id'] == backup.id and
                                        #     data['plan_online_dashboard']['selected']
                                        # ):
                                        #     default_online_dashboard_backup_price = online_data_backup_price
                                        #     default_selected = True
                                        # if plan_features_pricing_tier_online_dashboard_data_backup.default_quantity == backup.backup_days_id.days:
                                        #     default_selected = True
                                        #     default_online_dashboard_backup_price = online_data_backup_price
                                        total_price += default_offline_dashboard_backup_price
                                        product_data_json['plan_offline_dashboard_data_backup'].append({
                                            'id': backup.id,
                                            'backup_days': backup.backup_days_id.days,
                                            'days_price': default_offline_dashboard_backup_price_days,
                                            'price': default_offline_dashboard_backup_price,
                                            'currency_symbol': backup.currency_id.currency_symbol,
                                            'default_selected': default_selected,
                                            'plan_pricing_description': plan_features_pricing_tier_offline_dashboard_data_backup['plan_pricing_description'],
                                        })
                        # plan_features_pricing_tier_offline_dashboard_data_backup = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Offline Data Backup').values('id','uuid','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                        # if plan_features_pricing_tier_offline_dashboard_data_backup:
                        #     # online_data_backup = PlanFeatureDaysPrice.objects.filter(
                        #     #     plans_id=plans_data['id'],
                        #     #     plan_days_and_discount_id=plan_features_pricing_tier_online_dashboard_data_backup.id,  
                        #     #     plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard_data_backup.id,
                        #     #     currency_id=currency_type_id
                        #     # ).first()
                        #     # online_data_backup = PlanFeatureDaysPrice.objects.filter(
                        #     #     plans_id=id,
                        #     #     plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard_data_backup.id,
                        #     #     currency_id=data['currency_type_id']
                        #     # ).all()
                        #     offline_data_backup = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_offline_dashboard_data_backup['id'],currency_id=data['currency_type_id']).all()

                        #     print("offline data backup", offline_data_backup)

                        #     # if online_data_backup:
                        #     #     online_data_backup_price_days = plan_days * online_data_backup.days_price
                        #     #     online_data_backup_price = plan_days * online_data_backup_price_days
                        #     if offline_data_backup:
                        #         for backup in offline_data_backup:
                        #             default_offline_dashboard_backup_price_days = camera_quantity * backup.days_price
                        #             default_offline_dashboard_backup_price = backup.backup_days_id.days * camera_quantity * backup.days_price
                        #             default_selected = backup.default_selected
                        #             # default_selected = False 
                        #             print("backup",backup)
                        #         # if product_data['plan_online_data_backup']['backup_id'] == online_data_backup['id'] and data['plan_online_dashboard']['selected'] == True:
                        #         #     default_online_dashboard_backup_price = online_data_backup_price
                        #         #     default_selected = True
                        #             # default_selected = False
                        #             # if (
                        #             #     product_data['plan_online_data_backup']['backup_id'] == backup.id and
                        #             #     data['plan_online_dashboard']['selected']
                        #             # ):
                        #             #     default_online_dashboard_backup_price = online_data_backup_price
                        #             #     default_selected = True
                        #             # if plan_features_pricing_tier_online_dashboard_data_backup.default_quantity == backup.backup_days_id.days:
                        #             #     default_selected = True
                        #             #     default_online_dashboard_backup_price = online_data_backup_price
                        #             if default_selected:
                        #                 final_offline_data_dashboard_price = default_offline_dashboard_backup_price
                        #                 print("final_offline_dashboard_price",final_offline_data_dashboard_price)
                        #             product_data_json['plan_offline_dashboard_data_backup'].append({
                        #                 'id': backup.id,
                        #                 'backup_days': backup.backup_days_id.days,
                        #                 'days_price': default_offline_dashboard_backup_price_days,
                        #                 'price': final_offline_data_dashboard_price,
                        #                 'currency_symbol': backup.currency_id.currency_symbol,
                        #                 'default_selected': default_selected,
                        #                 'plan_pricing_description': plan_features_pricing_tier_offline_dashboard_data_backup['plan_pricing_description'],
                        #             })
                        
                        # total_price = camera_price + online_dashboard_price +final_online_data_dashboard_price + offline_dashboard_price + final_offline_data_dashboard_price + default_product_price+default_product_feature_price
                        all_product_total_price+=total_price
                        print("total_price",total_price)
                        # existing_plan_id = data.get('existing_plan_id')
                        # try:
                        #     existing_plan = BusinessPlanHistory.objects.get(id=existing_plan_id)
                        #     remaining_value = self.calculate_remaining_value(existing_plan)
                        # except BusinessPlanHistory.DoesNotExist:
                        #     return JsonResponse({'error': 'Invalid existing_plan_id'}, status=status.HTTP_400_BAD_REQUEST)

                    
                        # refund_amount = min(remaining_value, total_price)

                        # default_camera_price = sum(product['plan_camera_detail']['camera_quantity'] * 10 for product in plans_detail['plan_product'])
                        # default_online_dashboard_price = sum(100 for product in plans_detail['plan_product'] if product['plan_online_dashboard']['selected'])
                        # default_online_dashboard_backup_price = sum(50 for product in plans_detail['plan_product'] if product['plan_online_data_backup']['backup_id'])
                        # default_offline_dashboard_price = sum(80 for product in plans_detail['plan_product'] if product['plan_offline_dashboard']['selected'])
                        # default_offline_dashboard_backup_price = sum(30 for product in plans_detail['plan_product'] if product['plan_offline_data_backup']['backup_id'])
                        # default_product_price = sum(product['plan_camera_detail']['camera_quantity'] * 5 for product in plans_detail['plan_product'])
                        # default_product_feature_price = 0  
                        
                        # total_price = (
                        #     default_camera_price + 
                        #     default_online_dashboard_price + 
                        #     default_online_dashboard_backup_price + 
                        #     default_offline_dashboard_price + 
                        #     default_offline_dashboard_backup_price + 
                        #     default_product_price + 
                        #     default_product_feature_price
                        # )

                        
                        # existing_plan_id = data.get('existing_plan_id')
                       
                    
                    
                        plans_data['product_data'].append(product_data_json)
                        discount_amount = (total_price * get_plan_days_and_discount.discount_percentage)/100
                        total_price_after_discount = total_price - discount_amount
                        if plans_detail['coupon_code'] != None:
                            get_coupon = Coupon.objects.filter(code=plans_detail['coupon_code'],currency_id=data['currency_type_id'],plan_buy_days__gte=plan_days,coupon_expiry_datetime__gte= timezone.datetime.now(),is_active=True).values('id','uuid','code','description','discount_type','discount_value','currency_id','currency_id__currency_type').first()
                            if get_coupon != None:
                                total_coupon_amount = 0.0
                                if get_coupon['discount_type'] == 'percentage':
                                    total_coupon_amount =  (all_product_total_price * get_coupon['discount_value'])/100
                                elif get_coupon['discount_type'] == 'fixed amount':
                                    total_coupon_amount = all_product_total_price - get_coupon['discount_value']
                                total_price_after_discount -= total_coupon_amount

                            plans_data['coupon_code'] ={
                                # 'id':get_coupon['id'],
                                # 'uuid':get_coupon['uuid'],
                                'code':get_coupon['code'],
                                'description':get_coupon['description'],
                                'discount_type':get_coupon['discount_type'],
                                'discount_value':get_coupon['discount_value'],
                                # 'currency_id':get_coupon['currency_id'],
                                'total_coupon_amount':total_coupon_amount
                            }

                        else:
                            return Response({'detail':"coupon code is not valid."},status.HTTP_400_BAD_REQUEST)

                    plan_pricing_tax_detail = PlanPricingTax.objects.filter(plan_pricing_id = get_plan_days_and_discount.plan_pricing_id).values('id','uuid','plan_pricing_id','tax_percentage_detail_id','tax_percentage_detail_id__tax_percentage','tax_percentage_detail_id__tax_type')
                    tax_detail = []
                    total_price_after_tax = total_price_after_discount
                    for pricing_tax in plan_pricing_tax_detail:
                        tax_amount = (total_price_after_discount*pricing_tax['tax_percentage_detail_id__tax_percentage'])/100
                        total_price_after_tax += tax_amount
                        tax_detail.append({
                            # 'id':pricing_tax['id'],
                            # 'uuid':pricing_tax['uuid'],
                            # 'tax_percentage_detail_id':pricing_tax['tax_percentage_detail_id'],
                            'tax_percentage':pricing_tax['tax_percentage_detail_id__tax_percentage'],
                            'tax_type':pricing_tax['tax_percentage_detail_id__tax_type'],
                            'tax_amount':tax_amount
                        })
                    plans_data['plan_pricing'] ={
                        'total_price':total_price,
                        'discount_percent':get_plan_days_and_discount.discount_percentage,
                        'discount_amount':discount_amount,
                        'total_price_after_discount':total_price_after_discount,
                        'total_price_after_tax':total_price_after_tax,
                        'tax_detail':tax_detail
                    }
                        
                return Response(plans_data, status=status.HTTP_200_OK)
            else:
                return Response({"detail": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)    
        
class CashfreeWebhookView(APIView):
    def post(self, request, *args, **kwargs):
        try:


            logger.info("Received webhook POST request")
            body_unicode = request.body.decode('utf-8')
            print(body_unicode)
            logger.debug(f"Request body: {body_unicode}")
            event_data = json.loads(body_unicode)
            print("ed",event_data)
            logger.info("Event data parsed successfully")

            customer_id = event_data.get('data', {}).get('customer_details', {}).get('customer_id')
            print("cid",customer_id)
            
            if not customer_id:
                raise ValueError("customer_id not found in the event data")
            
            logger.debug(f"Extracted customer_id: {customer_id}")
            
            company_detail_obj = CompanyDetail.objects.get(uuid=customer_id)
            business_plan_history_obj = BusinessPlanHistory.objects.filter(company_detail_id=company_detail_obj.id).latest('id')
            print("bpho", business_plan_history_obj)
            
            plan_type = business_plan_history_obj.plan_type

            
            business_plan_history = BusinessPlanHistorySerializer(business_plan_history_obj).data
            print("bph",business_plan_history)
                       
            self.process_webhook_event(request,business_plan_history, event_data)
            print("success")
            logger.info("Webhook event processed successfully")

                
                
            return JsonResponse({'status': 'success'})
        except Exception as e:
            logger.error(f"Error processing webhook: {str(e)}", exc_info=True)
            
            return JsonResponse({'status': 'error', 'message': str(e)}, status=500)


    def process_webhook_event(self,request, business_plan_history, event_data):
        try:
                
                payload = json.loads(request.body)
                event_data = payload['data']


                event_type = payload['type']
                event_time = payload['event_time']
                order_id = event_data['order']['order_id']
                payment_status = event_data['payment']['payment_status']
                customer_id = event_data['customer_details']['customer_id']
                customer_email = event_data['customer_details']['customer_email']
                payment_amount = event_data['payment']['payment_amount']
                payment_time = event_data['payment']['payment_time']

               
                print("Event Type:", event_type)
                print("Event Time:", event_time)
                print("Order ID:", order_id)
                print("Payment Status:", payment_status)
                print("Customer ID:", customer_id)
                print("Customer Email:", customer_email)
                print("Payment Amount:", payment_amount)
                print("Payment Time:", payment_time)
               
                company_detail_obj = CompanyDetail.objects.get(uuid=customer_id)
                business_plan_history_obj = BusinessPlanHistory.objects.filter(company_detail_id=company_detail_obj.id).latest('id')
                print("bpho", business_plan_history_obj)
                
                plan_type = business_plan_history_obj.plan_type
            
                if event_type == 'PAYMENT_SUCCESS_WEBHOOK' and payment_status == 'SUCCESS':
                #if event_type == 'payment' and payment_status == 'success':
                
                    self.update_transaction_history(business_plan_history, payment_amount, customer_email)
                else:
                     if plan_type == 'BuyPlan':
                        
                        self.rollback_transaction(business_plan_history)
                     elif plan_type == 'Upgrade Plan':
                        self.rollback_transaction_for_upgradeplan(business_plan_history)
                        
                        print("failed")

        except Exception as e:
                    print("Error in process_webhook_event")
                    logger.error(f"Error in process_webhook_event: {str(e)}", exc_info=True)
                    raise
      
    def send_payment_confirmation_email(self, customer_email, payment_amount):
        subject = 'Payment Confirmation'
        message = f'Your payment of {payment_amount} was successful.'
        from_email = 'prachipatel200023@gmail.com'
        recipient_list = [customer_email]

        try:
            send_mail(subject, message, from_email, recipient_list)
            logger.info(f"Payment confirmation email sent to {customer_email}")
            print(f"Payment confirmation email sent to {customer_email}")
        except Exception as e:
            logger.info(f"Failed to send payment confirmation email to {customer_email}: {e}")
            print(f"Failed to send payment confirmation email to {customer_email}: {e}")
    @transaction.atomic
    def update_transaction_history(self, business_plan_history, payment_amount, customer_email):
        try:
            currency = Currency.objects.get(id=business_plan_history['currency_id'])
            company_detail = CompanyDetail.objects.get(id=business_plan_history['company_detail_id'])
            business_plan_history_obj = BusinessPlanHistory.objects.get(id=business_plan_history['id'])


            BusinessTransactionHistory.objects.create(
                amout_paid=payment_amount,
                currency_id=currency,
                currency_type=business_plan_history['currency_type'],
                currency_symbol=business_plan_history['currency_symbol'],
                date_and_time=timezone.now(),
                business_detail_id=company_detail,
                business_plan_history_id=business_plan_history_obj,
                #payment_status=True
            )

            business_plan_history_obj.payment_status = True
            business_plan_history_obj.save()
            self.send_payment_confirmation_email(customer_email, payment_amount)
        except Exception as e:
            logger.error(f"Error updating transaction history: {e}", exc_info=True)
            print(f"Error updating transaction history: {e}")
            raise
        
    @transaction.atomic
    def rollback_transaction(self, business_plan_history):
        try:
            company_detail_id = business_plan_history['company_detail_id']

            
            BusinessPlanHistory.objects.filter(id=business_plan_history['id']).delete()

           
            user_role_mappings = UserRoleMapping.objects.filter(company_detail_id=company_detail_id)
            users = User.objects.filter(company_detail_id=company_detail_id)
            add_user_emails = AddUserEmail.objects.filter(company_detail_id=company_detail_id)

            for user_role_map in user_role_mappings:
                UserRoleMapping.objects.filter(id=user_role_map.id).delete()

            for user in users:
                User.objects.filter(id=user.id).delete()

            for add_user_email in add_user_emails:
                AddUserEmail.objects.filter(id=add_user_email.id).delete()

            
            try:
                latest_role = Roles.objects.filter(company_detail_id=company_detail_id).latest('created_datetime')

               
                permissions_to_delete = Permission.objects.filter(role=latest_role)
                for permission in permissions_to_delete:
                    Permission.objects.filter(id=permission.id).delete()

              
                Roles.objects.filter(id=latest_role.id).delete()
            except Roles.DoesNotExist:
                logger.warning(f"No roles found for company_detail_id {company_detail_id}")

            
            CompanyDetail.objects.filter(id=company_detail_id).delete()

            logger.info("Rolled back all related entries for the failed transaction")
        except Exception as e:
            logger.error(f"Error during rollback: {e}", exc_info=True)
            raise

    @transaction.atomic
    def rollback_transaction_for_upgradeplan(self, business_plan_history):
        try:
            company_detail_id = business_plan_history['company_detail_id']

            
            BusinessPlanHistory.objects.filter(id=business_plan_history['id']).delete()
            BusinessPricingTier.objects.filter(business_plan_history_id=company_detail_id).delete()
            #BusinessTransactionHistory.objects.filter(business_plan_history_id=business_detail_id).delete()
            BusinessPlanPricingTax.objects.filter(business_plan_history_id=company_detail_id).delete()
            
           
            BusinessPlanHistory.objects.filter(id=company_detail_id).delete()
            
            logger.info("Rolled back all related entries for the failed upgrade transaction")
        except Exception as e:
            logger.error(f"Error during rollback of upgrade transaction: {e}", exc_info=True)
            raise