from django.db import models
# from django.contrib.auth.models import User
import datetime
from uuid import uuid4
from django.contrib.postgres.functions import RandomUUID
import pytz
from django.contrib.auth.models import (
    BaseUserManager, AbstractBaseUser,AbstractUser,PermissionsMixin
)
import django
import uuid
from django.core.validators import RegexValidator
from django.utils import timezone
timezone.now

class AccountManager(BaseUserManager):
    use_in_migrations = True

    def _create_user(self, email, company_detail_id, password, **extra_fields):
        values = [email, company_detail_id]
        field_value_map = dict(zip(self.model.REQUIRED_FIELDS, values))
        for field_name, value in field_value_map.items():
            if not value:
                raise ValueError('The {} value must be set'.format(field_name))

        email = self.normalize_email(email)
        user = self.model(
            email=email,
            company_detail_id=company_detail_id,
            **extra_fields
        )
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_user(self, email, company_detail_id, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', False)
        extra_fields.setdefault('is_superuser', False)
        return self._create_user(email, company_detail_id, password, **extra_fields)

    def create_superuser(self, email, company_detail_id, password=None, **extra_fields):
        extra_fields.setdefault('is_active', True)
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)

        if extra_fields.get('is_staff') is not True:
            raise ValueError('Superuser must have is_staff=True.')
        if extra_fields.get('is_superuser') is not True:
            raise ValueError('Superuser must have is_superuser=True.')

        return self._create_user(email, company_detail_id, password, **extra_fields)




##Dfault Enter Manually
# class Days(models.Model):
#     uuid = models.UUIDField(default = uuid4,editable = False)
#     days = models.IntegerField()
#     category = models.CharField(max_length=50)

##Dfault Enter Manually
class Currency(models.Model):
    uuid = models.UUIDField(default = uuid4,editable = False)
    currency_type = models.CharField(max_length=30)
    currency_symbol = models.CharField(max_length=10)

##Dfault Enter Manually
# class PlanFeaturesPricingCategory(models.Model):
#     uuid = models.UUIDField(default = uuid4,editable = False)
#     category_name = models.CharField(max_length=50)


##Dfault Enter Manually
# class CountryCategory(models.Model):
#     uuid = models.UUIDField(default = uuid4,editable = False)
#     country = models.CharField(max_length=30)

##Dfault Enter Manually
# class TaxPercentageDetail(models.Model):
#     uuid = models.UUIDField(default = uuid4,editable = False)
#     tax_percentage = models.FloatField(default=0.0)
#     tax_type = models.CharField(max_length=20)
#     country_category = models.ForeignKey(CountryCategory,on_delete=models.CASCADE)


# ##Dfault Enter Manually
# class Plans(models.Model):
#     uuid = models.UUIDField(default = uuid4,editable = False)
#     plan_name = models.CharField(max_length=30)

# ##Dfault Enter Manually
# class PlanDescription(models.Model):
#     uuid = models.UUIDField(default = uuid4,editable = False)
#     plan_description = models.TextField()
#     plan_id = models.ForeignKey(Plans,on_delete=models.CASCADE)

# ##Dfault Enter Manually
# class PlanPricing(models.Model):
#     uuid = models.UUIDField(default = uuid4,editable = False)
#     basic_price = models.FloatField()
#     basic_price_after_discount = models.FloatField()
#     basic_price_after_tax = models.FloatField()
#     days_price = models.FloatField()
#     days_price_after_discount = models.FloatField()
#     days_price_after_tax = models.FloatField()
#     currency_id = models.ForeignKey(Currency,on_delete=models.CASCADE)
#     country_type_id = models.ForeignKey(CountryCategory,on_delete=models.CASCADE)
#     plan_id = models.ForeignKey(Plans,on_delete=models.CASCADE)
#     # plan_days_and_discount = models.ForeignKey(PlanDaysAndDiscount,on_delete=models.CASCADE)
#     # discount_percentage = models.FloatField()
#     # discount_in_currency = models.FloatField()

# ##Dfault Enter Manually
# class PlanDaysAndDiscount(models.Model):
#     uuid = models.UUIDField(default = uuid4,editable = False)
#     plan_days = models.IntegerField()
#     discount_percentage = models.FloatField(default=0.0)
#     category = models.CharField(max_length=50)
#     default_select = models.BooleanField(default=False)
#     plan_id = models.ForeignKey(Plans,on_delete=models.CASCADE)
#     plan_pricing_id = models.ForeignKey(PlanPricing,on_delete=models.CASCADE)

# class PlanPricingTax(models.Model):
#     uuid = models.UUIDField(default = uuid4,editable = False)
#     plan_pricing_id = models.ForeignKey(PlanPricing,on_delete=models.CASCADE)
#     tax_percentage_detail_id = models.ForeignKey(TaxPercentageDetail,on_delete=models.CASCADE)
#     tax_amount = models.FloatField()
#     currency_id = models.ForeignKey(Currency,on_delete=models.CASCADE)


# # class PlanDaysPricingBasedOnCurrency(models.Model):
# ##Dfault Enter Manually
# class PlanFeaturePricingTier(models.Model):
#     uuid = models.UUIDField(default = uuid4,editable = False)
#     min_quantity = models.IntegerField(blank=True, null=True)
#     max_quantity = models.IntegerField(blank=True, null=True)
#     default_quantity = models.IntegerField(blank=True, null=True)
#     default_product_id = models.ForeignKey(DefaultProduct,on_delete=models.CASCADE, blank=True, null=True)
#     default_product_feature_id = models.ForeignKey(DefaultProductFeature,on_delete=models.CASCADE, blank=True, null=True)
#     pricing_feature_category_id = models.ForeignKey(PlanFeaturesPricingCategory,on_delete=models.CASCADE)
#     plan_id = models.ForeignKey(Plans,on_delete=models.CASCADE)
#     # default_selected = models.BooleanField(default=False)
#     plan_pricing_description = models.TextField()
#     show_plan_pricing = models.BooleanField(default=False)

# class PlanFeatureDaysPrice(models.Model):
#     uuid = models.UUIDField(default = uuid4,editable = False)
#     backup_days_id = models.ForeignKey(Days,on_delete=models.CASCADE, blank=True, null=True)
#     plan_days_and_discount_id = models.ForeignKey(PlanDaysAndDiscount,on_delete=models.CASCADE,blank=True, null=True)
#     days_price = models.FloatField()
#     currency_id = models.ForeignKey(Currency,on_delete=models.CASCADE)
#     plan_feature_pricing_tier_id = models.ForeignKey(PlanFeaturePricingTier,on_delete=models.CASCADE)
#     plans_id = models.ForeignKey(Plans,on_delete=models.CASCADE)
#     default_selected = models.BooleanField(default=False)

# ##Dfault Enter Manually
# # class DefaultPlanPricingTier(models.Model):
# #     uuid = models.UUIDField(default = uuid4,editable = False)
# #     days = models.ForeignKey(Days,on_delete=models.CASCADE, blank=True, null=True)
# #     quantity = models.IntegerField()
# #     price = models.FloatField()
# #     days_price = models.FloatField()
# #     currency = models.ForeignKey(Currency,on_delete=models.CASCADE)
# #     default_product = models.ForeignKey(DefaultProduct,on_delete=models.CASCADE, blank=True, null=True)
# #     default_product_feature = models.ForeignKey(DefaultProductFeature,on_delete=models.CASCADE, blank=True, null=True)
# #     pricing_category = models.ForeignKey(PricingCategory,on_delete=models.CASCADE)
# #     plan_id = models.ForeignKey(Plans,on_delete=models.CASCADE)

# class Coupon(models.Model):
#     uuid = models.UUIDField(default = uuid4,editable = False)
#     code = models.CharField(max_length=100)
#     description = models.CharField(max_length=500)
#     discount_type = models.CharField(max_length=30)
#     discount_value = models.FloatField()
#     currency_id = models.ForeignKey(Currency,on_delete=models.CASCADE)
#     country_category_id = models.ForeignKey(CountryCategory,on_delete=models.CASCADE)
#     plan_buy_days = models.IntegerField(default=30)
#     coupon_expiry_datetime = models.DateTimeField()
#     is_active = models.BooleanField(default=True)
#     user_valid_for_coupon = models.IntegerField(default=10)

# class ProductPlan(models.Model):
#     uuid = models.UUIDField(default = uuid4,editable = False)
#     default_product_id = models.ForeignKey(DefaultProduct,on_delete=models.CASCADE)
#     plan_id = models.ForeignKey(Plans,on_delete=models.CASCADE)
#     allowed_status = models.BooleanField(default=False)

# class ProductFeaturePlan(models.Model):
#     uuid = models.UUIDField(default = uuid4,editable = False)
#     default_product_id = models.ForeignKey(DefaultProduct,on_delete=models.CASCADE)
#     default_product_feature_id = models.ForeignKey(DefaultProductFeature,on_delete=models.CASCADE)
#     product_plan_id = models.ForeignKey(ProductPlan, on_delete=models.CASCADE)
#     plan_id = models.ForeignKey(Plans,on_delete=models.CASCADE)
#     allowed_status = models.BooleanField(default=False)

class CompanyDetail(models.Model):
    uuid = models.UUIDField(default = uuid4,editable = False)
    company_name = models.CharField(max_length=50)
    company_logo = models.ImageField(upload_to='port_management_system/logo/',blank=True,null=True,max_length=500)
    country = models.CharField(max_length=20)
    uses_type = models.CharField(max_length=100,default='free trail')
    plan_start_datetime = models.DateTimeField(default=django.utils.timezone.now)
    plan_expire_datetime = models.DateTimeField(default=django.utils.timezone.now)
    days_to_expire = models.IntegerField(default=15)
    minute_to_expire = models.IntegerField(default=21600)
    plan_validity = models.BooleanField(default=True)
    currency = models.ForeignKey(Currency,on_delete=models.CASCADE)
    timezones = models.CharField(max_length=50,default='Asia/Kolkata')
    delete_previous_data_after_day_cloud = models.IntegerField(default=30)
    delete_previous_data_after_day_on_premises = models.IntegerField(default=30)

# class CompanyPlanHistory(models.Model):
#     uuid = models.UUIDField(default = uuid4,editable = False)
#     plan_name = models.CharField(max_length=30)
#     price = models.FloatField()
#     price_after_discount = models.FloatField()
#     price_after_tax = models.FloatField()
#     days_price = models.FloatField()
#     days_price_after_discount = models.FloatField()
#     days_price_after_tax = models.FloatField()
#     currency_id = models.ForeignKey(Currency,on_delete=models.CASCADE)
#     currency_type = models.CharField(max_length=30)
#     currency_symbol = models.CharField(max_length=10)
#     country_category_id = models.ForeignKey(CountryCategory,on_delete=models.CASCADE)
#     country_type = models.CharField(max_length=30)
#     plan_id = models.ForeignKey(Plans,on_delete=models.CASCADE)
#     plan_days_and_discount_id = models.ForeignKey(PlanDaysAndDiscount,on_delete=models.CASCADE)
#     plan_days = models.IntegerField()
#     discount_in_percentage = models.FloatField(default=0.0)
#     discount_in_currency = models.FloatField(default=0.0)
#     total_discount = models.FloatField()
#     total_tax_in_percentae = models.FloatField()
#     total_tax_in_currency = models.FloatField()
#     buy_datetime = models.DateTimeField(default=django.utils.timezone.now)
#     plan_start_datetime = models.DateTimeField(default=django.utils.timezone.now)
#     plan_end_datetime = models.DateTimeField()
#     minutes_to_expire = models.IntegerField()
#     plan_validity = models.BooleanField()
#     active_plan = models.BooleanField()
#     plan_type = models.CharField(max_length=30)
#     company_detail_id = models.ForeignKey(CompanyDetail,on_delete=models.CASCADE)

# class CompanyPlanPricingTax(models.Model):
#     uuid = models.UUIDField(default = uuid4,editable = False)
#     company_plan_history_id = models.ForeignKey(CompanyPlanHistory,on_delete=models.CASCADE)
#     tax_percentage_detail_id = models.ForeignKey(TaxPercentageDetail,on_delete=models.CASCADE)
#     tax_type = models.CharField(max_length=30)
#     tax_percentage = models.FloatField()
#     tax_amount = models.FloatField()
#     company_detail_id = models.ForeignKey(CompanyDetail,on_delete=models.CASCADE)

# class CompanyPlanCoupon(models.Model):
#     uuid = models.UUIDField(default = uuid4,editable = False)
#     coupon_code = models.CharField(max_length=100)
#     description = models.CharField(max_length=500)
#     discount_type = models.CharField(max_length=30)
#     discount_value = models.FloatField()
#     coupon_id = models.ForeignKey(Coupon,on_delete=models.CASCADE)
#     total_coupon_amount = models.FloatField()
#     company_plan_history_id = models.ForeignKey(CompanyPlanHistory,on_delete=models.CASCADE)
#     company_detail_id = models.ForeignKey(CompanyDetail,on_delete=models.CASCADE)

# class CompanyPricingTier(models.Model):
#     uuid = models.UUIDField(default = uuid4,editable = False)
#     backup_days_id = models.ForeignKey(Days,on_delete=models.CASCADE, blank=True, null=True)
#     backup_days = models.IntegerField(blank=True,null=True)
#     quantity = models.IntegerField(blank=True,null=True)
#     price = models.FloatField()
#     days_price = models.FloatField()
#     currency_id = models.ForeignKey(Currency,on_delete=models.CASCADE)
#     default_product_id = models.ForeignKey(DefaultProduct,on_delete=models.CASCADE, blank=True, null=True)
#     default_product_feature_id = models.ForeignKey(DefaultProductFeature,on_delete=models.CASCADE, blank=True, null=True)
#     plan_feature_pricing_category_id = models.ForeignKey(PlanFeaturesPricingCategory,on_delete=models.CASCADE)
#     category_name = models.CharField(max_length=30)
#     plan_id = models.ForeignKey(Plans,on_delete=models.CASCADE)
#     company_plan_history_id = models.ForeignKey(CompanyPlanHistory,on_delete=models.CASCADE)
#     plan_feature_pricing_tier_id = models.ForeignKey(PlanFeaturePricingTier,on_delete=models.CASCADE)
#     company_detail_id = models.ForeignKey(CompanyDetail,on_delete=models.CASCADE)
#     plan_pricing_description = models.TextField()

# class CompanyTransactionHistory(models.Model):
#     uuid = models.UUIDField(default = uuid4,editable = False)
#     Amout_Paid = models.FloatField()
#     currency_id = models.ForeignKey(Currency,on_delete=models.CASCADE)
#     currency_type = models.CharField(max_length=30)
#     currency_symbol = models.CharField(max_length=10)
#     date_and_time = models.DateTimeField(default=django.utils.timezone.now)
#     company_detail_id = models.ForeignKey(CompanyDetail,on_delete=models.CASCADE)
#     company_plan_history_id = models.ForeignKey(CompanyPlanHistory,on_delete=models.CASCADE)



class Roles(models.Model):
    uuid = models.UUIDField(default = uuid4,editable = False)
    role_name = models.CharField(max_length=50)
    company_detail_id = models.ForeignKey(CompanyDetail, on_delete=models.CASCADE)
    created_by = models.CharField(max_length=50,blank=True, null=True)
    created_datetime = models.DateTimeField(default=django.utils.timezone.now)
    updated_by = models.CharField(max_length=50,blank=True, null=True)
    updated_datetime = models.DateTimeField(default=django.utils.timezone.now)

class UserType(models.Model):
    uuid = models.UUIDField(default = uuid4,editable = False)
    is_menu_visible = models.CharField(max_length=100)

class MenuPage(models.Model):
    uuid = models.UUIDField(default = uuid4,editable = False)
    menu_name = models.CharField(max_length=100)
    is_menu_type = models.ForeignKey(UserType, on_delete=models.CASCADE)
    created_by = models.CharField(max_length=50,blank=True, null=True)
    created_datetime = models.DateTimeField(default=django.utils.timezone.now)
    updated_by = models.CharField(max_length=50,blank=True, null=True)
    updated_datetime = models.DateTimeField(default=django.utils.timezone.now)

class Action(models.Model):
    uuid = models.UUIDField(default = uuid4,editable = False)
    action_name = models.CharField(max_length=100)

class MenuActionMap(models.Model):
    uuid = models.UUIDField(default = uuid4,editable = False)
    menu_page = models.ForeignKey(MenuPage, on_delete=models.CASCADE)
    action = models.ForeignKey(Action, on_delete=models.CASCADE)

class Permission(models.Model):
    uuid = models.UUIDField(default = uuid4,editable = False)
    role = models.ForeignKey(Roles, on_delete=models.CASCADE)
    menu_page = models.ForeignKey(MenuPage, on_delete=models.CASCADE)
    action = models.ForeignKey(Action, on_delete=models.CASCADE)

class User(AbstractBaseUser,PermissionsMixin):
    uuid = models.UUIDField(default = uuid4,editable = False)
    email = models.EmailField(verbose_name='email address',max_length=255,unique=True,)
    phone_regex = RegexValidator(regex=r'^\+?1?\d{11,15}$', message="Phone number must be entered in the format: '+919999999999'. Up to 15 digits allowed.")
    phone_number = models.CharField(validators=[phone_regex], max_length=17, blank=True) # Validators should be a list
    company_detail_id = models.ForeignKey(CompanyDetail, on_delete=models.CASCADE)
    user_login_or_not = models.BooleanField(default=False)
    timezones = models.CharField(max_length=50,default='Asia/Kolkata')
    is_active = models.BooleanField(default=False)
    is_staff = models.BooleanField(default=False) # a admin user; non super-user
    date_joined = models.DateTimeField(default=django.utils.timezone.now)
    last_login = models.DateTimeField(null=True)
    is_verified = models.BooleanField(default=False)
    
    # notice the absence of a "Password field", that is built in.

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['company_detail_id'] # Email & Password are required by default.
    objects = AccountManager()
    def get_full_name(self):
        # The user is identified by their email address
        return self.email

    def get_short_name(self):
        # The user is identified by their email address
        return self.email

class LoginLogs(models.Model):
    uuid = models.UUIDField(default = uuid4,editable = False)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    last_login_datetime = models.DateTimeField(default=django.utils.timezone.now)


class UserRoleMapping(models.Model):
    uuid = models.UUIDField(default = uuid4,editable = False)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    role = models.ForeignKey(Roles, on_delete=models.CASCADE)
    company_detail_id = models.ForeignKey(CompanyDetail, on_delete=models.CASCADE)
    created_by = models.CharField(max_length=50,blank=True, null=True)
    created_datetime = models.DateTimeField(default=django.utils.timezone.now)
    updated_by = models.CharField(max_length=50,blank=True, null=True)
    updated_datetime = models.DateTimeField(default=django.utils.timezone.now)

class AddUserEmail(models.Model):
    uuid = models.UUIDField(default = uuid4,editable = False)
    email = models.EmailField(verbose_name='email address',max_length=255,unique=True,)
    role = models.ForeignKey(Roles, on_delete=models.CASCADE)
    company_detail_id = models.ForeignKey(CompanyDetail, on_delete=models.CASCADE)


class Sites(models.Model):
    uuid = models.UUIDField(default = uuid4,editable = False)
    site_name = models.CharField(max_length=30)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    company_detail_id = models.ForeignKey(CompanyDetail, on_delete=models.CASCADE)
    skip_frame = models.IntegerField(default=5)
    user_login_or_not = models.BooleanField(default=False)
    active = models.BooleanField(default=True)
    # plan_validity = models.BooleanField(default=True)
    # days_to_expire = models.IntegerField(default=15)
    site_encryption_key = models.UUIDField(default = uuid4,editable = False)
    created_by = models.CharField(max_length=50,blank=True, null=True)
    created_datetime = models.DateTimeField(default=django.utils.timezone.now)
    updated_by = models.CharField(max_length=50,blank=True, null=True)
    updated_datetime = models.DateTimeField(default=django.utils.timezone.now)

# class UserVerificationOtp(models.Model):
#     uuid = models.UUIDField(default = uuid4,editable = False)
#     opt_number = models.IntegerField(max_length=6)
#     user_id = models.ForeignKey(User, on_delete=models.CASCADE)
#     otp_validity_datetime = models.DateTimeField()
    


class WindowsSitesActiveLog(models.Model):
    uuid = models.UUIDField(default = uuid4,editable = False) 
    sites = models.ForeignKey(Sites, on_delete=models.CASCADE)
    company_detail_id = models.ForeignKey(CompanyDetail,on_delete=models.CASCADE)
    last_active_datetime = models.DateTimeField(default=django.utils.timezone.now)
    application_open = models.BooleanField(default=False)
    active = models.BooleanField(default=False)
    login = models.BooleanField(default=False)
    last_active_status = models.BooleanField(default=True)
    email_sent = models.BooleanField(default=False)

class WindowsDeactiveLog(models.Model):
    uuid = models.UUIDField(default = uuid4,editable = False)
    sites = models.ForeignKey(Sites, on_delete=models.CASCADE)
    company_detail_id = models.ForeignKey(CompanyDetail,on_delete=models.CASCADE)
    start_datetime = models.DateTimeField(default=django.utils.timezone.now)
    end_datetime = models.DateTimeField(default=django.utils.timezone.now)

class SiteLoginLog(models.Model):
    uuid = models.UUIDField(default = uuid4,editable = False)
    sites = models.ForeignKey(Sites, on_delete=models.CASCADE)
    company_detail_id = models.ForeignKey(CompanyDetail,on_delete=models.CASCADE)
    last_login_datetime = models.DateTimeField(default=django.utils.timezone.now)
    mac_address = models.CharField(max_length=17,blank=True, null=True)


class OTP(models.Model):
    uuid = models.UUIDField(default = uuid4,editable = False)
    user =models.ForeignKey(User, on_delete=models.PROTECT)
    email = models.EmailField(verbose_name='email address', max_length=255)
    is_verified = models.BooleanField(default=False)
    otp = models.CharField(max_length=6)
    otp_validity = models.DateTimeField()

class SendMailNotification(models.Model):
    uuid = models.UUIDField(default = uuid4,editable = False)
    email = models.EmailField(verbose_name='email address', max_length=255)
    company_detail_id = models.ForeignKey(CompanyDetail,on_delete=models.CASCADE)


##Dfault Enter Manually
class DefaultProduct(models.Model):
    uuid = models.UUIDField(default = uuid4,editable = False)
    product_name = models.CharField(max_length=30)

##Dfault Enter Manually
class DefaultProductFeature(models.Model):
    uuid = models.UUIDField(default = uuid4,editable = False)
    feature = models.CharField(max_length=50)
    default_product = models.ForeignKey(DefaultProduct,on_delete=models.CASCADE)
    parent_feature = models.ForeignKey('self', on_delete=models.CASCADE, null=True, blank=True, related_name='children')

class ProductAllowed(models.Model):
    uuid = models.UUIDField(default = uuid4,editable = False)
    default_product = models.ForeignKey(DefaultProduct,on_delete=models.CASCADE)
    allowed_status = models.BooleanField(default=False)
    company_detail_id = models.ForeignKey(CompanyDetail, on_delete=models.CASCADE)

class FeatureAllowed(models.Model):
    uuid = models.UUIDField(default = uuid4,editable = False)
    default_product_feature = models.ForeignKey(DefaultProductFeature,on_delete=models.CASCADE)
    allowed_status = models.BooleanField(default=False)
    product_allowed = models.ForeignKey(ProductAllowed, on_delete=models.CASCADE)
    # parent_feature = models.ForeignKey('self', on_delete=models.CASCADE, null=True, blank=True, related_name='children')
    company_detail_id = models.ForeignKey(CompanyDetail, on_delete=models.CASCADE)

class Days(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    days = models.IntegerField()
    category = models.CharField(max_length=50)



class PlanFeaturesPricingCategory(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    category_name = models.CharField(max_length=50)

class Plans(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    plan_name = models.CharField(max_length=30)

class CountryCategory(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    country = models.CharField(max_length=30)

class PlanPricing(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    basic_price = models.FloatField()
    basic_price_after_discount = models.FloatField()
    basic_price_after_tax = models.FloatField()
    days_price = models.FloatField()
    days_price_after_discount = models.FloatField()
    days_price_after_tax = models.FloatField()
    currency_id = models.ForeignKey(Currency,on_delete=models.CASCADE)
    country_type_id = models.ForeignKey(CountryCategory,on_delete=models.CASCADE)
    plan_id = models.ForeignKey(Plans,on_delete=models.CASCADE)
    # plan_days_and_discount = models.ForeignKey(PlanDaysAndDiscount,on_delete=models.CASCADE)
    # discount_percentage = models.FloatField()
    # discount_in_currency = models.FloatField()

class TaxPercentageDetail(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    tax_percentage = models.FloatField(default=0.0)
    tax_type = models.CharField(max_length=20)
    country_category = models.ForeignKey(CountryCategory,on_delete=models.CASCADE)

class PlanDescription(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    plan_description = models.TextField()
    plan_id = models.ForeignKey(Plans,on_delete=models.CASCADE)


class PlanDaysAndDiscount(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    plan_days = models.IntegerField()
    discount_percentage = models.FloatField(default=0.0)
    category = models.CharField(max_length=50)
    default_select = models.BooleanField(default=False)
    plan_id = models.ForeignKey(Plans,on_delete=models.CASCADE)
    plan_pricing_id = models.ForeignKey(PlanPricing,on_delete=models.CASCADE)

class PlanPricingTax(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    plan_pricing_id = models.ForeignKey(PlanPricing,on_delete=models.CASCADE)
    tax_percentage_detail_id = models.ForeignKey(TaxPercentageDetail,on_delete=models.CASCADE)
    tax_amount = models.FloatField()
    currency_id = models.ForeignKey(Currency,on_delete=models.CASCADE)


# class PlanDaysPricingBasedOnCurrency(models.Model):
##Dfault Enter Manually
class PlanFeaturePricingTier(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    min_quantity = models.IntegerField(blank=True, null=True)
    max_quantity = models.IntegerField(blank=True, null=True)
    default_quantity = models.IntegerField(blank=True, null=True)
    default_product_id = models.ForeignKey(DefaultProduct,on_delete=models.CASCADE, blank=True, null=True)
    default_product_feature_id = models.ForeignKey(DefaultProductFeature,on_delete=models.CASCADE, blank=True, null=True)
    pricing_feature_category_id = models.ForeignKey(PlanFeaturesPricingCategory,on_delete=models.CASCADE)
    plan_id = models.ForeignKey(Plans,on_delete=models.CASCADE)
    # default_selected = models.BooleanField(default=False)
    plan_pricing_description = models.TextField()
    show_plan_pricing = models.BooleanField(default=False)
    is_encluded_plan_feature_id = models.ForeignKey('self',on_delete=models.CASCADE, blank=True, null=True)

class PlanFeatureDaysPrice(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    backup_days_id = models.ForeignKey(Days,on_delete=models.CASCADE, blank=True, null=True)
    plan_days_and_discount_id = models.ForeignKey(PlanDaysAndDiscount,on_delete=models.CASCADE,blank=True, null=True)
    days_price = models.FloatField()
    currency_id = models.ForeignKey(Currency,on_delete=models.CASCADE)
    plan_feature_pricing_tier_id = models.ForeignKey(PlanFeaturePricingTier,on_delete=models.CASCADE)
    plans_id = models.ForeignKey(Plans,on_delete=models.CASCADE)
    default_selected = models.BooleanField(default=False)

class Coupon(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    code = models.CharField(max_length=100)
    description = models.CharField(max_length=500)
    discount_type = models.CharField(max_length=30)
    discount_value = models.FloatField()
    currency_id = models.ForeignKey(Currency,on_delete=models.CASCADE)
    country_category_id = models.ForeignKey(CountryCategory,on_delete=models.CASCADE)
    plan_buy_days = models.IntegerField(default=30)
    coupon_expiry_datetime = models.DateTimeField()
    is_active = models.BooleanField(default=True)
    user_valid_for_coupon = models.IntegerField(default=10)

class BusinessPlanHistory(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    plan_name = models.CharField(max_length=30)
    price = models.FloatField()
    price_after_discount = models.FloatField()
    price_after_tax = models.FloatField()
    days_price = models.FloatField()
    days_price_after_discount = models.FloatField()
    days_price_after_tax = models.FloatField()
    currency_id = models.ForeignKey(Currency,on_delete=models.CASCADE)
    currency_type = models.CharField(max_length=30)
    currency_symbol = models.CharField(max_length=10)
    country_category_id = models.ForeignKey(CountryCategory,on_delete=models.CASCADE)
    country_type = models.CharField(max_length=30)
    plan_id = models.ForeignKey(Plans,on_delete=models.CASCADE)
    plan_days_and_discount_id = models.ForeignKey(PlanDaysAndDiscount,on_delete=models.CASCADE)
    plan_days = models.IntegerField()
    discount_in_percentage = models.FloatField(default=0.0)
    discount_in_currency = models.FloatField(default=0.0)
    total_discount = models.FloatField()
    total_tax_in_percentage = models.FloatField()
    total_tax_in_currency = models.FloatField()
    # buy_datetime = models.DateTimeField(default=django.utils.timezone.now)
    # plan_start_datetime = models.DateTimeField(default=django.utils.timezone.now)
    # plan_expire_datetime = models.DateTimeField()
    buy_datetime = models.DateTimeField(auto_now_add=True)
    plan_start_datetime = models.DateTimeField(auto_now_add=True)
    plan_expire_datetime = models.DateTimeField()
    minutes_to_expire = models.IntegerField()
    days_to_expire = models.IntegerField()
    plan_validity = models.BooleanField()
    current_active = models.BooleanField()
    plan_status = models.CharField(max_length=30)##active,pending,expire
    plan_type = models.CharField(max_length=30) ##Upgrade,Renew,BuyPlan,Free trail
    company_detail_id = models.ForeignKey(CompanyDetail,on_delete=models.CASCADE)
    upgrade_plan_id = models.ForeignKey('self',on_delete=models.CASCADE, blank=True, null=True)
    payment_status = models.BooleanField(default=False)
   
    def save(self, *args, **kwargs):
        if not self.plan_expire_datetime.tzinfo:
            self.plan_expire_datetime = timezone.make_aware(self.plan_expire_datetime, timezone=timezone.get_current_timezone())
        
        super().save(*args, **kwargs)

class BusinessPlanPricingTax(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    business_plan_history_id = models.ForeignKey(BusinessPlanHistory,on_delete=models.CASCADE)
    tax_percentage_detail_id = models.ForeignKey(TaxPercentageDetail,on_delete=models.CASCADE)
    tax_type = models.CharField(max_length=30)
    tax_percentage = models.FloatField()
    tax_amount = models.FloatField()
    company_detail_id = models.ForeignKey(CompanyDetail,on_delete=models.CASCADE)

class BusinessPlanCoupon(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    coupon_code = models.CharField(max_length=100)
    description = models.CharField(max_length=500)
    discount_type = models.CharField(max_length=30)
    discount_value = models.FloatField()
    coupon_id = models.ForeignKey(Coupon,on_delete=models.CASCADE)
    total_coupon_amount = models.FloatField()
    business_plan_history_id = models.ForeignKey(BusinessPlanHistory,on_delete=models.CASCADE)
    company_detail_id = models.ForeignKey(CompanyDetail,on_delete=models.CASCADE)

class BusinessPricingTier(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    backup_days_id = models.ForeignKey(Days,on_delete=models.CASCADE, blank=True, null=True)
    backup_days = models.IntegerField(blank=True,null=True)
    quantity = models.IntegerField(blank=True,null=True)
    price = models.FloatField()
    days_price = models.FloatField()
    currency_id = models.ForeignKey(Currency,on_delete=models.CASCADE)
    default_product_id = models.ForeignKey(DefaultProduct,on_delete=models.CASCADE, blank=True, null=True)
    default_product_feature_id = models.ForeignKey(DefaultProductFeature,on_delete=models.CASCADE, blank=True, null=True)
    plan_feature_pricing_category_id = models.ForeignKey(PlanFeaturesPricingCategory,on_delete=models.CASCADE)
    category_name = models.CharField(max_length=30)
    plan_id = models.ForeignKey(Plans,on_delete=models.CASCADE)
    business_plan_history_id = models.ForeignKey(BusinessPlanHistory,on_delete=models.CASCADE)
    plan_feature_pricing_tier_id = models.ForeignKey(PlanFeaturePricingTier,on_delete=models.CASCADE)
    company_detail_id= models.ForeignKey(CompanyDetail,on_delete=models.CASCADE)
    plan_pricing_description = models.TextField()

class BusinessTransactionHistory(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    amout_paid = models.FloatField()
    currency_id = models.ForeignKey(Currency,on_delete=models.CASCADE)
    currency_type = models.CharField(max_length=30)
    currency_symbol = models.CharField(max_length=10)
    date_and_time = models.DateTimeField(default=django.utils.timezone.now)
    company_detail_id= models.ForeignKey(CompanyDetail,on_delete=models.CASCADE)
    business_plan_history_id = models.ForeignKey(BusinessPlanHistory,on_delete=models.CASCADE)
    #payment_status = models.BooleanField(default=False)

class Schedule(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    days= models.IntegerField()
    type= models.CharField(max_length=30)

class SiteProductAllowed(models.Model):
    uuid = models.UUIDField(default = uuid4,editable = False)
    product_allowed = models.ForeignKey(ProductAllowed,on_delete=models.CASCADE)
    allowed_status = models.BooleanField(default=False)
    company_detail_id = models.ForeignKey(CompanyDetail, on_delete=models.CASCADE)
    site = models.ForeignKey(Sites, on_delete=models.CASCADE)


class SiteFeatureAllowed(models.Model):
    uuid = models.UUIDField(default = uuid4,editable = False)
    feature_allowed = models.ForeignKey(FeatureAllowed,on_delete=models.CASCADE)
    allowed_status = models.BooleanField(default=False)
    site_product_allowed = models.ForeignKey(SiteProductAllowed, on_delete=models.CASCADE)
    company_detail_id = models.ForeignKey(CompanyDetail, on_delete=models.CASCADE)
    site = models.ForeignKey(Sites, on_delete=models.CASCADE)