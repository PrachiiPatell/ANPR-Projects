#from django.conf.urls import url
from django.urls import path,reverse,reverse_lazy
from account import views
from django.conf.urls.static import static
from django.conf import settings 
from django.contrib.auth import views as auth_views
from .views import *
app_name = 'account'
urlpatterns = [
    # path('register/', views.register, name='register'),
    path('api/default_product', views.DefaultProductView.as_view()),
    path('api/default_product_feature', views.DefaultProductFeatureView.as_view()),
    path('api/register', views.Register.as_view()),
    path('api/login',views.Login.as_view()),
    path('api/windows-login',views.WindowsLogin.as_view()),
    path('api/windows-logout',WindowsLogout.as_view()),
    path('api/windows-get-user-detail',WindowsGetUserDetail.as_view()),
    path('api/add-new-company',views.AddCompany.as_view()),
    path('api/get-user-detail',views.GetUserDetail.as_view()),
    path('api/add-user-email', views.AddUserEmailView.as_view()),
    path('api/add-user-email/<int:id>', views.UserEmailDetailView.as_view()),
    path('api/site', views.SiteView.as_view()),
    path('api/site/<int:id>', views.SitesDetailView.as_view()),
    path('api/company-product-feature-allowed',views.GetCompanyProductAndFeatureDetail.as_view()),
    path('api/user-email', views.UserEmailView.as_view()),
    path('api/roles',views.RoleDropdownView.as_view()),
    # path('api/Login/',views.user_loginApi, name="user_loginApi"),
    # path('api/logout/<int:user_id>', views.Logout,name="logout"),
    path("password-reset", auth_views.PasswordResetView.as_view(template_name='reset_password.html',html_email_template_name='emails.html',success_url=reverse_lazy('account:password_reset_done')), name="password_reset"),
    path("password-reset-done", auth_views.PasswordResetDoneView.as_view(template_name='reset_password_done.html'), name="password_reset_done"),
    path("password-reset-confirm/<uidb64>/<token>", auth_views.PasswordResetConfirmView.as_view(template_name='password_reset_confirm.html',success_url=reverse_lazy('account:password_reset_complete')), name="password_reset_confirm"),
    path("password-reset-complete", auth_views.PasswordResetCompleteView.as_view(template_name='password_reset_complete.html'), name="password_reset_complete"),
    

    #path('roles/<int:role_id>/permissions/', custom_permissions, name='custom_permissions'),

    path('roles-and-permission', RolesAndPermissionView.as_view(), name='roles-and-permission'),
    path('roles-and-permission/<int:id>', RolesAndPermissionDetailView.as_view()),
    path('get-roles-and-permission',GetRolesAndPermissionView.as_view(), name='get-roles-and-permission'),

    path('send_otp/', views.SendOTP.as_view()),

    path('verify_otp/', views.VerifyOTP.as_view()),
    path('SiteDropDown/',views.SitesDropDownView.as_view()),
    path('send-email-notification/',views.SendEmailNotificationView.as_view()),
    path('notify-admin-user/', views.SitesWorkingNotifyAdminUser.as_view()),
    path('free-trial/', FreeTrailView.as_view(), name='free_trial_view'),
    path('buy-plan/', BuyPlanView.as_view(), name='buy_plan_view'),
    path('buy-plan/<int:id>/', BuyPlanView.as_view(), name='update_resource'),
    path('get-buyplan-detail/<int:id>/',views.GetBuyPlanDetail.as_view()),
    path('upgrade-plan/', UpgradePlanView.as_view(), name='upgrade_plan_view'),
    path('upgrade-plan/<int:id>/', UpgradePlanView.as_view()),
    path('get-upgradeplan-detail/<int:existing_plan_id>/',GetUpgradePlanDetail.as_view()),
    path('renew-plan/', RenewPlanView.as_view(), name='renew_plan_view'),
    path('renew-plan/<int:id>/', RenewPlanView.as_view()),
    path('webhook/', CashfreeWebhookView.as_view(), name='cashfree_webhook'),

] + static(settings.STATIC_URL)

# + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)



