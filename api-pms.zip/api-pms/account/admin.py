from django.contrib import admin
from .models import *
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin

from .forms import UserCreationForm, UserChangeForm

User = get_user_model()



class AccountAdmin(BaseUserAdmin):
    form = UserChangeForm
    add_form = UserCreationForm

    list_display = ('id','uuid','email', 'phone_number', 'company_detail_id', 'user_login_or_not', 'timezones','is_active', 'is_staff',  'is_superuser','is_verified')
    list_filter = ('is_superuser',)

    fieldsets = (
        (None, {'fields': ('email','is_active', 'is_staff', 'is_superuser', 'password')}),
        ('Personal info', {'fields': ('phone_number', 'company_detail_id', 'user_login_or_not', 'timezones','is_verified')}),
        ('Groups', {'fields': ('groups',)}),
        ('Permissions', {'fields': ('user_permissions',)}),
    )
    add_fieldsets = (
        (None, {'fields': ('email','is_active','is_staff', 'is_superuser', 'password1', 'password2')}),
        ('Personal info', {'fields': ('phone_number', 'company_detail_id', 'user_login_or_not', 'timezones','is_verified')}),
        ('Groups', {'fields': ('groups',)}),
        ('Permissions', {'fields': ('user_permissions',)}),
    )

    search_fields = ('phone_number', 'company_detail_id', 'user_login_or_not', 'timezones')
    ordering = ('email',)
    filter_horizontal = ()


admin.site.register(User, AccountAdmin)


class CompanyDetailAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','company_name','country','uses_type','plan_start_datetime','plan_expire_datetime','days_to_expire','plan_validity','delete_previous_data_after_day_cloud','delete_previous_data_after_day_on_premises')

class DefaultProductAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','product_name')

class DefaultProductFeatureAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','feature','default_product')

class ProductAllowedAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','default_product','allowed_status','company_detail_id')

class FeatureAllowedAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','default_product_feature','allowed_status','product_allowed','company_detail_id')

# class DaysAdmin(admin.ModelAdmin):
#     list_display = ('id','uuid','days','category')

class CurrencyAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','currency_type','currency_symbol')



# class PricingCategoryAdmin(admin.ModelAdmin):
#     list_display = ('id','uuid','category_name')

# class CountryCategoryAdmin(admin.ModelAdmin):
#     list_display = ('id','uuid','country')

# class TaxPercentageDetailAdmin(admin.ModelAdmin):
#     list_display = ('id','uuid','tax_percentage','tax_type','country_category')

# class PlansAdmin(admin.ModelAdmin):
#     list_display = ('id','uuid','plan_name')

# class PlanDescriptionAdmin(admin.ModelAdmin):
#     list_display = ('id','uuid','plan_description','plan_id')

# class PlanDaysAdmin(admin.ModelAdmin):
#     list_display = ('id','uuid','plan_days','category','plan_id')

# class PlanPricingAdmin(admin.ModelAdmin):
#     list_display = ('id','uuid','basic_pricing','basic_price_after_discount','currency','country_type','plan_id','plan_days','discount_percentage','discount_in_currency')

# class PlanPricingTaxAdmin(admin.ModelAdmin):
#     list_display = ('id','uuid','plan_pricing','tax_percentage_detail','tax_amount','currency')

# class PlanPricingTierAdmin(admin.ModelAdmin):
#     list_display = ('id','uuid','days','quantity','price','days_price','currency','default_product','default_product_feature','pricing_category','plan_id')

# # class DefaultPlanPricingTierAdmin(admin.ModelAdmin):
# #     list_display = ('id','uuid','days','quantity','price','days_price','currency','default_product','default_product_feature','pricing_category','plan_id')

# class CompanyPlanHistoryAdmin(admin.ModelAdmin):
#     list_display = ('id','uuid','plan_name','price','price_after_discount','price_after_tax','days_price','currency','currency_type','currency_symbol','country_category','country_type','plan_id','plan_days_id','plan_days','discount_in_percentage','discount_in_currency','buy_datetime','plan_end_datetime','minutes_to_expire','active_plan','plan_type')

# class CompanyPlanPricingTaxAdmin(admin.ModelAdmin):
#     list_display = ('id','uuid','company_plan_pricing','tax_percentage_detail')

# class CompanyPricingTierAdmin(admin.ModelAdmin):
#     list_display = ('id','uuid','days','quantity','price','days_price','currency','default_product','default_product_feature','pricing_category','category_name','plan_id','company_plan_history_id','plan_pricing_tier','company_detail_id')



class RolesAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','role_name','company_detail_id','created_by','created_datetime','updated_by','updated_datetime')

class UserTypeAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','is_menu_visible')

class MenuPageAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','menu_name','is_menu_type','created_by','created_datetime','updated_by','updated_datetime')

class ActionAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','action_name')

class MenuActionMapAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','menu_page','action')

class PermissionAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','role','menu_page','action')

class UserRoleMappingAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','user','role','company_detail_id','created_by','created_datetime','updated_by','updated_datetime')

class AddUserEmailAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','email','role','company_detail_id')

class SitesAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','site_name','user','company_detail_id','skip_frame','user_login_or_not','active','site_encryption_key')

class OTPAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','user','email','is_verified','otp','otp_validity')

class SendMailNotificationAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','email','company_detail_id')

class WindowsSitesActiveLogAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','sites','company_detail_id','last_active_datetime','application_open','active','login','last_active_status','email_sent')

class DaysAdmin(admin.ModelAdmin):
    list_display = ('id', 'uuid', 'days', 'category')

class PlanFeaturesPricingCategoryAdmin(admin.ModelAdmin):
    list_display = ('id', 'uuid', 'category_name')

class PlansAdmin(admin.ModelAdmin):
    list_display = ('id', 'uuid', 'plan_name')

class CountryCategoryAdmin(admin.ModelAdmin):
    list_display = ('id', 'uuid', 'country')

class PlanPricingAdmin(admin.ModelAdmin):
    list_display = ('id', 'uuid', 'basic_price', 'basic_price_after_discount', 'basic_price_after_tax', 'days_price', 'days_price_after_discount', 'days_price_after_tax', 'currency_id', 'country_type_id', 'plan_id')

class TaxPercentageDetailAdmin(admin.ModelAdmin):
    list_display = ('id', 'uuid', 'tax_percentage', 'tax_type', 'country_category')

class PlanDescriptionAdmin(admin.ModelAdmin):
    list_display = ('id', 'uuid', 'plan_description', 'plan_id')

class PlanDaysAndDiscountAdmin(admin.ModelAdmin):
    list_display = ('id', 'uuid', 'plan_days', 'discount_percentage', 'category', 'default_select', 'plan_id', 'plan_pricing_id')

class PlanPricingTaxAdmin(admin.ModelAdmin):
    list_display = ('id', 'uuid', 'plan_pricing_id', 'tax_percentage_detail_id', 'tax_amount', 'currency_id')

class PlanFeaturePricingTierAdmin(admin.ModelAdmin):
    list_display = ('id', 'uuid', 'min_quantity', 'max_quantity', 'default_quantity', 'default_product_id', 'default_product_feature_id', 'pricing_feature_category_id', 'plan_id', 'plan_pricing_description', 'show_plan_pricing', 'is_encluded_plan_feature_id')

class PlanFeatureDaysPriceAdmin(admin.ModelAdmin):
    list_display = ('id', 'uuid', 'backup_days_id', 'plan_days_and_discount_id', 'days_price', 'currency_id', 'plan_feature_pricing_tier_id', 'plans_id', 'default_selected')

class CouponAdmin(admin.ModelAdmin):
    list_display = ('id', 'uuid', 'code', 'description', 'discount_type', 'discount_value', 'currency_id', 'country_category_id', 'plan_buy_days', 'coupon_expiry_datetime', 'is_active', 'user_valid_for_coupon')

class BusinessPlanHistoryAdmin(admin.ModelAdmin):
    list_display = ('id', 'uuid', 'plan_name', 'price', 'price_after_discount', 'price_after_tax', 'days_price', 'currency_id', 'currency_type', 'currency_symbol', 'country_category_id', 'country_type', 'plan_id', 'plan_days_and_discount_id', 'plan_days', 'discount_in_percentage', 'discount_in_currency', 'total_discount', 'total_tax_in_percentage', 'total_tax_in_currency', 'buy_datetime', 'plan_expire_datetime', 'minutes_to_expire', 'days_to_expire', 'plan_validity', 'current_active', 'plan_status', 'plan_type', 'company_detail_id', 'upgrade_plan_id', 'payment_status')

class BusinessPlanPricingTaxAdmin(admin.ModelAdmin):
    list_display = ('id', 'uuid', 'business_plan_history_id', 'tax_percentage_detail_id', 'tax_type', 'tax_percentage', 'tax_amount', 'company_detail_id')

class BusinessPlanCouponAdmin(admin.ModelAdmin):
    list_display = ('id', 'uuid', 'coupon_code', 'description', 'discount_type', 'discount_value', 'coupon_id', 'total_coupon_amount', 'business_plan_history_id', 'company_detail_id')

class BusinessPricingTierAdmin(admin.ModelAdmin):
    list_display = ('id', 'uuid', 'backup_days_id', 'backup_days', 'quantity', 'price', 'days_price', 'currency_id', 'default_product_id', 'default_product_feature_id', 'plan_feature_pricing_category_id', 'category_name', 'plan_id', 'business_plan_history_id', 'plan_feature_pricing_tier_id', 'company_detail_id', 'plan_pricing_description')

class BusinessTransactionHistoryAdmin(admin.ModelAdmin):
    list_display = ('id', 'uuid', 'amout_paid', 'currency_id', 'currency_type', 'currency_symbol', 'date_and_time', 'company_detail_id', 'business_plan_history_id')

class ScheduleAdmin(admin.ModelAdmin):
    list_display = ('id', 'uuid', 'days', 'type')

class SiteProductAllowedAdmin(admin.ModelAdmin):
    list_display = ('id', 'uuid', 'product_allowed', 'allowed_status', 'company_detail_id', 'site')

class SiteFeatureAllowedAdmin(admin.ModelAdmin):
    list_display = ('id', 'uuid', 'feature_allowed', 'allowed_status', 'site_product_allowed', 'company_detail_id', 'site')

# Register your models here.
# admin.site.register(UserProfileInformation,UserProfileInformationAdmin)

# admin.site.register(PrimaryIndustryOption,PrimaryIndustryOptionAdmin)
# admin.site.register(PrimaryUseCaseOption,PrimaryUseCaseOptionAdmin)
admin.site.register(CompanyDetail,CompanyDetailAdmin)
admin.site.register(Roles,RolesAdmin)
admin.site.register(UserType,UserTypeAdmin)
admin.site.register(MenuPage,MenuPageAdmin)
admin.site.register(Action,ActionAdmin)
admin.site.register(MenuActionMap,MenuActionMapAdmin)
admin.site.register(Permission,PermissionAdmin)
admin.site.register(UserRoleMapping,UserRoleMappingAdmin)
admin.site.register(AddUserEmail,AddUserEmailAdmin)
admin.site.register(DefaultProduct,DefaultProductAdmin)
admin.site.register(DefaultProductFeature,DefaultProductFeatureAdmin)
admin.site.register(ProductAllowed,ProductAllowedAdmin)
admin.site.register(FeatureAllowed,FeatureAllowedAdmin)
admin.site.register(Sites,SitesAdmin)
#admin.site.register(Days,DaysAdmin)
admin.site.register(Currency,CurrencyAdmin)
#admin.site.register(PricingCategory,PricingCategoryAdmin)
#admin.site.register(CountryCategory,CountryCategoryAdmin)
# admin.site.register(TaxPercentageDetail,TaxPercentageDetailAdmin)
# #admin.site.register(PlanPricingTier,PlanPricingTierAdmin)
# admin.site.register(Plans,PlansAdmin)
# admin.site.register(PlanDescription,PlanDescriptionAdmin)
# #admin.site.register(PlanDays,PlanDaysAdmin)
# admin.site.register(PlanPricing,PlanPricingAdmin)
# admin.site.register(PlanPricingTax,PlanPricingTaxAdmin)
# # admin.site.register(DefaultPlanPricingTier,DefaultPlanPricingTierAdmin)
# admin.site.register(CompanyPlanHistory,CompanyPlanHistoryAdmin)
# admin.site.register(CompanyPlanPricingTax,CompanyPlanPricingTaxAdmin)
# admin.site.register(CompanyPricingTier,CompanyPricingTierAdmin)
admin.site.register(OTP,OTPAdmin)
admin.site.register(SendMailNotification,SendMailNotificationAdmin)
admin.site.register(WindowsSitesActiveLog,WindowsSitesActiveLogAdmin)
admin.site.register(Days, DaysAdmin)
admin.site.register(PlanFeaturesPricingCategory, PlanFeaturesPricingCategoryAdmin)
admin.site.register(Plans, PlansAdmin)
admin.site.register(CountryCategory, CountryCategoryAdmin)
admin.site.register(PlanPricing, PlanPricingAdmin)
admin.site.register(TaxPercentageDetail, TaxPercentageDetailAdmin)
admin.site.register(PlanDescription, PlanDescriptionAdmin)
admin.site.register(PlanDaysAndDiscount, PlanDaysAndDiscountAdmin)
admin.site.register(PlanPricingTax, PlanPricingTaxAdmin)
admin.site.register(PlanFeaturePricingTier, PlanFeaturePricingTierAdmin)
admin.site.register(PlanFeatureDaysPrice, PlanFeatureDaysPriceAdmin)
admin.site.register(Coupon, CouponAdmin)
admin.site.register(BusinessPlanHistory, BusinessPlanHistoryAdmin)
admin.site.register(BusinessPlanPricingTax, BusinessPlanPricingTaxAdmin)
admin.site.register(BusinessPlanCoupon, BusinessPlanCouponAdmin)
admin.site.register(BusinessPricingTier, BusinessPricingTierAdmin)
admin.site.register(BusinessTransactionHistory, BusinessTransactionHistoryAdmin)
admin.site.register(Schedule, ScheduleAdmin)
admin.site.register(SiteProductAllowed, SiteProductAllowedAdmin)
admin.site.register(SiteFeatureAllowed, SiteFeatureAllowedAdmin)