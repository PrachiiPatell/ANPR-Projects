from rest_framework.serializers import ModelSerializer
from rest_framework.validators import UniqueValidator
from django.contrib.auth.password_validation import validate_password
from .models import *
from account.models import DefaultProduct, DefaultProductFeature, ProductAllowed, FeatureAllowed
from account.serializers import  DefaultProductFeatureSerializer, DefaultProductSerializer, ProductAllowedSerializer, FeatureAllowedSerializer
from rest_framework import serializers
import pytz

class GateSiteBlackListedVehicleSerializer(serializers.ModelSerializer):
    class Meta:
        model = GateSiteBlackListedVehicle
        fields = ['id','licence_plate_number','reason_to_blacklist','date_and_time','company_detail_id']
    def create(self, validate_data):
        if GateSiteBlackListedVehicle.objects.filter(licence_plate_number=validate_data['licence_plate_number'], company_detail_id=validate_data['company_detail_id']).exists():
            raise serializers.ValidationError(
                {'licence_plate_number': 'Licence plate number are already exist.'})
        return GateSiteBlackListedVehicle.objects.create(**validate_data)

    def update(self, instance, validate_data):
        if GateSiteBlackListedVehicle.objects.filter(licence_plate_number=validate_data['licence_plate_number'], company_detail_id=validate_data['company_detail_id']).exclude(id=instance.pk).exists():
            raise serializers.ValidationError(
                {'licence_plate_number': 'Licence plate number are already exist.'})
        return super().update(instance, validate_data)

class GateSiteBlackListedContainerSerializer(serializers.ModelSerializer):
    class Meta:
        model = GateSiteBlackListedContainer
        fields = ['id','container_number','reason_to_blacklist','date_and_time','company_detail_id']
    def create(self, validate_data):
        if GateSiteBlackListedContainer.objects.filter(container_number=validate_data['container_number'], company_detail_id=validate_data['company_detail_id']).exists():
            raise serializers.ValidationError(
                {'container_number': 'Container number are already exist.'})
        return GateSiteBlackListedContainer.objects.create(**validate_data)

    def update(self, instance, validate_data):
        if GateSiteBlackListedContainer.objects.filter(container_number=validate_data['container_number'], company_detail_id=validate_data['company_detail_id']).exclude(id=instance.pk).exists():
            raise serializers.ValidationError(
                {'container_number': 'Container number are already exist.'})
        return super().update(instance, validate_data)

class GateSiteDetectedVehicleDetailSerializer(serializers.ModelSerializer):
    licence_plate_image = serializers.CharField(required=False,allow_null=True)
    driver_seat_belt_image = serializers.CharField(required=False,allow_null=True)
    class Meta:
        model = GateSiteDetectedVehicleDetail
        fields = ['id','uuid','licence_plate_number','licence_plate_image','avg_confidence_plate_number','blacklisted','blacklisted_vehicle','vehicle_type','driver_seat_belt','driver_seat_belt_image','camera_name','camera_view_name','camera_group_name']

class GateSiteDetectedSealImageSerializer(ModelSerializer):
    seal_image = serializers.CharField()
    class Meta:
        model = GateSiteDetectedSealImage
        fields = ['id','uuid','seal_image','seal_presence','avg_confidence_seal_presence']

class GateSiteDetectedContainerDetailSerializer(serializers.ModelSerializer):
    container_number_image = serializers.CharField(required=False,allow_null=True)
    hazard_sign_image = serializers.CharField(required=False,allow_null=True)
    detected_seal = GateSiteDetectedSealImageSerializer(many=True)
    class Meta:
        model = GateSiteDetectedContainerDetail
        fields = ['id','uuid','container_number','iso_code','container_number_image','avg_confidence_container_number','blacklisted','blacklisted_container','seal_presence','seal_presence_count','length','height','width','hazard_sign_presence','hazard_sign_image','door_direction','door_open_close','camera_name','camera_view_name','camera_group_name','detected_seal']

class GateSiteDetectedDamageSerializer(serializers.ModelSerializer):
    damage_image = serializers.CharField()
    class Meta:
        model = GateSiteDetectedDamage
        fields = ['id','uuid','damage_image','avg_confidence_damage_presence','damage_type']

class GateSiteDetectedFrameImageSerializer(ModelSerializer):
    detected_damage = GateSiteDetectedDamageSerializer(many=True)
    frame_image = serializers.CharField()
    class Meta:
        model = GateSiteDetectedFrameImage
        fields = ['id','frame_image','damage_found','camera_name','camera_view_name','camera_group_name','detected_damage']

# class GateSiteDetectedGetTableSerializer(ModelSerializer):
#     site_name = serializers.CharField(source='sites.site_name', read_only=True)
#     class Meta:
#         model =  GateSiteDetected
#         fields = ('id','datetime','camera_name','sites','company_detail_id','site_name') #'site_name','truck_booking_id','transporter_name','driver_name','driver_dl_number','approve'



class GateSiteDetectedSerializer(serializers.ModelSerializer):
    detected_vehicle_detail = GateSiteDetectedVehicleDetailSerializer(many=True, write_only=True)
    detected_container_detail = GateSiteDetectedContainerDetailSerializer(many=True, write_only=True)
    detected_frame = GateSiteDetectedFrameImageSerializer(many=True, write_only=True)
    site_name = serializers.CharField(source='sites.site_name', read_only=True)
    
    def create(self, validated_data):
        print("validate_data:",validated_data)
        detected_vehicles = validated_data.pop('detected_vehicle_detail')
        detected_containers = validated_data.pop('detected_container_detail')
        detected_frames = validated_data.pop('detected_frame')
        
        detected_data = GateSiteDetected.objects.create(**validated_data)
        
        for data in detected_vehicles:
            GateSiteDetectedVehicleDetail.objects.create(detected=detected_data, **data)

        for data in detected_containers:
            print("detected_container:",data)
            detected_seals = data.pop('detected_seal')
            container_data = GateSiteDetectedContainerDetail.objects.create(detected=detected_data, **data)
            for seal_data in detected_seals:
                GateSiteDetectedSealImage.objects.create(detected_container_detail=container_data, **seal_data)

        for frame in detected_frames:
            detected_damage_image = frame.pop('detected_damage')
            detected_frame_data = GateSiteDetectedFrameImage.objects.create(detected=detected_data, **frame)
            for damage_data in detected_damage_image:
                GateSiteDetectedDamage.objects.create(detected_frame_image_detail=detected_frame_data,**damage_data)
        return detected_data

    class Meta:
        model = GateSiteDetected
        fields = ('id', 'datetime','container_presence','group_name', 'sites','company_detail_id','site_name', 'detected_frame','detected_vehicle_detail','detected_container_detail') #'truck_booking_id', 'transporter_name', 'driver_name', 'driver_photo', 'driver_dl_number', 'approve'


class GateSiteDetectedDetailSerializer(ModelSerializer):
    detected_vehicle = GateSiteDetectedVehicleDetailSerializer(many=True, read_only=True)
    detected_container = GateSiteDetectedContainerDetailSerializer(many=True, read_only=True) 
    detected_frame = GateSiteDetectedFrameImageSerializer(many=True,read_only=True)
    site_name = serializers.CharField(source='sites.site_name', read_only=True)
    # datetime = serializers.SerializerMethodField()
    
    class Meta:
        model = GateSiteDetected
        fields = ('id', 'datetime','container_presence', 'group_name', 'sites','company_detail_id','site_name', 'detected_vehicle','detected_container','detected_frame') # 'truck_booking_id', 'transporter_name', 'driver_name', 'driver_photo', 'driver_dl_number', 'approve'

    # def get_datetime(self, instance):
    #     timezone_IST = pytz.timezone('Asia/Kolkata')
    #     datetime_ist = instance.datetime.astimezone(timezone_IST)
    #     # return datetime_ist.strftime('%Y-%m-%d %I:%M:%S %p')
    #     return datetime_ist.strftime('%Y-%m-%d %H:%M:%S')

class GateSitePartiallyDetectedVehicleDetailSerializer(serializers.ModelSerializer):
    licence_plate_image = serializers.CharField()
    driver_seat_belt_image = serializers.CharField()
    class Meta:
        model = GateSitePartiallyDetectedVehicleDetail
        fields = ['id','uuid','licence_plate_number','licence_plate_image','avg_confidence_plate_number','vehicle_type','driver_seat_belt','driver_seat_belt_image','camera_name','camera_view_name','camera_group_name']

class GateSitePartiallyDetectedSealImageSerializer(ModelSerializer):
    seal_image = serializers.CharField()
    class Meta:
        model = GateSitePartiallyDetectedSealImage
        fields = ['id','uuid','seal_image','seal_presence','avg_confidence_seal_presence']

class GateSitePartiallyDetectedContainerDetailSerializer(serializers.ModelSerializer):
    container_number_image = serializers.CharField()
    hazard_sign_image = serializers.CharField()
    partially_detected_seal = GateSitePartiallyDetectedSealImageSerializer(many=True)
    class Meta:
        model = GateSitePartiallyDetectedContainerDetail
        fields = ['id','uuid','container_number','iso_code','container_number_image','avg_confidence_container_number','seal_presence','seal_presence_count','length','height','width','hazard_sign_presence','hazard_sign_image','door_direction','door_open_close','camera_name','camera_view_name','camera_group_name','partially_detected_seal']

class GateSitePartiallyDetectedDamageSerializer(serializers.ModelSerializer):
    damage_image = serializers.CharField()
    class Meta:
        model = GateSitePartiallyDetectedDamage
        fields = ['id','uuid','damage_image','avg_confidence_damage_presence','damage_type']

class GateSitePartiallyDetectedFrameImageSerializer(ModelSerializer):
    partially_detected_damage = GateSitePartiallyDetectedDamageSerializer(many=True)
    frame_image = serializers.CharField()
    class Meta:
        model = GateSitePartiallyDetectedFrameImage
        fields = ['id','frame_image','camera_name','camera_view_name','camera_group_name','damage_found','partially_detected_damage']


class GateSitePartiallyDetectedGetTableSerializer(ModelSerializer):
    site_name = serializers.CharField(source='sites.site_name', read_only=True)
    class Meta:
        model =  GateSitePartiallyDetected
        fields = ('id','datetime','camera_name','sites','company_detail_id','site_name')



class GateSitePartiallyDetectedSerializer(ModelSerializer):
    partially_detected_vehicle_detail = GateSitePartiallyDetectedVehicleDetailSerializer(many=True, write_only=True)
    partially_detected_container_detail = GateSitePartiallyDetectedContainerDetailSerializer(many=True, write_only=True)
    partially_detected_frame = GateSitePartiallyDetectedFrameImageSerializer(many=True, write_only=True)
    site_name = serializers.CharField(source='sites.site_name', read_only=True)
    
    def create(self, validated_data):
        print("validate", validated_data)
        partially_detected_vehicles = validated_data.pop('partially_detected_vehicle_detail')
        partially_detected_containers = validated_data.pop('partially_detected_container_detail')
        partially_detected_frames = validated_data.pop('partially_detected_frame')
        
        partially_detected_data = GateSitePartiallyDetected.objects.create(**validated_data)
        
        for data in partially_detected_vehicles:
            GateSitePartiallyDetectedVehicleDetail.objects.create(partially_detected=partially_detected_data, **data)

        for data in partially_detected_containers:
            #print(partially_detected_containers)
            partially_detected_seals = data.pop('partially_detected_seal')
            container_data = GateSitePartiallyDetectedContainerDetail.objects.create(partially_detected=partially_detected_data, **data)
            for seal_data in partially_detected_seals:
                GateSitePartiallyDetectedSealImage.objects.create(partially_detected_container_detail=container_data, **seal_data)

        for frame in partially_detected_frames:
            partially_detected_damage_image = frame.pop('partially_detected_damage')
            partially_detected_frame_data = GateSitePartiallyDetectedFrameImage.objects.create(partially_detected=partially_detected_data, **frame)
            for damage_data in partially_detected_damage_image:
                GateSitePartiallyDetectedDamage.objects.create(partially_detected_frame_image_detail=partially_detected_frame_data,**damage_data)
        return partially_detected_data

    
    class Meta:
        model = GateSitePartiallyDetected
        fields = ('id','datetime','sites','company_detail_id','site_name','partially_detected_frame','partially_detected_vehicle_detail','partially_detected_container_detail')



class GateSitePartiallyDetectedDetailSerializer(ModelSerializer):
    partially_detected_vehicle = GateSitePartiallyDetectedVehicleDetailSerializer(many=True, read_only=True)
    partially_detected_container = GateSitePartiallyDetectedContainerDetailSerializer(many=True, read_only=True)
    partially_detected_frame = GateSitePartiallyDetectedFrameImageSerializer(many=True,read_only=True)
    site_name = serializers.CharField(source='sites.site_name', read_only=True)
    class Meta:
        model = GateSitePartiallyDetected
        fields = ('id','datetime','container_presence','group_name','sites','company_detail_id','site_name','partially_detected_vehicle','partially_detected_container','partially_detected_frame')


# class DetectedExcelSerializer(ModelSerializer):
#     datetime = serializers.SerializerMethodField()
#     detected_container = GateSiteDetectedContainerDetailSerializer(many=True, read_only=True)
#     detected_frame = GateSiteDetectedFrameImageSerializer(many=True,read_only=True)

#     class Meta:
#         model = GateSiteDetected
#         fields = ['datetime','detected_container','detected_frame']

#     def get_datetime(self, instance):
#         timezone_IST = pytz.timezone('Asia/Kolkata')
#         datetime_ist = instance.datetime.astimezone(timezone_IST)
#         return datetime_ist.strftime('%Y-%m-%d %I:%M:%S %p')

class DetectedExcelSerializer(serializers.ModelSerializer):
    container_number = serializers.SerializerMethodField()
    # container_number_image = serializers.SerializerMethodField()
    iso_code = serializers.SerializerMethodField()
    length_height_width = serializers.SerializerMethodField()
    # datetime = serializers.DateTimeField(format='%Y-%m-%d %I:%M:%S %p')
    datetime = serializers.SerializerMethodField()
    seal_presence = serializers.SerializerMethodField()
    hazard_sign_presence = serializers.SerializerMethodField()
    door_direction = serializers.SerializerMethodField()
    door_open_close = serializers.SerializerMethodField()
    damage_found = serializers.SerializerMethodField()
    camera_name = serializers.SerializerMethodField()

    class Meta:
        model = GateSiteDetected
        fields = ['container_number', 'iso_code', 'length_height_width', 'datetime', 'seal_presence', 'hazard_sign_presence', 'door_direction', 'door_open_close', 'damage_found', 'camera_name']

    def get_container_number(self, obj):
        containers = obj.detected_container.all()
        return [container.container_number for container in containers]
    

    # def get_container_number_image(self, obj):
    #     containers = obj.detected_container.all()
    #     images = []
    #     for container in containers:
    #         if container.container_number_image:
    #             images.append(container.container_number_image.url)
    #         else:
    #             images.append(None)
    #     return images


    def get_iso_code(self, obj):
        containers = obj.detected_container.all()
        return [container.iso_code for container in containers]

    def get_length_height_width(self, obj):
        containers = obj.detected_container.all()
        return [f"{container.length},{container.height},{container.width}.ft" for container in containers]

    def get_seal_presence(self, obj):
        containers = obj.detected_container.all()
        return [container.seal_presence for container in containers]

    def get_hazard_sign_presence(self, obj):
        containers = obj.detected_container.all()
        return [container.hazard_sign_presence for container in containers]

    def get_door_direction(self, obj):
        containers = obj.detected_container.all()
        return [container.door_direction for container in containers]

    def get_door_open_close(self, obj):
        containers = obj.detected_container.all()
        return [container.door_open_close for container in containers]

    def get_damage_found(self, obj):
        frames = obj.detected_frame.all()
        return [frame.damage_found for frame in frames]

    def get_camera_name(self, obj):
        frames = obj.detected_container.all()
        return [frame.camera_name for frame in frames]
    
 
    def get_datetime(self, instance):
        timezone_IST = pytz.timezone('Asia/Kolkata')
        datetime_ist = instance.datetime.astimezone(timezone_IST)
        # return datetime_ist.strftime('%Y-%m-%d %I:%M:%S %p')
        return datetime_ist.strftime('%Y-%m-%d %H:%M:%S')