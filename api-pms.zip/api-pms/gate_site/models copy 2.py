from django.db import models
import uuid
import django
# Create your models here.
from account.models import Sites,CompanyDetail,User

class GateSiteDetected(models.Model):
    uuid = models.UUIDField(default=uuid.uuid4,editable=False)
    datetime = models.DateTimeField(default=django.utils.timezone.now)
    container_presence = models.BooleanField(blank=True, null=True)
    group_name = models.CharField(max_length=30)
    sites = models.ForeignKey(Sites,on_delete=models.PROTECT)
    company_detail_id = models.ForeignKey(CompanyDetail,on_delete=models.PROTECT)
    created_by = models.ForeignKey(User,on_delete=models.PROTECT,related_name='created_by_%(class)s_related',blank=True,null=True)
    created_datetime = models.DateTimeField(blank=True,null=True)
    updated_by = models.ForeignKey(User,on_delete=models.PROTECT,related_name='updated_by_%(class)s_related',blank=True,null=True)
    updated_datetime = models.DateTimeField(blank=True,null=True)
    # site_name = models.CharField(max_length=15)
    # truck_booking_id = models.IntegerField(blank=True)
    # transporter_name = models.CharField(max_length=25)
    # driver_name = models.CharField(max_length=25)
    # driver_photo = models.TextField(blank=True, null=True)
    # driver_dl_number = models.CharField(max_length=25)
    # approve = models.BooleanField()

class GateSiteBlackListedVehicle(models.Model):
    uuid = models.UUIDField(default=uuid.uuid4,editable=False)
    licence_plate_number = models.CharField(max_length=30,blank=True, null=True)
    reason_to_blacklist = models.CharField(max_length=50)
    date_and_time = models.DateTimeField(default=django.utils.timezone.now)
    company_detail_id = models.ForeignKey(CompanyDetail,on_delete=models.PROTECT)
    created_by = models.ForeignKey(User,on_delete=models.PROTECT,related_name='created_by_%(class)s_related',blank=True,null=True)
    created_datetime = models.DateTimeField(blank=True,null=True)
    updated_by = models.ForeignKey(User,on_delete=models.PROTECT,related_name='updated_by_%(class)s_related',blank=True,null=True)
    updated_datetime = models.DateTimeField(blank=True,null=True)


class GateSiteBlackListedContainer(models.Model):
    uuid = models.UUIDField(default=uuid.uuid4,editable=False)
    container_number = models.CharField(max_length=30,blank=True, null=True)
    reason_to_blacklist = models.CharField(max_length=50)
    date_and_time = models.DateTimeField(default=django.utils.timezone.now)
    company_detail_id = models.ForeignKey(CompanyDetail,on_delete=models.PROTECT)
    created_by = models.ForeignKey(User,on_delete=models.PROTECT,related_name='created_by_%(class)s_related',blank=True,null=True)
    created_datetime = models.DateTimeField(blank=True,null=True)
    updated_by = models.ForeignKey(User,on_delete=models.PROTECT,related_name='updated_by_%(class)s_related',blank=True,null=True)
    updated_datetime = models.DateTimeField(blank=True,null=True)

class GateSiteDetectedVehicleDetail(models.Model):
    uuid = models.UUIDField(default=uuid.uuid4,editable=False)
    licence_plate_number = models.CharField(max_length=30,blank=True, null=True)
    licence_plate_image = models.ImageField(upload_to='port_management_system/licence_plate_image/',blank=True,null=True,max_length=500)
    avg_confidence_plate_number = models.FloatField(blank=True,null=True)
    blacklisted = models.BooleanField(blank=True, null=True)
    blacklisted_vehicle = models.ForeignKey(GateSiteBlackListedVehicle,on_delete=models.PROTECT, null=True)
    vehicle_type = models.CharField(max_length=15,blank=True,null=True)
    driver_seat_belt = models.CharField(max_length=20,blank=True,null=True)
    driver_seat_belt_image = models.ImageField('port_management_system/driver_seat_belt_image/',blank=True,null=True,max_length=500)
    camera_name = models.CharField(max_length=30,default='camera_name')
    camera_view_name = models.CharField(max_length=30,default='camera_view_name')
    camera_group_name = models.CharField(max_length=30,default='camera_group_name')
    detected = models.ForeignKey(GateSiteDetected,related_name='detected_vehicle',on_delete=models.PROTECT)
    created_by = models.ForeignKey(User,on_delete=models.PROTECT,related_name='created_by_%(class)s_related',blank=True,null=True)
    created_datetime = models.DateTimeField(blank=True,null=True)
    updated_by = models.ForeignKey(User,on_delete=models.PROTECT,related_name='updated_by_%(class)s_related',blank=True,null=True)
    updated_datetime = models.DateTimeField(blank=True,null=True)
    

class GateSiteDetectedContainerDetail(models.Model):
    uuid = models.UUIDField(default=uuid.uuid4,editable=False)
    container_number = models.CharField(max_length=30,blank=True, null=True)
    iso_code = models.CharField(max_length=5,blank=True, null=True)
    container_number_image = models.ImageField(upload_to='port_management_system/container_number_image/',blank=True,null=True,max_length=500)
    avg_confidence_container_number = models.FloatField(blank=True, null=True)
    blacklisted = models.BooleanField(blank=True, null=True)
    blacklisted_container = models.ForeignKey(GateSiteBlackListedContainer,on_delete=models.PROTECT, null=True)
    seal_presence = models.BooleanField(blank=True, null=True)
    seal_presence_count = models.IntegerField(default=0)
    length = models.FloatField(default=0.0,null=True,blank=True)
    height = models.FloatField(default=0.0,null=True,blank=True)
    width = models.FloatField(default=0.0,null=True,blank=True)
    hazard_sign_presence = models.BooleanField(blank=True,null=True)
    hazard_sign_image = models.ImageField(upload_to='port_management_system/hazard_sign_image/',blank=True,null=True,max_length=500)
    door_direction = models.CharField(max_length=30,blank=True, null=True)
    door_open_close = models.CharField(max_length=30,blank=True, null=True)
    camera_name = models.CharField(max_length=30,default='camera_name')
    camera_view_name = models.CharField(max_length=30,default='camera_view_name')
    camera_group_name = models.CharField(max_length=30,default='camera_group_name')
    detected = models.ForeignKey(GateSiteDetected,related_name='detected_container',on_delete=models.PROTECT)
    created_by = models.ForeignKey(User,on_delete=models.PROTECT,related_name='created_by_%(class)s_related',blank=True,null=True)
    created_datetime = models.DateTimeField(blank=True,null=True)
    updated_by = models.ForeignKey(User,on_delete=models.PROTECT,related_name='updated_by_%(class)s_related',blank=True,null=True)
    updated_datetime = models.DateTimeField(blank=True,null=True) 


class GateSiteDetectedSealImage(models.Model):
    uuid = models.UUIDField(default=uuid.uuid4,editable=False)
    seal_image = models.ImageField(upload_to='port_management_system/seal_area_image/',blank=True,null=True,max_length=500)
    seal_presence = models.BooleanField(default=False,blank=True,null=True)
    avg_confidence_seal_presence = models.FloatField(blank=True, null=True)
    detected_container_detail = models.ForeignKey(GateSiteDetectedContainerDetail,related_name='detected_seal', on_delete=models.PROTECT)


class GateSiteDetectedFrameImage(models.Model):
    uuid = models.UUIDField(default=uuid.uuid4,editable=False)
    frame_image = models.ImageField(upload_to='port_management_system/frame_image/',blank=True,null=True,max_length=500)
    damage_found = models.BooleanField(blank=True,null=True)
    camera_name = models.CharField(max_length=30,default='camera_name')
    camera_view_name = models.CharField(max_length=30,default='camera_view_name')
    camera_group_name = models.CharField(max_length=30,default='camera_group_name')
    detected = models.ForeignKey(GateSiteDetected,related_name='detected_frame', on_delete=models.PROTECT)
    # detected_vehicle_detail = models.ForeignKey(GateSiteDetectedVehicleDetail, on_delete=models.PROTECT,null=True)
    # detected_container_detail = models.ForeignKey(GateSiteDetectedContainerDetail, on_delete=models.PROTECT,null=True)

class GateSiteDetectedDamage(models.Model):
    uuid = models.UUIDField(default=uuid.uuid4,editable=False)
    damage_image = models.ImageField(upload_to='port_management_system/damage_image/',blank=True,null=True,max_length=500)
    avg_confidence_damage_presence = models.FloatField(blank=True, null=True)
    damage_type = models.CharField(max_length=30)
    detected_frame_image_detail = models.ForeignKey(GateSiteDetectedFrameImage,related_name='detected_damage', on_delete=models.PROTECT,null=True)

class GateSitePartiallyDetected(models.Model):
    uuid = models.UUIDField(default=uuid.uuid4,editable=False)
    datetime = models.DateTimeField(default=django.utils.timezone.now)
    container_presence = models.BooleanField(blank=True, null=True)
    group_name = models.CharField(max_length=30)
    sites = models.ForeignKey(Sites,on_delete=models.PROTECT)
    company_detail_id = models.ForeignKey(CompanyDetail,on_delete=models.PROTECT)
    created_by = models.ForeignKey(User,on_delete=models.PROTECT,related_name='created_by_%(class)s_related',blank=True,null=True)
    created_datetime = models.DateTimeField(blank=True,null=True)
    updated_by = models.ForeignKey(User,on_delete=models.PROTECT,related_name='updated_by_%(class)s_related',blank=True,null=True)
    updated_datetime = models.DateTimeField(blank=True,null=True)

class GateSitePartiallyDetectedVehicleDetail(models.Model):
    uuid = models.UUIDField(default=uuid.uuid4,editable=False)
    licence_plate_number = models.CharField(max_length=30,blank=True, null=True)
    licence_plate_image = models.TextField(blank=True, null=True)
    avg_confidence_plate_number = models.FloatField(blank=True, null=True)
    vehicle_type = models.CharField(max_length=15,blank=True, null=True)
    driver_seat_belt = models.CharField(max_length=20,blank=True,null=True)
    driver_seat_belt_image = models.ImageField('port_management_system/driver_seat_belt_image/',blank=True,null=True,max_length=500)
    camera_name = models.CharField(max_length=30,default='camera_name')
    camera_view_name = models.CharField(max_length=30,default='camera_view_name')
    camera_group_name = models.CharField(max_length=30,default='camera_group_name')
    partially_detected = models.ForeignKey(GateSitePartiallyDetected,related_name='partially_detected_vehicle',on_delete=models.PROTECT)
    created_by = models.ForeignKey(User,on_delete=models.PROTECT,related_name='created_by_%(class)s_related',blank=True,null=True)
    created_datetime = models.DateTimeField(blank=True,null=True)
    updated_by = models.ForeignKey(User,on_delete=models.PROTECT,related_name='updated_by_%(class)s_related',blank=True,null=True)
    updated_datetime = models.DateTimeField(blank=True,null=True)


class GateSitePartiallyDetectedContainerDetail(models.Model):
    uuid = models.UUIDField(default=uuid.uuid4,editable=False)
    container_number = models.CharField(max_length=30,blank=True, null=True)
    iso_code = models.CharField(max_length=5,blank=True, null=True)
    container_number_image = models.ImageField(upload_to='port_management_system/container_number_image/',blank=True,null=True,max_length=500)
    avg_confidence_container_number = models.FloatField(blank=True, null=True)
    seal_presence = models.BooleanField(blank=True, null=True)
    seal_presence_count = models.IntegerField(default=0)
    length = models.FloatField(default=0.0,null=True,blank=True)
    height = models.FloatField(default=0.0,null=True,blank=True)
    width = models.FloatField(default=0.0,null=True,blank=True)
    hazard_sign_presence = models.BooleanField(blank=True,null=True)
    hazard_sign_image = models.ImageField(upload_to='port_management_system/hazard_sign_image/',blank=True,null=True,max_length=500)
    door_direction = models.CharField(max_length=30,blank=True, null=True)
    door_open_close = models.CharField(max_length=30,blank=True, null=True)
    camera_name = models.CharField(max_length=30,default='camera_name')
    camera_view_name = models.CharField(max_length=30,default='camera_view_name')
    camera_group_name = models.CharField(max_length=30,default='camera_group_name')
    partially_detected = models.ForeignKey(GateSitePartiallyDetected,related_name='partially_detected_container',on_delete=models.PROTECT)
    created_by = models.ForeignKey(User,on_delete=models.PROTECT,related_name='created_by_%(class)s_related',blank=True,null=True)
    created_datetime = models.DateTimeField(blank=True,null=True)
    updated_by = models.ForeignKey(User,on_delete=models.PROTECT,related_name='updated_by_%(class)s_related',blank=True,null=True)
    updated_datetime = models.DateTimeField(blank=True,null=True) 


class GateSitePartiallyDetectedSealImage(models.Model):
    uuid = models.UUIDField(default=uuid.uuid4,editable=False)
    seal_image = models.ImageField(upload_to='port_management_system/seal_image/',blank=True,null=True,max_length=500)
    partially_detected_container_detail = models.ForeignKey(GateSitePartiallyDetectedContainerDetail,related_name='partially_detected_seal', on_delete=models.PROTECT)


class GateSitePartiallyDetectedFrameImage(models.Model):
    uuid = models.UUIDField(default=uuid.uuid4,editable=False)
    frame_image = models.ImageField(upload_to='port_management_system/frame_image/',blank=True,null=True,max_length=500)
    camera_name = models.CharField(max_length=30,default='camera_name')
    camera_view_name = models.CharField(max_length=30,default='camera_view_name')
    camera_group_name = models.CharField(max_length=30,default='camera_group_name')
    # camera_group_name = models.CharField(max_length=30)
    damage_found = models.BooleanField()
    partially_detected = models.ForeignKey(GateSitePartiallyDetected,related_name='partially_detected_frame', on_delete=models.PROTECT)
    # partially_detected_vehicle_detail = models.ForeignKey(GateSitePartiallyDetectedVehicleDetail, on_delete=models.PROTECT,null=True)
    # partially_detected_container_detail = models.ForeignKey(GateSitePartiallyDetectedContainerDetail, on_delete=models.PROTECT,null=True)


class GateSitePartiallyDetectedDamage(models.Model):
    uuid = models.UUIDField(default=uuid.uuid4,editable=False)
    damage_image = models.ImageField(upload_to='port_management_system/damage_image/',blank=True,null=True,max_length=500)
    detected_frame_image_detail = models.ForeignKey(GateSitePartiallyDetectedFrameImage,related_name='partially_detected_damage', on_delete=models.PROTECT,null=True)

