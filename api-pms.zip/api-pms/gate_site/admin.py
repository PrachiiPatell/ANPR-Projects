from django.contrib import admin
from .models import *
# Register your models here.

class GateSiteDetectedAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','datetime','container_presence','group_name','sites','company_detail_id')
# 'site_name','truck_booking_id','transporter_name','driver_name','driver_photo','driver_dl_number','approve'

class GateSiteBlackListedVehicleAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','licence_plate_number','reason_to_blacklist','date_and_time', 'company_detail_id')

class GateSiteBlackListedContainerAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','container_number','reason_to_blacklist','date_and_time', 'company_detail_id')

class GateSiteDetectedVehicleDetailAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','licence_plate_number','licence_plate_image','avg_confidence_plate_number', 'blacklisted', 'blacklisted_vehicle','vehicle_type','camera_name','camera_view_name','camera_group_name','detected')

class GateSiteDetectedContainerDetailAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','container_number','iso_code','container_number_image','avg_confidence_container_number', 'blacklisted', 'blacklisted_container','seal_presence','seal_presence_count','length','height','width','hazard_sign_presence','hazard_sign_image','camera_name','detected')


class GateSiteDetectedSealImageAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','seal_image','detected_container_detail')

class GateSiteDetectedFrameImageAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','frame_image','camera_name','damage_found','detected')
# ,'detected_vehicle_detail','detected_container_detail'

class GateSitePartiallyDetectedAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','datetime','group_name','sites','company_detail_id')


class GateSitePartiallyDetectedVehicleDetailAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','licence_plate_number','licence_plate_image','avg_confidence_plate_number','vehicle_type','camera_name','partially_detected')

class GateSitePartiallyDetectedContainerDetailAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','container_number','iso_code','container_number_image','avg_confidence_container_number', 'seal_presence','seal_presence_count','length','height','width','hazard_sign_presence','hazard_sign_image','camera_name','partially_detected')


class GateSitePartiallyDetectedSealImageAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','seal_image','partially_detected_container_detail')

class GateSitePartiallyDetectedFrameImageAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','frame_image','camera_name','damage_found','partially_detected')
# ,'partially_detected_vehicle_detail','partially_detected_container_detail'



admin.site.register(GateSiteDetected, GateSiteDetectedAdmin)
admin.site.register(GateSiteBlackListedVehicle, GateSiteBlackListedVehicleAdmin)
admin.site.register(GateSiteBlackListedContainer, GateSiteBlackListedContainerAdmin)
admin.site.register(GateSiteDetectedVehicleDetail, GateSiteDetectedVehicleDetailAdmin)
admin.site.register(GateSiteDetectedContainerDetail, GateSiteDetectedContainerDetailAdmin)
admin.site.register(GateSiteDetectedSealImage, GateSiteDetectedSealImageAdmin)
admin.site.register(GateSiteDetectedFrameImage,GateSiteDetectedFrameImageAdmin)

admin.site.register(GateSitePartiallyDetected, GateSitePartiallyDetectedAdmin)
admin.site.register(GateSitePartiallyDetectedVehicleDetail, GateSitePartiallyDetectedVehicleDetailAdmin)
admin.site.register(GateSitePartiallyDetectedContainerDetail, GateSitePartiallyDetectedContainerDetailAdmin)
admin.site.register(GateSitePartiallyDetectedSealImage, GateSitePartiallyDetectedSealImageAdmin)
admin.site.register(GateSitePartiallyDetectedFrameImage,GateSitePartiallyDetectedFrameImageAdmin)