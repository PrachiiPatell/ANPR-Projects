#from django.conf.urls import url
from django.urls import path,reverse,reverse_lazy
from django.conf.urls.static import static
from django.conf import settings 
from django.contrib.auth import views as auth_views
from .views import *
app_name = 'gatesite'
urlpatterns = [
    # path('register/', views.register, name='register'),
    path('gate_site_blacklisted_vehicle/',GateSiteBlackListedVehicleView.as_view()),
    path('gate_site_blacklisted_vehicle_detail/<int:id>',GateSiteBlackListedVehicleDetailView.as_view()),

    path('gate_site_blacklisted_container/',GateSiteBlackListedContainerView.as_view()),
    path('gate_site_blacklisted_container_detail/<int:id>',GateSiteBlackListedContainerDetailView.as_view()),

    path('gate_site_detected_temp/',GateSiteDetectedTempView.as_view()),
    path('gate-site-partially-detected_temp/',GateSitePartiallyDetectedTempView.as_view()),
    path('gate-site-detected', GateSiteDetectedView.as_view()),
    path('gate-site-detected/<int:id>', GateSiteDetectedDetailView.as_view()),
    path('gate-site-partially-detected', GateSitePartiallyDetectedView.as_view()),
    path('gate-site-partially-detected/<int:id>', GateSitePartiallyDetectedDetailView.as_view()),
    path('gate-site-dashboard/', DashboardData.as_view()),
    path('detected-excel-download',DetectedExcelDownloadView.as_view()),

] + static(settings.STATIC_URL)

# + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)