from django.urls import path
from importexport_site import views
from django.conf.urls.static import static
from django.conf import settings 

from .views import *
app_name = 'importexport_site'
urlpatterns = [

    path('import_export/',views.ImportExportView.as_view()),
    path('import_export_detail/<int:id>', views.ImportExportDetailView.as_view()),
    path('object/',views.ObjectView.as_view()),
    path('import_export_object_count/',views.ImportExportObjectCountView.as_view()),
    path('import_export_object_count_detail/<int:id>', views.ImportExportObjectCountDetailView.as_view()),
    path('object_dropdown/',views.ObjectListView.as_view()),
    path('import_export_dashboard/', views.DashboardData.as_view()),

] + static(settings.STATIC_URL)