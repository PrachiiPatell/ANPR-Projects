# from django.shortcuts import render

# # Create your views here.
# from django.shortcuts import render
# from rest_framework.permissions import AllowAny,IsAuthenticated
# from rest_framework.views import APIView
# from django.http.response import JsonResponse,Http404
# from rest_framework.response import Response
# from account.views import get_user_data_page
# from rest_framework import status
# from .models import *
# from .serializers import *
# from rest_framework.pagination import LimitOffsetPagination
# from django.db.models import Q


# # Create your views here.

# class ImportExportView(APIView):
#     permission_classes = (IsAuthenticated,)

#     def get(self, request):
#         limit = int(request.GET.get('limit',10))
#         offset = int(request.GET.get('offset',0))
#         user_detail_page = get_user_data_page(request.user.id,'import_export','view')  
#         if user_detail_page['company_detail']['plan_validity'] == True:
#             AccessToPage = False
#             if user_detail_page['permission'] != None:
#                 AccessToPage = True
#             if AccessToPage == True:

#                 if (
#     any(product['default_product__product_name'] == 'Import Export Object Count' and product['allowed_status'] for product in user_detail_page['product_allowed'])
#     and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
# ):
#                     from_datetime = request.GET.get('start_datetime',None)
#                     to_datetime = request.GET.get('end_datetime',None)
#                     camera_name = request.GET.get('camera_name',None)
#                     camera_view_name = request.GET.get('camera_view_name',None)
#                     camera_group_name = request.GET.get('camera_group_name',None)
#                     ordering = request.GET.get('order_by',None)
#                     if ordering ==None:
#                         ordering = '-from_datetime'
#                     f= Q(company_detail_id = user_detail_page['company_detail']['id'])
#                     if from_datetime != None:
#                         f &= Q(from_datetime__gte=from_datetime)
#                     if to_datetime != None:
#                         f &= Q(from_datetime__lte=to_datetime)
#                     if camera_name != '' and camera_name != None:
#                         f &= Q(detected_container__camera_name=camera_name)
#                     if camera_view_name != '' and camera_view_name != None:
#                         f &= Q(detected_container__camera_view_name=camera_view_name)
#                     if camera_group_name != '' and camera_group_name != None:
#                         f &= Q(group_name=camera_group_name)

#                     import_export = ImportExport.objects.filter(f).all().order_by(ordering)[offset:limit+offset]
#                     import_export_count = ImportExport.objects.filter(f).order_by(ordering).count()
#                     serializer = ImportExportSerializer(import_export, many=True)
#                     return Response({'count':import_export_count, 'results': serializer.data})
#                 else:
#                     return Response({"detail": "You don't have permission for Import Export Object Count."}, status=status.HTTP_400_BAD_REQUEST)
#             else:
#                 return Response({"detail": "you don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
#         else:
#             return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
        

#     def post(self, request):
#         user_detail_page = get_user_data_page(request.user.id,'import_export','create')  
#         if user_detail_page['company_detail']['plan_validity'] == True:
#             AccessToPage = False
#             if user_detail_page['permission'] != None:
#                 AccessToPage = True
#             if AccessToPage == True:
#                 if (
#     any(product['default_product__product_name'] == 'Import Export Object Count' and product['allowed_status'] for product in user_detail_page['product_allowed'])
#     and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
# ):
#                     data = request.data
#                     data['company_detail_id'] = user_detail_page['company_detail']['id']
#                     serializer = ImportExportSerializer(data=data)
#                     if serializer.is_valid():
#                         serializer.save()
#                         return Response(serializer.data, status=status.HTTP_201_CREATED)
#                     return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
#                 else:
#                     return Response({"detail": "You don't have permission for Import Export Object Count."}, status=status.HTTP_400_BAD_REQUEST)
#             else:
#                 return Response({"detail": "you don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
#         else:
#             return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

# class ImportExportDetailView(APIView):
#     permission_classes = (IsAuthenticated,)
#     def get_object(self, id):
#         try:
#             return ImportExport.objects.get(pk=id)
#         except ImportExport.DoesNotExist:
#             raise Http404
#     def get(self, request,id, format=None):
#         user_detail_page = get_user_data_page(request.user.id,'import_export','view')  
#         if user_detail_page['company_detail']['plan_validity'] == True:
#             AccessToPage = False
#             if user_detail_page['permission'] != None:
#                 AccessToPage = True
#             if AccessToPage == True:
#                 if (
#     any(product['default_product__product_name'] == 'Import Export Object Count' and product['allowed_status'] for product in user_detail_page['product_allowed'])
#     and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
# ):
        
#                     import_export = self.get_object(id)
#                     serializer = ImportExportSerializer(import_export)
#                     return Response(serializer.data)
#                 else:
#                     return Response({"detail": "You don't have permission for Import Export Object Count."}, status=status.HTTP_400_BAD_REQUEST)
#             else:
#                 return Response({"detail": "you don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
#         else:
#             return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
        

# class ObjectView(APIView):
#     permission_classes = (IsAuthenticated,)

#     def get(self, request):
#         limit = int(request.GET.get('limit',10))
#         offset = int(request.GET.get('offset',0))
#         user_detail_page = get_user_data_page(request.user.id,'object','view')  
#         if user_detail_page['company_detail']['plan_validity'] == True:
#             AccessToPage = False
#             if user_detail_page['permission'] != None:
#                 AccessToPage = True
#             if AccessToPage == True:
#                 if (
#     any(product['default_product__product_name'] == 'Import Export Object Count' and product['allowed_status'] for product in user_detail_page['product_allowed'])
#     and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
# ):
        
#                     object = Object.objects.all()[offset:limit+offset]
#                     object_count = Object.objects.count()
#                     serializer = ObjectSerializer(object, many=True)
#                     return Response({'count':object_count, 'results': serializer.data})
#                 else:
#                     return Response({"detail": "You don't have permission for Import Export Object Count."}, status=status.HTTP_400_BAD_REQUEST)
#             else:
#                 return Response({"detail": "you don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
#         else:
#             return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
        

#     def post(self, request):
#         user_detail_page = get_user_data_page(request.user.id,'object','create')  
#         if user_detail_page['company_detail']['plan_validity'] == True:
#             AccessToPage = False
#             if user_detail_page['permission'] != None:
#                 AccessToPage = True
#             if AccessToPage == True:
#                 if (
#     any(product['default_product__product_name'] == 'Import Export Object Count' and product['allowed_status'] for product in user_detail_page['product_allowed'])
#     and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
# ):
        
#                     serializer = ObjectSerializer(data=request.data)
#                     if serializer.is_valid():
#                         serializer.save()
#                         return Response(serializer.data, status=status.HTTP_201_CREATED)
#                     return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
#                 else:
#                     return Response({"detail": "You don't have permission for Import Export Object Count."}, status=status.HTTP_400_BAD_REQUEST)
#             else:
#                 return Response({"detail": "you don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
#         else:
#             return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

          

# class ImportExportObjectCountView(APIView):
#     permission_classes = (IsAuthenticated,)

#     def get(self, request):
#         limit = int(request.GET.get('limit',10))
#         offset = int(request.GET.get('offset',0))
#         user_detail_page = get_user_data_page(request.user.id,'import_export_object','view')  
#         if user_detail_page['company_detail']['plan_validity'] == True:
#             AccessToPage = False
#             if user_detail_page['permission'] != None:
#                 AccessToPage = True
#             if AccessToPage == True:
#                 if (
#     any(product['default_product__product_name'] == 'Import Export Object Count' and product['allowed_status'] for product in user_detail_page['product_allowed'])
#     and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
# ):
        
#                     import_export_object = ImportExportObjectCount.objects.all()[offset:limit+offset]
#                     import_export_object_count = ImportExportObjectCount.objects.count()
#                     serializer = ImportExportObjectCountSerializer(import_export_object, many=True)
#                     return Response({'count':import_export_object_count, 'results': serializer.data})
#                 else:
#                     return Response({"detail": "You don't have permission for Import Export Object Count."}, status=status.HTTP_400_BAD_REQUEST)
#             else:
#                 return Response({"detail": "you don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
#         else:
#             return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
        

#     def post(self, request):
#         user_detail_page = get_user_data_page(request.user.id,'import_export_object','create')  
#         if user_detail_page['company_detail']['plan_validity'] == True:
#             AccessToPage = False
#             if user_detail_page['permission'] != None:
#                 AccessToPage = True
#             if AccessToPage == True:
#                 if (
#     any(product['default_product__product_name'] == 'Import Export Object Count' and product['allowed_status'] for product in user_detail_page['product_allowed'])
#     and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
# ):
#                     data = request.data
#                     data['company_detail_id'] = user_detail_page['company_detail']['id']
#                     serializer = ImportExportObjectCountSerializer(data=data)
#                     if serializer.is_valid():
#                         serializer.save()
#                         return Response(serializer.data, status=status.HTTP_201_CREATED)
#                     return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
#                 else:
#                     return Response({"detail": "You don't have permission for Import Export Object Count."}, status=status.HTTP_400_BAD_REQUEST)
#             else:
#                 return Response({"detail": "you don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
#         else:
#             return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

# class ImportExportObjectCountDetailView(APIView):
#     permission_classes = (IsAuthenticated,)
#     def get_object(self, id):
#         try:
#             return ImportExportObjectCount.objects.get(pk=id)
#         except ImportExportObjectCount.DoesNotExist:
#             raise Http404
#     def get(self, request,id, format=None):
#         user_detail_page = get_user_data_page(request.user.id,'import_export_object','view')  
#         if user_detail_page['company_detail']['plan_validity'] == True:
#             AccessToPage = False
#             if user_detail_page['permission'] != None:
#                 AccessToPage = True
#             if AccessToPage == True:
#                 if (
#     any(product['default_product__product_name'] == 'Import Export Object Count' and product['allowed_status'] for product in user_detail_page['product_allowed'])
#     and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
# ):
        
#                     warehouse_object = self.get_object(id)
#                     serializer = ImportExportObjectCountSerializer(warehouse_object)
#                     return Response(serializer.data)
#                 else:
#                     return Response({"detail": "You don't have permission for Import Export Object Count."}, status=status.HTTP_400_BAD_REQUEST)
#             else:
#                 return Response({"detail": "you don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
#         else:
#             return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)




from django.shortcuts import render

# Create your views here.
from django.shortcuts import render
from rest_framework.permissions import AllowAny,IsAuthenticated
from rest_framework.views import APIView
from django.http.response import JsonResponse,Http404
from rest_framework.response import Response
from account.views import get_user_data_page
from rest_framework import status
from .models import *
from .serializers import *
from rest_framework.pagination import LimitOffsetPagination
from django.db.models import Q, Count



# Create your views here.

class ImportExportView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request):
        limit = int(request.GET.get('limit',10))
        offset = int(request.GET.get('offset',0))
        user_detail_page = get_user_data_page(request.user.id,'import_export','view')  
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:

                if (
    any(product['default_product__product_name'] == 'Import Export Object Count' and product['allowed_status'] for product in user_detail_page['product_allowed'])
    and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
):
                    from_datetime = request.GET.get('start_datetime',None)
                    to_datetime = request.GET.get('end_datetime',None)
                    camera_name = request.GET.get('camera_name',None)
                    camera_view_name = request.GET.get('camera_view_name',None)
                    camera_group_name = request.GET.get('camera_group_name',None)
                    ordering = request.GET.get('order_by',None)
                    if ordering ==None:
                        ordering = '-from_datetime'
                    f= Q(company_detail_id = user_detail_page['company_detail']['id'])
                    if from_datetime != None:
                        f &= Q(from_datetime__gte=from_datetime)
                    if to_datetime != None:
                        f &= Q(from_datetime__lte=to_datetime)
                    if camera_name != '' and camera_name != None:
                        f &= Q(camera_name=camera_name)
                    if camera_view_name != '' and camera_view_name != None:
                        f &= Q(camera_view_name=camera_view_name)
                    if camera_group_name != '' and camera_group_name != None:
                        f &= Q(camera_group_name=camera_group_name)

                    import_export = ImportExport.objects.filter(f).order_by(ordering)[offset:limit+offset]
                    import_export_count = ImportExport.objects.filter(f).order_by(ordering).count()
                    serializer = ImportExportSerializer(import_export, many=True)
                    return Response({'count':import_export_count, 'results': serializer.data})
                else:
                    return Response({"detail": "You don't have permission for Import Export Object Count."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "you don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
        

    def post(self, request):
        user_detail_page = get_user_data_page(request.user.id,'import_export','create')  
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                if (
    any(product['default_product__product_name'] == 'Import Export Object Count' and product['allowed_status'] for product in user_detail_page['product_allowed'])
    and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
):
                    data = request.data
                    data['company_detail_id'] = user_detail_page['company_detail']['id']
                    serializer = ImportExportSerializer(data=data)
                    if serializer.is_valid():
                        serializer.save()
                        return Response(serializer.data, status=status.HTTP_201_CREATED)
                    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                else:
                    return Response({"detail": "You don't have permission for Import Export Object Count."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "you don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

class ImportExportDetailView(APIView):
    permission_classes = (IsAuthenticated,)
    def get_object(self, id):
        try:
            return ImportExport.objects.get(pk=id)
        except ImportExport.DoesNotExist:
            raise Http404
    def get(self, request,id, format=None):
        user_detail_page = get_user_data_page(request.user.id,'import_export','view')  
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                if (
    any(product['default_product__product_name'] == 'Import Export Object Count' and product['allowed_status'] for product in user_detail_page['product_allowed'])
    and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
):
        
                    import_export = self.get_object(id)
                    serializer = ImportExportSerializer(import_export)
                    return Response(serializer.data)
                else:
                    return Response({"detail": "You don't have permission for Import Export Object Count."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "you don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
        

class ObjectView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request):
        limit = int(request.GET.get('limit',10))
        offset = int(request.GET.get('offset',0))
        user_detail_page = get_user_data_page(request.user.id,'object','view')  
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                if (
    any(product['default_product__product_name'] == 'Import Export Object Count' and product['allowed_status'] for product in user_detail_page['product_allowed'])
    and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
):
        
                    object = Object.objects.all()[offset:limit+offset]
                    object_count = Object.objects.count()
                    serializer = ObjectSerializer(object, many=True)
                    return Response({'count':object_count, 'results': serializer.data})
                else:
                    return Response({"detail": "You don't have permission for Import Export Object Count."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "you don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
        

    def post(self, request):
        user_detail_page = get_user_data_page(request.user.id,'object','create')  
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                if (
    any(product['default_product__product_name'] == 'Import Export Object Count' and product['allowed_status'] for product in user_detail_page['product_allowed'])
    and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
):
        
                    serializer = ObjectSerializer(data=request.data)
                    if serializer.is_valid():
                        serializer.save()
                        return Response(serializer.data, status=status.HTTP_201_CREATED)
                    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                else:
                    return Response({"detail": "You don't have permission for Import Export Object Count."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "you don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

          

class ImportExportObjectCountView(APIView):
    permission_classes = (IsAuthenticated,)

#     def get(self, request):
#         limit = int(request.GET.get('limit',10))
#         offset = int(request.GET.get('offset',0))
#         user_detail_page = get_user_data_page(request.user.id,'import_export_object','view')  
#         if user_detail_page['company_detail']['plan_validity'] == True:
#             AccessToPage = False
#             if user_detail_page['permission'] != None:
#                 AccessToPage = True
#             if AccessToPage == True:
#                 if (
#     any(product['default_product__product_name'] == 'Import Export Object Count' and product['allowed_status'] for product in user_detail_page['product_allowed'])
#     and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
# ):
        
#                     import_export_object = ImportExportObjectCount.objects.all()[offset:limit+offset]
#                     import_export_object_count = ImportExportObjectCount.objects.count()
#                     serializer = ImportExportObjectCountSerializer(import_export_object, many=True)
#                     return Response({'count':import_export_object_count, 'results': serializer.data})
#                 else:
#                     return Response({"detail": "You don't have permission for Import Export Object Count."}, status=status.HTTP_400_BAD_REQUEST)
#             else:
#                 return Response({"detail": "you don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
#         else:
#             return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
        

    def post(self, request):
        user_detail_page = get_user_data_page(request.user.id,'import_export_object','create')  
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                if (
    any(product['default_product__product_name'] == 'Import Export Object Count' and product['allowed_status'] for product in user_detail_page['product_allowed'])
    and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
):
                    data = request.data
                    data['company_detail_id'] = user_detail_page['company_detail']['id']
                    serializer = ImportExportObjectCountSerializer(data=data)
                    if serializer.is_valid():
                        serializer.save()
                        return Response(serializer.data, status=status.HTTP_201_CREATED)
                    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                else:
                    return Response({"detail": "You don't have permission for Import Export Object Count."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "you don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

class ImportExportObjectCountDetailView(APIView):
    permission_classes = (IsAuthenticated,)
    def get_object(self, id):
        try:
            return ImportExportObjectCount.objects.get(pk=id)
        except ImportExportObjectCount.DoesNotExist:
            raise Http404
    def get(self, request,id, format=None):
        user_detail_page = get_user_data_page(request.user.id,'import_export_object','view')  
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                if (
    any(product['default_product__product_name'] == 'Import Export Object Count' and product['allowed_status'] for product in user_detail_page['product_allowed'])
    and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
):
        
                    warehouse_object = self.get_object(id)
                    serializer = ImportExportObjectCountSerializer(warehouse_object)
                    return Response(serializer.data)
                else:
                    return Response({"detail": "You don't have permission for Import Export Object Count."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "you don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

# DropDown
class ObjectListView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):

        object = Object.objects.all()
        
        object_serializer = ObjectListSerializer(object, many=True)
        return Response(object_serializer.data)
    
class DashboardData(APIView):
    permission_classes = (IsAuthenticated,)
    def get(self,request, format=None):
        user_detail_page = get_user_data_page(request.user.id, 'dashboard', 'view')
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                start_date = request.GET.get('start_date')
                end_date = request.GET.get('end_date')
                company_detail_id = user_detail_page['company_detail']['id']
                importexport_total_count = ImportExport.objects.filter(from_datetime__gte=start_date, to_datetime__lte=end_date,company_detail_id=user_detail_page['company_detail']['id']).count()
                import_count = ImportExport.objects.filter(from_datetime__gte=start_date, to_datetime__lte=end_date,company_detail_id=user_detail_page['company_detail']['id'], type_of_view='Import').count()
                export_count = ImportExport.objects.filter(from_datetime__gte=start_date, to_datetime__lte=end_date,company_detail_id=user_detail_page['company_detail']['id'], type_of_view='Export').count()
                gunnybag_count = ImportExport.objects.filter(
                                from_datetime__gte=start_date, to_datetime__lte=end_date,company_detail_id=company_detail_id,).annotate(
                                gunny_bag_count=Count('importexportobjectcount', 
                                                      filter=models.Q(importexportobjectcount__object_id__object_type='Gunny Bag'))).values('gunny_bag_count')

                barrel_count = ImportExport.objects.filter(
                                from_datetime__gte=start_date, to_datetime__lte=end_date,company_detail_id=company_detail_id,).annotate(
                                barrel_counts=Count('importexportobjectcount', 
                                                      filter=models.Q(importexportobjectcount__object_id__object_type='Barrel'))).values('barrel_counts')

                drum_count = ImportExport.objects.filter(
                                from_datetime__gte=start_date, to_datetime__lte=end_date,company_detail_id=company_detail_id,).annotate(
                                drum_counts=Count('importexportobjectcount', 
                                                      filter=models.Q(importexportobjectcount__object_id__object_type='Drum'))).values('drum_counts')

                box_count = ImportExport.objects.filter(
                                from_datetime__gte=start_date, to_datetime__lte=end_date,company_detail_id=company_detail_id,).annotate(
                                box_counts=Count('importexportobjectcount', 
                                                      filter=models.Q(importexportobjectcount__object_id__object_type='Box'))).values('box_counts')

                # # Access the count
                gunnybag_count = gunnybag_count[0]['gunny_bag_count'] if gunnybag_count else 0
                barrel_count = barrel_count[0]['barrel_counts'] if barrel_count else 0
                drum_count = drum_count[0]['drum_counts'] if drum_count else 0
                box_count = box_count[0]['box_counts'] if box_count else 0
                results = {
                    "importexport_total_count": {'count':importexport_total_count,'filter_values':'importexport'},
                    "import_count": {'count':import_count,'filter_values':'Import'},
                    "export_count": {'count':export_count,'filter_values':'Export'},
                    "gunnybag_count": {'count':gunnybag_count,'filter_values':'Gunny Bag'},
                    "barrel_count": {'count':barrel_count,'filter_values':'Barrel'},
                    "drum_count": {'count':drum_count,'filter_values':'Drum'},
                    "box_count": {'count':box_count,'filter_values':'Box'},
                    "company_detail_id":user_detail_page['company_detail']['id'],
                    "StartDateTime": start_date,
                    "EndDateTime": end_date
                    }
                return JsonResponse(results, safe=False)
            else:
                return Response({"detail": "you don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)      