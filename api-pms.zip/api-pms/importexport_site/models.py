from django.db import models
import uuid
import django
from account.models import Sites,CompanyDetail,User
# Create your models here.


class ImportExport(models.Model):
    uuid = models.UUIDField(default=uuid.uuid4,editable=False)
    total_object_count = models.IntegerField()
    from_datetime = models.DateTimeField(default=django.utils.timezone.now)
    to_datetime = models.DateTimeField(default=django.utils.timezone.now)
    camera_name = models.CharField(max_length=20)
    camera_view_name = models.CharField(max_length=30)
    camera_group_name = models.CharField(max_length=30)
    type_of_view = models.CharField(max_length=20)
    sites = models.ForeignKey(Sites,on_delete=models.PROTECT)
    company_detail_id = models.ForeignKey(CompanyDetail,on_delete=models.PROTECT)
    created_by = models.ForeignKey(User,on_delete=models.PROTECT,related_name='created_by_%(class)s_related',blank=True,null=True)
    created_datetime = models.DateTimeField(blank=True,null=True)
    updated_by = models.ForeignKey(User,on_delete=models.PROTECT,related_name='updated_by_%(class)s_related',blank=True,null=True)
    updated_datetime = models.DateTimeField(blank=True,null=True)

class Object(models.Model):
    uuid = models.UUIDField(default=uuid.uuid4,editable=False)
    object_type = models.CharField(max_length=15)

class ImportExportObjectCount(models.Model):
    uuid = models.UUIDField(default=uuid.uuid4,editable=False)
    import_export_id = models.ForeignKey(ImportExport,on_delete=models.CASCADE)
    object_id = models.ForeignKey(Object,on_delete=models.CASCADE)
    count = models.IntegerField()
    sites = models.ForeignKey(Sites,on_delete=models.PROTECT)
    company_detail_id = models.ForeignKey(CompanyDetail,on_delete=models.PROTECT)
    created_by = models.ForeignKey(User,on_delete=models.PROTECT,related_name='created_by_%(class)s_related',blank=True,null=True)
    created_datetime = models.DateTimeField(blank=True,null=True)
    updated_by = models.ForeignKey(User,on_delete=models.PROTECT,related_name='updated_by_%(class)s_related',blank=True,null=True)
    updated_datetime = models.DateTimeField(blank=True,null=True)