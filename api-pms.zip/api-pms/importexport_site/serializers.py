from rest_framework.serializers import ModelSerializer
from .models import *
from rest_framework import serializers

class ImportExportObjectCountSerializer(ModelSerializer):
    object_name = serializers.CharField(source='object_id.object_type', read_only=True)
    site_name = serializers.CharField(source='sites.site_name', read_only=True)
    class Meta:
        model = ImportExportObjectCount
        fields = '__all__'

class ImportExportSerializer(ModelSerializer):
    site_name = serializers.CharField(source='sites.site_name', read_only=True)
    import_export_object_counts = ImportExportObjectCountSerializer(many=True, read_only=True)
    class Meta:
        model = ImportExport
        fields = '__all__'


    def to_representation(self, instance):
        rep = super().to_representation(instance)
        # Include ImportExportObjectCount data in the serialized output
        rep['import_export_object_counts'] = ImportExportObjectCountSerializer(instance.importexportobjectcount_set.all(), many=True).data
        return rep
    
class ObjectSerializer(ModelSerializer):
    class Meta:
        model = Object
        fields = '__all__'

class ObjectListSerializer(serializers.ModelSerializer):
    class Meta:
        model = Object
        fields = ["id", "object_type"]