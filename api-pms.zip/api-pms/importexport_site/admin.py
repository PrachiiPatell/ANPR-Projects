from django.contrib import admin
from .models import *

# Register your models here.

class ImportExportAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','total_object_count','from_datetime','to_datetime','camera_name','camera_view_name','camera_group_name','type_of_view','sites','company_detail_id')

class ImportExportObjectCountAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','import_export_id','object_id','count','sites','company_detail_id')

admin.site.register(ImportExport, ImportExportAdmin)
admin.site.register(ImportExportObjectCount, ImportExportObjectCountAdmin)
