# custom_storages.py

from storages.backends.s3boto3 import S3Boto3Storage

class StaticStorage(S3Boto3Storage):
    location = 'port_management_system/static'
    file_overwrite = False  # Optional: set to True if you want to overwrite existing files

class MediaStorage(S3Boto3Storage):
    location = 'port_management_system'
    file_overwrite = False  # Optional: set to True if you want to overwrite existing files
    