from django.urls import path
from train_baggage_counting import views
from django.conf.urls.static import static
from django.conf import settings 

from .views import *
app_name = 'train_baggage_counting'
urlpatterns = [

    path('PlatormCustomerDetail/',views.PlatormCustomerDetailView.as_view()), 
    path('PlatormCustomerDetail/<uuid:uuid>/',views.PlatormCustomerDetailView.as_view()),
    path('PlatFormDetail/',views.PlatFormDetailView.as_view()), 
    path('PlatFormDetail/<uuid:uuid>/',views.PlatFormDetailView.as_view()),
    path('platFormTrainDetail/',views.platFormTrainDetailView.as_view()), 
    path('platFormTrainDetail/<uuid:uuid>/',views.platFormTrainDetailView.as_view()),
    path('GateCountDetection/',views.GateCountDetectionView.as_view()),
    path('GateCountDetection/<uuid:uuid>/',views.GateCountDetectionView.as_view()),
    # path('FreightTrainNumberDetail/',views.FreightTrainNumberDetailView.as_view()),
    # path('FreightTrainNumberDetail/<uuid:uuid>/',views.FreightTrainNumberDetailView.as_view()),
    path('FreightTrainBoxCountDetection/',views.FreightTrainBoxCountDetectionView.as_view()),
    path('FreightTrainBoxCountDetection/<uuid:uuid>/',views.FreightTrainBoxCountDetectionView.as_view()),
    path('CameraCountDetection/',views.CameraCountDetectionView.as_view()),
    path('CameraCountDetection/<uuid:uuid>/',views.CameraCountDetectionView.as_view()),
    path('Camera/',views.CameraView.as_view()),
    path('Camera/<uuid:uuid>/',views.CameraView.as_view()),
    path('FreightTrainCustomerDetail/',views.FreightTrainCustomerDetailView.as_view()),
    path('FreightTrainCustomerDetail/<uuid:uuid>/',views.FreightTrainCustomerDetailView.as_view()),
    path('PlatormCustomerDetailDropDown/',views.PlatormCustomerDetailDropDownView.as_view()),
    path('TrainBaggageCountingDashBoard/',views.DashboardData.as_view()),

    path('UpdateFromOfflinePlatformCustomer/<uuid:uuid>/',views.OfflinUpdatePlatformCustomerView.as_view()),

    path('UpdateFromOfflineFreightTrainCustomer/<uuid:uuid>/',views.OfflineUpdateFreightTrainCustomerView.as_view()), 
    

    


    # path('baggage_counting/',views.BaggageCountingView.as_view()),
    # path('baggage_counting_detail/<int:id>', views.BaggageCountingDetailView.as_view()),
    # path('doors/',views.DoorsView.as_view()),
    # path('doors_detail/<int:id>', views.DoorsDetailView.as_view()),


] + static(settings.STATIC_URL)