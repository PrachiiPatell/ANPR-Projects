from django.contrib import admin
from .models import *
# Register your models here.

from django.contrib import admin
from .models import *

@admin.register(PlatormCustomerDetail)
class PlatormCustomerDetailAdmin(admin.ModelAdmin):
    list_display = ('id', 'uuid', 'platform_name', 'customer_name', 'number_of_freight_train_boxes', 'start_datetime', 'end_datetime', 'company_detail_id','sites','offline_insert','offline_update')

@admin.register(FreightTrainCustomerDetail)
class FreightTrainCustomerDetailAdmin(admin.ModelAdmin):
    list_display = ('id', 'uuid', 'freight_train_number', 'material_type','train_freight_sequence_number', 'platfrom_customer_detail', 'company_detail_id','sites','offline_insert','offline_update')

@admin.register(PlatFormDetail)
class PlatFormDetailAdmin(admin.ModelAdmin):
    list_display = ('id', 'uuid', 'name', 'train_presence', 'sites', 'company_detail_id')

@admin.register(PlatFormTrainDetail)
class PlatFormTrainDetailAdmin(admin.ModelAdmin):
    list_display = ('id', 'uuid', 'count_gunnybag', 'start_datetime', 'end_datetime', 'platform_name', 'platfrom_customer_detail', 'sites', 'company_detail_id')

@admin.register(Camera)
class CameraAdmin(admin.ModelAdmin):
    list_display = ('id', 'uuid', 'url_or_video', 'camera_type', 'camera_name', 'user_name', 'camera_working', 'platform_name', 'camera_sequence_number', 'detection', 'sites', 'company_detail_id')

# @admin.register(FreightTrainNumberDetail)
# class FreightTrainNumberDetailAdmin(admin.ModelAdmin):
#     list_display = ('id', 'uuid', 'freight_train_number', 'date_time', 'camera_name', 'platform_name', 'camera_sequence_number', 'sites', 'company_detail_id')

@admin.register(GateCountDetection)
class GateCountDetectionAdmin(admin.ModelAdmin):
    list_display = ('id', 'uuid', 'count_of_gunnybag', 'start_datetime', 'end_datetime', 'camera_name', 'platform_name', 'camera_sequence', 'platform_train_detail', 'destuffing', 'gate_name','platfrom_customer_detail','sites', 'company_detail_id')

@admin.register(FreightTrainBoxCountDetection)
class FreightTrainBoxCountDetectionAdmin(admin.ModelAdmin):
    list_display = ('id', 'uuid', 'count_of_gunnybag', 'start_datetime', 'end_datetime', 'freight_train_box_name', 'platform_name', 'freight_train_number','platfrom_customer_detail', 'sites', 'company_detail_id')

@admin.register(FreightCameraDetail)
class FreightCameraDetailAdmin(admin.ModelAdmin):
    list_display = ('id','camera_name', 'camera_sequence_number', 'freight_train_box_detail')

@admin.register(CameraCountDetection)
class CameraCountDetectionAdmin(admin.ModelAdmin):
    list_display = ('id', 'uuid', 'count_of_gunnybag', 'start_datetime', 'end_datetime', 'camera_name', 'camera_sequence_number', 'platform_name','platfrom_customer_detail', 'sites', 'company_detail_id')



    



# admin.site.register(BaggageCounting, BaggageCountingAdmin)
# admin.site.register(Doors, DoorsAdmin)