from django.shortcuts import render
from rest_framework.permissions import AllowAny,IsAuthenticated
from rest_framework.views import APIView
from django.http.response import JsonResponse,Http404
from rest_framework.response import Response
from account.views import get_user_data_page
from rest_framework import status
from .models import *
from .serializers import *
#from .views import*
from datetime import datetime,timedelta
from django.db.models import Q
from django.core.mail import EmailMultiAlternatives,send_mail
from django.template.loader import render_to_string
import pytz
from datetime import timezone
from collections import defaultdict
import json
#from account.views  import get_user_data , GetUserDetail
#from account.views import*     

# Create your views here.

class PlatormCustomerDetailView(APIView):
    permission_classes = (IsAuthenticated,)
    
    def get(self, request, format=None):
        # Get query parameters
        limit = int(request.GET.get('limit', 10))
        offset = int(request.GET.get('offset', 0))
        
        user_detail_page = get_user_data_page(
            request.user.id, 'PlatormCustomerDetail', 'view')
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                # Check if user has permission for feature
                if (any(product['default_product__product_name'] == 'Baggage Counting' and product['allowed_status'] for product in user_detail_page['product_allowed'])
                            and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
                        ):
                    f= Q(company_detail_id = user_detail_page['company_detail']['id'])
            

                    sites = Sites.objects.filter(company_detail_id=user_detail_page['company_detail']['id'],user=request.user.id).values('id')

                    site_id = None
                    if sites.exists():
                        site_id = sites[0]['id']
                        f &= Q(sites=site_id)

                    from_datetime = request.GET.get('start_datetime',None)
                    to_datetime = request.GET.get('end_datetime',None)
                    platform_name = request.GET.get('platform_name',None)
                    customer_name = request.GET.get('customer_name',None)
                    offline_insert = request.GET.get('offline_insert',None)
                    offline_update = request.GET.get('offline_update',None)
                    if from_datetime != None:
                        f &= Q(start_datetime__gte=from_datetime)
                    if to_datetime != None:
                        f &= Q(end_datetime__lte=to_datetime)
                    if platform_name != '' and platform_name != None:
                        f &= Q(platform_name=platform_name)
                    if customer_name != '' and customer_name != None:
                        f &= Q(customer_name=customer_name)
                    if offline_insert != '' and offline_insert != None:
                        f &= Q(offline_insert=offline_insert)
                    
                    if offline_update != '' and offline_update != None:
                        f &= Q(offline_update=offline_update)

                    platForms = PlatormCustomerDetail.objects.filter(f).order_by('-id')[offset:limit+offset]
                    platForm_count = PlatormCustomerDetail.objects.filter(f).count()
                    
                    # Serialize data
                    serializer = PlatormCustomerDetailSerializer(platForms, many=True)
                    
                    # Return response
                    return Response({'count': platForm_count, 'results': serializer.data})
                else:
                    return Response({"detail": "You don't have permission for this feature."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "You don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "Account validity has expired."}, status=status.HTTP_400_BAD_REQUEST)

    def post(self, request, format=None):
        user_detail_page = get_user_data_page(request.user.id, 'PlatormCustomerDetail', 'create')
        

        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                # Check if user has permission for feature
                if (any(product['default_product__product_name'] == 'Baggage Counting' and product['allowed_status'] for product in user_detail_page['product_allowed'])
                            and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
                        ):
                    get_data = request.data
                    get_data['sites'] = user_detail_page['site']['id']
                    get_data['company_detail_id'] = user_detail_page['company_detail']['id']
                    serializer = PlatormCustomerDetailSerializer(data=get_data)
                    
                    if serializer.is_valid():
                        serializer.save()
                        return Response(serializer.data, status=status.HTTP_201_CREATED)
                    else:
                        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                else:
                    return Response({"detail": "You don't have permission for this feature."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "You don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "Account validity has expired."}, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, uuid, format=None):
        user_detail_page = get_user_data_page(request.user.id, 'PlatormCustomerDetail', 'update')
        
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                # Check if user has permission for feature
                if (any(product['default_product__product_name'] == 'Baggage Counting' and product['allowed_status'] for product in user_detail_page['product_allowed'])
                            and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
                        ):
                  
                    platForm= PlatormCustomerDetail.objects.get(uuid=uuid) 
                    get_data = request.data
                    get_data['offline_update'] = False
                    get_data['sites'] = user_detail_page['site']['id']
                    get_data['company_detail_id'] = user_detail_page['company_detail']['id']
                    serializer = PlatormCustomerDetailSerializer(platForm, get_data)
                    
                    if serializer.is_valid():
                        serializer.save()
                        return Response(serializer.data, status=status.HTTP_201_CREATED)
                    else:
                        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                else:
                    return Response({"detail": "You don't have permission for this feature."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "You don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "Account validity has expired."}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, uuid, format=None):
        user_detail_page = get_user_data_page(request.user.id, 'PlatormCustomerDetail', 'delete')
        
        
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                # Check if user has permission for feature
                if (any(product['default_product__product_name'] == 'Baggage Counting' and product['allowed_status'] for product in user_detail_page['product_allowed'])
                            and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
                        ):
                    platForm= PlatormCustomerDetail.objects.get(uuid=uuid)
                    platForm.delete()
                    return Response(status=status.HTTP_204_NO_CONTENT)
                else:
                    return Response({"detail": "You don't have permission for this feature."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "You don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "Account validity has expired."}, status=status.HTTP_400_BAD_REQUEST)

class PlatFormDetailView(APIView):
    permission_classes = (IsAuthenticated,)
    
    def get(self, request, format=None):
        # Get query parameters
        limit = int(request.GET.get('limit', 10))
        offset = int(request.GET.get('offset', 0))
        
        user_detail_page = get_user_data_page(
            request.user.id, 'platFormDetail', 'view')
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                # Check if user has permission for feature
                if (any(product['default_product__product_name'] == 'Baggage Counting' and product['allowed_status'] for product in user_detail_page['product_allowed'])
                            and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
                        ):
                    f= Q(company_detail_id = user_detail_page['company_detail']['id'])
                    
                    platForms = PlatFormDetail.objects.filter(f).order_by('-id')[offset:limit+offset]
                    platForm_count = PlatFormDetail.objects.filter(f).count()
                    
                    # Serialize data
                    serializer = PlatFormDetailSerializer(platForms, many=True)
                    
                    # Return response
                    return Response({'count': platForm_count, 'results': serializer.data})
                else:
                    return Response({"detail": "You don't have permission for this feature."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "You don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "Account validity has expired."}, status=status.HTTP_400_BAD_REQUEST)

    def post(self, request, format=None):
        user_detail_page = get_user_data_page(request.user.id, 'platFormDetail', 'create')
        
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                # Check if user has permission for feature
                if (any(product['default_product__product_name'] == 'Baggage Counting' and product['allowed_status'] for product in user_detail_page['product_allowed'])
                            and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
                        ):
                    get_data = request.data
                    get_data['company_detail_id'] = user_detail_page['company_detail']['id']
                    serializer = PlatFormDetailSerializer(data=get_data)
                    
                    if serializer.is_valid():
                        serializer.save()
                        return Response(serializer.data, status=status.HTTP_201_CREATED)
                    else:
                        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                else:
                    return Response({"detail": "You don't have permission for this feature."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "You don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "Account validity has expired."}, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, uuid, format=None):
        user_detail_page = get_user_data_page(request.user.id, 'platFormDetail', 'update')
        
       
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                # Check if user has permission for feature
                if (any(product['default_product__product_name'] == 'Baggage Counting' and product['allowed_status'] for product in user_detail_page['product_allowed'])
                            and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
                        ):
                  
                    platForm= PlatFormDetail.objects.get(uuid=uuid) 
                    get_data = request.data
                    get_data['company_detail_id'] = user_detail_page['company_detail']['id']
                    serializer = PlatFormDetailSerializer(platForm, get_data)
                    
                    if serializer.is_valid():
                        serializer.save()
                        return Response(serializer.data, status=status.HTTP_201_CREATED)
                    else:
                        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                else:
                    return Response({"detail": "You don't have permission for this feature."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "You don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "Account validity has expired."}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, uuid, format=None):
        user_detail_page = get_user_data_page(request.user.id, 'platFormDetail', 'delete')
        
       
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                # Check if user has permission for feature
                if (any(product['default_product__product_name'] == 'Baggage Counting' and product['allowed_status'] for product in user_detail_page['product_allowed'])
                            and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
                        ):
                    platForm= PlatFormDetail.objects.get(uuid=uuid) 
                    platForm.delete()
                    return Response(status=status.HTTP_204_NO_CONTENT)
                else:
                    return Response({"detail": "You don't have permission for this feature."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "You don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "Account validity has expired."}, status=status.HTTP_400_BAD_REQUEST)


class platFormTrainDetailView(APIView):
    #permission_classes = (AllowAny,)
    permission_classes = (IsAuthenticated,)
        
    def get(self, request, format=None):
        limit = int(request.GET.get('limit', 10))
        offset = int(request.GET.get('offset', 0))
        user_detail_page = get_user_data_page(
            request.user.id, 'platFormTrainDetail', 'view')
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                if (any(product['default_product__product_name'] == 'Baggage Counting' and product['allowed_status'] for product in user_detail_page['product_allowed'])
                            and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
                        ):
                    f= Q(company_detail_id = user_detail_page['company_detail']['id'])
                    from_datetime = request.GET.get('start_datetime',None)
                    to_datetime = request.GET.get('end_datetime',None)
                    platform_name = request.GET.get('platform_name',None)
                    if from_datetime != None:
                        f &= Q(start_datetime__gte=from_datetime)
                    if to_datetime != None:
                        f &= Q(end_datetime__lte=to_datetime)
                    if platform_name != '' and platform_name != None:
                        f &= Q(platform_name=platform_name)
                    platForm = PlatFormTrainDetail.objects.filter(f).order_by('-id').all()[
                        offset:limit+offset]
                    platForm_count = PlatFormTrainDetail.objects.filter(f).count()
                    serializer = PlatFormTrainDetailSerializer(
                        platForm, many=True)
                    return Response({'count': platForm_count, 'results': serializer.data})
                else:
                    return Response({"detail": "You don't have permission for Baggage Counting feature."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "you don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

   
    def post(self, request, format=None):
        user_detail_page = get_user_data_page(
            request.user.id, 'platFormTrainDetail', 'create')
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                if (any(product['default_product__product_name'] == 'Baggage Counting' and product['allowed_status'] for product in user_detail_page['product_allowed'])
                            and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
                        ):
                    get_data = request.data

                    platfrom_customer_detail_id = None
                    platfrom_customer_uuid = request.data.get('platfrom_customer_uuid')

                    if platfrom_customer_uuid is not None:
                        platfrom_customer_detail = PlatormCustomerDetail.objects.filter(uuid=platfrom_customer_uuid).first()
                        if platfrom_customer_detail:
                            platfrom_customer_detail_id = platfrom_customer_detail.id

                    get_data['company_detail_id'] = user_detail_page['company_detail']['id']
                    get_data['platfrom_customer_detail'] = platfrom_customer_detail_id

                    serializer = PlatFormTrainDetailSerializer(
                        data=get_data)
                    if serializer.is_valid():
                        serializer.save()
                        return Response(serializer.data, status=status.HTTP_201_CREATED)
                    else:
                        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                else:
                    return Response({"detail": "You don't have permission for  feature."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "you don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request,uuid, format=None):
        user_detail_page = get_user_data_page(request.user.id,'platFormTrainDetail','update')
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage:
                if (any(product['default_product__product_name'] == 'Baggage Counting' and product['allowed_status'] for product in user_detail_page['product_allowed'])
                            and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
                        ):
                    add_user_email = PlatFormTrainDetail.objects.get(uuid=uuid)
                    get_data = request.data
                    platfrom_customer_detail_id = None
                    platfrom_customer_uuid = request.data.get('platfrom_customer_uuid')

                    if platfrom_customer_uuid is not None:
                        platfrom_customer_detail = PlatormCustomerDetail.objects.filter(uuid=platfrom_customer_uuid).first()
                        if platfrom_customer_detail:
                            platfrom_customer_detail_id = platfrom_customer_detail.id

                    get_data['company_detail_id'] = user_detail_page['company_detail']['id']
                    get_data['platfrom_customer_detail'] = platfrom_customer_detail_id
                    
                    serializer = PlatFormTrainDetailSerializer(add_user_email,data=get_data)
                    if serializer.is_valid():
                        serializer.save()
                        return Response(serializer.data, status=status.HTTP_201_CREATED)
                    else:
                        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "You don`t have permissions."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
        
    def delete(self, request, uuid, format=None):
        user_detail_page = get_user_data_page(request.user.id, 'platFormTrainDetail', 'delete')
        
       
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                # Check if user has permission for feature
                if (any(product['default_product__product_name'] == 'Baggage Counting' and product['allowed_status'] for product in user_detail_page['product_allowed'])
                            and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
                        ):
                    platForm= PlatFormTrainDetail.objects.get(uuid=uuid) 
                    platForm.delete()
                    return Response(status=status.HTTP_204_NO_CONTENT)
                else:
                    return Response({"detail": "You don't have permission for this feature."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "You don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "Account validity has expired."}, status=status.HTTP_400_BAD_REQUEST)
        

    
class GateCountDetectionView(APIView):   
    permission_classes = (IsAuthenticated,)
    
    def get(self, request, format=None):
        limit = int(request.GET.get('limit', 10))
        offset = int(request.GET.get('offset', 0))
        user_detail_page = get_user_data_page(
            request.user.id, 'GetCountDetection', 'view')
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                if (any(product['default_product__product_name'] == 'Baggage Counting' and product['allowed_status'] for product in user_detail_page['product_allowed'])
                            and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
                        ):
                    f= Q(company_detail_id = user_detail_page['company_detail']['id'])
                    f &= Q(is_deleted = False)
                    from_datetime = request.GET.get('start_datetime',None)
                    to_datetime = request.GET.get('end_datetime',None)
                    platform_name = request.GET.get('platform_name',None)
                    camera_name = request.GET.get('camera_name',None)
                    if from_datetime != None:
                        f &= Q(start_datetime__gte=from_datetime)
                    if to_datetime != None:
                        f &= Q(end_datetime__lte=to_datetime)
                    if platform_name != '' and platform_name != None:
                        f &= Q(platform_name=platform_name)
                    if camera_name != '' and camera_name != None:
                        f &= Q(camera_name=camera_name)
                    Gate = GateCountDetection.objects.filter(f).order_by('-id').all()[
                        offset:limit+offset]
                    Gate_count = GateCountDetection.objects.filter(f).count()
                    serializer = GateCountDetectionSerializer(
                        Gate, many=True)
                    return Response({'count': Gate_count, 'results': serializer.data})
                    
                    
                else:
                    return Response({"detail": "You don't have permission for Gate Site feature."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "you don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def post(self,request,format=None):
        #permission_classes = (AllowAny,)
        permission_classes = (IsAuthenticated,)
        user_detail_page = get_user_data_page(request.user.id,'GetCountDetection','create')
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage:
                if (any(product['default_product__product_name'] == 'Baggage Counting' and product['allowed_status'] for product in user_detail_page['product_allowed'])
                            and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
                        ):
                
                    get_data = request.data
                    platfrom_customer_detail_id = None
                    platfrom_customer_uuid = request.data.get('platfrom_customer_uuid')

                    if platfrom_customer_uuid is not None:
                        platfrom_customer_detail = PlatormCustomerDetail.objects.filter(uuid=platfrom_customer_uuid).first()
                        if platfrom_customer_detail:
                            platfrom_customer_detail_id = platfrom_customer_detail.id

                    get_data['company_detail_id'] = user_detail_page['company_detail']['id']
                    get_data['platfrom_customer_detail'] = platfrom_customer_detail_id
                    
                    serializer = GateCountDetectionSerializer(data=get_data)
                    if serializer.is_valid():
                        serializer.save()
                        return Response(serializer.data, status=status.HTTP_201_CREATED)
                    else:
                        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                else:
                    return Response({"detail": "You don't have permission for feature."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "you don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def put(self,request,uuid,format=None):
        permission_classes = (IsAuthenticated,)
        user_detail_page = get_user_data_page(request.user.id,'GetCountDetection','update')
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage:
                if (any(product['default_product__product_name'] == 'Baggage Counting' and product['allowed_status'] for product in user_detail_page['product_allowed'])
                            and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
                        ):
                
                    add_user_email = GateCountDetection.objects.get(uuid=uuid)
                    get_data = request.data
                    platfrom_customer_detail_id = None
                    platfrom_customer_uuid = request.data.get('platfrom_customer_uuid')

                    if platfrom_customer_uuid is not None:
                        platfrom_customer_detail = PlatormCustomerDetail.objects.filter(uuid=platfrom_customer_uuid).first()
                        if platfrom_customer_detail:
                            platfrom_customer_detail_id = platfrom_customer_detail.id

                    get_data['company_detail_id'] = user_detail_page['company_detail']['id']
                    get_data['platfrom_customer_detail'] = platfrom_customer_detail_id
                    
                    serializer = GateCountDetectionSerializer(add_user_email,data=get_data)
                    if serializer.is_valid():
                        serializer.save()
                        return Response(serializer.data, status=status.HTTP_201_CREATED)
                    else:
                        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "You don`t have permissions."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
        
    def delete(self, request, uuid, format=None):
        user_detail_page = get_user_data_page(request.user.id, 'GetCountDetection', 'delete')
        
       
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                # Check if user has permission for feature
                if (any(product['default_product__product_name'] == 'Baggage Counting' and product['allowed_status'] for product in user_detail_page['product_allowed'])
                            and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
                        ):
                    gate= GateCountDetection.objects.get(uuid=uuid) 
                    gate.delete()
                    return Response(status=status.HTTP_204_NO_CONTENT)
                else:
                    return Response({"detail": "You don't have permission for this feature."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "You don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "Account validity has expired."}, status=status.HTTP_400_BAD_REQUEST)
           
     
# class FreightTrainNumberDetailView(APIView):
#     permission_classes = (IsAuthenticated,)
    
#     def get(self, request, format=None):
#         # Get query parameters
#         limit = int(request.GET.get('limit', 10))
#         offset = int(request.GET.get('offset', 0))
        
#         user_detail_page = get_user_data_page(
#             request.user.id, 'FreightTrainNumberDetail', 'view')
#         if user_detail_page['company_detail']['plan_validity'] == True:
#             AccessToPage = False
#             if user_detail_page['permission'] != None:
#                 AccessToPage = True
#             if AccessToPage == True:
#                 # Check if user has permission for feature
#                 if (any(product['default_product__product_name'] == 'Baggage Counting' and product['allowed_status'] for product in user_detail_page['product_allowed'])
#                             and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
#                         ):
#                     f= Q(company_detail_id = user_detail_page['company_detail']['id'])
#                     platform_name = request.GET.get('platform_name',None)
#                     camera_name = request.GET.get('camera_name',None)
#                     if platform_name != '' and platform_name != None:
#                         f &= Q(platform_name=platform_name)
#                     if camera_name != '' and camera_name != None:
#                         f &= Q(camera_name=camera_name)
#                     platForms = FreightTrainNumberDetail.objects.filter(f)[offset:limit+offset]
#                     platForm_count = FreightTrainNumberDetail.objects.filter(f).count()
                    
#                     # Serialize data
#                     serializer = FreightTrainNumberDetailSerializer(platForms, many=True)
                    
#                     # Return response
#                     return Response({'count': platForm_count, 'results': serializer.data})
#                 else:
#                     return Response({"detail": "You don't have permission for this feature."}, status=status.HTTP_400_BAD_REQUEST)
#             else:
#                 return Response({"detail": "You don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
#         else:
#             return Response({"detail": "Account validity has expired."}, status=status.HTTP_400_BAD_REQUEST)

#     def post(self, request, format=None):
#         user_detail_page = get_user_data_page(request.user.id, 'FreightTrainNumberDetail', 'create')
        

#         if user_detail_page['company_detail']['plan_validity'] == True:
#             AccessToPage = False
#             if user_detail_page['permission'] != None:
#                 AccessToPage = True
#             if AccessToPage == True:
#                 # Check if user has permission for feature
#                 if (any(product['default_product__product_name'] == 'Baggage Counting' and product['allowed_status'] for product in user_detail_page['product_allowed'])
#                             and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
#                         ):
#                     get_data = request.data
#                     get_data['company_detail_id'] = user_detail_page['company_detail']['id']
#                     serializer = FreightTrainNumberDetailSerializer(data=get_data)
                    
#                     if serializer.is_valid():
#                         serializer.save()
#                         return Response(serializer.data, status=status.HTTP_201_CREATED)
#                     else:
#                         return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
#                 else:
#                     return Response({"detail": "You don't have permission for this feature."}, status=status.HTTP_400_BAD_REQUEST)
#             else:
#                 return Response({"detail": "You don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
#         else:
#             return Response({"detail": "Account validity has expired."}, status=status.HTTP_400_BAD_REQUEST)

#     def put(self, request, uuid, format=None):
#         user_detail_page = get_user_data_page(request.user.id, 'FreightTrainNumberDetail', 'update')
        
#         if user_detail_page['company_detail']['plan_validity'] == True:
#             AccessToPage = False
#             if user_detail_page['permission'] != None:
#                 AccessToPage = True
#             if AccessToPage == True:
#                 # Check if user has permission for feature
#                 if (any(product['default_product__product_name'] == 'Baggage Counting' and product['allowed_status'] for product in user_detail_page['product_allowed'])
#                             and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
#                         ):
                  
#                     platForm= FreightTrainNumberDetail.objects.get(uuid=uuid) 
#                     get_data = request.data
#                     get_data['company_detail_id'] = user_detail_page['company_detail']['id']
#                     serializer = FreightTrainNumberDetailSerializer(platForm, get_data)
                    
#                     if serializer.is_valid():
#                         serializer.save()
#                         return Response(serializer.data, status=status.HTTP_201_CREATED)
#                     else:
#                         return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
#                 else:
#                     return Response({"detail": "You don't have permission for this feature."}, status=status.HTTP_400_BAD_REQUEST)
#             else:
#                 return Response({"detail": "You don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
#         else:
#             return Response({"detail": "Account validity has expired."}, status=status.HTTP_400_BAD_REQUEST)

#     def delete(self, request, uuid, format=None):
#         user_detail_page = get_user_data_page(request.user.id, 'FreightTrainNumberDetail', 'delete')
        
        
#         if user_detail_page['company_detail']['plan_validity'] == True:
#             AccessToPage = False
#             if user_detail_page['permission'] != None:
#                 AccessToPage = True
#             if AccessToPage == True:
#                 # Check if user has permission for feature
#                 if (any(product['default_product__product_name'] == 'Baggage Counting' and product['allowed_status'] for product in user_detail_page['product_allowed'])
#                             and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
#                         ):
#                     platForm= FreightTrainNumberDetail.objects.get(uuid=uuid)
#                     platForm.delete()
#                     return Response(status=status.HTTP_204_NO_CONTENT)
#                 else:
#                     return Response({"detail": "You don't have permission for this feature."}, status=status.HTTP_400_BAD_REQUEST)
#             else:
#                 return Response({"detail": "You don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
#         else:
#             return Response({"detail": "Account validity has expired."}, status=status.HTTP_400_BAD_REQUEST)

    

class FreightTrainBoxCountDetectionView(APIView):
    permission_classes = (IsAuthenticated,)
   
    def get(self, request,format=None):
        limit = int(request.GET.get('limit', 10))
        offset = int(request.GET.get('offset', 0))
        user_detail_page = get_user_data_page(
            request.user.id, 'FreightTrainBoxCountDetection', 'view')
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                if (any(product['default_product__product_name'] == 'Baggage Counting' and product['allowed_status'] for product in user_detail_page['product_allowed'])
                            and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
                        ):
                    f= Q(company_detail_id = user_detail_page['company_detail']['id'])
                    from_datetime = request.GET.get('start_datetime',None)
                    to_datetime = request.GET.get('end_datetime',None)
                    platform_name = request.GET.get('platform_name',None)
                    camera_name = request.GET.get('camera_name',None)
                    if from_datetime != None:
                        f &= Q(start_datetime__gte=from_datetime)
                    if to_datetime != None:
                        f &= Q(end_datetime__lte=to_datetime)
                    if platform_name != '' and platform_name != None:
                        f &= Q(platform_name=platform_name)
                    if camera_name != '' and camera_name != None:
                        f &= Q(camera_name=camera_name)
                    freight_trains = FreightTrainBoxCountDetection.objects.filter(f).order_by('-id').all()[offset:offset + limit]
                    freight_train_count = FreightTrainBoxCountDetection.objects.filter(f).count()
                    camera_details = []
                    
                    for freight_train in freight_trains:
                        freight_train_data = {
                            'id':freight_train.id,
                            'uuid':freight_train.uuid,
                            'count_of_gunnybag':freight_train.count_of_gunnybag,
                            'start_datetime':freight_train.start_datetime,
                            'end_datetime': freight_train.end_datetime,
                            'freight_train_box_name':freight_train.freight_train_box_name,
                            'platform_name':freight_train.platform_name,
                            'platfrom_customer_detail':freight_train.platfrom_customer_detail.id if freight_train.platfrom_customer_detail else None,
                            'freight_train_customer_detail':freight_train.freight_train_customer_detail.id if freight_train.freight_train_customer_detail else None,
                            'freight_train_number':freight_train.freight_train_number,
                            'sites':freight_train.sites.id,
                            'company_detail_id':freight_train.company_detail_id.id,
                            'camera_details' : []
                        }
                        freight_cams = FreightCameraDetail.objects.filter(freight_train_box_detail=freight_train.id).order_by('-id').all()
                        if freight_cams:
                            for freight_cam in freight_cams:
                                freight_train_data['camera_details'].append({
                                    "id": freight_cam.id,
                                "camera_name": freight_cam.camera_name,
                                "cam_sequence_number": freight_cam.camera_sequence_number,
                                "freight_train_box_detail":freight_cam.freight_train_box_detail.id
                                })

                        camera_details.append(freight_train_data)

                    # camera_details = camera_details[offset:offset + limit]

                    return Response({"count": freight_train_count, "results": camera_details})
                    
                else:
                    return Response({"detail": "You don't have permission for Gate Site feature."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "you don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    
    

    
    def post(self,request,format=None):
        #permission_classes = (AllowAny,)
        permission_classes = (IsAuthenticated,)
        
        user_detail_page = get_user_data_page(request.user.id,'FreightTrainBoxCountDetection','create')
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                if (any(product['default_product__product_name'] == 'Baggage Counting' and product['allowed_status'] for product in user_detail_page['product_allowed'])
                            and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
                        ):
                    platfrom_customer_detail_id = None
                    freight_train_customer_detail_id = None
                    platfrom_customer_uuid = request.data.get('platfrom_customer_uuid')
                    freight_train_customer_uuid = request.data.get('freight_train_customer_uuid')

                    if platfrom_customer_uuid is not None:
                        platfrom_customer_detail = PlatormCustomerDetail.objects.filter(uuid=platfrom_customer_uuid).first()
                        if platfrom_customer_detail:
                            platfrom_customer_detail_id = platfrom_customer_detail.id

                    if freight_train_customer_uuid is not None:
                        freight_train_customer_detail = FreightTrainCustomerDetail.objects.filter(uuid=freight_train_customer_uuid).first()
                        if freight_train_customer_detail:
                            freight_train_customer_detail_id = freight_train_customer_detail.id

                    company_detail_id = user_detail_page['company_detail']['id']
                    freight_train_box_detail = {
                        'uuid':request.data['uuid'],
                        'count_of_gunnybag':request.data['count_of_gunnybag'],
                        'start_datetime':request.data['start_datetime'],
                        'end_datetime': request.data['end_datetime'],
                        'freight_train_box_name':request.data['freight_train_box_name'],
                        'platform_name':request.data['platform_name'],
                        'platfrom_customer_detail':platfrom_customer_detail_id,
                        'freight_train_customer_detail':freight_train_customer_detail_id,
                        'freight_train_number':request.data['freight_train_number'],
                        'sites':request.data['sites'],
                        'company_detail_id':company_detail_id
                    }
                    #'id':request.data[manual_uuid]

                    freight_serializer = FreightTrainBoxCountDetectionSerializer(data= freight_train_box_detail)
                    
                    freight_id = None
                    if freight_serializer.is_valid():
                        freight_obj=freight_serializer.save()
                        freight_id = freight_obj.id
                    else:
                        return Response(freight_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                    
                    cam_datas = request.data.get('cam_datas', [])
                    cam_datas_id = []

                    for data in cam_datas:
                        freight_cam_data = {
                            'camera_name':data['camera_name'],
                            'camera_sequence_number':data['camera_sequence_number'],
                            'freight_train_box_detail': freight_id
                        }

                        cam_serializer = FreightCameraDetailSerializer(data= freight_cam_data)
                    
                        if cam_serializer.is_valid():
                            cam_obj=cam_serializer.save()
                            cam_datas_id.append(cam_obj.id)
                        else:
                            FreightTrainBoxCountDetection.objects.filter(id=freight_id).delete()
                            for cam_id in cam_datas_id:
                                FreightCameraDetail.objects.filter(id=cam_id).delete()
                            return Response(cam_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                    
                    return Response({'Success': 'Freight Train Box Data Added Successfully.'}, status=status.HTTP_201_CREATED)
                
            else:
                return Response({"detail": "You don`t have permissions."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
        

    def put(self,request,uuid,format=None):
        #permission_classes = (AllowAny,)
        permission_classes = (IsAuthenticated,)
        
        user_detail_page = get_user_data_page(request.user.id,'FreightTrainBoxCountDetection','update')
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                if (any(product['default_product__product_name'] == 'Baggage Counting' and product['allowed_status'] for product in user_detail_page['product_allowed'])
                            and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
                        ):
                    
                    platfrom_customer_detail_id = None
                    freight_train_customer_detail_id = None
                    platfrom_customer_uuid = request.data.get('platfrom_customer_uuid')
                    freight_train_customer_uuid = request.data.get('freight_train_customer_uuid')

                    if platfrom_customer_uuid is not None:
                        platfrom_customer_detail = PlatormCustomerDetail.objects.filter(uuid=platfrom_customer_uuid).first()
                        if platfrom_customer_detail:
                            platfrom_customer_detail_id = platfrom_customer_detail.id

                    if freight_train_customer_uuid is not None:
                        freight_train_customer_detail = FreightTrainCustomerDetail.objects.filter(uuid=freight_train_customer_uuid).first()
                        if freight_train_customer_detail:
                            freight_train_customer_detail_id = freight_train_customer_detail.id
                
                    freight_data = FreightTrainBoxCountDetection.objects.get(uuid=uuid)
                    company_detail_id = user_detail_page['company_detail']['id']
                    freight_train_box_detail = {
                        'uuid':request.data['uuid'],
                        'count_of_gunnybag':request.data['count_of_gunnybag'],
                        'start_datetime':request.data['start_datetime'],
                        'end_datetime': request.data['end_datetime'],
                        'freight_train_box_name':request.data['freight_train_box_name'],
                        'platform_name':request.data['platform_name'],
                        'platfrom_customer_detail':platfrom_customer_detail_id,
                        'freight_train_customer_detail':freight_train_customer_detail_id,
                        'freight_train_number':request.data['freight_train_number'],
                        'sites':request.data['sites'],
                        'company_detail_id':company_detail_id
                    }
                    #'id':request.data[manual_uuid]

                    freight_serializer = FreightTrainBoxCountDetectionSerializer(freight_data,data= freight_train_box_detail)
                    
                    if freight_serializer.is_valid():
                        freight_serializer.save()
                    else:
                        return Response(freight_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                    
                    # camera_data = FreightCameraDetail.objects.filter(freight_train_box_detail=freight_data.id).all()
                    camera_data = FreightCameraDetail.objects.filter(freight_train_box_detail=freight_data.id)
                    cam_datas = request.data.get('cam_datas', [])
                    cam_datas_id = []

                    for index, data in enumerate(cam_datas):
                        try:
                            current_camera_data = camera_data[index]
                        except IndexError:
                            current_camera_data = None

                        freight_cam_data = {
                            'camera_name': data['camera_name'],
                            'camera_sequence_number': data['camera_sequence_number'],
                            'freight_train_box_detail': freight_data.id
                        }

                        if current_camera_data:
                            # Update existing camera data
                            cam_serializer = FreightCameraDetailSerializer(current_camera_data, data=freight_cam_data)
                        else:
                            # Create new camera data
                            cam_serializer = FreightCameraDetailSerializer(data=freight_cam_data)
                        
                        if cam_serializer.is_valid():
                            cam_serializer.save()
                        else:
                            return Response(cam_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                    
                    return Response({'Success': 'Freight Train Box Data Added Successfully.'}, status=status.HTTP_201_CREATED)
                
            else:
                return Response({"detail": "You don`t have permissions."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)    



    # def put(self,request,uuid,format=None):
    #     permission_classes = (IsAuthenticated,)
    #     user_detail_page = get_user_data_page(request.user.id,'FreightTrainBoxCountDetection','update')
    #     if user_detail_page['company_detail']['plan_validity'] == True:
    #         AccessToPage = False
    #         if user_detail_page['permission'] != None:
    #             AccessToPage = True
    #         if AccessToPage:
    #             if (any(product['default_product__product_name'] == 'Baggage Counting' and product['allowed_status'] for product in user_detail_page['product_allowed'])
    #                         and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
    #                     ):
                
    #                 add_user_email = FreightTrainBoxCountDetection.objects.get(uuid=uuid)
    #                 get_data = request.data
    #                 get_data['company_detail_id'] = user_detail_page['company_detail']['id']
                    
    #                 serializer = FreightTrainBoxCountDetectionSerializer(add_user_email,data=get_data)
    #                 if serializer.is_valid():
    #                     serializer.save()
    #                     return Response(serializer.data, status=status.HTTP_201_CREATED)
    #                 else:
    #                     return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    #         else:
    #             return Response({"detail": "You don`t have permissions."}, status=status.HTTP_400_BAD_REQUEST)
    #     else:
    #         return Response({"detail": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
        
    def delete(self, request, uuid, format=None):
        
        user_detail_page = get_user_data_page(request.user.id, 'FreightTrainBoxCountDetection', 'delete')
        
       
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                # Check if user has permission for feature
                if (any(product['default_product__product_name'] == 'Baggage Counting' and product['allowed_status'] for product in user_detail_page['product_allowed'])
                            and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
                        ):
                    freight_train= FreightTrainBoxCountDetection.objects.get(uuid=uuid) 
                    freight_train.delete()
                    return Response(status=status.HTTP_204_NO_CONTENT)
                else:
                    return Response({"detail": "You don't have permission for this feature."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "You don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "Account validity has expired."}, status=status.HTTP_400_BAD_REQUEST)
        

class CameraCountDetectionView(APIView):
    permission_classes = (IsAuthenticated,)
    
    
    def get(self, request, format=None):
        limit = int(request.GET.get('limit', 10))
        offset = int(request.GET.get('offset', 0))
        user_detail_page = get_user_data_page(
            request.user.id, 'CameraCountDetection', 'view')
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                if (any(product['default_product__product_name'] == 'Baggage Counting' and product['allowed_status'] for product in user_detail_page['product_allowed'])
                            and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
                        ):
                    f= Q(company_detail_id = user_detail_page['company_detail']['id'])
                    from_datetime = request.GET.get('start_datetime',None)
                    to_datetime = request.GET.get('end_datetime',None)
                    platform_name = request.GET.get('platform_name',None)
                    camera_name = request.GET.get('camera_name',None)
                    if from_datetime != None:
                        f &= Q(start_datetime__gte=from_datetime)
                    if to_datetime != None:
                        f &= Q(end_datetime__lte=to_datetime)
                    if platform_name != '' and platform_name != None:
                        f &= Q(platform_name=platform_name)
                    if camera_name != '' and camera_name != None:
                        f &= Q(camera_name=camera_name)
                    Camera = CameraCountDetection.objects.filter(f).order_by('-id').all()[
                        offset:limit+offset]
                    Camera_count = CameraCountDetection.objects.filter(f).count()
                    serializer = CameraCountDetectionSerializer(
                        Camera, many=True)
                    return Response({'count': Camera_count, 'results': serializer.data})
                else:
                    return Response({"detail": "You don't have permission  feature."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "you don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def post(self,request,format=None):
        
        user_detail_page = get_user_data_page(
            request.user.id, 'CameraCountDetection', 'create')
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                if (any(product['default_product__product_name'] == 'Baggage Counting' and product['allowed_status'] for product in user_detail_page['product_allowed'])
                            and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
                        ):
                    get_data = request.data
                    platfrom_customer_detail_id = None
                    platfrom_customer_uuid = request.data.get('platfrom_customer_uuid')

                    if platfrom_customer_uuid is not None:
                        platfrom_customer_detail = PlatormCustomerDetail.objects.filter(uuid=platfrom_customer_uuid).first()
                        if platfrom_customer_detail:
                            platfrom_customer_detail_id = platfrom_customer_detail.id

                    get_data['company_detail_id'] = user_detail_page['company_detail']['id']
                    get_data['platfrom_customer_detail'] = platfrom_customer_detail_id
                    serializer = CameraCountDetectionSerializer(
                        data=get_data)
                    if serializer.is_valid():
                        serializer.save()
                        return Response(serializer.data, status=status.HTTP_201_CREATED)
                    else:
                        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                else:
                    return Response({"detail": "You don't have permission for Camera Count feature."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "you don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def put(self,request,uuid,format=None):
        permission_classes = (IsAuthenticated,)
        user_detail_page = get_user_data_page(request.user.id,'CameraCountDetection','update')
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                
                if (any(product['default_product__product_name'] == 'Baggage Counting' and product['allowed_status'] for product in user_detail_page['product_allowed'])
                            and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
                        ):
                    
                    add_user_email = CameraCountDetection.objects.get(uuid=uuid)
                    get_data = request.data
                
                    platfrom_customer_detail_id = None
                    platfrom_customer_uuid = request.data.get('platfrom_customer_uuid')

                    if platfrom_customer_uuid is not None:
                        platfrom_customer_detail = PlatormCustomerDetail.objects.filter(uuid=platfrom_customer_uuid).first()
                        if platfrom_customer_detail:
                            platfrom_customer_detail_id = platfrom_customer_detail.id

                    get_data['company_detail_id'] = user_detail_page['company_detail']['id']
                    get_data['platfrom_customer_detail'] = platfrom_customer_detail_id
                    serializer = CameraCountDetectionSerializer(add_user_email, data=get_data)
                    if serializer.is_valid():
                        serializer.save()
                        return Response(serializer.data, status=status.HTTP_201_CREATED)
                    else:
                        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)  
                else:
                    return Response({"detail": "You don't have permission for Camera Count feature."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "you don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
        

    def delete(self, request, uuid, format=None):
        
        user_detail_page = get_user_data_page(request.user.id, 'CameraCountDetection', 'delete')
        
       
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                # Check if user has permission for feature
                if (any(product['default_product__product_name'] == 'Baggage Counting' and product['allowed_status'] for product in user_detail_page['product_allowed'])
                            and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
                        ):
                    cam= CameraCountDetection.objects.get(uuid=uuid) 
                    cam.delete()
                    return Response(status=status.HTTP_204_NO_CONTENT)
                else:
                    return Response({"detail": "You don't have permission for this feature."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "You don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "Account validity has expired."}, status=status.HTTP_400_BAD_REQUEST)


def send_email_on_status_change(sender, instance, **kwargs):
    # if kwargs.get('created', False): 
    #     return
    # admin_roles = Roles.objects.filter(role_name__iexact='Admin', company_detail_id_id=instance.company_detail_id_id).values('id').first()
    # admin_users = UserRoleMapping.objects.filter(
    #     role=admin_roles['id']
    # )
    # admin_emails = admin_users.values_list('user__email', flat=True)
    get_business_email =SendMailNotification.objects.filter(company_detail_id=instance.company_detail_id)
    email_list = get_business_email.values_list('email',flat=True)
    if len(email_list) > 0:
        subject = f'{instance.camera_name} Camera Offline Notification'
        timezones = 'Asia/Kolkata'  # Replace with your desired timezone
        last_active_datetime = datetime.strptime(str(instance.date_time), '%Y-%m-%d %H:%M:%S.%f%z')
        last_active_datetime = last_active_datetime.astimezone(pytz.timezone(timezones)).strftime("%d-%m-%Y %I:%M %p")

        html_message = render_to_string('camera_emails.html', {'camera_name': instance.camera_name,'last_active_datetime':str(last_active_datetime)})
                # message = f"Local Site {get_sites_name['sites__site_name']} is Offline"

        from_email = 'anprsolutionsllp@gmail.com'
        send_mail(subject, '', from_email, email_list,html_message=html_message)


class CameraView(APIView):
    permission_classes = (IsAuthenticated,)
    
    def get(self, request, format=None):
        # Get query parameters
        limit = int(request.GET.get('limit', 10))
        offset = int(request.GET.get('offset', 0))
        
        user_detail_page = get_user_data_page(
            request.user.id, 'Camera', 'view')
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                # Check if user has permission for feature
                if (any(product['default_product__product_name'] == 'Baggage Counting' and product['allowed_status'] for product in user_detail_page['product_allowed'])
                            and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
                        ):

                    f= Q(company_detail_id = user_detail_page['company_detail']['id'])
                    
                    platform_name = request.GET.get('platform_name',None)
                    camera_name = request.GET.get('camera_name',None)
                   
                    if platform_name != '' and platform_name != None:
                        f &= Q(platform_name=platform_name)
                    if camera_name != '' and camera_name != None:
                        f &= Q(camera_name=camera_name)

                    platForms = Camera.objects.filter(f).order_by('-id')[offset:limit+offset]
                    platForm_count = Camera.objects.filter(f).count()
                    
                    # Serialize data
                    serializer = CameraSerializer(platForms, many=True)
                    
                    # Return response
                    return Response({'count': platForm_count, 'results': serializer.data})
                else:
                    return Response({"detail": "You don't have permission for this feature."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "You don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "Account validity has expired."}, status=status.HTTP_400_BAD_REQUEST)

    def post(self, request, format=None):
        user_detail_page = get_user_data_page(request.user.id, 'Camera', 'create')
        

        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                # Check if user has permission for feature
                if (any(product['default_product__product_name'] == 'Baggage Counting' and product['allowed_status'] for product in user_detail_page['product_allowed'])
                            and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
                        ):

                    company_detail_id = user_detail_page['company_detail']['id']
                    offline_uuids = request.data.get('offline_uuids', [])
                    offline_data = request.data.get('offline_data', [])
                    print(request.data)
                    # try:
                    # with transaction.atomic():
                    self.sync_offline_data(company_detail_id, offline_uuids, offline_data)

                    return Response({"status": "success", "message": "Synchronization successful"}, status=status.HTTP_200_OK)
                else:
                    return Response({"detail": "You don't have permission for this feature."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "You don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "Account validity has expired."}, status=status.HTTP_400_BAD_REQUEST)
        

        
    def sync_offline_data(self, company_detail_id, offline_uuids, offline_data):
        online_data = Camera.objects.filter(uuid__in=offline_uuids, company_detail_id=company_detail_id)
        # print(online_data,offline_uuids,offline_data)
        
        for online_instance in online_data:
            offline_instance_data = [data for data in offline_data if data['uuid'] == str(online_instance.uuid)]
            # print("yes2",online_data,offline_data,offline_instance_data['camera_working'],online_instance.camera_working)
            # print(offline_instance_data)
            if len(offline_instance_data) > 0:
                update_data =  Camera.objects.filter(id=online_instance.id).update(camera_name=offline_instance_data[0]['camera_name'],url_or_video=offline_instance_data[0]['url_or_video'],camera_type=offline_instance_data[0]['camera_type'],camera_working=offline_instance_data[0]['camera_working'])
                #,,date_time=offline_instance_data[0]['date_time'],camera_working=offline_instance_data[0]['camera_working']

                if offline_instance_data[0]['camera_working']==False and online_instance.camera_working:
                    # print("yes",online_data,offline_data,BusinessCameraDetail.objects.filter(uuid=offline_instance_data[0]['uuid']).values('uuid'),offline_instance_data[0]['camera_working'],online_instance.camera_working)
                    send_email_on_status_change(sender=Camera, instance=online_instance)
        
        new_uuids = set(offline_uuids) - set([str(data) for data in online_data.values_list('uuid', flat=True)])
        new_uuids = list(new_uuids)
        # print("sets",new_uuids,set(offline_uuids),set(online_data.values_list('uuid', flat=True)),[str(data) for data in online_data.values_list('uuid', flat=True)])
        for i in range(len(new_uuids)):
            new_instance_data = {
                'uuid': new_uuids[i],
                'company_detail_id': CompanyDetail.objects.get(id=company_detail_id),
                'camera_name': offline_data[i].get('camera_name', 'default_camera_name'),
                'url_or_video': offline_data[i].get('url_or_video', 'default_url_or_video'),
                'camera_type': offline_data[i].get('camera_type', 'IP Camera'),
                'date_time': offline_data[i].get('date_time', datetime.now()),
                'user_name': offline_data[i].get('user_name', 'user_email'),
                'platform_name': offline_data[i].get('platform_name', 'S8'),
                'camera_working': offline_data[i].get('camera_working', True),
                'camera_sequence_number': offline_data[i].get('camera_sequence_number', 1),
                'detection': offline_data[i].get('detection', True),
                'sites': Sites.objects.get(pk=offline_data[i].get('sites',5))
            }            
            Camera.objects.create(**new_instance_data)
            
        online_data = Camera.objects.filter(company_detail_id=company_detail_id)
        get_id_list_data = list(set([str(data) for data in online_data.values_list('uuid', flat=True)]) - set(offline_uuids))
        # print("get_id_list_data:",get_id_list_data)
        Camera.objects.filter(uuid__in=get_id_list_data,
                                            company_detail_id=company_detail_id)

    # def put(self, request, uuid, format=None):
    #     user_detail_page = get_user_data_page(request.user.id, 'Camera', 'update')
        
    #     if user_detail_page['company_detail']['plan_validity'] == True:
    #         AccessToPage = False
    #         if user_detail_page['permission'] != None:
    #             AccessToPage = True
    #         if AccessToPage == True:
    #             # Check if user has permission for feature
    #             if (any(product['default_product__product_name'] == 'Baggage Counting' and product['allowed_status'] for product in user_detail_page['product_allowed'])
    #                         and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
    #                     ):
                  
    #                 platForm= Camera.objects.get(uuid=uuid) 
    #                 get_data = request.data
    #                 get_data['company_detail_id'] = user_detail_page['company_detail']['id']
    #                 serializer = CameraSerializer(platForm, get_data)
                    
    #                 if serializer.is_valid():
    #                     serializer.save()
    #                     return Response(serializer.data, status=status.HTTP_201_CREATED)
    #                 else:
    #                     return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    #             else:
    #                 return Response({"detail": "You don't have permission for this feature."}, status=status.HTTP_400_BAD_REQUEST)
    #         else:
    #             return Response({"detail": "You don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
    #     else:
    #         return Response({"detail": "Account validity has expired."}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, uuid, format=None):
        user_detail_page = get_user_data_page(request.user.id, 'Camera', 'delete')
        
        
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                # Check if user has permission for feature
                if (any(product['default_product__product_name'] == 'Baggage Counting' and product['allowed_status'] for product in user_detail_page['product_allowed'])
                            and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
                        ):
                    platForm= Camera.objects.get(uuid=uuid)
                    platForm.delete()
                    return Response(status=status.HTTP_204_NO_CONTENT)
                else:
                    return Response({"detail": "You don't have permission for this feature."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "You don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "Account validity has expired."}, status=status.HTTP_400_BAD_REQUEST)


class FreightTrainCustomerDetailView(APIView):
    permission_classes = (IsAuthenticated,)
    
    def get(self, request, format=None):
        # Get query parameters
        limit = int(request.GET.get('limit', 10))
        offset = int(request.GET.get('offset', 0))
        
        user_detail_page = get_user_data_page(
            request.user.id, 'FreightTrainCustomerDetail', 'view')
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                # Check if user has permission for feature
                if (any(product['default_product__product_name'] == 'Baggage Counting' and product['allowed_status'] for product in user_detail_page['product_allowed'])
                            and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
                        ):
                    
                    f= Q(company_detail_id = user_detail_page['company_detail']['id'])
                    sites = Sites.objects.filter(company_detail_id=user_detail_page['company_detail']['id'],user=request.user.id).values('id')

                    site_id = None
                    if sites.exists():
                        site_id = sites[0]['id']
                        f &= Q(sites=site_id)

                    offline_insert = request.GET.get('offline_insert',None)
                    offline_update = request.GET.get('offline_update',None)

                    if offline_insert != '' and offline_insert != None:
                        f &= Q(offline_insert=offline_insert)
                    
                    if offline_update != '' and offline_update != None:
                        f &= Q(offline_update=offline_update)

                    platForms = FreightTrainCustomerDetail.objects.filter(f)[offset:limit+offset]
                    platForm_count = FreightTrainCustomerDetail.objects.filter(f).count()
                    
                    # Serialize data
                    serializer = FreightTrainCustomerDetailSerializer(platForms, many=True)
                    
                    # Return response
                    return Response({'count': platForm_count, 'results': serializer.data})
                else:
                    return Response({"detail": "You don't have permission for this feature."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "You don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "Account validity has expired."}, status=status.HTTP_400_BAD_REQUEST)

    def post(self, request, format=None):
        user_detail_page = get_user_data_page(request.user.id, 'FreightTrainCustomerDetail', 'create')
        

        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                # Check if user has permission for feature
                if (any(product['default_product__product_name'] == 'Baggage Counting' and product['allowed_status'] for product in user_detail_page['product_allowed'])
                            and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
                        ):
                    get_data = request.data

                    # platfrom_customer_detail_id = None
                    # platfrom_customer_uuid = request.data.get('platfrom_customer_uuid')

                    # if platfrom_customer_uuid is not None:
                    #     platfrom_customer_detail = PlatormCustomerDetail.objects.filter(uuid=platfrom_customer_uuid).first()
                    #     if platfrom_customer_detail:
                    #         platfrom_customer_detail_id = platfrom_customer_detail.id

                    get_data['company_detail_id'] = user_detail_page['company_detail']['id']
                    get_data['sites'] = user_detail_page['site']['id']
                    # get_data['platfrom_customer_detail'] = platfrom_customer_detail_id
                    serializer = FreightTrainCustomerDetailSerializer(data=get_data)
                    
                    if serializer.is_valid():
                        serializer.save()
                        return Response(serializer.data, status=status.HTTP_201_CREATED)
                    else:
                        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                else:
                    return Response({"detail": "You don't have permission for this feature."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "You don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "Account validity has expired."}, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, uuid, format=None):
        user_detail_page = get_user_data_page(request.user.id, 'FreightTrainCustomerDetail', 'update')
        
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                # Check if user has permission for feature
                if (any(product['default_product__product_name'] == 'Baggage Counting' and product['allowed_status'] for product in user_detail_page['product_allowed'])
                            and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
                        ):
                  
                    platForm= FreightTrainCustomerDetail.objects.get(uuid=uuid) 
                    get_data = request.data


                    # platfrom_customer_detail_id = None
                    # platfrom_customer_uuid = request.data.get('platfrom_customer_uuid')

                    # if platfrom_customer_uuid is not None:
                    #     platfrom_customer_detail = PlatormCustomerDetail.objects.filter(uuid=platfrom_customer_uuid).first()
                    #     if platfrom_customer_detail:
                    #         platfrom_customer_detail_id = platfrom_customer_detail.id

                    get_data['offline_update'] = False
                    get_data['company_detail_id'] = user_detail_page['company_detail']['id']
                    get_data['sites'] = user_detail_page['site']['id']
                    # get_data['platfrom_customer_detail'] = platfrom_customer_detail_id

                    serializer = FreightTrainCustomerDetailSerializer(platForm, get_data)
                    
                    if serializer.is_valid():
                        serializer.save()
                        return Response(serializer.data, status=status.HTTP_201_CREATED)
                    else:
                        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                else:
                    return Response({"detail": "You don't have permission for this feature."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "You don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "Account validity has expired."}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, uuid, format=None):
        user_detail_page = get_user_data_page(request.user.id, 'FreightTrainCustomerDetail', 'delete')
        
        
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                # Check if user has permission for feature
                if (any(product['default_product__product_name'] == 'Baggage Counting' and product['allowed_status'] for product in user_detail_page['product_allowed'])
                            and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
                        ):
                    platForm= FreightTrainCustomerDetail.objects.get(uuid=uuid)
                    platForm.delete()
                    return Response(status=status.HTTP_204_NO_CONTENT)
                else:
                    return Response({"detail": "You don't have permission for this feature."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "You don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "Account validity has expired."}, status=status.HTTP_400_BAD_REQUEST)
        

# DropDown
class PlatormCustomerDetailDropDownView(APIView):

    def get(self, request):
    
        company_detail_id = request.user.company_detail_id
      
        customer_name = PlatormCustomerDetail.objects.filter(company_detail_id=company_detail_id)
        customer_serializer = PlatormCustomerDetailListSerializer(customer_name, many=True)
        return Response(customer_serializer.data)
    

class DashboardData(APIView):
    permission_classes = (IsAuthenticated,)
    def get(self,request, format=None):
        user_detail_page = get_user_data_page(request.user.id, 'dashboard', 'view')
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                if (any(product['default_product__product_name'] == 'Dashboard' and product['allowed_status'] for product in user_detail_page['product_allowed'])
                        ):
                    
                    start_date = request.GET.get('start_datetime')
                    end_date = request.GET.get('end_datetime')
                    train_count = PlatFormTrainDetail.objects.filter(start_datetime__gte=start_date, end_datetime__lte=end_date,company_detail_id=user_detail_page['company_detail']['id']).count()
                    freight_box_count = FreightTrainBoxCountDetection.objects.filter(start_datetime__gte=start_date, end_datetime__lte=end_date,company_detail_id=user_detail_page['company_detail']['id']).count()
                    gate_count = GateCountDetection.objects.filter(start_datetime__gte=start_date, end_datetime__lte=end_date,company_detail_id=user_detail_page['company_detail']['id'], is_deleted = False).count()
                    camera_count = CameraCountDetection.objects.filter(start_datetime__gte=start_date, end_datetime__lte=end_date,company_detail_id=user_detail_page['company_detail']['id']).count()
                    active_camera_count = Camera.objects.filter(company_detail_id=user_detail_page['company_detail']['id'],camera_working=True).count()
                    deactive_camera_count = Camera.objects.filter(company_detail_id=user_detail_page['company_detail']['id'],camera_working=False).count()

                    results = {
                        "total_train_count": train_count,
                        "total_freight_box_count": freight_box_count,
                        "total_gate_count": gate_count,
                        "total_camera_count_count": camera_count,
                        "total_active_camera_count" : active_camera_count,
                        "total_deactive_camera_count": deactive_camera_count,
                        "company_detail_id":user_detail_page['company_detail']['id'],
                        "StartDateTime": start_date,
                        "EndDateTime": end_date
                        }
                    return JsonResponse(results, safe=False)
                else:
                    return Response({"detail": "You don't have permission for Dashboard."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "you don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
        

class OfflinUpdatePlatformCustomerView(APIView):
    permission_classes = (IsAuthenticated,)

    def put(self, request, uuid, format=None):
        user_detail_page = get_user_data_page(request.user.id, 'PlatormCustomerDetail', 'update')
        
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                # Check if user has permission for feature
                if (any(product['default_product__product_name'] == 'Baggage Counting' and product['allowed_status'] for product in user_detail_page['product_allowed'])
                            and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
                        ):
                  
                    platForm= PlatormCustomerDetail.objects.get(uuid=uuid) 
                    get_data = request.data
                    get_data['company_detail_id'] = user_detail_page['company_detail']['id']
                    get_data['sites'] = user_detail_page['site']['id']
                    serializer = PlatormCustomerDetailSerializer(platForm, get_data)
                    
                    if serializer.is_valid():
                        serializer.save()
                        return Response(serializer.data, status=status.HTTP_201_CREATED)
                    else:
                        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                else:
                    return Response({"detail": "You don't have permission for this feature."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "You don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "Account validity has expired."}, status=status.HTTP_400_BAD_REQUEST)
        

class OfflineUpdateFreightTrainCustomerView(APIView):
    permission_classes = (IsAuthenticated,)

    def put(self, request, uuid, format=None):
        user_detail_page = get_user_data_page(request.user.id, 'FreightTrainCustomerDetail', 'update')
        
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                # Check if user has permission for feature
                if (any(product['default_product__product_name'] == 'Baggage Counting' and product['allowed_status'] for product in user_detail_page['product_allowed'])
                            and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
                        ):
                    
                    platForm= FreightTrainCustomerDetail.objects.get(uuid=uuid) 
                    get_data = request.data
                    
                    get_data['company_detail_id'] = user_detail_page['company_detail']['id']
                    get_data['sites'] = user_detail_page['site']['id']
                    # get_data['platfrom_customer_detail'] = platfrom_customer_detail_id

                    serializer = FreightTrainCustomerDetailSerializer(platForm, get_data)
                    
                    if serializer.is_valid():
                        serializer.save()
                        return Response(serializer.data, status=status.HTTP_201_CREATED)
                    else:
                        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                else:
                    return Response({"detail": "You don't have permission for this feature."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "You don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "Account validity has expired."}, status=status.HTTP_400_BAD_REQUEST)