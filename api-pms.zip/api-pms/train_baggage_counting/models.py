from django.db import models
import uuid
import django
# Create your models here.
from account.models import Sites,CompanyDetail,User, SendMailNotification, Roles


class PlatormCustomerDetail(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    platform_name = models.CharField(max_length=50)
    customer_name = models.CharField(max_length=80)
    number_of_freight_train_boxes = models.IntegerField()
    start_datetime = models.DateTimeField(default=django.utils.timezone.now)
    end_datetime = models.DateTimeField(default=django.utils.timezone.now)
    sites = models.ForeignKey(Sites,on_delete=models.PROTECT, blank=True, null=True)
    company_detail_id = models.ForeignKey(CompanyDetail,on_delete=models.PROTECT)
    offline_insert = models.BooleanField(default=False)
    offline_update = models.BooleanField(default=False)

class FreightTrainCustomerDetail(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    freight_train_number = models.CharField(max_length=50)
    material_type = models.CharField(max_length=50)
    train_freight_sequence_number = models.IntegerField(blank=True, null=True)
    platfrom_customer_detail = models.ForeignKey(PlatormCustomerDetail,on_delete=models.PROTECT)
    sites = models.ForeignKey(Sites,on_delete=models.PROTECT, blank=True, null=True)
    company_detail_id = models.ForeignKey(CompanyDetail,on_delete=models.PROTECT)
    offline_insert = models.BooleanField(default=False)
    offline_update = models.BooleanField(default=False)

class PlatFormDetail(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    name = models.CharField(max_length=20)
    train_presence = models.BooleanField()
    sites = models.ForeignKey(Sites,on_delete=models.PROTECT)
    company_detail_id = models.ForeignKey(CompanyDetail,on_delete=models.PROTECT)

class PlatFormTrainDetail(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    count_gunnybag = models.IntegerField()
    start_datetime = models.DateTimeField(default=django.utils.timezone.now)
    end_datetime = models.DateTimeField(default=django.utils.timezone.now)
    platform_name = models.CharField(max_length=20)
    platfrom_customer_detail = models.ForeignKey(PlatormCustomerDetail,on_delete=models.PROTECT, blank=True, null=True)
    sites = models.ForeignKey(Sites,on_delete=models.PROTECT)
    company_detail_id = models.ForeignKey(CompanyDetail,on_delete=models.PROTECT)

class Camera(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    url_or_video = models.CharField(max_length=255)
    camera_type = models.CharField(max_length=50)
    camera_name = models.CharField(max_length=50)
    user_name = models.CharField(max_length=50)
    date_time = models.DateTimeField(default=django.utils.timezone.now)
    camera_working = models.BooleanField()
    platform_name = models.CharField(max_length=50)
    camera_sequence_number = models.IntegerField()
    detection = models.BooleanField()
    sites = models.ForeignKey(Sites,on_delete=models.PROTECT)
    company_detail_id = models.ForeignKey(CompanyDetail,on_delete=models.PROTECT)


# class FreightTrainNumberDetail(models.Model):
#     uuid = models.UUIDField(default = uuid.uuid4,editable = False)
#     freight_train_number = models.IntegerField()
#     date_time = models.DateTimeField(default=django.utils.timezone.now)
#     camera_name= models.CharField(max_length=50)
#     platform_name = models.CharField(max_length=50) 
#     camera_sequence_number = models.IntegerField()
#     sites = models.ForeignKey(Sites,on_delete=models.PROTECT)
#     company_detail_id = models.ForeignKey(CompanyDetail,on_delete=models.PROTECT)

    

class GateCountDetection(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    count_of_gunnybag = models.IntegerField()
    start_datetime = models.DateTimeField(default=django.utils.timezone.now)
    end_datetime = models.DateTimeField(default=django.utils.timezone.now)
    camera_name= models.CharField(max_length=50)
    platform_name = models.CharField(max_length=50)
    camera_sequence = models.IntegerField()
    platform_train_detail = models.ForeignKey(PlatFormTrainDetail,on_delete=models.PROTECT, blank=True, null=True)     
    destuffing = models.IntegerField()
    gate_name = models.CharField(max_length=50, blank=True, null=True)
    platfrom_customer_detail = models.ForeignKey(PlatormCustomerDetail,on_delete=models.PROTECT, blank=True, null=True)
    is_deleted = models.BooleanField(default=False)
    sites = models.ForeignKey(Sites,on_delete=models.PROTECT)
    company_detail_id = models.ForeignKey(CompanyDetail,on_delete=models.PROTECT)

class FreightTrainBoxCountDetection(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    count_of_gunnybag = models.IntegerField()
    start_datetime = models.DateTimeField(default=django.utils.timezone.now)
    end_datetime = models.DateTimeField(default=django.utils.timezone.now)
    freight_train_box_name = models.CharField(max_length=50) 
    platform_name = models.CharField(max_length=50)
    platfrom_customer_detail = models.ForeignKey(PlatormCustomerDetail,on_delete=models.PROTECT, blank=True, null=True)
    freight_train_customer_detail = models.ForeignKey(FreightTrainCustomerDetail,on_delete=models.PROTECT, blank=True, null=True)
    freight_train_number = models.CharField(max_length=50, blank=True, null=True) 
    sites = models.ForeignKey(Sites,on_delete=models.PROTECT, blank=True, null=True)
    company_detail_id = models.ForeignKey(CompanyDetail,on_delete=models.PROTECT)

class FreightCameraDetail(models.Model):
    camera_name = models.CharField(max_length=50)  # (Data Type Json)
    camera_sequence_number = models.IntegerField()
    freight_train_box_detail = models.ForeignKey(FreightTrainBoxCountDetection,on_delete=models.PROTECT)


class CameraCountDetection(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    count_of_gunnybag = models.IntegerField()
    start_datetime = models.DateTimeField(default=django.utils.timezone.now)
    end_datetime = models.DateTimeField(default=django.utils.timezone.now)
    camera_name = models.CharField(max_length=50)  # (Data Type Json)
    camera_sequence_number = models.IntegerField()
    platform_name = models.CharField(max_length=50)
    platfrom_customer_detail = models.ForeignKey(PlatormCustomerDetail,on_delete=models.PROTECT, blank=True, null=True)
    sites = models.ForeignKey(Sites,on_delete=models.PROTECT)
    company_detail_id = models.ForeignKey(CompanyDetail,on_delete=models.PROTECT)


# class AddCustomerDetail(models.Model):
#     uuid = models.UUIDField(default = uuid.uuid4,editable = False)
#     company_name = models.CharField(max_length=80)
#     company_email = models.EmailField(verbose_name='email address',max_length=255,unique=True,)
#     role = models.ForeignKey(Roles, on_delete=models.CASCADE)
#     company_detail_id = models.ForeignKey(CompanyDetail, on_delete=models.CASCADE)


 













    
    






