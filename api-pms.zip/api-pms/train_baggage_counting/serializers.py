from rest_framework.serializers import ModelSerializer
from .models import *
from rest_framework import serializers
from account.serializers import UserSerializer,SitesSerializer


class PlatormCustomerDetailSerializer(ModelSerializer):
    uuid = serializers.UUIDField(default=uuid.uuid4)
    class Meta:
        model = PlatormCustomerDetail
        fields ='__all__'

    def create(self, validated_data):
        # Check if the UUID already exists
        uuid_exists = PlatormCustomerDetail.objects.filter(uuid=validated_data.get('uuid')).exists()
        if uuid_exists:
            raise serializers.ValidationError("UUID must be unique.")

        # Create the instance
        instance = PlatormCustomerDetail.objects.create(**validated_data)
        return instance


class PlatFormDetailSerializer(ModelSerializer):
    uuid = serializers.UUIDField(default=uuid.uuid4)
    site_name = serializers.CharField(source='sites.site_name', read_only=True)
    class Meta:
        model = PlatFormDetail
        fields ='__all__'
    def create(self, validated_data):
        # Check if the UUID already exists
        uuid_exists = PlatFormDetail.objects.filter(uuid=validated_data.get('uuid')).exists()
        if uuid_exists:
            raise serializers.ValidationError("UUID must be unique.")

        # Create the instance
        instance = PlatFormDetail.objects.create(**validated_data)
        return instance
    

class PlatFormTrainDetailSerializer(ModelSerializer):          
    #site_name = serializers.CharField(source='sites.site_name', read_only=True)
    customer_name = serializers.CharField(source='platfrom_customer_detail.customer_name', read_only=True)
    uuid = serializers.UUIDField(default=uuid.uuid4)
    class Meta:
        model = PlatFormTrainDetail
        fields=["id","uuid","count_gunnybag","start_datetime","end_datetime","platform_name","customer_name","platfrom_customer_detail","sites","company_detail_id"]
        # def create(self, validate_data):
        #     if PlatFormTrainDetail.objects.filter(count_of_gunnybag=validate_data['count_of_gunnybag'], company_detail_id=validate_data['company_detail_id']).exists():
        #         raise serializers.ValidationError(
        #             {'count_of_bag_number': 'count_of_gunnybag are already exist.'})
        #     return PlatFormTrainDetailSerializer.objects.create(**validate_data)

        # def update(self, instance, validate_data):
        #     if PlatFormTrainDetail.objects.filter(count_of_gunnybag=validate_data['count_of_gunnybag'], company_detail_id=validate_data['company_detail_id']).exclude(id=instance.pk).exists():
        #         raise serializers.ValidationError(
        #             {'container_number': 'count_of_gunnybag are already exist.'})
        #     return super().update(instance, validate_data)
    def create(self, validated_data):
        # Check if the UUID already exists
        uuid_exists = PlatFormTrainDetail.objects.filter(uuid=validated_data.get('uuid')).exists()
        if uuid_exists:
            raise serializers.ValidationError("UUID must be unique.")

        # Create the instance
        instance = PlatFormTrainDetail.objects.create(**validated_data)
        return instance
    
   
class CameraSerializer(ModelSerializer):
    site_name = serializers.CharField(source='sites.site_name', read_only=True)
    uuid = serializers.UUIDField(default=uuid.uuid4)
    class Meta:
        model = Camera
        fields ='__all__'
    def create(self, validated_data):
        # Check if the UUID already exists
        uuid_exists = Camera.objects.filter(uuid=validated_data.get('uuid')).exists()
        if uuid_exists:
            raise serializers.ValidationError("UUID must be unique.")

        # Create the instance
        instance = Camera.objects.create(**validated_data)
        return instance

# class FreightTrainNumberDetailSerializer(ModelSerializer):
#     #site_name = serializers.CharField(source='sites.site_name', read_only=True)
#     uuid = serializers.UUIDField(default=uuid.uuid4)

#     class Meta:
#         model = FreightTrainNumberDetail
#         fields ='__all__'

#     def create(self, validated_data):
#         # Check if the UUID already exists
#         uuid_exists = FreightTrainNumberDetail.objects.filter(uuid=validated_data.get('uuid')).exists()
#         if uuid_exists:
#             raise serializers.ValidationError("UUID must be unique.")

#         # Create the instance
#         instance = FreightTrainNumberDetail.objects.create(**validated_data)
#         return instance

class GateCountDetectionSerializer(ModelSerializer):
    #site_name = serializers.CharField(source='sites.site_name', read_only=True)
    platFormTrainDetail = serializers.CharField(source='platFormTrainDetail.id', read_only=True)
    uuid = serializers.UUIDField(default=uuid.uuid4)

    class Meta:
        model = GateCountDetection
        fields ='__all__'

    def create(self, validated_data):
        # Check if the UUID already exists
        uuid_exists = GateCountDetection.objects.filter(uuid=validated_data.get('uuid')).exists()
        if uuid_exists:
            raise serializers.ValidationError("UUID must be unique.")

        # Create the instance
        instance = GateCountDetection.objects.create(**validated_data)
        return instance

class FreightTrainBoxCountDetectionSerializer(ModelSerializer):
    uuid = serializers.UUIDField(default=uuid.uuid4)
    class Meta:
        model = FreightTrainBoxCountDetection
        fields ='__all__'

    def create(self, validated_data):
        # Check if the UUID already exists
        uuid_exists = FreightTrainBoxCountDetection.objects.filter(uuid=validated_data.get('uuid')).exists()
        if uuid_exists:
            raise serializers.ValidationError("UUID must be unique.")

        # Create the instance
        instance = FreightTrainBoxCountDetection.objects.create(**validated_data)
        return instance

class CameraCountDetectionSerializer(ModelSerializer):
    uuid = serializers.UUIDField(default=uuid.uuid4)
    #site_name = serializers.CharField(source='sites.site_name', read_only=True)
    class Meta:
        model = CameraCountDetection
        fields = ["id","uuid","count_of_gunnybag","start_datetime","end_datetime","camera_name","camera_sequence_number","platform_name","sites","company_detail_id"]
    def create(self, validate_data):
        # Check if the UUID already exists
        uuid_exists = CameraCountDetection.objects.filter(uuid=validate_data.get('uuid')).exists()
        if uuid_exists:
            raise serializers.ValidationError("UUID must be unique.")

        # if CameraCountDetection.objects.filter(count_of_gunnybag=validate_data['count_of_gunnybag'], company_detail_id=validate_data['company_detail_id']).exists():
        #     raise serializers.ValidationError(
        #         {'count_of_bag_number': 'count_of_gunnybag are already exist.'})
        return CameraCountDetection.objects.create(**validate_data)

    # def update(self, instance, validate_data):
    #     if CameraCountDetection.objects.filter(count_of_gunnybag=validate_data['count_of_gunnybag'], company_detail_id=validate_data['company_detail_id']).exclude(id=instance.pk).exists():
    #         raise serializers.ValidationError(
    #             {'container_number': 'count_of_gunnybag are already exist.'})
    #     return super().update(instance, validate_data)
 

class FreightTrainCustomerDetailSerializer(ModelSerializer):
    uuid = serializers.UUIDField(default=uuid.uuid4)
    customer_name = serializers.CharField(source='platfrom_customer_detail.customer_name', read_only=True)
    class Meta:
        model = FreightTrainCustomerDetail
        fields ='__all__'

    def create(self, validated_data):
        # Check if the UUID already exists
        uuid_exists = FreightTrainCustomerDetail.objects.filter(uuid=validated_data.get('uuid')).exists()
        if uuid_exists:
            raise serializers.ValidationError("UUID must be unique.")
        
        freight_train_number_exists = FreightTrainCustomerDetail.objects.filter(freight_train_number=validated_data.get('freight_train_number')).exists()
        if freight_train_number_exists:
            raise serializers.ValidationError("Freight Train Number already exist.")
        
        train_freight_sequence_number_exists = FreightTrainCustomerDetail.objects.filter(train_freight_sequence_number=validated_data.get('train_freight_sequence_number')).exists()
        if train_freight_sequence_number_exists:
            raise serializers.ValidationError("Freight Train Box Sequence already exist.")

        # Create the instance
        instance = FreightTrainCustomerDetail.objects.create(**validated_data)
        return instance
    
    def update(self, instance, validate_data):
        freight_train_number_exists = FreightTrainCustomerDetail.objects.filter(freight_train_number=validate_data.get('freight_train_number')).exclude(id=instance.pk).exists()
        if freight_train_number_exists:
            raise serializers.ValidationError("Freight Train Number already exist.")
        
        train_freight_sequence_number_exists = FreightTrainCustomerDetail.objects.filter(train_freight_sequence_number=validate_data.get('train_freight_sequence_number')).exclude(id=instance.pk).exists()
        if train_freight_sequence_number_exists:
            raise serializers.ValidationError("Freight Train Box Sequence already exist.")
        return super().update(instance, validate_data)

class PlatormCustomerDetailListSerializer(ModelSerializer):
  
    class Meta:
        model = PlatormCustomerDetail
        fields =["id", "customer_name"]


class FreightCameraDetailSerializer(ModelSerializer):
  
    class Meta:
        model = FreightCameraDetail
        fields ='__all__'

