from django.apps import AppConfig


class TrainBaggageCountingConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "train_baggage_counting"
