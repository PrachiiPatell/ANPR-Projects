import urllib3
import time

def call_api():
    try:
        URL = "https://anprsiplapi2.site/account/notify-admin-user/"
        http = urllib3.PoolManager(cert_reqs='CERT_NONE')
        resp = http.request(
            'GET', URL, timeout=10.0,headers={'Content-Type': 'application/json'})
        if resp.status == 200:
            return resp
        else:
            return resp
    except Exception as e:
        print(e)
def main():
    while True:
        print("Background service is running...")
        call_api()
        time.sleep(300)

if __name__ == "__main__":
    main()