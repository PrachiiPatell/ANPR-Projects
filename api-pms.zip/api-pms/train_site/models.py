from django.db import models
import uuid
import django
from account.models import Sites,CompanyDetail,User
# Create your models here.

class TrainSiteDetected(models.Model):
    uuid = models.UUIDField(default=uuid.uuid4,editable=False)
    datetime = models.DateTimeField(default=django.utils.timezone.now)
    container_presence = models.BooleanField(blank=True, null=True)
    group_name = models.CharField(max_length=30)
    sites = models.ForeignKey(Sites,on_delete=models.PROTECT)
    company_detail_id = models.ForeignKey(CompanyDetail,on_delete=models.PROTECT)
    created_by = models.ForeignKey(User,on_delete=models.PROTECT,related_name='created_by_%(class)s_related',blank=True,null=True)
    created_datetime = models.DateTimeField(blank=True,null=True)
    updated_by = models.ForeignKey(User,on_delete=models.PROTECT,related_name='updated_by_%(class)s_related',blank=True,null=True)
    updated_datetime = models.DateTimeField(blank=True,null=True)

class TrainSiteTriggeredWagon(models.Model):
    uuid = models.UUIDField(default=uuid.uuid4,editable=False)
    wagon_number = models.CharField(max_length=30,blank=True, null=True)
    reason_to_trigger = models.CharField(max_length=50)
    date_and_time = models.DateTimeField(default=django.utils.timezone.now)
    company_detail_id = models.ForeignKey(CompanyDetail,on_delete=models.PROTECT)
    created_by = models.ForeignKey(User,on_delete=models.PROTECT,related_name='created_by_%(class)s_related',blank=True,null=True)
    created_datetime = models.DateTimeField(blank=True,null=True)
    updated_by = models.ForeignKey(User,on_delete=models.PROTECT,related_name='updated_by_%(class)s_related',blank=True,null=True)
    updated_datetime = models.DateTimeField(blank=True,null=True)


class TrainSiteTriggeredContainer(models.Model):
    uuid = models.UUIDField(default=uuid.uuid4,editable=False)
    container_number = models.CharField(max_length=30,blank=True, null=True)
    reason_to_trigger = models.CharField(max_length=50)
    date_and_time = models.DateTimeField(default=django.utils.timezone.now)
    company_detail_id = models.ForeignKey(CompanyDetail,on_delete=models.PROTECT)
    created_by = models.ForeignKey(User,on_delete=models.PROTECT,related_name='created_by_%(class)s_related',blank=True,null=True)
    created_datetime = models.DateTimeField(blank=True,null=True)
    updated_by = models.ForeignKey(User,on_delete=models.PROTECT,related_name='updated_by_%(class)s_related',blank=True,null=True)
    updated_datetime = models.DateTimeField(blank=True,null=True)

class TrainSiteDetectedWagonDetail(models.Model):
    uuid = models.UUIDField(default=uuid.uuid4,editable=False)
    wagon_number = models.CharField(max_length=30,blank=True, null=True)
    wagon_number_image = models.ImageField(upload_to='port_management_system/wagon_number_image/',blank=True,null=True,max_length=500)
    avg_confidence_wagon_number = models.FloatField(blank=True,null=True)
    triggered = models.BooleanField(blank=True, null=True)
    triggered_wagon = models.ForeignKey(TrainSiteTriggeredWagon,on_delete=models.PROTECT, null=True)
    camera_name = models.CharField(max_length=30)
    camera_view_name = models.CharField(max_length=30)
    camera_group_name = models.CharField(max_length=30)
    detected = models.ForeignKey(TrainSiteDetected,related_name='detected_wagon',on_delete=models.PROTECT)
    created_by = models.ForeignKey(User,on_delete=models.PROTECT,related_name='created_by_%(class)s_related',blank=True,null=True)
    created_datetime = models.DateTimeField(blank=True,null=True)
    updated_by = models.ForeignKey(User,on_delete=models.PROTECT,related_name='updated_by_%(class)s_related',blank=True,null=True)
    updated_datetime = models.DateTimeField(blank=True,null=True)

class TrainSiteDetectedContainerDetail(models.Model):
    uuid = models.UUIDField(default=uuid.uuid4,editable=False)
    container_number = models.CharField(max_length=30,blank=True, null=True)
    iso_code = models.CharField(max_length=5,blank=True, null=True)
    container_number_image = models.ImageField(upload_to='port_management_system/container_number_image/',blank=True,null=True,max_length=500)
    avg_confidence_container_number = models.FloatField(blank=True, null=True)
    triggered = models.BooleanField(blank=True, null=True)
    triggered_container = models.ForeignKey(TrainSiteTriggeredContainer,on_delete=models.PROTECT, null=True)
    seal_presence = models.BooleanField(blank=True, null=True)
    seal_presence_count = models.IntegerField(default=0)
    length = models.FloatField(default=0.0,null=True,blank=True)
    height = models.FloatField(default=0.0,null=True,blank=True)
    width = models.FloatField(default=0.0,null=True,blank=True)
    hazard_sign_presence = models.BooleanField(blank=True,null=True)
    hazard_sign_image = models.ImageField(upload_to='port_management_system/hazard_sign_image/',blank=True,null=True,max_length=500)
    camera_name = models.CharField(max_length=30)
    camera_view_name = models.CharField(max_length=30)
    camera_group_name = models.CharField(max_length=30)
    detected = models.ForeignKey(TrainSiteDetected,related_name='detected_container',on_delete=models.PROTECT)
    created_by = models.ForeignKey(User,on_delete=models.PROTECT,related_name='created_by_%(class)s_related',blank=True,null=True)
    created_datetime = models.DateTimeField(blank=True,null=True)
    updated_by = models.ForeignKey(User,on_delete=models.PROTECT,related_name='updated_by_%(class)s_related',blank=True,null=True)
    updated_datetime = models.DateTimeField(blank=True,null=True)


class TrainSiteDetectedSealImage(models.Model):
    uuid = models.UUIDField(default=uuid.uuid4,editable=False)
    seal_image = models.ImageField(upload_to='port_management_system/seal_area_image/',blank=True,null=True,max_length=500)
    seal_presence = models.BooleanField(default=False,blank=True,null=True)
    avg_confidence_seal_presence = models.FloatField(blank=True, null=True)
    detected_container_detail = models.ForeignKey(TrainSiteDetectedContainerDetail,related_name='detected_seal', on_delete=models.PROTECT)


class TrainSiteDetectedFrameImage(models.Model):
    uuid = models.UUIDField(default=uuid.uuid4,editable=False)
    frame_image = models.ImageField(upload_to='port_management_system/frame_image/',blank=True,null=True,max_length=500)
    damage_found = models.BooleanField(blank=True,null=True)
    camera_name = models.CharField(max_length=30)
    camera_view_name = models.CharField(max_length=30)
    camera_group_name = models.CharField(max_length=30)
    detected = models.ForeignKey(TrainSiteDetected,related_name='detected_frame', on_delete=models.PROTECT)

class TrainSiteDetectedDamage(models.Model):
    uuid = models.UUIDField(default=uuid.uuid4,editable=False)
    damage_image = models.ImageField(upload_to='port_management_system/damage_image/',blank=True,null=True,max_length=500)
    avg_confidence_damage_presence = models.FloatField(blank=True, null=True)
    damage_type = models.CharField(max_length=30)
    detected_frame_image_detail = models.ForeignKey(TrainSiteDetectedFrameImage,related_name='detected_damage', on_delete=models.PROTECT,null=True)



class TrainSitePartiallyDetected(models.Model):
    uuid = models.UUIDField(default=uuid.uuid4,editable=False)
    datetime = models.DateTimeField(default=django.utils.timezone.now)
    container_presence = models.BooleanField(blank=True, null=True)
    group_name = models.CharField(max_length=30)
    sites = models.ForeignKey(Sites,on_delete=models.PROTECT)
    company_detail_id = models.ForeignKey(CompanyDetail,on_delete=models.PROTECT)
    created_by = models.ForeignKey(User,on_delete=models.PROTECT,related_name='created_by_%(class)s_related',blank=True,null=True)
    created_datetime = models.DateTimeField(blank=True,null=True)
    updated_by = models.ForeignKey(User,on_delete=models.PROTECT,related_name='updated_by_%(class)s_related',blank=True,null=True)
    updated_datetime = models.DateTimeField(blank=True,null=True)


class TrainSitePartiallyDetectedWagonDetail(models.Model):
    uuid = models.UUIDField(default=uuid.uuid4,editable=False)
    wagon_number = models.CharField(max_length=30,blank=True, null=True)
    wagon_number_image = models.ImageField(upload_to='port_management_system/wagon_number_image/',blank=True,null=True,max_length=500)
    avg_confidence_wagon_number = models.FloatField(blank=True,null=True)
    camera_name = models.CharField(max_length=30)
    camera_view_name = models.CharField(max_length=30)
    camera_group_name = models.CharField(max_length=30)
    partially_detected = models.ForeignKey(TrainSitePartiallyDetected,related_name='partially_detected_wagon',on_delete=models.PROTECT)
    created_by = models.ForeignKey(User,on_delete=models.PROTECT,related_name='created_by_%(class)s_related',blank=True,null=True)
    created_datetime = models.DateTimeField(blank=True,null=True)
    updated_by = models.ForeignKey(User,on_delete=models.PROTECT,related_name='updated_by_%(class)s_related',blank=True,null=True)
    updated_datetime = models.DateTimeField(blank=True,null=True)

class TrainSitePartiallyDetectedContainerDetail(models.Model):
    uuid = models.UUIDField(default=uuid.uuid4,editable=False)
    container_number = models.CharField(max_length=30,blank=True, null=True)
    iso_code = models.CharField(max_length=5,blank=True, null=True)
    container_number_image = models.ImageField(upload_to='port_management_system/container_number_image/',blank=True,null=True,max_length=500)
    avg_confidence_container_number = models.FloatField(blank=True, null=True)
    seal_presence = models.BooleanField(blank=True, null=True)
    seal_presence_count = models.IntegerField(default=0)
    length = models.FloatField(default=0.0,null=True,blank=True)
    height = models.FloatField(default=0.0,null=True,blank=True)
    width = models.FloatField(default=0.0,null=True,blank=True)
    hazard_sign_presence = models.BooleanField(blank=True,null=True)
    hazard_sign_image = models.ImageField(upload_to='port_management_system/hazard_sign_image/',blank=True,null=True,max_length=500)
    datetime = models.DateTimeField(default=django.utils.timezone.now)
    camera_name = models.CharField(max_length=30)
    camera_view_name = models.CharField(max_length=30)
    camera_group_name = models.CharField(max_length=30)
    partially_detected = models.ForeignKey(TrainSitePartiallyDetected,related_name='partially_detected_container',on_delete=models.PROTECT)
    created_by = models.ForeignKey(User,on_delete=models.PROTECT,related_name='created_by_%(class)s_related',blank=True,null=True)
    created_datetime = models.DateTimeField(blank=True,null=True)
    updated_by = models.ForeignKey(User,on_delete=models.PROTECT,related_name='updated_by_%(class)s_related',blank=True,null=True)
    updated_datetime = models.DateTimeField(blank=True,null=True)


class TrainSitePartiallyDetectedSealImage(models.Model):
    uuid = models.UUIDField(default=uuid.uuid4,editable=False)
    seal_image = models.ImageField(upload_to='port_management_system/seal_area_image/',blank=True,null=True,max_length=500)
    seal_presence = models.BooleanField(default=False,blank=True,null=True)
    avg_confidence_seal_presence = models.FloatField(blank=True, null=True)
    partially_detected_container_detail = models.ForeignKey(TrainSitePartiallyDetectedContainerDetail,related_name='partially_detected_seal', on_delete=models.PROTECT)


class TrainSitePartiallyDetectedFrameImage(models.Model):
    uuid = models.UUIDField(default=uuid.uuid4,editable=False)
    frame_image = models.ImageField(upload_to='port_management_system/frame_image/',blank=True,null=True,max_length=500)
    damage_found = models.BooleanField(blank=True,null=True)
    camera_name = models.CharField(max_length=30)
    camera_view_name = models.CharField(max_length=30)
    camera_group_name = models.CharField(max_length=30)
    partially_detected = models.ForeignKey(TrainSitePartiallyDetected,related_name='partially_detected_frame', on_delete=models.PROTECT)



class TrainSitePartiallyDetectedDamage(models.Model):
    uuid = models.UUIDField(default=uuid.uuid4,editable=False)
    damage_image = models.ImageField(upload_to='port_management_system/damage_image/',blank=True,null=True,max_length=500)
    avg_confidence_damage_presence = models.FloatField(blank=True, null=True)
    damage_type = models.CharField(max_length=30)
    partially_detected_frame_image_detail = models.ForeignKey(TrainSitePartiallyDetectedFrameImage,related_name='partially_detected_damage', on_delete=models.PROTECT,null=True)



#----------------------------------


# class TrainSitePartiallyDetected(models.Model):
#     uuid = models.UUIDField(default=uuid.uuid4,editable=False)
#     datetime = models.DateTimeField(default=django.utils.timezone.now)
#     container_presence = models.BooleanField(blank=True, null=True)
#     group_name = models.CharField(max_length=30)
#     sites = models.ForeignKey(Sites,on_delete=models.PROTECT)
#     company_detail_id = models.ForeignKey(CompanyDetail,on_delete=models.PROTECT)
#     created_by = models.ForeignKey(User,on_delete=models.PROTECT,related_name='created_by_%(class)s_related',blank=True,null=True)
#     created_datetime = models.DateTimeField(blank=True,null=True)
#     updated_by = models.ForeignKey(User,on_delete=models.PROTECT,related_name='updated_by_%(class)s_related',blank=True,null=True)
#     updated_datetime = models.DateTimeField(blank=True,null=True)


# class TrainSitePartiallyDetected(models.Model):
#     uuid = models.UUIDField(default=uuid.uuid4,editable=False)
#     container_number = models.CharField(max_length=30,blank=True, null=True)
#     iso_code = models.CharField(max_length=5)
#     container_number_image = models.TextField(blank=True, null=True)
#     wagon_number = models.CharField(max_length=30,blank=True, null=True)
#     wagon_number_image = models.TextField(blank=True, null=True)
#     seal_presence = models.BooleanField()
#     seal_presence_count = models.IntegerField()
#     length = models.IntegerField()
#     height = models.IntegerField()
#     width = models.IntegerField()
#     hazard_sign_presence = models.BooleanField()
#     hazard_sign_image = models.TextField(blank=True, null=True)
#     datetime = models.DateTimeField(default=django.utils.timezone.now)
#     camera_name = models.CharField(max_length=15)
#     sites = models.ForeignKey(Sites,on_delete=models.PROTECT)
#     company_detail_id = models.ForeignKey(CompanyDetail,on_delete=models.PROTECT)
#     created_by = models.ForeignKey(User,on_delete=models.PROTECT,related_name='created_by_%(class)s_related',blank=True,null=True)
#     created_datetime = models.DateTimeField(blank=True,null=True)
#     updated_by = models.ForeignKey(User,on_delete=models.PROTECT,related_name='updated_by_%(class)s_related',blank=True,null=True)
#     updated_datetime = models.DateTimeField(blank=True,null=True)


# class TrainSitePartiallyDetectedSealImage(models.Model):
#     uuid = models.UUIDField(default=uuid.uuid4,editable=False)
#     seal_image = models.TextField()
#     partially_detected = models.ForeignKey(TrainSitePartiallyDetected,related_name='partially_detected_seal', on_delete=models.PROTECT)


# class TrainSitePartiallyDetectedFrameImage(models.Model):
#     uuid = models.UUIDField(default=uuid.uuid4,editable=False)
#     frame_image = models.TextField()
#     partially_detected = models.ForeignKey(TrainSitePartiallyDetected,related_name='partially_detected_frame', on_delete=models.PROTECT)
#     image_type = models.CharField(max_length=15)

