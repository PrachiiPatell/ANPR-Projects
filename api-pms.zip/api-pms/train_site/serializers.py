from rest_framework.serializers import ModelSerializer
from rest_framework.validators import UniqueValidator
from django.contrib.auth.password_validation import validate_password
from .models import *
from rest_framework import serializers

class TrainSiteTriggeredWagonSerializer(serializers.ModelSerializer):
    class Meta:
        model = TrainSiteTriggeredWagon
        fields = ['id','wagon_number','reason_to_trigger','date_and_time','company_detail_id']
    def create(self, validate_data):
        if TrainSiteTriggeredWagon.objects.filter(wagon_number=validate_data['wagon_number'], company_detail_id=validate_data['company_detail_id']).exists():
            raise serializers.ValidationError(
                {'wagon_number': 'Wagon number are already exist.'})
        return TrainSiteTriggeredWagon.objects.create(**validate_data)

    def update(self, instance, validate_data):
        if TrainSiteTriggeredWagon.objects.filter(wagon_number=validate_data['wagon_number'], company_detail_id=validate_data['company_detail_id']).exclude(id=instance.pk).exists():
            raise serializers.ValidationError(
                {'wagon_number': 'Wagon number are already exist.'})
        return super().update(instance, validate_data)

class TrainSiteTriggeredContainerSerializer(serializers.ModelSerializer):
    class Meta:
        model = TrainSiteTriggeredContainer
        fields = ['id','container_number','reason_to_trigger','date_and_time','company_detail_id']
    def create(self, validate_data):
        if TrainSiteTriggeredContainer.objects.filter(container_number=validate_data['container_number'], company_detail_id=validate_data['company_detail_id']).exists():
            raise serializers.ValidationError(
                {'container_number': 'Container number are already exist.'})
        return TrainSiteTriggeredContainer.objects.create(**validate_data)

    def update(self, instance, validate_data):
        if TrainSiteTriggeredContainer.objects.filter(container_number=validate_data['container_number'], company_detail_id=validate_data['company_detail_id']).exclude(id=instance.pk).exists():
            raise serializers.ValidationError(
                {'container_number': 'Container number are already exist.'})
        return super().update(instance, validate_data)

class TrainSiteDetectedWagonDetailSerializer(serializers.ModelSerializer):
    wagon_number_image = serializers.CharField(required=False,allow_null=True)
    class Meta:
        model = TrainSiteDetectedWagonDetail
        fields = ['id','uuid','wagon_number','wagon_number_image','avg_confidence_wagon_number','triggered','triggered_wagon','camera_name','camera_view_name','camera_group_name']


class TrainSiteDetectedSealImageSerializer(ModelSerializer):
    seal_image = serializers.CharField()
    class Meta:
        model = TrainSiteDetectedSealImage
        fields = ['id','uuid','seal_image','seal_presence','avg_confidence_seal_presence']

class TrainSiteDetectedContainerDetailSerializer(serializers.ModelSerializer):
    container_number_image = serializers.CharField(required=False,allow_null=True)
    hazard_sign_image = serializers.CharField(required=False,allow_null=True)
    detected_seal = TrainSiteDetectedSealImageSerializer(many=True)
    class Meta:
        model = TrainSiteDetectedContainerDetail
        fields = ['id','uuid','container_number','iso_code','container_number_image','avg_confidence_container_number','triggered','triggered_container','seal_presence','seal_presence_count','length','height','width','hazard_sign_presence','hazard_sign_image','camera_name','camera_view_name','camera_group_name','detected_seal']

class TrainSiteDetectedDamageSerializer(serializers.ModelSerializer):
    damage_image = serializers.CharField()
    class Meta:
        model = TrainSiteDetectedDamage
        fields = ['id','uuid','damage_image','avg_confidence_damage_presence','damage_type']


class TrainSiteDetectedFrameImageSerializer(ModelSerializer):
    detected_damage = TrainSiteDetectedDamageSerializer(many=True)
    frame_image = serializers.CharField()
    class Meta:
        model = TrainSiteDetectedFrameImage
        fields = ['id','frame_image','damage_found','camera_name','camera_view_name','camera_group_name','detected_damage']

# class  TrainSiteDetectedGetTableSerializer(ModelSerializer):
#     site_name = serializers.CharField(source='sites.site_name', read_only=True)
#     class Meta:
#         model =  TrainSiteDetected
#         fields = ('id','datetime','camera_name','sites','company_detail_id','site_name')


class TrainSiteDetectedSerializer(ModelSerializer):
    detected_wagon_detail = TrainSiteDetectedWagonDetailSerializer(many=True, write_only=True)
    detected_container_detail = TrainSiteDetectedContainerDetailSerializer(many=True, write_only=True)
    #detected_seal = TrainSiteDetectedSealImageSerializer(many=True,write_only=True)    
    detected_frame = TrainSiteDetectedFrameImageSerializer(many=True,write_only=True)
    site_name = serializers.CharField(source='sites.site_name', read_only=True)

    def create(self, validated_data):
        print("validate_data:",validated_data)
        detected_wagons = validated_data.pop('detected_wagon_detail')
        detected_containers = validated_data.pop('detected_container_detail')
        detected_frames = validated_data.pop('detected_frame')
        
        detected_data = TrainSiteDetected.objects.create(**validated_data)
        
        for data in detected_wagons:
           TrainSiteDetectedWagonDetail.objects.create(detected=detected_data, **data)

        for data in detected_containers:
            print("detected_container:",data)
            detected_seals = data.pop('detected_seal')
            container_data = TrainSiteDetectedContainerDetail.objects.create(detected=detected_data, **data)
            for seal_data in detected_seals:
                TrainSiteDetectedSealImage.objects.create(detected_container_detail=container_data, **seal_data)

        for frame in detected_frames:
            detected_damage_image = frame.pop('detected_damage')
            detected_frame_data = TrainSiteDetectedFrameImage.objects.create(detected=detected_data, **frame)
            for damage_data in detected_damage_image:
                TrainSiteDetectedDamage.objects.create(detected_frame_image_detail=detected_frame_data,**damage_data)
        return detected_data

    class Meta:
        model = TrainSiteDetected
        fields = ('id', 'datetime','container_presence','group_name', 'sites','company_detail_id','site_name', 'detected_frame','detected_wagon_detail','detected_container_detail') #'truck_booking_id', 'transporter_name', 'driver_name', 'driver_photo', 'driver_dl_number', 'approve'


class TrainSiteDetectedDetailSerializer(ModelSerializer):
    detected_wagon = TrainSiteDetectedWagonDetailSerializer(many=True, read_only=True)
    detected_container = TrainSiteDetectedContainerDetailSerializer(many=True, read_only=True) 
    detected_frame = TrainSiteDetectedFrameImageSerializer(many=True,read_only=True)
    site_name = serializers.CharField(source='sites.site_name', read_only=True)
    
    class Meta:
        model = TrainSiteDetected
        fields = ('id', 'datetime','container_presence', 'group_name', 'sites','company_detail_id','site_name', 'detected_wagon','detected_container','detected_frame') # 'truck_booking_id', 'transporter_name', 'driver_name', 'driver_photo', 'driver_dl_number', 'approve'


class TrainSitePartiallyDetectedWagonDetailSerializer(serializers.ModelSerializer):
    wagon_number_image = serializers.CharField(required=False,allow_null=True)
    class Meta:
        model =  TrainSitePartiallyDetectedWagonDetail
        fields = ['id','uuid','wagon_number','wagon_number_image','avg_confidence_wagon_number','camera_name','camera_view_name','camera_group_name']


class TrainSitePartiallyDetectedSealImageSerializer(ModelSerializer):
    seal_image = serializers.CharField()
    class Meta:
        model = TrainSitePartiallyDetectedSealImage
        fields = ['id','uuid','seal_image','seal_presence','avg_confidence_seal_presence']


class TrainSitePartiallyDetectedContainerDetailSerializer(serializers.ModelSerializer):
    container_number_image = serializers.CharField(required=False,allow_null=True)
    hazard_sign_image = serializers.CharField(required=False,allow_null=True)
    partially_detected_seal = TrainSitePartiallyDetectedSealImageSerializer(many=True)
    class Meta:
        model = TrainSitePartiallyDetectedContainerDetail
        fields = ['id','uuid','container_number','iso_code','container_number_image','avg_confidence_container_number','seal_presence','seal_presence_count','length','height','width','hazard_sign_presence','hazard_sign_image','partially_detected_seal','camera_name','camera_view_name','camera_group_name']

class TrainSitePartiallyDetectedDamageSerializer(serializers.ModelSerializer):
    damage_image = serializers.CharField()
    class Meta:
        model = TrainSitePartiallyDetectedDamage
        fields = ['id','uuid','damage_image','avg_confidence_damage_presence','damage_type']


class TrainSitePartiallyDetectedFrameImageSerializer(ModelSerializer):
    frame_image = serializers.CharField()
    partially_detected_damage = TrainSitePartiallyDetectedDamageSerializer(many=True)
    class Meta:
        model = TrainSitePartiallyDetectedFrameImage
        fields = ['id','frame_image','camera_name','camera_view_name','camera_group_name','damage_found','partially_detected_damage']



class  TrainSitePartiallyDetectedGetTableSerializer(ModelSerializer):
    site_name = serializers.CharField(source='sites.site_name', read_only=True)
    class Meta:
        model =  TrainSitePartiallyDetected
        fields = ('id','datetime','camera_name','sites','company_detail_id','site_name')


class TrainSitePartiallyDetectedSerializer(ModelSerializer):
    partially_detected_wagon_detail = TrainSitePartiallyDetectedWagonDetailSerializer(many=True, write_only=True)
    partially_detected_container_detail = TrainSitePartiallyDetectedContainerDetailSerializer(many=True, write_only=True)
    partially_detected_frame = TrainSitePartiallyDetectedFrameImageSerializer(many=True, write_only=True)
    site_name = serializers.CharField(source='sites.site_name', read_only=True)
    
    def create(self, validated_data):
        partially_detected_wagon = validated_data.pop('partially_detected_wagon_detail')
        partially_detected_containers = validated_data.pop('partially_detected_container_detail')
        partially_detected_frames = validated_data.pop('partially_detected_frame')
        
        partially_detected_data = TrainSitePartiallyDetected.objects.create(**validated_data)
        
        for data in partially_detected_wagon:
            TrainSitePartiallyDetectedWagonDetail.objects.create(partially_detected=partially_detected_data, **data)

        for data in partially_detected_containers:
            partially_detected_seals = data.pop('partially_detected_seal')
            container_data = TrainSitePartiallyDetectedContainerDetail.objects.create(partially_detected=partially_detected_data, **data)
            for seal_data in partially_detected_seals:
                TrainSitePartiallyDetectedSealImage.objects.create(partially_detected_container_detail=container_data, **seal_data)

        for frame in partially_detected_frames:
            partially_detected_damage_image = frame.pop('partially_detected_damage')
            partially_detected_frame_data = TrainSitePartiallyDetectedFrameImage.objects.create(partially_detected=partially_detected_data, **frame)
            for damage_data in partially_detected_damage_image:
                TrainSitePartiallyDetectedDamage.objects.create(partially_detected_frame_image_detail=partially_detected_frame_data,**damage_data)
        return partially_detected_data

    
    class Meta:
        model = TrainSitePartiallyDetected
        fields = ('id','datetime','sites','company_detail_id','site_name','partially_detected_frame','partially_detected_wagon_detail','partially_detected_container_detail')


class TrainSitePartiallyDetectedDetailSerializer(ModelSerializer):
    partially_detected_wagon = TrainSitePartiallyDetectedWagonDetailSerializer(many=True, read_only=True)
    partially_detected_container = TrainSitePartiallyDetectedContainerDetailSerializer(many=True, read_only=True)
    partially_detected_frame = TrainSitePartiallyDetectedFrameImageSerializer(many=True,read_only=True)
    site_name = serializers.CharField(source='sites.site_name', read_only=True)
    class Meta:
        model = TrainSitePartiallyDetected
        fields = ('id','datetime','container_presence','group_name','sites','company_detail_id','site_name','partially_detected_wagon','partially_detected_container','partially_detected_frame')
