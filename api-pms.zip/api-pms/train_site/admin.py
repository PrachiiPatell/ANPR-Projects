from django.contrib import admin
from .models import *
# Register your models here.

class TrainSiteDetectedAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','datetime','container_presence','group_name','sites','company_detail_id')

class TrainSiteTriggeredWagonAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','wagon_number','reason_to_trigger','date_and_time', 'company_detail_id')

class TrainSiteTriggeredContainerAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','container_number','reason_to_trigger','date_and_time', 'company_detail_id')

class TrainSiteDetectedWagonDetailAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','wagon_number','wagon_number_image','avg_confidence_wagon_number', 'triggered', 'triggered_wagon','camera_name','camera_view_name','camera_group_name','detected')

class TrainSiteDetectedContainerDetailAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','container_number','iso_code','container_number_image','avg_confidence_container_number', 'triggered', 'triggered_container','seal_presence','seal_presence_count','length','height','width','hazard_sign_presence','hazard_sign_image','camera_name','detected')


class TrainSiteDetectedSealImageAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','seal_image','detected_container_detail')

class TrainSiteDetectedFrameImageAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','frame_image','camera_name','damage_found','detected')
# ,'detected_Wagon_detail','detected_container_detail'

class TrainSitePartiallyDetectedAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','datetime','group_name','sites','company_detail_id')


class TrainSitePartiallyDetectedWagonDetailAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','wagon_number','wagon_number_image','avg_confidence_wagon_number','camera_name','partially_detected')

class TrainSitePartiallyDetectedContainerDetailAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','container_number','iso_code','container_number_image','avg_confidence_container_number', 'seal_presence','seal_presence_count','length','height','width','hazard_sign_presence','hazard_sign_image','camera_name','partially_detected')


class TrainSitePartiallyDetectedSealImageAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','seal_image','partially_detected_container_detail')

class TrainSitePartiallyDetectedFrameImageAdmin(admin.ModelAdmin):
    list_display = ('id','uuid','frame_image','camera_name','damage_found','partially_detected')
# ,'partially_detected_Wagon_detail','partially_detected_container_detail'



admin.site.register(TrainSiteDetected, TrainSiteDetectedAdmin)
admin.site.register(TrainSiteTriggeredWagon, TrainSiteTriggeredWagonAdmin)
admin.site.register(TrainSiteTriggeredContainer, TrainSiteTriggeredContainerAdmin)
admin.site.register(TrainSiteDetectedWagonDetail, TrainSiteDetectedWagonDetailAdmin)
admin.site.register(TrainSiteDetectedContainerDetail, TrainSiteDetectedContainerDetailAdmin)
admin.site.register(TrainSiteDetectedSealImage, TrainSiteDetectedSealImageAdmin)
admin.site.register(TrainSiteDetectedFrameImage,TrainSiteDetectedFrameImageAdmin)

admin.site.register(TrainSitePartiallyDetected, TrainSitePartiallyDetectedAdmin)
admin.site.register(TrainSitePartiallyDetectedWagonDetail, TrainSitePartiallyDetectedWagonDetailAdmin)
admin.site.register(TrainSitePartiallyDetectedContainerDetail, TrainSitePartiallyDetectedContainerDetailAdmin)
admin.site.register(TrainSitePartiallyDetectedSealImage, TrainSitePartiallyDetectedSealImageAdmin)
admin.site.register(TrainSitePartiallyDetectedFrameImage,TrainSitePartiallyDetectedFrameImageAdmin)

