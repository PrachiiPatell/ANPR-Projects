#from django.conf.urls import url
from django.urls import path,reverse,reverse_lazy
from train_site import views
from django.conf.urls.static import static
from django.conf import settings 
from django.contrib.auth import views as auth_views
from .views import *
app_name = 'train_site'
urlpatterns = [

    # path('register/', views.register, name='register'),
    path('train_site_triggered_wagon/',TrainSiteTriggeredWagonView.as_view()),
    path('train_site_triggered_wagon_detail/<int:id>',TrainSiteTriggeredWagonDetailView.as_view()),

    path('train_site_triggered_container/',TrainSiteTriggeredContainerView.as_view()),
    path('train_site_triggered_container_detail/<int:id>',TrainSiteTriggeredContainerDetailView.as_view()),

    path('train_site_detected_temp/',TrainSiteDetectedTempView.as_view()),
    path('train-site-partially-detected_temp/',TrainSitePartiallyDetectedTempView.as_view()),
    path('train-site-detected', TrainSiteDetectedView.as_view()),
    path('train-site-detected/<int:id>', TrainSiteDetectedDetailView.as_view()),
    path('train-site-partially-detected', TrainSitePartiallyDetectedView.as_view()),
    path('train-site-partially-detected/<int:id>', TrainSitePartiallyDetectedDetailView.as_view()),
    path('train-site-dashboard/', DashboardData.as_view()),


    
] + static(settings.STATIC_URL)

# + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)