from django.shortcuts import render
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.views import APIView
from django.http.response import JsonResponse, Http404
from rest_framework.response import Response
from account.views import get_user_data_page
from rest_framework import status
from .models import *
from .serializers import *
from django.db.models import Q

from PIL import Image
from io import BytesIO
import base64
import os
from django.core.files.storage import default_storage
from datetime import datetime

# Create your views here.


class TrainSiteTriggeredWagonView(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, format=None):
        user_detail_page = get_user_data_page(
            request.user.id, 'triggered wagon', 'create')
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                if (any(product['default_product__product_name'] == 'Train Site' and product['allowed_status'] for product in user_detail_page['product_allowed'])
                            and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
                        ):
                    get_data = request.data
                    get_data['company_detail_id'] = user_detail_page['company_detail']['id']
                    serializer = TrainSiteTriggeredWagonSerializer(
                        data=get_data)
                    if serializer.is_valid():
                        serializer.save()
                        return Response(serializer.data, status=status.HTTP_201_CREATED)
                    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                else:
                    return Response({"detail": "You don't have permission for Train Site feature."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "you don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def get(self, request, format=None):
        limit = int(request.GET.get('limit', 10))
        offset = int(request.GET.get('offset', 0))
        user_detail_page = get_user_data_page(
            request.user.id, 'triggered wagon', 'view')
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                if (any(product['default_product__product_name'] == 'Train Site' and product['allowed_status'] for product in user_detail_page['product_allowed'])
                            and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
                        ):
                    wagons = TrainSiteTriggeredWagon.objects.all()[
                        offset:limit+offset]
                    wagon_count = TrainSiteTriggeredWagon.objects.count()
                    serializer = TrainSiteTriggeredWagonSerializer(
                        wagons, many=True)
                    return Response({'count': wagon_count, 'results': serializer.data})
                else:
                    return Response({"detail": "You don't have permission for Train Site feature."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "you don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class TrainSiteTriggeredWagonDetailView(APIView):
    permission_classes = (IsAuthenticated,)

    def get_object(self, id):
        try:
            return TrainSiteTriggeredWagon.objects.get(pk=id)
        except TrainSiteTriggeredWagon.DoesNotExist:
            raise Http404

    def get(self, request, id, format=None):
        user_detail_page = get_user_data_page(
            request.user.id, 'triggered wagon', 'view')
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                if (any(product['default_product__product_name'] == 'Train Site' and product['allowed_status'] for product in user_detail_page['product_allowed'])
                            and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
                        ):
                    wagon = self.get_object(id)
                    serializer = TrainSiteTriggeredWagonSerializer(wagon)
                    return Response(serializer.data)
                else:
                    return Response({"detail": "You don't have permission for Train Site feature."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "you don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, id, format=None):
        user_detail_page = get_user_data_page(
            request.user.id, 'triggered wagon', 'update')
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                if (any(product['default_product__product_name'] == 'Train Site' and product['allowed_status'] for product in user_detail_page['product_allowed'])
                            and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
                        ):
                    wagon = self.get_object(id)
                    get_data = request.data
                    get_data['company_detail_id'] = user_detail_page['company_detail']['id']
                    serializer = TrainSiteTriggeredWagonSerializer(
                        wagon, data=get_data)
                    if serializer.is_valid():
                        serializer.save()
                        return Response(serializer.data)
                    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                else:
                    return Response({"detail": "You don't have permission for Train Site feature."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "you don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, id, format=None):
        user_detail_page = get_user_data_page(
            request.user.id, 'triggered wagon', 'delete')
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                if (any(product['default_product__product_name'] == 'Train Site' and product['allowed_status'] for product in user_detail_page['product_allowed'])
                            and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
                        ):
                    wagon = self.get_object(id)
                    wagon.delete()
                    return Response(status=status.HTTP_204_NO_CONTENT)
                else:
                    return Response({"detail": "You don't have permission for Train Site feature."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "you don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
        


class TrainSiteTriggeredContainerView(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, format=None):
        user_detail_page = get_user_data_page(
            request.user.id, 'container triggered', 'create')
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                if (any(product['default_product__product_name'] == 'Train Site' and product['allowed_status'] for product in user_detail_page['product_allowed'])
                            and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
                        ):
                    get_data = request.data
                    get_data['company_detail_id'] = user_detail_page['company_detail']['id']
                    serializer = TrainSiteTriggeredContainerSerializer(
                        data=get_data)
                    if serializer.is_valid():
                        serializer.save()
                        return Response(serializer.data, status=status.HTTP_201_CREATED)
                    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                else:
                    return Response({"detail": "You don't have permission for Train Site feature."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "you don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def get(self, request, format=None):
        limit = int(request.GET.get('limit', 10))
        offset = int(request.GET.get('offset', 0))
        user_detail_page = get_user_data_page(
            request.user.id, 'container triggered', 'view')
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                if (any(product['default_product__product_name'] == 'Train Site' and product['allowed_status'] for product in user_detail_page['product_allowed'])
                            and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
                        ):
                    containers = TrainSiteTriggeredContainer.objects.all()[
                        offset:limit+offset]
                    containers_count = TrainSiteTriggeredContainer.objects.count()
                    serializer = TrainSiteTriggeredContainerSerializer(
                        containers, many=True)
                    return Response({'count': containers_count, 'results': serializer.data})
                else:
                    return Response({"detail": "You don't have permission for Train Site feature."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "you don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class TrainSiteTriggeredContainerDetailView(APIView):
    permission_classes = (IsAuthenticated,)

    def get_object(self, id):
        try:
            return TrainSiteTriggeredContainer.objects.get(pk=id)
        except TrainSiteTriggeredContainer.DoesNotExist:
            raise Http404

    def get(self, request, id, format=None):
        user_detail_page = get_user_data_page(
            request.user.id, 'container triggered', 'view')
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                if (any(product['default_product__product_name'] == 'Train Site' and product['allowed_status'] for product in user_detail_page['product_allowed'])
                            and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
                        ):
                    container = self.get_object(id)
                    serializer = TrainSiteTriggeredContainerSerializer(
                        container)
                    return Response(serializer.data)
                else:
                    return Response({"detail": "You don't have permission for Train Site feature."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "you don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, id, format=None):
        user_detail_page = get_user_data_page(
            request.user.id, 'container triggered', 'update')
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                if (any(product['default_product__product_name'] == 'Train Site' and product['allowed_status'] for product in user_detail_page['product_allowed'])
                            and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
                        ):
                    container = self.get_object(id)
                    get_data = request.data
                    get_data['company_detail_id'] = user_detail_page['company_detail']['id']
                    serializer = TrainSiteTriggeredContainerSerializer(
                        container, data=get_data)
                    if serializer.is_valid():
                        serializer.save()
                        return Response(serializer.data)
                    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                else:
                    return Response({"detail": "You don't have permission for Train Site feature."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "you don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, id, format=None):
        user_detail_page = get_user_data_page(
            request.user.id, 'container triggered', 'delete')
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                if (any(product['default_product__product_name'] == 'Train Site' and product['allowed_status'] for product in user_detail_page['product_allowed'])
                            and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
                        ):
                    container = self.get_object(id)
                    container.delete()
                    return Response(status=status.HTTP_204_NO_CONTENT)
                else:
                    return Response({"detail": "You don't have permission for Train Site feature."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "you don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
        

class TrainSiteDetectedTempView(APIView):
    permission_classes = (IsAuthenticated,)
    def convert_base64_to_image(self, base64_data):
        # Decode the base64 data
        image_data = base64.b64decode(base64_data)

        # Create a PIL Image object from the image data
        image = Image.open(BytesIO(image_data))
        return image

    def upload_image_to_s3(self, image,file_path):
        image_io = BytesIO()
        image.save(image_io, format='JPEG')

        # Set the S3 object key
        file_name = file_path
        storage = default_storage
        image_file = storage.save(f'{file_name}', image_io)
        # s3 = boto3.resource('s3')
        # bucket = s3.Bucket(default_storage.bucket_name)
        # object = bucket.Object(image_file)
        # object.upload_file(image_file, ExtraArgs={'ContentType': 'image/webp'})
        return image_file
    
    def post(self, request, format=None):
        user_detail_page = get_user_data_page(
            request.user.id, 'train site detected', 'view')
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                if (
                    any(product['default_product__product_name'] == 'Train Site' and product['allowed_status']
                        for product in user_detail_page['product_allowed'])
                    and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
                ):
                    get_data = request.data
                    get_company_name = CompanyDetail.objects.filter(id=get_data['company_detail_id']).values('company_name').first()
                    get_site_name = Sites.objects.filter(id=get_data['sites']).values('site_name').first()
                    datetime_format = datetime.strptime(get_data['datetime'],'%Y-%m-%d %H:%M:%S.%f%z')
                    get_date_string = str(datetime_format.date())
                    if get_company_name != None or get_site_name != None:
                        if len(get_data['detected_wagon_detail']) > 0:
                            for index,wagon_data in enumerate(get_data['detected_wagon_detail']):
                                wagon_number_image_data = wagon_data['wagon_number_image']
                                if wagon_number_image_data != None:
                                    image = self.convert_base64_to_image(wagon_number_image_data['image_base64'])
                                    folder_path = 'port_management_system/'+get_company_name['company_name']+'/'+get_site_name['site_name']+'/'+get_data['group_name'] +'/wagon_number_image/'+get_date_string+'/detected'
                                    object_key = os.path.join(folder_path, wagon_number_image_data['image_name'])
                                    get_data['detected_wagon_detail'][index]['wagon_number_image'] = self.upload_image_to_s3(image,object_key)
                            
                                
                        if len(get_data['detected_container_detail']) > 0:
                            for index,container_data in enumerate(get_data['detected_container_detail']):
                                container_number_image_data = container_data['container_number_image']
                                if container_number_image_data != None:
                                    image = self.convert_base64_to_image(container_number_image_data['image_base64'])
                                    folder_path = 'port_management_system/'+get_company_name['company_name']+'/'+get_site_name['site_name']+'/'+get_data['group_name'] +'/container_number_image/'+get_date_string+'/detected'
                                    object_key = os.path.join(folder_path, container_number_image_data['image_name'])
                                    get_data['detected_container_detail'][index]['container_number_image'] = self.upload_image_to_s3(image,object_key)
                                hazard_sign_image_data = container_data['hazard_sign_image']
                                if hazard_sign_image_data != None:
                                    image = self.convert_base64_to_image(hazard_sign_image_data['image_base64'])
                                    folder_path = 'port_management_system/'+get_company_name['company_name']+'/'+get_site_name['site_name']+'/'+get_data['group_name'] +'/hazard_sign_image/'+get_date_string+'/detected'
                                    object_key = os.path.join(folder_path, hazard_sign_image_data['image_name'])
                                    get_data['detected_container_detail'][index]['hazard_sign_image'] = self.upload_image_to_s3(image,object_key)
                                detected_seal_area_data = container_data['detected_seal']
                                for index_seal,seal_area_data in enumerate(detected_seal_area_data):
                                    seal_image_data = seal_area_data['seal_image']
                                    if seal_image_data != None:
                                        image = self.convert_base64_to_image(seal_image_data['image_base64'])
                                        folder_path = 'port_management_system/'+get_company_name['company_name']+'/'+get_site_name['site_name']+'/'+get_data['group_name'] +'/seal_image/'+get_date_string+'/detected'
                                        object_key = os.path.join(folder_path, seal_image_data['image_name'])
                                        get_data['detected_container_detail'][index]['detected_seal'][index_seal]['seal_image'] = self.upload_image_to_s3(image,object_key)
                                    
                        if len(get_data['detected_frame']) > 0:
                            for index,frame_data in enumerate(get_data['detected_frame']):
                                frame_image_data = frame_data['frame_image']
                                if frame_image_data != None:
                                    image = self.convert_base64_to_image(frame_image_data['image_base64'])
                                    folder_path = 'port_management_system/'+get_company_name['company_name']+'/'+get_site_name['site_name']+'/'+get_data['group_name'] +'/frame_image/'+get_date_string+'/detected'
                                    object_key = os.path.join(folder_path, frame_image_data['image_name'])
                                    get_data['detected_frame'][index]['frame_image'] = self.upload_image_to_s3(image,object_key)
                            
                                damage_detected_data = frame_data['detected_damage']
                                for index_damage,damage_data in enumerate(damage_detected_data):
                                    damage_image_data = damage_data['damage_image']
                                    if damage_image_data != None:
                                        image = self.convert_base64_to_image(damage_image_data['image_base64'])
                                        folder_path = 'port_management_system/'+get_company_name['company_name']+'/'+get_site_name['site_name']+'/'+get_data['group_name'] +'/damage_image/'+get_date_string+'/detected'
                                        object_key = os.path.join(folder_path, damage_image_data['image_name'])
                                        get_data['detected_frame'][index]['detected_damage'][index_damage]['damage_image'] = self.upload_image_to_s3(image,object_key)
                        #print(get_data)
                        detected_serializer = TrainSiteDetectedSerializer(
                            data=get_data)
                        if detected_serializer.is_valid(raise_exception=True):
                            detected_serializer.save()
                            return Response(detected_serializer.data, status=status.HTTP_201_CREATED)
                        return Response(detected_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                    else:
                        return Response({'message':'company and sites are required.'}, status=status.HTTP_400_BAD_REQUEST)
                else:
                    return Response({"detail": "You don't have permission for Train Site feature."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "you don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
        

class TrainSitePartiallyDetectedTempView(APIView):
    permission_classes = (IsAuthenticated,)
    def convert_base64_to_image(self, base64_data):
        # Decode the base64 data
        image_data = base64.b64decode(base64_data)

        # Create a PIL Image object from the image data
        image = Image.open(BytesIO(image_data))
        return image

    def upload_image_to_s3(self, image,file_path):
        image_io = BytesIO()
        image.save(image_io, format='JPEG')

        # Set the S3 object key
        file_name = file_path
        storage = default_storage
        image_file = storage.save(f'{file_name}', image_io)
        # s3 = boto3.resource('s3')
        # bucket = s3.Bucket(default_storage.bucket_name)
        # object = bucket.Object(image_file)
        # object.upload_file(image_file, ExtraArgs={'ContentType': 'image/webp'})
        return image_file
    
    def post(self, request, format=None):
        user_detail_page = get_user_data_page(
            request.user.id, 'train site partially detected', 'create')
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                if (
                    any(product['default_product__product_name'] == 'Train Site' and product['allowed_status']
                        for product in user_detail_page['product_allowed'])
                    and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
                ):
                    get_data = request.data
                    get_company_name = CompanyDetail.objects.filter(id=get_data['company_detail_id']).values('company_name').first()
                    get_site_name = Sites.objects.filter(id=get_data['sites']).values('site_name').first()
                    datetime_format = datetime.strptime(get_data['datetime'],'%Y-%m-%d %H:%M:%S.%f%z')
                    get_date_string = str(datetime_format.date())
                    if get_company_name != None or get_site_name != None:
                        if len(get_data['partially_detected_wagon_detail']) > 0:
                            for index,wagon_data in enumerate(get_data['partially_detected_wagon_detail']):
                                wagon_number_image_data = wagon_data['wagon_number_image']
                                if wagon_number_image_data != None:
                                    image = self.convert_base64_to_image(wagon_number_image_data['image_base64'])
                                    folder_path = 'port_management_system/'+get_company_name['company_name']+'/'+get_site_name['site_name']+'/'+get_data['group_name'] +'/wagon_number_image/'+get_date_string+'/partially_detected'
                                    object_key = os.path.join(folder_path, wagon_number_image_data['image_name'])
                                    get_data['partially_detected_wagon_detail'][index]['wagon_number_image'] = self.upload_image_to_s3(image,object_key)
                            
                                
                        if len(get_data['partially_detected_container_detail']) > 0:
                            for index,container_data in enumerate(get_data['partially_detected_container_detail']):
                                container_number_image_data = container_data['container_number_image']
                                if container_number_image_data != None:
                                    image = self.convert_base64_to_image(container_number_image_data['image_base64'])
                                    folder_path = 'port_management_system/'+get_company_name['company_name']+'/'+get_site_name['site_name']+'/'+get_data['group_name'] +'/container_number_image/'+get_date_string+'/partially_detected'
                                    object_key = os.path.join(folder_path, container_number_image_data['image_name'])
                                    get_data['partially_detected_container_detail'][index]['container_number_image'] = self.upload_image_to_s3(image,object_key)
                                hazard_sign_image_data = container_data['hazard_sign_image']
                                if hazard_sign_image_data != None:
                                    image = self.convert_base64_to_image(hazard_sign_image_data['image_base64'])
                                    folder_path = 'port_management_system/'+get_company_name['company_name']+'/'+get_site_name['site_name']+'/'+get_data['group_name'] +'/hazard_sign_image/'+get_date_string+'/partially_detected'
                                    object_key = os.path.join(folder_path, hazard_sign_image_data['image_name'])
                                    get_data['partially_detected_container_detail'][index]['hazard_sign_image'] = self.upload_image_to_s3(image,object_key)
                                partially_detected_seal_area_data = container_data['partially_detected_seal']
                                for index_seal,seal_area_data in enumerate(partially_detected_seal_area_data):
                                    seal_image_data = seal_area_data['seal_image']
                                    if seal_image_data != None:
                                        image = self.convert_base64_to_image(seal_image_data['image_base64'])
                                        folder_path = 'port_management_system/'+get_company_name['company_name']+'/'+get_site_name['site_name']+'/'+get_data['group_name'] +'/seal_image/'+get_date_string+'/partially_detected'
                                        object_key = os.path.join(folder_path, seal_image_data['image_name'])
                                        get_data['partially_detected_container_detail'][index]['partially_detected_seal'][index_seal]['seal_image'] = self.upload_image_to_s3(image,object_key)
                                    
                        if len(get_data['partially_detected_frame']) > 0:
                            for index,frame_data in enumerate(get_data['partially_detected_frame']):
                                frame_image_data = frame_data['frame_image']
                                if frame_image_data != None:
                                    image = self.convert_base64_to_image(frame_image_data['image_base64'])
                                    folder_path = 'port_management_system/'+get_company_name['company_name']+'/'+get_site_name['site_name']+'/'+get_data['group_name'] +'/frame_image/'+get_date_string+'/partially_detected'
                                    object_key = os.path.join(folder_path, frame_image_data['image_name'])
                                    get_data['partially_detected_frame'][index]['frame_image'] = self.upload_image_to_s3(image,object_key)
                            
                                damage_partially_detected_data = frame_data['partially_detected_damage']
                                for index_damage,damage_data in enumerate(damage_partially_detected_data):
                                    damage_image_data = damage_data['damage_image']
                                    if damage_image_data != None:
                                        image = self.convert_base64_to_image(damage_image_data['image_base64'])
                                        folder_path = 'port_management_system/'+get_company_name['company_name']+'/'+get_site_name['site_name']+'/'+get_data['group_name'] +'/damage_image/'+get_date_string+'/partially_detected'
                                        object_key = os.path.join(folder_path, damage_image_data['image_name'])
                                        get_data['partially_detected_frame'][index]['partially_detected_damage'][index_damage]['damage_image'] = self.upload_image_to_s3(image,object_key)         
                        partially_detected_serializer = TrainSitePartiallyDetectedSerializer(
                            data=get_data)
                        if partially_detected_serializer.is_valid(raise_exception=True):
                            partially_detected_serializer.save()
                            return Response(partially_detected_serializer.data, status=status.HTTP_201_CREATED)
                        return Response(partially_detected_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                    else:
                        return Response({'message':'company and sites are required.'}, status=status.HTTP_400_BAD_REQUEST)
                else:
                    return Response({"detail": "You don't have permission for Train Site feature."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "you don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
        

class TrainSiteDetectedView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request):
        limit = int(request.GET.get('limit', 10))
        offset = int(request.GET.get('offset', 0))
        user_detail_page = get_user_data_page(
            request.user.id, 'train site detected', 'view')
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                if (
                    any(product['default_product__product_name'] == 'Train Site' and product['allowed_status']
                        for product in user_detail_page['product_allowed'])
                    and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
                ):
                    wagon_number = request.GET.get('wagon_number', None)
                    container_number = request.GET.get('container_number', None)
                    seal_presence = request.GET.get('seal_presence', None)
                    hazard_sign_presence = request.GET.get('hazard_sign_presence',None)
                    damage_found = request.GET.get('damage_found',None)
                    triggered_wagon = request.GET.get('triggered_wagon',None)
                    triggered_container = request.GET.get('triggered_container',None)
                    from_datetime = request.GET.get('start_datetime',None)
                    to_datetime = request.GET.get('end_datetime',None)
                    camera_name = request.GET.get('camera_name',None)
                    camera_view_name = request.GET.get('camera_view_name',None)
                    camera_group_name = request.GET.get('camera_group_name',None)
                    ordering = request.GET.get('order_by',None)
                    if ordering ==None:
                        ordering = '-datetime'
                    f= Q(company_detail_id = user_detail_page['company_detail']['id'])
                    if wagon_number != '' and wagon_number != None:
                        f &= Q(detected_wagon__wagon_number__contains=wagon_number)
                    if container_number != '' and container_number != None:
                        f &= Q(detected_container__container_number__contains=container_number)

                    if seal_presence != 'All' and seal_presence != None:
                        seal_presence_bool = False
                        if seal_presence== 'Yes':
                            seal_presence_bool = True
                        f &= Q(detected_container__seal_presence=seal_presence_bool)
                    if hazard_sign_presence != 'All' and hazard_sign_presence != None:
                        hazard_sign_presence_bool = False
                        if hazard_sign_presence == 'Yes':
                            hazard_sign_presence_bool = True
                        f &= Q(detected_container__hazard_sign_presence=hazard_sign_presence_bool)
                    if damage_found != 'All' and damage_found != None:
                        damage_found_bool = False
                        if damage_found == 'Yes':
                            damage_found_bool = True
                        f &= Q(detected_frame__damage_found=damage_found_bool)
                    if triggered_wagon != 'All' and triggered_wagon != None:
                        triggered_wagon_bool = False
                        if triggered_wagon == 'Yes':
                            triggered_wagon_bool = True
                        f &= Q(detected_wagon__triggered=triggered_wagon_bool)
                    if triggered_container != 'All' and triggered_container != None:
                        triggered_container_bool = False
                        if triggered_container == 'Yes':
                            triggered_container_bool = True
                        f &= Q(detected_container__triggered=triggered_container_bool)
                    if from_datetime != None:
                        f &= Q(datetime__gte=from_datetime)
                    if to_datetime != None:
                        f &= Q(datetime__lte=to_datetime)
                    if camera_name != '' and camera_name != None:
                        f &= Q(detected_container__camera_name=camera_name)
                    if camera_view_name != '' and camera_view_name != None:
                        f &= Q(detected_container__camera_view_name=camera_view_name)
                    if camera_group_name != '' and camera_group_name != None:
                        f &= Q(group_name=camera_group_name)
                    
                    detected = TrainSiteDetected.objects.filter(f).all().order_by(ordering)[
                        offset:limit+offset]
                    detected_count = TrainSiteDetected.objects.filter(f).order_by(ordering).count()
                    serializer = TrainSiteDetectedDetailSerializer(
                        detected, many=True)
                    serializer_data = serializer.data
                    for index,data in enumerate(serializer_data):
                        detected_wagon = data.get('detected_wagon')
                        if len(detected_wagon) > 0:
                            id = []
                            uuid = []
                            wagon_number = []
                            wagon_number_image = []
                            avg_confidence_wagon_number = []
                            triggered = []
                            for detected_wagon_data in detected_wagon:
                                id.append(detected_wagon_data.get('id'))
                                uuid.append(detected_wagon_data.get('uuid'))
                                if detected_wagon_data.get('wagon_number') != None:
                                    wagon_number.append(detected_wagon_data.get('wagon_number'))
                                else:
                                    wagon_number.append('N/A')
                                wagon_number_image.append(detected_wagon_data.get('wagon_number_image'))
                                avg_confidence_wagon_number.append(detected_wagon_data.get('avg_confidence_wagon_number'))
                                if detected_wagon_data.get('triggered') != None:
                                    if detected_wagon_data.get('triggered') == True:
                                        triggered.append('Yes')
                                    else:
                                        triggered.append('No')
                                else:
                                    triggered.append('N/A')
                            serializer_data[index]['detected_wagon'] = [{'id':id,'uuid':uuid,'wagon_number':wagon_number,'wagon_number_image':wagon_number_image,'avg_confidence_wagon_number':avg_confidence_wagon_number,'triggered':triggered}]
                        detected_container = data.get('detected_container')
                        if len(detected_container) > 0:
                            id = []
                            uuid = []
                            container_number = []
                            iso_code = []
                            triggered = []
                            seal_presence = []
                            seal_presence_count = []
                            hazard_sign_presence = []
                            length_height_width = []
                            for detected_container_data in detected_container:
                                id.append(detected_container_data.get('id'))
                                uuid.append(detected_container_data.get('uuid'))
                                if detected_container_data.get('container_number') != None:
                                    container_number.append(detected_container_data.get('container_number'))
                                else:
                                    container_number.append('N/A')
                                if detected_container_data.get('iso_code') != None:
                                    iso_code.append(detected_container_data.get('iso_code'))
                                else:
                                    iso_code.append('N/A')
                                if detected_container_data.get('triggered') != None:
                                    if detected_container_data.get('triggered') == True:
                                        triggered.append('Yes')
                                    else:
                                        triggered.append('No')
                                else:
                                    triggered.append('N/A')
                                if detected_container_data.get('seal_presence') != None:
                                    if detected_container_data.get('seal_presence') == True:
                                        seal_presence.append('Yes')
                                    else:
                                        seal_presence.append('No')
                                else:
                                    seal_presence.append('N/A')
                                if detected_container_data.get('seal_presence_count') != None:
                                    seal_presence_count.append(detected_container_data.get('seal_presence_count'))
                                else:
                                    seal_presence_count.append("N/A")
                
                                if detected_container_data.get('hazard_sign_presence') != None:
                                    if detected_container_data.get('hazard_sign_presence') == True:
                                        hazard_sign_presence.append('Yes')
                                    else:
                                        hazard_sign_presence.append('No')
                                else:
                                    hazard_sign_presence.append('N/A')
                                if detected_container_data.get('length') != None and detected_container_data.get('height') != None and detected_container_data.get('width') != None:
                                    length_height_width.append(str(detected_container_data.get('length'))+","+str(detected_container_data.get('height'))+","+str(detected_container_data.get('width'))+".ft")
                                else:
                                    length_height_width.append('N/A')
                            serializer_data[index]['detected_container'] = [{'id':id,'uuid':uuid,'container_number':container_number,'iso_code':iso_code,'length_height_width':length_height_width,'triggered':triggered,'seal_presence':seal_presence,'seal_presence_count':seal_presence_count,'hazard_sign_presence':hazard_sign_presence}]
                        detected_frame = data.get('detected_frame')
                        if len(detected_frame) > 0:
                            id = []
                            uuid = []
                            camera_name = []
                            camera_view_name = []
                            damage_found = []
                            for detected_frame_data in detected_frame:
                                id.append(detected_frame_data.get('id'))
                                uuid.append(detected_frame_data.get('uuid'))
                                if detected_frame_data.get('camera_name') != None:
                                    camera_name.append(detected_frame_data.get('camera_name'))
                                else:
                                    camera_name.append('N/A')
                                if detected_frame_data.get('camera_view_name') != None:
                                    camera_view_name.append(detected_frame_data.get('camera_view_name'))
                                else:
                                    camera_view_name.append('N/A')
                                if detected_frame_data.get('damage_found') != None:
                                    if detected_frame_data.get('damage_found') == True:
                                        damage_found.append("Yes")
                                    else:
                                        damage_found.append("No")
                                else:
                                    damage_found.append('N/A')
                            serializer_data[index]['detected_frame'] = [{'id':id,'uuid':uuid,'camera_name':camera_name,'camera_view_name':camera_view_name,'damage_found':damage_found}]

                    # print(type(serializer.data),len(serializer.data),serializer.data[0])
                    return Response({'count': detected_count, 'results': serializer_data})
                else:
                    return Response({"detail": "You don't have permission for Train Site feature."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "you don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class TrainSiteDetectedDetailView(APIView):
    permission_classes = (IsAuthenticated,)

    def get_object(self, id):
        try:
            return TrainSiteDetected.objects.get(pk=id)
        except TrainSiteDetected.DoesNotExist:
            raise Http404

    def get(self, request, id, format=None):
        user_detail_page = get_user_data_page(
            request.user.id, 'train site detected', 'view')
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                if (
                    any(product['default_product__product_name'] == 'Train Site' and product['allowed_status']
                        for product in user_detail_page['product_allowed'])
                    and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
                ):

                    detected = self.get_object(id)
                    serializer = TrainSiteDetectedDetailSerializer(detected)
                    return Response(serializer.data)
                else:
                    return Response({"detail": "You don't have permission for Train Site feature."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "you don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class TrainSitePartiallyDetectedView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request):
        limit = int(request.GET.get('limit', 10))
        offset = int(request.GET.get('offset', 0))

        user_detail_page = get_user_data_page(
            request.user.id, 'train site partially detected', 'view')
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                if (
                    any(product['default_product__product_name'] == 'Train Site' and product['allowed_status']
                        for product in user_detail_page['product_allowed'])
                    and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
                ):
                    ordering = request.GET.get('order_by',None)
                    if ordering ==None:
                        ordering = '-datetime'
                    f= Q(company_detail_id = user_detail_page['company_detail']['id'])
                    wagon_number = request.GET.get('wagon_number', None)
                    container_number = request.GET.get('container_number', None)
                    seal_presence = request.GET.get('seal_presence', None)
                    hazard_sign_presence = request.GET.get('hazard_sign_presence',None)
                    damage_found = request.GET.get('damage_found',None)
                    triggered_wagon = request.GET.get('triggered_wagon',None)
                    triggered_container = request.GET.get('triggered_container',None)
                    from_datetime = request.GET.get('start_datetime',None)
                    to_datetime = request.GET.get('end_datetime',None)
                    camera_name = request.GET.get('camera_name',None)
                    camera_view_name = request.GET.get('camera_view_name',None)
                    camera_group_name = request.GET.get('camera_group_name',None)
                    ordering = request.GET.get('order_by',None)
                    if ordering ==None:
                        ordering = '-datetime'
                    f= Q(company_detail_id = user_detail_page['company_detail']['id'])
                    if wagon_number != '' and wagon_number != None:
                        f &= Q(partially_detected_wagon__wagon_number__contains=wagon_number)
                    if container_number != '' and container_number != None:
                        f &= Q(partially_detected_container__container_number__contains=container_number)

                    if seal_presence != 'All' and seal_presence != None:
                        seal_presence_bool = False
                        if seal_presence== 'Yes':
                            seal_presence_bool = True
                        f &= Q(partially_detected_container__seal_presence=seal_presence_bool)
                    if hazard_sign_presence != 'All' and hazard_sign_presence != None:
                        hazard_sign_presence_bool = False
                        if hazard_sign_presence == 'Yes':
                            hazard_sign_presence_bool = True
                        f &= Q(partially_detected_container__hazard_sign_presence=hazard_sign_presence_bool)
                    if damage_found != 'All' and damage_found != None:
                        damage_found_bool = False
                        if damage_found == 'Yes':
                            damage_found_bool = True
                        f &= Q(partially_detected_frame__damage_found=damage_found_bool)
                    if from_datetime != None:
                        f &= Q(datetime__gte=from_datetime)
                    if to_datetime != None:
                        f &= Q(datetime__lte=to_datetime)
                    if camera_name != '' and camera_name != None:
                        f &= Q(partially_detected_container__camera_name=camera_name)
                    if camera_view_name != '' and camera_view_name != None:
                        f &= Q(partially_detected_container__camera_view_name=camera_view_name)
                    if camera_group_name != '' and camera_group_name != None:
                        f &= Q(group_name=camera_group_name)
                        
                    partially_detected = TrainSitePartiallyDetected.objects.filter(f).order_by(ordering).all()[
                        offset:limit+offset]
                    partially_detected_count = TrainSitePartiallyDetected.objects.filter(f).order_by(ordering).count()
                    serializer = TrainSitePartiallyDetectedDetailSerializer(
                        partially_detected, many=True)
                    serializer_data = serializer.data
                    for index,data in enumerate(serializer_data):
                        print(data)
                        partially_detected_wagon = data.get('partially_detected_wagon')
                        if len(partially_detected_wagon) > 0:
                            id = []
                            uuid = []
                            wagon_number = []
                            wagon_number_image = []
                            avg_confidence_wagon_number = []
                            for partially_detected_wagon_data in partially_detected_wagon:
                                id.append(partially_detected_wagon_data.get('id'))
                                uuid.append(partially_detected_wagon_data.get('uuid'))
                                if partially_detected_wagon_data.get('wagon_number') != None:
                                    wagon_number.append(partially_detected_wagon_data.get('wagon_number'))
                                else:
                                    wagon_number.append('N/A')
                                wagon_number_image.append(partially_detected_wagon_data.get('wagon_number_image'))
                                avg_confidence_wagon_number.append(partially_detected_wagon_data.get('avg_confidence_wagon_number'))
                            serializer_data[index]['partially_detected_wagon'] = [{'id':id,'uuid':uuid,'wagon_number':wagon_number,'wagon_number_image':wagon_number_image,'avg_confidence_wagon_number':avg_confidence_wagon_number}]
                        partially_detected_container = data.get('partially_detected_container')
                        if len(partially_detected_container) > 0:
                            id = []
                            uuid = []
                            container_number = []
                            iso_code = []
                            seal_presence = []
                            seal_presence_count = []
                            hazard_sign_presence = []
                            length_height_width = []
                            for partially_detected_container_data in partially_detected_container:
                                id.append(partially_detected_container_data.get('id'))
                                uuid.append(partially_detected_container_data.get('uuid'))
                                if partially_detected_container_data.get('container_number') != None:
                                    container_number.append(partially_detected_container_data.get('container_number'))
                                else:
                                    container_number.append('N/A')
                                if partially_detected_container_data.get('iso_code') != None:
                                    iso_code.append(partially_detected_container_data.get('iso_code'))
                                else:
                                    iso_code.append('N/A')
                                if partially_detected_container_data.get('seal_presence') != None:
                                    if partially_detected_container_data.get('seal_presence') == True:
                                        seal_presence.append('Yes')
                                    else:
                                        seal_presence.append('No')
                                else:
                                    seal_presence.append('N/A')
                                if partially_detected_container_data.get('seal_presence_count') != None:
                                    seal_presence_count.append(partially_detected_container_data.get('seal_presence_count'))
                                else:
                                    seal_presence_count.append("N/A")
                                
                                if partially_detected_container_data.get('hazard_sign_presence') != None:
                                    if partially_detected_container_data.get('hazard_sign_presence') == True:
                                        hazard_sign_presence.append('Yes')
                                    else:
                                        hazard_sign_presence.append('No')
                                else:
                                    hazard_sign_presence.append('N/A')
                                if partially_detected_container_data.get('length') != None and partially_detected_container_data.get('height') != None and partially_detected_container_data.get('width') != None:
                                    length_height_width.append(str(partially_detected_container_data.get('length'))+","+str(partially_detected_container_data.get('height'))+","+str(partially_detected_container_data.get('width'))+".ft")
                                else:
                                    length_height_width.append('N/A')
                            serializer_data[index]['partially_detected_container'] = [{'id':id,'uuid':uuid,'container_number':container_number,'iso_code':iso_code,'length_height_width':length_height_width,'seal_presence':seal_presence,'seal_presence_count':seal_presence_count,'hazard_sign_presence':hazard_sign_presence}]
                        partially_detected_frame = data.get('partially_detected_frame')
                        if len(partially_detected_frame) > 0:
                            id = []
                            uuid = []
                            camera_name = []
                            camera_view_name = []
                            damage_found = []
                            for partially_detected_frame_data in partially_detected_frame:
                                id.append(partially_detected_frame_data.get('id'))
                                uuid.append(partially_detected_frame_data.get('uuid'))
                                if partially_detected_frame_data.get('camera_name') != None:
                                    camera_name.append(partially_detected_frame_data.get('camera_name'))
                                else:
                                    camera_name.append('N/A')
                                if partially_detected_frame_data.get('camera_view_name') != None:
                                    camera_view_name.append(partially_detected_frame_data.get('camera_view_name'))
                                else:
                                    camera_view_name.append('N/A')
                                if partially_detected_frame_data.get('damage_found') != None:
                                    if partially_detected_frame_data.get('damage_found') == True:
                                        damage_found.append("Yes")
                                    else:
                                        damage_found.append("No")
                                else:
                                    damage_found.append('N/A')
                            serializer_data[index]['partially_detected_frame'] = [{'id':id,'uuid':uuid,'camera_name':camera_name,'camera_view_name':camera_view_name,'damage_found':damage_found}]

                    return Response({'count': partially_detected_count, 'results': serializer_data})
                else:
                    return Response({"detail": "You don't have permission for Train Site feature."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "you don't have permission to."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

class TrainSitePartiallyDetectedDetailView(APIView):
    permission_classes = (IsAuthenticated,)

    def get_object(self, id):
        try:
            return TrainSitePartiallyDetected.objects.get(pk=id)
        except TrainSitePartiallyDetected.DoesNotExist:
            raise Http404

    def get(self, request, id, format=None):
        user_detail_page = get_user_data_page(
            request.user.id, 'train site partially detected', 'view')
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:

                if (
                    any(product['default_product__product_name'] == 'Train Site' and product['allowed_status']
                        for product in user_detail_page['product_allowed'])
                    and all(feature['allowed_status'] for feature in user_detail_page['feature_allowed'])
                ):

                    partially_detected = self.get_object(id)
                    serializer = TrainSitePartiallyDetectedDetailSerializer(
                        partially_detected)
                    return Response(serializer.data)
                else:
                    return Response({"detail": "You don't have permission for Train Site feature."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "you don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
        

class DashboardData(APIView):
    permission_classes = (IsAuthenticated,)
    def get(self,request, format=None):
        user_detail_page = get_user_data_page(request.user.id, 'dashboard', 'view')
        if user_detail_page['company_detail']['plan_validity'] == True:
            AccessToPage = False
            if user_detail_page['permission'] != None:
                AccessToPage = True
            if AccessToPage == True:
                start_date = request.GET.get('start_date')
                end_date = request.GET.get('end_date')
                trainsite_detected_count = TrainSiteDetected.objects.filter(datetime__gte=start_date, datetime__lte=end_date,company_detail_id=user_detail_page['company_detail']['id']).count()
                trainsite_partially_detected_count = TrainSitePartiallyDetected.objects.filter(datetime__gte=start_date, datetime__lte=end_date,company_detail_id=user_detail_page['company_detail']['id']).count()
                trainsite_detected_seal_presence = TrainSiteDetected.objects.filter(datetime__gte=start_date, datetime__lte=end_date,company_detail_id=user_detail_page['company_detail']['id'],detected_container__seal_presence=True).count()
                trainsite_detected_hazard_sign_presence = TrainSiteDetected.objects.filter(datetime__gte=start_date, datetime__lte=end_date,company_detail_id=user_detail_page['company_detail']['id'],detected_container__hazard_sign_presence=True).count()
                trainsite_detected_damage_found = TrainSiteDetected.objects.filter(datetime__gte=start_date, datetime__lte=end_date,company_detail_id=user_detail_page['company_detail']['id'],detected_frame__damage_found=True).count()
                trainsite_detected_triggered_wagon = TrainSiteDetected.objects.filter(datetime__gte=start_date, datetime__lte=end_date,company_detail_id=user_detail_page['company_detail']['id'],detected_wagon__triggered=True).count()
                trainsite_detected_triggered_container = TrainSiteDetected.objects.filter(datetime__gte=start_date, datetime__lte=end_date,company_detail_id=user_detail_page['company_detail']['id'],detected_container__triggered=True).count()

                results = {
                    "trainsite_detected_count": {'count':trainsite_detected_count,'filter_values':'detected'},
                    "trainsite_partially_detected_count": {'count':trainsite_partially_detected_count,'filter_values':'partially_detected'},
                    "trainsite_detected_seal_presence": {'count':trainsite_detected_seal_presence,'filter_values':'Yes'},
                    "trainsite_detected_hazard_sign_presence": {'count':trainsite_detected_hazard_sign_presence,'filter_values':'Yes'},
                    "trainsite_detected_damage_found" : {'count':trainsite_detected_damage_found,'filter_values':'Yes'},
                    "trainsite_detected_triggered_wagon": {'count':trainsite_detected_triggered_wagon,'filter_values':'Yes'},
                    "trainsite_detected_triggered_container": {'count':trainsite_detected_triggered_container,'filter_values':'Yes'},
                    "company_detail_id":user_detail_page['company_detail']['id'],
                    "StartDateTime": start_date,
                    "EndDateTime": end_date
                    }
                return JsonResponse(results, safe=False)
            else:
                return Response({"detail": "you don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)



