from django.urls import path
from visitorapp import views
from visitorapp.views import EmployeeVisitorRequestView, AccessoryOptionsView, VisitorApprovalView, CheckedInOutAPIView, \
    CheckedOutAPIView, VisitorFineView

urlpatterns = [

    path('VisitorFineList/', views.VisitorFineList.as_view()),
    path('VisitorFineDetail/<int:id>', views.VisitorFineDetail.as_view()),

    path('VisitorAccessoryForFineList/', views.VisitorAccessoryForFineList.as_view()),
    path('VisitorAccessoryForFineDetail/<int:id>', views.VisitorAccessoryForFineDetail.as_view()),

    path('AccessoryProvidedList/', views.AccessoryProvidedList.as_view()),
    path('AccessoryProvidedDetail/<int:id>', views.AccessoryProvidedDetail.as_view()),

    path('AccessoryReturnList/', views.AccessoryReturnList.as_view()),
    path('AccessoryReturnDetail/<int:id>', views.AccessoryReturnDetail.as_view()),

    path('VisitorHaveAccessoryList/', views.VisitorHaveAccessoryList.as_view()),
    path('VisitorHaveAccessoryDetail/<int:id>', views.VisitorHaveAccessoryDetail.as_view()),

    path('id_proof_type/', views.IdProofTypeView.as_view()),
    path('id_proof_type_detail/<int:id>', views.IdProofTypeDetailView.as_view()),

    path('mobile_type/', views.MobileTypeView.as_view()),
    path('mobile_type_detail/<int:id>', views.MobileTypeDetailView.as_view()),

    path('AccessoryAllowList/', views.AccessoryAllowList.as_view()),
    path('AccessoryAllowDetail/<int:id>', views.AccessoryAllowDetail.as_view()),

    path('ApprovalList/', views.ApprovalList.as_view()),
    path('ApprovalDetail/<int:id>', views.ApprovalDetail.as_view()),

    path('register_visitor/', views.RegisterVisitor.as_view()),
    path('visitor_login/', views.VisitorLogin.as_view()),

    path('visitor_restriction/', views.VisitorRestrictionView.as_view()),
    path('visitor_restriction_detail/<int:id>', views.VisitorRestrictionDetailView.as_view()),

    path('visitor_request_by_employee/', views.VisitorRequestByEmployeeView.as_view()),
    path('visitor_request_by_employee_detail/<int:id>', views.VisitorRequestByEmployeeDetailView.as_view()),

    path('visitor_profile/', views.VisitorProfileView.as_view()),
    path('visitor_profile/<int:id>', views.VisitorProfileView.as_view()),

    path('visitor_request_by_self/', views.VisitorRequestBySelfView.as_view()),
    path('visitor_request_by_self_detail/<int:id>', views.VisitorRequestBySelfDetailView.as_view()),

    path('visitor_request_dropdown/', views.VisitorRequestListView.as_view()),

    path('visitor_accessory_dropdown/', views.VisitorProvidedAccessoryListView.as_view()),

    path('PassGenerationView/<int:id>', views.PassGenerationAPIView.as_view()),

    path('approve_visitor_request/<int:id>', views.ApproveVisitorRequestView.as_view()),

    path('hold_visitor_request/<int:id>', views.HoldVisitorRequestView.as_view()),

    path('reject_visitor_request/<int:id>', views.RejectVisitorRequestView.as_view()),

    path('id_proof_type_dropdown/', views.IdProofTypeListView.as_view()),

    path('mobile_type_dropdown/', views.MobileTypeListView.as_view()),

    path('visitor_request_get_detail/', views.VisitorRequestBySelfGetDetailView.as_view()),

    path('visitor_provided_accessory_for_approval_dropdown/<int:id>', views.VisitorProvidedAccessoryListForApprovalView.as_view()),

    path('visitor_have_accessory_for_approval_dropdown/<int:id>', views.VisitorHaveAccessoryListForApprovalView.as_view()),

    path('default_visitor_have_accessory_dropdown/', views.DefaultVisitorHaveAccessoryListView.as_view()),

    path('DefaultVisitorHaveAccessoryView/', views.DefaultVisitorHaveAccessoryView.as_view()),
    path('DefaultVisitorHaveAccessoryDetailView/<int:id>', views.DefaultVisitorHaveAccessoryDetailView.as_view()),

    path('visitor_provided_accessory_for_fine_dropdown/<int:id>', views.VisitorProvidedAccessoryListForFineView.as_view()),

    path('visitor_request_qr_detail/<uuid:uuid>', views.VisitorRequestQRDetailView.as_view()),

    path('dashboard/', views.DashboardView.as_view()),
    path('visitor_graph/', views.GraphDashboardView.as_view()),

    # path('checked_in_out/', views.CheckedInOutView.as_view()),
    #
    # path('checked_out_get/', views.CheckedOutView.as_view()),

    path('checked_in_out_detail/<int:id>', views.CheckedInOutDetailView.as_view()),

    path('fetch_associated_companies/', views.FetchAssociatedCompanies.as_view()),


##sachin
    path('approval-list/', VisitorApprovalView.as_view()),
    path('employee-visitor-request/', EmployeeVisitorRequestView.as_view(), name='employee_visitor_request'),
    path('accessory-options/', AccessoryOptionsView.as_view(), name='accessory_options'),
    path('checked_in_out/', CheckedInOutAPIView.as_view(), name='checked_in_out'),
    path('checked_out_get/', CheckedOutAPIView.as_view(), name='checked_out_get'),
    path('visitor-fines/', VisitorFineView.as_view(), name='visitor-fine-list'),



]
