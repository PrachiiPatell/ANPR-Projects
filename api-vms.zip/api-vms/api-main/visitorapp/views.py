import django
from django.shortcuts import render
from rest_framework import status
from rest_framework.response import Response
from django.http import Http404
from datetime import datetime, timedelta
from django.contrib.auth import authenticate, login, logout
from django.http.response import JsonResponse
from django.db.models import Q, F
from django.utils import timezone
from dateutil import parser


from rest_framework.views import APIView
from rest_framework.pagination import LimitOffsetPagination
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework_simplejwt.tokens import RefreshToken

from django.forms.models import model_to_dict

from account.getUserDataLogin import getUserDataLogin
from account.getVisitorUserDataLogin import getVisitorUserDataLogin


from .models import Visitor,DefaultVisitorHaveAccessory, VisitorAccessoryForFine, VisitorRequest, AccessoryProvided, \
                    AccessoryReturn, VisitorRestriction, VisitorDetail, VisitorHaveAccessory, AccessoryAllow, VisitorProvidedAccessory, VisitorFine, VisitorLoginLog, \
                    Approval, CheckedInOut
from .serializers import (
    VisitorSerializer,
    VisitorFineSerializer,
    DefaultVisitorHaveAccessorySerializer,
    VisitorAccessoryForFineSerializer,
    VisitorRequestDetailSerializer,
    VisitorRequestListSerializer,
    VisitorRequestSerializer,
    AccessoryProvidedSerializer,
    AccessoryReturnSerializer,
    VisitorRestrictionSerializer,
    VisitorDetailSerializer,
    VisitorHaveAccessorySerializer,
    VisitorHaveAccessorySerializerList,
    AccessoryAllowSerializer,
    VisitorProvidedAccessorySerializer,
    VisitorProvidedAccessorySerializerList,
    VisitorProvidedAccessoryListSerializer,
    VisitorLoginLogSerializer,
    ApprovalSerializer,
    MobileTypeListSerializer,
    IdProofTypeListSerializer,
    DefaultVisitorHaveAccessoryListSerializer,
    CheckedInOutSerializer,
    VisitorRequestDetailListSerializer
)

from .models import VisitorDetail as VisitorDetails

from .models import MobileType, IdProofType
from .serializers import MobileTypeSerializer, IdProofTypeSerializer


from .models import ApproveStepByRole, User, AddUserEmail, DefaultVisitorHaveAccessory, ApprovalLayer, Approval, DefaultAccessoryProvidedByCompany, ApprovalType, Roles, ApprovalChangeByNumberOfDays, SubCompany

from account.serializers import UserLoginSerializer, UserSerializer, CompanyDetailListSerializer

from employeeapp.models import Employee, Department

from io import BytesIO
import base64
import qrcode
from dateutil.relativedelta import relativedelta

# Create your views here.


# Visitor API
class VisitorList(APIView):
    permission_classes = (IsAuthenticated,)


    def get_object(self):
        try:
            return Visitor.objects.all()
        except:
            raise Http404

    ObjectSerializer = VisitorSerializer
    model_name = "Visitor"

    def get(self, request, format=None):
        limit = int(request.GET.get('limit',10))
        offset = int(request.GET.get('offset',0))

        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'visitor' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['visitor']:
                    acess_to_page = True
            if acess_to_page == True:
                queryset = Visitor.objects.all()[offset:limit+offset]
                serializer = self.ObjectSerializer(queryset, many=True)
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def post(self, request, format=None):
        # serializer = CompanyDetailSerializer(data=request.data)
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'visitor' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['visitor']:
                    acess_to_page = True
            if acess_to_page == True:

                data = request.data
                serializer = self.ObjectSerializer(data=data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)




# VisitorFine API
class VisitorFineList(APIView):
    permission_classes = (IsAuthenticated,)


    def get_object(self):
        try:
            return VisitorFine.objects.all()
        except:
            raise Http404

    ObjectSerializer = VisitorFineSerializer
    model_name = "VisitorFine"

    def get(self, request, format=None):
        limit = int(request.GET.get('limit',10))
        offset = int(request.GET.get('offset',0))

        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'visitor_fine' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['visitor_fine']:
                    acess_to_page = True
            if acess_to_page == True:

                queryset = VisitorFine.objects.order_by('-id').all()[offset:limit+offset]
                queryset_count = VisitorFine.objects.count()
                serializer = self.ObjectSerializer(queryset, many=True)
                return Response({'count':queryset_count, 'results': serializer.data})
                #return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def post(self, request, format=None):
        # serializer = CompanyDetailSerializer(data=request.data)
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'visitor_fine' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['visitor_fine']:
                    acess_to_page = True
            if acess_to_page == True:
                data = request.data
                visitor_provided_accessory_id = data.get('visitor_provided_accessory_id')
                visitor_provided_accessory = VisitorProvidedAccessory.objects.get(pk=visitor_provided_accessory_id)
                data['default_accessory_provided_by_company'] = visitor_provided_accessory.default_accessory_provided_by_company_id.id
                print("data: ", visitor_provided_accessory_id, data['default_accessory_provided_by_company'])
                serializer = self.ObjectSerializer(data=data, context={'request': request})
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class VisitorFineDetail(APIView):
    permission_classes = (IsAuthenticated,)

    def get_object(self, pk):
        try:
            return VisitorFine.objects.get(pk=pk)
        except:
            raise Http404

    ObjectSerializer = VisitorFineSerializer

    def get(self, request, id=None, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'visitor_fine' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['visitor_fine']:
                    acess_to_page = True
            if acess_to_page == True:

                print(r'get details of id: ', id)
                
                queryset = self.get_object(pk=id)
                # serializer = CompanyDetailSerializer(queryset)
                serializer = self.ObjectSerializer(queryset)
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
            

    def put(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'visitor_fine' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['visitor_fine']:
                    acess_to_page = True
            if acess_to_page == True:
                queryset = self.get_object(pk=id)
                data=request.data
                visitor_provided_accessory_id = data.get('visitor_provided_accessory_id')
                visitor_provided_accessory = VisitorProvidedAccessory.objects.get(pk=visitor_provided_accessory_id)
                data['default_accessory_provided_by_company'] = visitor_provided_accessory.default_accessory_provided_by_company_id.id
                serializer = self.ObjectSerializer(queryset, data=data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'visitor_fine' in get_user_data['permission'].keys():
                if 'delete' in get_user_data['permission']['visitor_fine']:
                    acess_to_page = True
            if acess_to_page == True:
                queryset = self.get_object(pk=id)
                try:
                    queryset.delete()
                    return Response(status=status.HTTP_204_NO_CONTENT)
                except Exception as e:
                    return Response({"submit": "Cannot delete. This object is referenced by other objects."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


# VisitorAccessoryForFine API
class VisitorAccessoryForFineList(APIView):
    permission_classes = (IsAuthenticated,)

    def get_object(self):
        try:
            return VisitorAccessoryForFine.objects.all()
        except:
            raise Http404

    ObjectSerializer = VisitorAccessoryForFineSerializer
    model_name = "VisitorAccessoryForFine"

    def get(self, request, format=None):
        limit = int(request.GET.get('limit',10))
        offset = int(request.GET.get('offset',0))
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'visitor_accessor_for_fine' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['visitor_accessor_for_fine']:
                    acess_to_page = True
            if acess_to_page == True:

                queryset = VisitorAccessoryForFine.objects.order_by('-id').all()[offset:limit+offset]
                queryset_count = VisitorAccessoryForFine.objects.count()
                serializer = self.ObjectSerializer(queryset, many=True)
                return Response({'count':queryset_count, 'results': serializer.data})
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def post(self, request, format=None):
        # serializer = CompanyDetailSerializer(data=request.data)
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'visitor_accessor_for_fine' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['visitor_accessor_for_fine']:
                    acess_to_page = True
            if acess_to_page == True:
                data = request.data
                serializer = self.ObjectSerializer(data=data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class VisitorAccessoryForFineDetail(APIView):
    permission_classes = (IsAuthenticated,)

    def get_object(self, pk):
        try:
            return VisitorAccessoryForFine.objects.get(pk=pk)
        except:
            raise Http404

    ObjectSerializer = VisitorAccessoryForFineSerializer

    def get(self, request, id=None, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'visitor_accessor_for_fine' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['visitor_accessor_for_fine']:
                    acess_to_page = True
            if acess_to_page == True:

                print(r'get details of id: ', id)

                queryset = self.get_object(pk=id)
                # serializer = CompanyDetailSerializer(queryset)
                serializer = self.ObjectSerializer(queryset)
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)



    def put(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'visitor_accessor_for_fine' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['visitor_accessor_for_fine']:
                    acess_to_page = True
            if acess_to_page == True:
                queryset = self.get_object(pk=id)
                print("PUT request ", id, queryset, request.data)
                # serializer = CompanyDetailSerializer(queryset, data=request.data)
                serializer = self.ObjectSerializer(queryset, data=request.data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'visitor_accessor_for_fine' in get_user_data['permission'].keys():
                if 'delete' in get_user_data['permission']['visitor_accessor_for_fine']:
                    acess_to_page = True
            if acess_to_page == True:
                queryset = self.get_object(pk=id)
                try:
                    queryset.delete()
                    return Response(status=status.HTTP_204_NO_CONTENT)
                except Exception as e:
                    return Response({"submit": "Cannot delete. This object is referenced by other objects."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


# AccessoryProvided API
class AccessoryProvidedList(APIView):
    permission_classes = (IsAuthenticated,)


    def get_object(self):
        try:
            return AccessoryProvided.objects.all()
        except:
            raise Http404

    ObjectSerializer = AccessoryProvidedSerializer
    model_name = "AccessoryProvided"

    def get(self, request, format=None):
        limit = int(request.GET.get('limit',10))
        offset = int(request.GET.get('offset',0))
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'accessory_provided' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['accessory_provided']:
                    acess_to_page = True
            if acess_to_page == True:

                queryset = AccessoryProvided.objects.order_by('-id').all()[offset:limit+offset]
                queryset_count = AccessoryProvided.objects.count()
                serializer = self.ObjectSerializer(queryset, many=True)
                return Response({'count':queryset_count, 'results': serializer.data})
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def post(self, request, format=None):
        # serializer = CompanyDetailSerializer(data=request.data)
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'accessory_provided' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['accessory_provided']:
                    acess_to_page = True
            if acess_to_page == True:
                data = request.data
                serializer = self.ObjectSerializer(data=data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class AccessoryProvidedDetail(APIView):
    permission_classes = (IsAuthenticated,)

    def get_object(self, pk):
        try:
            return AccessoryProvided.objects.get(pk=pk)
        except:
            raise Http404

    ObjectSerializer = AccessoryProvidedSerializer

    def get(self, request, id=None, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'accessory_provided' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['accessory_provided']:
                    acess_to_page = True
            if acess_to_page == True:

                print(r'get details of id: ', id)
                
                queryset = self.get_object(pk=id)
                # serializer = CompanyDetailSerializer(queryset)
                serializer = self.ObjectSerializer(queryset)
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)



    def put(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'accessory_provided' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['accessory_provided']:
                    acess_to_page = True
            if acess_to_page == True:
                queryset = self.get_object(pk=id)
                print("PUT request ", id, queryset, request.data)
                # serializer = CompanyDetailSerializer(queryset, data=request.data)
                serializer = self.ObjectSerializer(queryset, data=request.data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'accessory_provided' in get_user_data['permission'].keys():
                if 'delete' in get_user_data['permission']['accessory_provided']:
                    acess_to_page = True
            if acess_to_page == True:
                queryset = self.get_object(pk=id)
                try:
                    queryset.delete()
                    return Response(status=status.HTTP_204_NO_CONTENT)
                except Exception as e:
                    return Response({"submit": "Cannot delete. This object is referenced by other objects."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


# AccessoryReturn API
class AccessoryReturnList(APIView):
    permission_classes = (IsAuthenticated,)


    def get_object(self):
        try:
            return AccessoryReturn.objects.all()
        except:
            raise Http404

    ObjectSerializer = AccessoryReturnSerializer
    model_name = "AccessoryReturn"

    def get(self, request, format=None):
        limit = int(request.GET.get('limit',10))
        offset = int(request.GET.get('offset',0))
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'accessory_return' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['accessory_return']:
                    acess_to_page = True
            if acess_to_page == True:

                queryset =  AccessoryReturn.objects.order_by('-id').all()[offset:limit+offset]
                queryset_count = AccessoryReturn.objects.count()
                serializer = self.ObjectSerializer(queryset, many=True)
                return Response({'count':queryset_count, 'results': serializer.data})
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def post(self, request, format=None):
        # serializer = CompanyDetailSerializer(data=request.data)
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'accessory_return' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['accessory_return']:
                    acess_to_page = True
            if acess_to_page == True:
                data = request.data
                serializer = self.ObjectSerializer(data=data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class AccessoryReturnDetail(APIView):
    permission_classes = (IsAuthenticated,)

    def get_object(self, pk):
        try:
            return AccessoryReturn.objects.get(pk=pk)
        except:
            raise Http404

    ObjectSerializer = AccessoryReturnSerializer

    def get(self, request, id=None, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'accessory_return' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['accessory_return']:
                    acess_to_page = True
            if acess_to_page == True:

                print(r'get details of id: ', id)
                
                queryset = self.get_object(pk=id)
                # serializer = CompanyDetailSerializer(queryset)
                serializer = self.ObjectSerializer(queryset)
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


    def put(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'accessory_return' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['accessory_return']:
                    acess_to_page = True
            if acess_to_page == True:
                queryset = self.get_object(pk=id)
                print("PUT request ", id, queryset, request.data)
                # serializer = CompanyDetailSerializer(queryset, data=request.data)
                serializer = self.ObjectSerializer(queryset, data=request.data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'accessory_return' in get_user_data['permission'].keys():
                if 'delete' in get_user_data['permission']['accessory_return']:
                    acess_to_page = True
            if acess_to_page == True:
                queryset = self.get_object(pk=id)
                try:
                    queryset.delete()
                    return Response(status=status.HTTP_204_NO_CONTENT)
                except Exception as e:
                    return Response({"submit": "Cannot delete. This object is referenced by other objects."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


# VisitorHaveAccessory API
class VisitorHaveAccessoryList(APIView):
    permission_classes = (IsAuthenticated,)


    def get_object(self):
        try:
            return VisitorHaveAccessory.objects.all()
        except:
            raise Http404

    ObjectSerializer = VisitorHaveAccessorySerializer
    model_name = "VisitorHaveAccessory"

    def get(self, request, format=None):
        limit = int(request.GET.get('limit',10))
        offset = int(request.GET.get('offset',0))
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'visitor_have_accessory' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['visitor_have_accessory']:
                    acess_to_page = True
            if acess_to_page == True:

                queryset = VisitorHaveAccessory.objects.order_by('-id').all()[offset:limit+offset]
                queryset_count = VisitorHaveAccessory.objects.count()
                serializer = self.ObjectSerializer(queryset, many=True)
                return Response({'count':queryset_count, 'results': serializer.data})
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def post(self, request, format=None):
        # serializer = CompanyDetailSerializer(data=request.data)
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'visitor_have_accessory' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['visitor_have_accessory']:
                    acess_to_page = True
            if acess_to_page == True:
                data = request.data
                serializer = self.ObjectSerializer(data=data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class VisitorHaveAccessoryDetail(APIView):
    def get_object(self, pk):
        try:
            return VisitorHaveAccessory.objects.get(pk=pk)
        except:
            raise Http404

    ObjectSerializer = VisitorHaveAccessorySerializer

    def get(self, request, id=None, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'visitor_have_accessory' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['visitor_have_accessory']:
                    acess_to_page = True
            if acess_to_page == True:

                print(r'get details of id: ', id)
                
                queryset = self.get_object(pk=id)
                # serializer = CompanyDetailSerializer(queryset)
                serializer = self.ObjectSerializer(queryset)
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)



    def put(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'visitor_have_accessory' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['visitor_have_accessory']:
                    acess_to_page = True
            if acess_to_page == True:
                queryset = self.get_object(pk=id)
                print("PUT request ", id, queryset, request.data)
                # serializer = CompanyDetailSerializer(queryset, data=request.data)
                serializer = self.ObjectSerializer(queryset, data=request.data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'visitor_have_accessory' in get_user_data['permission'].keys():
                if 'delete' in get_user_data['permission']['visitor_have_accessory']:
                    acess_to_page = True
            if acess_to_page == True:
                queryset = self.get_object(pk=id)
                try:
                    queryset.delete()
                    return Response(status=status.HTTP_204_NO_CONTENT)
                except Exception as e:
                    return Response({"submit": "Cannot delete. This object is referenced by other objects."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


# AccessoryAllow API
class AccessoryAllowList(APIView):
    permission_classes = (IsAuthenticated,)


    def get_object(self):
        try:
            return AccessoryAllow.objects.all()
        except:
            raise Http404

    ObjectSerializer = AccessoryAllowSerializer
    model_name = "AccessoryAllow"

    def get(self, request, format=None):
        limit = int(request.GET.get('limit',10))
        offset = int(request.GET.get('offset',0))
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'accessory_allow' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['accessory_allow']:
                    acess_to_page = True
            if acess_to_page == True:

                queryset = AccessoryAllow.objects.order_by('-id').all()[offset:limit+offset]
                queryset_count = AccessoryAllow.objects.count()
                serializer = self.ObjectSerializer(queryset, many=True)
                return Response({'count':queryset_count, 'results': serializer.data})
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def post(self, request, format=None):
        # serializer = CompanyDetailSerializer(data=request.data)
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'accessory_allow' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['accessory_allow']:
                    acess_to_page = True
            if acess_to_page == True:
                data = request.data
                serializer = self.ObjectSerializer(data=data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class AccessoryAllowDetail(APIView):
    permission_classes = (IsAuthenticated,)


    def get_object(self, pk):
        try:
            return AccessoryAllow.objects.get(pk=pk)
        except:
            raise Http404

    ObjectSerializer = AccessoryAllowSerializer

    def get(self, request, id=None, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'accessory_allow' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['accessory_allow']:
                    acess_to_page = True
            if acess_to_page == True:

                print(r'get details of id: ', id)
                
                queryset = self.get_object(pk=id)
                # serializer = CompanyDetailSerializer(queryset)
                serializer = self.ObjectSerializer(queryset)
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)



    def put(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'accessory_allow' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['accessory_allow']:
                    acess_to_page = True
            if acess_to_page == True:
                queryset = self.get_object(pk=id)
                print("PUT request ", id, queryset, request.data)
                # serializer = CompanyDetailSerializer(queryset, data=request.data)
                serializer = self.ObjectSerializer(queryset, data=request.data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'accessory_allow' in get_user_data['permission'].keys():
                if 'delete' in get_user_data['permission']['accessory_allow']:
                    acess_to_page = True
            if acess_to_page == True:
                queryset = self.get_object(pk=id)
                try:
                    queryset.delete()
                    return Response(status=status.HTTP_204_NO_CONTENT)
                except Exception as e:
                    return Response({"submit": "Cannot delete. This object is referenced by other objects."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
        


# RegisterVisitor
class RegisterVisitor(APIView):
    permission_classes = (AllowAny,)

    def post(self, request, format=None):
        data = {'email': request.data['email']}
        add_user_emails = AddUserEmail.objects.filter(email=request.data['email']).values('email').first()

        print("add_user_emails", add_user_emails)
        if add_user_emails == None:

            serializer = UserSerializer(
                data={'email': request.data['email'], 'password': request.data['password'],
                      'password2': request.data['password'],
                      'phone_number': request.data['phone_number'], 'user_login_or_not': False, 'is_superuser': False,
                      'is_active': True, "time_zone": "India", "is_staff": False, "user_type": "Visitor",
                      })

            print("user initial serializer: ", serializer.initial_data)
            user_id = None
            if serializer.is_valid():
                print("user data saved")
                print("user post serializer: ", serializer.validated_data)
                obj = serializer.save()
                user_id = obj.id
                print("obj.id", obj.id)
            else:
                print("UserSerializer error")
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                      

            serializer = VisitorDetailSerializer(
                data={
                    "email": request.data['email'],
                    "designation": request.data['designation'],
                    "phone_number": request.data['phone_number'],
                    "company_type": request.data['company_type'],
                    "company_name": request.data['company_name'],
                    "user_id": user_id,
                    "company_detail_id":request.data['company_detail_id']
                }, partial=True)

            print("user initial serializer: ", serializer.initial_data)
            #user_id = None
            if serializer.is_valid():
                print("Visitor data saved")
                print("Visitor post serializer: ", serializer.validated_data)
                obj = serializer.save()
                 # Check if email exists in VisitorRequest
                visitor_detail = VisitorDetail.objects.get(pk=obj.id)
                user = User.objects.get(pk=user_id)
                print("visitor_detail: ", visitor_detail)
                visitor_request = VisitorRequest.objects.filter(email=request.data['email']).first()
                if visitor_request:
                    if visitor_request.visitor_detail_id is None:
                        visitor_request.visitor_detail_id = visitor_detail
                        visitor_request.visitor_user_id = user
                        print("visitor_detail_id: ",visitor_request.visitor_detail_id)
                        visitor_request.save()
                        print("visitor_request: ", visitor_request)
                # user_id = obj.id
                # print("obj.id", obj.id)
            else:
                User.objects.filter(id=user_id).delete()
                print("VisitorSerializer error")
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

            return Response({'Visitor_detail': "Visitor Registered"}, status=status.HTTP_201_CREATED)

            # UserRoleMapping  # not modifying UserRoleMapping Not modifying UserRoleMapping for Visitor, sending directly role
            # user_role_mapping_data={}

        else:
            print("Yes")
            return Response({"result": {}, "message": "Visitor already register with this email."},
                            status=status.HTTP_400_BAD_REQUEST)

class VisitorLogin(APIView):
    permission_classes = (AllowAny,)

    def post(self, request, format=None):
        serializer = UserLoginSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        email = serializer.data.get('email')
        password = serializer.data.get('password')
        print(email, password)
        user = authenticate(email=email, password=password)
        print("is user none ? ", user)

        try:
            company_detail_id = request.data["company_detail_id"]
            visitor = VisitorDetail.objects.filter(company_detail_id=company_detail_id,user_id=user.id).first()
            if visitor == None:
                return Response({"detail": "Visitor is not registered with this company."}, status=status.HTTP_400_BAD_REQUEST)

        except KeyError:
            return Response({"error": "company detail is required"}, status=status.HTTP_400_BAD_REQUEST)

        company_detail_id = request.data["company_detail_id"]

        sub_company_id= request.data.get("sub_company_id")

        if not sub_company_id:
            sub_company_id = None

        if user:
            print(user, user.id)
            user_detail = {}
            if user.is_active:
                if user.is_verified:
                    refresh = RefreshToken.for_user(user)

                    user_detail['refresh'] = str(refresh)
                    user_detail['access'] = str(refresh.access_token)

                    user_detail["data"] = getVisitorUserDataLogin(user.id, company_detail_id, sub_company_id)
                    print("user_detail", user_detail)

                    # VisitorLogs
                    visitor_login_log_data = {"user_id": user.id,
                                            "company_detail_id": request.data["company_detail_id"],
                                            "date_time": datetime.now(),
                                            "sub_company_id":sub_company_id}

                    print(visitor_login_log_data)

                    visitor_login_log_serializer = VisitorLoginLogSerializer(data=visitor_login_log_data)
                    if visitor_login_log_serializer.is_valid():
                        visitor_login_log_serializer.save()
                    else:
                        # print("VisitorSerializer error")
                        return Response(visitor_login_log_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

                    return JsonResponse(user_detail, status=status.HTTP_200_OK)
                else:
                    return Response({"submit":"Please Verify your email."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                res = {"code": 400, "message": "Account was not active."}
                return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)
        else:
            res = {"code": 400, "message": "Invalid Username and Password."}
            return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)


class VisitorRequestByEmployeeView(APIView):
    permission_classes = [IsAuthenticated]


    def get_object(self):
        try:
            return DefaultVisitorHaveAccessory.objects.all()
        except DefaultVisitorHaveAccessory.DoesNotExist:
            raise Http404

    def post(self, request):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'visitor_request_by' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['visitor_request_by']:
                    acess_to_page = True
            if acess_to_page == True:
                print(request.data)
                sub_company_detail_id = None
                if len(get_user_data['sub_company']) > 0:
                    sub_company_detail_id = get_user_data['sub_company']['id']
                company_detail_id = request.user.company_detail_id.id
                print("company_detail_id: ", company_detail_id)
                user_email = request.user
                print("user email: ", user_email)

                from_date_str = request.data["from_date"]
                to_date_str = request.data["to_date"]
                from_date = datetime.fromisoformat(from_date_str[:-1])
                to_date = datetime.fromisoformat(to_date_str[:-1])
                duration = to_date - from_date
                duration_in_days = duration.days
                print("duration_in_days", duration_in_days)

                try:
                    employee = Employee.objects.get(email=user_email)
                    employee_id = employee.id
                    employee_name = employee.name

                    # user=Employee.objects.get(email=request.user)

                except Employee.DoesNotExist:
                    # # employee = User.objects.get(email=request.user)
                    # employee_id = "null"
                    # employee_name = "null"  # there is no field "name in User"
                    return Response({"message": "Employee has not access to make visitor request"})
                
                # Check if the provided email is in AddUserEmail
                visitor_email = request.data["email"]
                visitor_detail_id = None

                try:
                    add_user_email = AddUserEmail.objects.get(email=visitor_email, company_detail_id=company_detail_id, sub_company_id=sub_company_detail_id)
                except AddUserEmail.DoesNotExist:
                    add_user_email = None

                if add_user_email:
                    # Check if a visitor is registered with this email
                    try:
                        registered_visitor = VisitorRequest.objects.get(email=visitor_email, company_detail_id=company_detail_id, sub_company_id = sub_company_detail_id)
                        visitor_detail_id = registered_visitor.visitor_detail_id.id
                    except VisitorRequest.DoesNotExist:
                        visitor_detail_id = None

                to_date = request.data["from_date"]
                from_date = request.data["to_date"]
                # Convert the date strings to datetime objects
                to_date = parser.isoparse(to_date_str)
                from_date = parser.isoparse(from_date_str)
                # Calculate the difference in days
                visit_day = (to_date - from_date).days
                #matching_approval_change_ids = []

                # Query ApprovalChangeByNumberOfDays for matching date ranges
                matching_approvals = ApprovalChangeByNumberOfDays.objects.filter(
                    from_days__lte=visit_day,
                    to_days__gte=visit_day, company_detail_id = company_detail_id, sub_company_id = sub_company_detail_id
                ).first()

                if matching_approvals:
                    approval_change_by_number_of_days_id = matching_approvals.id
                else:
                    return Response({"submit": "Please select other dates. Approval change by number of days range not matched"}, status=status.HTTP_400_BAD_REQUEST)

                emp = Employee.objects.filter(pk=employee_id).first()
                print("department_id :", emp.department_id.id)

                visitor_request_data = {
                    "email": visitor_email,  # Visitor Email
                    "department_id": emp.department_id.id,
                    "from_date": from_date,
                    "to_date": to_date,
                    "purpose_of_visit": request.data["purpose_of_visit"],

                    "duration": duration_in_days,
                    "company_detail_id": company_detail_id,
                    "sub_company_id": sub_company_detail_id,

                    "employee_id": employee_id,
                    "employee_name": employee_name,
                    "visitor_detail_id":visitor_detail_id,
                    "approval_change_by_number_of_days_id": approval_change_by_number_of_days_id,
                    "type":"Employee"
                }
                visitor_serializer = VisitorRequestSerializer(data=visitor_request_data)
                visitor_request_id = None
                if visitor_serializer.is_valid():
                    obj = visitor_serializer.save()
                    visitor_request_id = obj.id

                else:
                    print("Visitor_request Serializer error")
                    return Response(visitor_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

                print(request.data["visitor_have_accessory"])

                data = request.data.get('visitor_have_accessory')
                print("data: ", data)
                for obj in data:
                    obj['user_id'] = None
                    obj['approval'] = False
                    obj['in_accessory'] = False
                    obj['out_accessory'] = False
                    obj['visitor_request_id'] = visitor_request_id
                    if obj["default_visitor_have_accessory_id"] == None:
                        del obj["default_visitor_have_accessory_id"]

                    print("obj", obj)

                # create an instance of the serializer with the default values set
                serializer = VisitorHaveAccessorySerializer(data=data, many=True)

                if serializer.is_valid():
                    serializer.save()
                else:
                    print("serializer error")
                    #VisitorRequest.objects.filter(email=visitor_email).delete()
                    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

                data = request.data.get('visitor_provided_accessory')
                for obj in data:
                    obj['user_id'] = None
                    obj['approval'] = False
                    obj['in_accessory'] = False
                    obj['out_accessory'] = False
                    obj['visitor_request_id'] = visitor_request_id

                    print("obj", obj)

                # create an instance of the serializer with the default values set
                serializer = VisitorProvidedAccessorySerializer(data=data, many=True)

                if serializer.is_valid():
                    serializer.save()

                else:
                    print("serializer error")
                    # VisitorHaveAccessory.objects.filter(visitor_request_id=visitor_request_id).delete()
                    # VisitorRequest.objects.filter(email=visitor_email).delete()
                    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                
                    
               # First, filter ApprovalType objects based on company_detail_id
                approval_types = ApprovalType.objects.filter(company_detail_id=company_detail_id)

                # Check if there are any ApprovalType objects with default_approval=False
                default_approval_false = approval_types.filter(default_approval=False).exists()

                if default_approval_false:
                    # Get the ApprovalType with approval_name="Hold"
                    hold_approval_type = approval_types.filter(approval_name="Hold").first()


                # Query ApprovalStepByRole based on the matching ids
                approval_steps = ApproveStepByRole.objects.filter(
                    approval_change_by_number_of_days_id=approval_change_by_number_of_days_id, company_detail_id = company_detail_id,
                    sub_company_id = sub_company_detail_id
                ).first()
                    

                approval_data = {
                    "approval_type_id": hold_approval_type.id,
                    "visitor_request_id": visitor_request_id,
                    "role_id":approval_steps.role_id.id,
                    "final_approval": False,
                    "approval_change_by_number_of_days_id": approval_change_by_number_of_days_id,
                    "approval_step_by_role_id": approval_steps.id,
                }

                approval_serializer = ApprovalSerializer(data=approval_data)
                approval_serializer_id = None
                if approval_serializer.is_valid():
                    obj = approval_serializer.save()
                    approval_serializer_id = obj.id

                else:
                    print("Approval Serializer error")
                    # VisitorProvidedAccessory.objects.filter(visitor_request_id=visitor_request_id).delete()
                    # VisitorHaveAccessory.objects.filter(visitor_request_id=visitor_request_id).delete()
                    # VisitorRequest.objects.filter(email=visitor_email).delete()
                    return Response(approval_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

                return Response(visitor_serializer.data)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def get(self, request):
        limit = int(request.GET.get('limit', 20))
        offset = int(request.GET.get('offset', 0))
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'visitor_request_by' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['visitor_request_by']:
                    acess_to_page = True
            if acess_to_page == True:

                print("Getting all Data")
                print("user", request.user.id)
                sub_company_detail_id = None
                if len(get_user_data['sub_company']) > 0:
                    sub_company_detail_id = get_user_data['sub_company']['id']

                employee = Employee.objects.filter(email=request.user.email).first()
                employee_id = employee.id

                visitor_requests = VisitorRequest.objects.all()
                visitor_requests = VisitorRequest.objects.filter(
                    company_detail_id=request.user.id)
                visitor_requests = VisitorRequest.objects.filter(company_detail_id=request.user.company_detail_id, sub_company_id = sub_company_detail_id,
                                                                employee_id=employee.id)

                if not visitor_requests.exists():
                    print("visitor_requests is empty")
                    return Response({"message": "No visitor requests data"})

                print("visitor_requests", visitor_requests)
                # Convert each instance to a dictionary and add it to a list
                my_model_dict_list = []
                for instance in visitor_requests:
                    my_model_dict = model_to_dict(instance)
                    my_model_dict_list.append(my_model_dict)

                serializer = VisitorRequestListSerializer(visitor_requests, many=True)

                visitor_requests_data_list = []
                for visitor_request1 in my_model_dict_list:
                    print("visitor_request", visitor_request1)
                    visitor_request_id = visitor_request1['id']
                    print("visitor_request_id", visitor_request_id)
                    visitor_request = VisitorRequest.objects.get(id=visitor_request_id)
                    visitor_request_serializer = VisitorRequestSerializer(visitor_request)
                    visitor_have_accessory_queryset = VisitorHaveAccessory.objects.filter(
                        visitor_request_id=visitor_request_id)
                    visitor_have_accessory_serializer = VisitorHaveAccessorySerializer(visitor_have_accessory_queryset,
                                                                                    many=True)

                    visitor_provided_accessory_queryset = VisitorProvidedAccessory.objects.filter(
                        visitor_request_id=visitor_request_id)
                    visitor_provided_accessory_serializer = VisitorProvidedAccessorySerializer(
                        visitor_provided_accessory_queryset,
                        many=True)

                    # data = {
                    #     'visitor_request': visitor_request_serializer.data,
                    #     'visitor_have_accessory': visitor_have_accessory_serializer.data,
                    # }

                    print("visitor_request_serializer", visitor_request_serializer.data)

                    visitor_requests_data = {
                        "id": visitor_request_serializer.data["id"],
                        "email": visitor_request_serializer.data["email"],
                        "department_id": visitor_request_serializer.data["department_id"],
                        "department": visitor_request_serializer.data["department"],
                        "from_date": visitor_request_serializer.data["from_date"],
                        "to_date": visitor_request_serializer.data["to_date"],
                        "purpose_of_visit": visitor_request_serializer.data["purpose_of_visit"],
                        "visitor_detail_id":visitor_request_serializer.data["visitor_detail_id"]
                    }

                    visitor_have_accessory_data = []
                    for data in visitor_have_accessory_serializer.data:
                        new_data = {
                            "id": data["id"],
                            "default_visitor_have_accessory": data.get("default_visitor_have_accessory", "N/A"),
                            "accessory_name": data.get("accessory_name", "N/A"),
                            "default_visitor_have_accessory_id": data.get("default_visitor_have_accessory_id", "N/A")
                        }
                        visitor_have_accessory_data.append(new_data)
                    print("visitor_have_accessory_data", visitor_have_accessory_data)

                    visitor_provided_accessory_data = []
                    for data in visitor_provided_accessory_serializer.data:
                        new_data = {
                            "id": data["id"],
                            "default_accessory_provided_by_company_id": data.get("default_accessory_provided_by_company_id",
                                                                                "N/A"),
                            "default_accessory_provided_by_company": data.get("default_accessory_provided_by_company",
                                                                            "N/A")
                        }
                        visitor_provided_accessory_data.append(new_data)

                    visitor_requests_data["visitor_have_accessory"] = visitor_have_accessory_data
                    visitor_requests_data["visitor_provided_accessory"] = visitor_provided_accessory_data
                    visitor_requests_data_list.append(visitor_requests_data)
                    visitor_requests_data_list = sorted(visitor_requests_data_list, key=lambda x: x['id'], reverse=True)
                    visitor_requests_data_list1 = visitor_requests_data_list[offset:offset+limit] 
                    visitor_requests_data_list_count = len(visitor_requests_data_list)


                return Response({"count": visitor_requests_data_list_count, "results": visitor_requests_data_list1})

            
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
    
class VisitorRequestByEmployeeDetailView(APIView):
    permission_classes = [IsAuthenticated]

    pagination_class = LimitOffsetPagination

    def get_object(self, pk):
        try:
            return DefaultVisitorHaveAccessory.objects.get(pk=pk)
        except DefaultVisitorHaveAccessory.DoesNotExist:
            raise Http404

    def get(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'visitor_request_by' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['visitor_request_by']:
                    acess_to_page = True
            if acess_to_page == True:

                visitor_request_id = id
                # , company_detail_id=request.user.id
                try:
                    employee = Employee.objects.filter(email=request.user.email).first()
                    employee_id = employee.id
                    visitor_request = VisitorRequest.objects.get(id=visitor_request_id,
                                                                employee_id=employee.id)
                    print("visitor_request specific", visitor_request)
                except VisitorRequest.DoesNotExist:
                    return Response(status=status.HTTP_404_NOT_FOUND)

                visitor_request_serializer = VisitorRequestSerializer(visitor_request)

                visitor_have_accessory_queryset = VisitorHaveAccessory.objects.filter(visitor_request_id=visitor_request_id)
                visitor_have_accessory_serializer = VisitorHaveAccessorySerializer(visitor_have_accessory_queryset,
                                                                                many=True)

                # default_visitor_have_accessory_queryset = DefaultVisitorHaveAccessory.objects.all()
                # default_visitor_have_accessory_serializer = DefaultVisitorHaveAccessorySerializer(
                #     default_visitor_have_accessory_queryset, many=True)

                visitor_provided_accessory_queryset = VisitorProvidedAccessory.objects.filter(
                    visitor_request_id=visitor_request_id)
                visitor_provided_accessory_serializer = VisitorProvidedAccessorySerializer(
                    visitor_provided_accessory_queryset,
                    many=True)
                # default_accessory_provided_by_company_queryset = DefaultAccessoryProvidedByCompany.objects.all()
                # default_accessory_provided_by_company_serializer = DefaultAccessoryProvidedByCompanySerializer(
                #     default_accessory_provided_by_company_queryset, many=True)

                data = {
                    'visitor_request': visitor_request_serializer.data,
                    'visitor_have_accessory': visitor_have_accessory_serializer.data,

                }

                visitor_requests_data = {
                    "id": visitor_request_serializer.data["id"],
                    "email": visitor_request_serializer.data["email"],
                    "department_id": visitor_request_serializer.data["department_id"],
                    "department": visitor_request_serializer.data["department"],
                    "from_date": visitor_request_serializer.data["from_date"],
                    "to_date": visitor_request_serializer.data["to_date"],
                    "purpose_of_visit": visitor_request_serializer.data["purpose_of_visit"]
                }

                visitor_have_accessory_data = []
                for data in visitor_have_accessory_serializer.data:
                    new_data = {
                        "id": data["id"],
                        "default_visitor_have_accessory": data.get("default_visitor_have_accessory", "N/A"),
                        "accessory_name": data.get("accessory_name", "N/A"),
                        "default_visitor_have_accessory_id": data.get("default_visitor_have_accessory_id", "N/A")
                    }
                    visitor_have_accessory_data.append(new_data)
                print("visitor_have_accessory_data", visitor_have_accessory_data)

                visitor_provided_accessory_data = []
                for data in visitor_provided_accessory_serializer.data:
                    new_data = {
                        "id": data["id"],
                        "default_accessory_provided_by_company_id": data.get("default_accessory_provided_by_company_id",
                                                                            "N/A"),
                        "default_accessory_provided_by_company": data.get("default_accessory_provided_by_company", "N/A")
                    }
                    visitor_provided_accessory_data.append(new_data)
                print("visitor_provided_accessory_data", visitor_provided_accessory_data)

                visitor_requests_data["visitor_have_accessory"] = visitor_have_accessory_data
                visitor_requests_data["visitor_provided_accessory"] = visitor_provided_accessory_data

                return Response(visitor_requests_data)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'visitor_request_by' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['visitor_request_by']:
                    acess_to_page = True
            if acess_to_page == True:

                company_detail_id = request.user.company_detail_id_id
                sub_company_detail_id = None
                if len(get_user_data['sub_company']) > 0:
                    sub_company_detail_id = get_user_data['sub_company']['id']

                try:
                    visitor_request1 = VisitorRequest.objects.get(pk=id)
                except VisitorRequest.DoesNotExist:
                    raise Http404

                from_date_str = request.data["from_date"]
                to_date_str = request.data["to_date"]
                from_date = datetime.fromisoformat(from_date_str[:-1])
                to_date = datetime.fromisoformat(to_date_str[:-1])
                duration = to_date - from_date
                duration_in_days = duration.days
                print("duration_in_days", duration_in_days)

                try:
                    employee = Employee.objects.filter(email=request.user.email).first()
                    employee_id = employee.id
                    employee_name = employee.name

                    # user=Employee.objects.get(email=request.user)

                except Employee.DoesNotExist:
                    # # employee = User.objects.get(email=request.user)
                    # employee_id = "null"
                    # employee_name = "null"  # there is no field "name in User"
                    return Response({"message": "Employee has not access to make visitor request"})

                visitor_request_data = {
                    "email": request.data["email"],  # Visitor Email
                    "department_id": request.data["department_id"],
                    "from_date": request.data["from_date"],
                    "to_date": request.data["to_date"],
                    "purpose_of_visit": request.data["purpose_of_visit"],

                    "duration": duration_in_days,
                    "company_detail_id": company_detail_id,
                    "sub_company_id": sub_company_detail_id,

                    "employee_id": employee_id,
                    "employee_name": employee_name,
                    "employee_id": employee_id,
                    # "visitor_user_id": request.user.id visitor login User Id
                }
                visitor_serializer = VisitorRequestSerializer(visitor_request1, data=visitor_request_data, partial=True)
                if visitor_serializer.is_valid():
                    visitor_serializer.save()
                else:
                    print("Serializer error")
                    return Response(visitor_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

                print(request.data["visitor_have_accessory"])

                # get data of VisitorHaveAccessory
                visitor_request_id = id

                visitor_have_accessory_list = VisitorHaveAccessory.objects.filter(
                    visitor_request_id=visitor_request_id).values()

                # visitor_have_accessory_list = VisitorHaveAccessory.objects.filter(visitor_request_id=visitor_request_id).values(
                #     'id',
                #     "accessory_name",
                #     'default_visitor_have_accessory_id',  # Include the related default_visitor_have_accessory_id field
                #     # 'visitor_request_id',
                #     # 'user_id',
                #     # 'approval',
                #     # 'in_accessory',
                #     # 'out_accessory',
                # )

                VisitorHaveAccessory.objects.filter(visitor_request_id=visitor_request_id).delete()

                # visitor_have_accessory_list = list(visitor_have_accessory_list)
                # print("Initial Data:", visitor_have_accessory_list)
                #
                data = request.data.get('visitor_have_accessory')
                print("data for PUT: ", data)

                visitor_request_id = id
                for obj in data:
                    obj['user_id'] = None
                    obj['approval'] = False
                    obj['in_accessory'] = False
                    obj['out_accessory'] = False
                    obj['visitor_request_id'] = visitor_request_id
                    if obj["default_visitor_have_accessory_id"] == "null":
                        del obj["default_visitor_have_accessory_id"]

                    print("obj", obj)

                # create an instance of the serializer with the default values set
                serializer = VisitorHaveAccessorySerializer(data=data, many=True)

                if serializer.is_valid():
                    serializer.save()
                else:
                    print("serializer error")
                    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

                VisitorProvidedAccessory.objects.filter(visitor_request_id=visitor_request_id).delete()
                data = request.data.get('visitor_provided_accessory')
                for obj in data:
                    obj['user_id'] = None
                    obj['approval'] = False
                    obj['in_accessory'] = False
                    obj['out_accessory'] = False
                    obj['visitor_request_id'] = visitor_request_id

                    print("obj", obj)

                # create an instance of the serializer with the default values set
                serializer = VisitorProvidedAccessorySerializer(data=data, many=True)

                if serializer.is_valid():
                    serializer.save()

                else:
                    print("serializer error")
                    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

                return Response({"message": "end"})
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'visitor_request_by' in get_user_data['permission'].keys():
                if 'delete' in get_user_data['permission']['visitor_request_by']:
                    acess_to_page = True
            if acess_to_page == True:

                company_detail_id = request.user.company_detail_id_id
                sub_company_detail_id = None
                if len(get_user_data['sub_company']) > 0:
                    sub_company_detail_id = get_user_data['sub_company']['id']
                try:
                    visitor_request1 = VisitorRequest.objects.get(pk=id)
                except VisitorRequest.DoesNotExist:
                    raise Http404

                try:
                    employee = Employee.objects.filter(email=request.user.email).first()
                    employee_id = employee.id
                    employee_name = employee.name
                except Employee.DoesNotExist:
                    return Response({"message": "Employee has not access to make visitor request"})

                
                try:
                    VisitorRequest.objects.filter(pk=id, company_detail_id=company_detail_id, sub_company_id = sub_company_detail_id,
                                            employee_id=employee_id).delete()
                    return Response(status=status.HTTP_204_NO_CONTENT)
                except Exception as e:
                    return Response({"submit": "Cannot delete. This object is referenced by other objects."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class VisitorProfileView(APIView):
    #permission_classes = [IsAuthenticated]

    # def get_company(self):
    #     User = get_user_model()
    #     user_email = self.request.user
    #     return (User.objects.filter(email=user_email).values('company_detail_id')[0]['company_detail_id'])

    def get(self, request):

        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'visitor_profile' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['visitor_profile']:
                    if get_user_data['role_detail']['role_name'] == 'Visitor':
                        acess_to_page = True
                if acess_to_page == True:
                    # Get the user ID from the JWT token
                    user_id = request.user.id

                    # Find the VisitorDetail instance with the matching user ID
                    try:
                        visitor_detail = VisitorDetails.objects.get(user_id=user_id)
                    except VisitorDetails.DoesNotExist:
                        return Response({'message': 'VisitorDetail not found for the authenticated user.'},
                                        status=status.HTTP_404_NOT_FOUND)

                    # Serialize the VisitorDetail instance and return it in the response data
                    serializer = VisitorDetailSerializer(visitor_detail)
                    return Response(serializer.data, status=status.HTTP_200_OK)
                
                else:
                    return Response({"submit": "You are not a visitor."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'visitor_profile' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['visitor_profile']:
                    if get_user_data['role_detail']['role_name'] == 'Visitor':

                        acess_to_page = True
                if acess_to_page == True:
                    print(request.data)
                    company_detail_id = request.user.company_detail_id
                    print("company_detail_id: ", company_detail_id)
                    user_email = request.user
                    print("user email: ", user_email)
                    print(request.auth.payload)
                    print(request.auth.payload["user_id"])
                    print(" request.user.id", request.user.id)

                    # Get the user ID from the JWT token
                    user_id = request.user.id

                    # Find the VisitorDetail instance with the matching user ID
                    try:
                        visitor_detail = VisitorDetails.objects.get(user_id=user_id)
                    except VisitorDetails.DoesNotExist:
                        return Response({'message': 'VisitorDetail not found for the authenticated user.'},
                                        status=status.HTTP_404_NOT_FOUND)

                    # Update the VisitorDetail instance with the request data
                    serializer = VisitorDetailSerializer(visitor_detail, data=request.data, partial=True)
                    print("before data  VisitorDetail", serializer.initial_data)
                    if serializer.is_valid():
                        serializer.save()
                        return Response(serializer.data, status=status.HTTP_200_OK)
                    else:
                        print("error in VisitorDetail", serializer.validated_data)
                        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                else:
                    return Response({"submit": "You are not a visitor."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

            


class VisitorRequestBySelfView(APIView):
    permission_classes = [IsAuthenticated]

    # pagination_class = LimitOffsetPagination

    def get_object(self):
        try:
            return DefaultVisitorHaveAccessory.objects.all()
        except DefaultVisitorHaveAccessory.DoesNotExist:
            raise Http404

    def get(self, request):
        get_user_data = getUserDataLogin(request.user.id)
        limit = int(request.GET.get('limit',10))
        offset = int(request.GET.get('offset',0))
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'visitor_request_by_self' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['visitor_request_by_self']:
                    if get_user_data['role_detail']['role_name'] == 'Visitor':
                        acess_to_page = True
                if acess_to_page == True:

                    print("Getting all Data")
                    print("user", request.user.id)

                    visitor_requests = VisitorRequest.objects.filter(visitor_user_id=request.user.id)

                    print(visitor_requests)
                    if not visitor_requests.exists():
                        print("visitor_requests is empty")
                        return Response({"message": "No visitor requests data"})

                    print("visitor_requests", visitor_requests)
                    # Convert each instance to a dictionary and add it to a list
                    my_model_dict_list = []
                    for instance in visitor_requests:
                        my_model_dict = model_to_dict(instance)
                        my_model_dict_list.append(my_model_dict)

                    serializer = VisitorRequestListSerializer(visitor_requests, many=True)

                    visitor_requests_data_list = []
                    for visitor_request1 in my_model_dict_list:
                        print("visitor_request", visitor_request1)
                        visitor_request_id = visitor_request1['id']
                        print("visitor_request_id", visitor_request_id)
                        visitor_request = VisitorRequest.objects.get(id=visitor_request_id)
                        visitor_request_serializer = VisitorRequestSerializer(visitor_request)
                        visitor_have_accessory_queryset = VisitorHaveAccessory.objects.filter(
                            visitor_request_id=visitor_request_id)
                        visitor_have_accessory_serializer = VisitorHaveAccessorySerializer(visitor_have_accessory_queryset,
                                                                                        many=True)

                        visitor_provided_accessory_queryset = VisitorProvidedAccessory.objects.filter(
                            visitor_request_id=visitor_request_id)
                        visitor_provided_accessory_serializer = VisitorProvidedAccessorySerializer(
                            visitor_provided_accessory_queryset,
                            many=True)

                        # data = {
                        #     'visitor_request': visitor_request_serializer.data,
                        #     'visitor_have_accessory': visitor_have_accessory_serializer.data,
                        # }

                        print("visitor_request_serializer", visitor_request_serializer.data)

                        visitor_requests_data = {
                            "id": visitor_request_serializer.data["id"],
                            "employee_name": visitor_request_serializer.data["employee_name"],
                            "email": visitor_request_serializer.data["email"],
                            "department_id": visitor_request_serializer.data["department_id"],
                            "department": visitor_request_serializer.data["department"],
                            "from_date": visitor_request_serializer.data["from_date"],
                            "to_date": visitor_request_serializer.data["to_date"],
                            "purpose_of_visit": visitor_request_serializer.data["purpose_of_visit"]
                        }

                        visitor_have_accessory_data = []
                        for data in visitor_have_accessory_serializer.data:
                            new_data = {
                                "id": data["id"],
                                "default_visitor_have_accessory": data.get("default_visitor_have_accessory", "N/A"),
                                "accessory_name": data.get("accessory_name", "N/A"),
                                "default_visitor_have_accessory_id": data.get("default_visitor_have_accessory_id", "N/A")
                            }
                            visitor_have_accessory_data.append(new_data)
                        print("visitor_have_accessory_data", visitor_have_accessory_data)

                        visitor_provided_accessory_data = []
                        for data in visitor_provided_accessory_serializer.data:
                            new_data = {
                                "id": data["id"],
                                "default_accessory_provided_by_company_id": data.get("default_accessory_provided_by_company_id",
                                                                                    "N/A"),
                                "default_accessory_provided_by_company": data.get("default_accessory_provided_by_company",
                                                                                "N/A")
                            }
                            visitor_provided_accessory_data.append(new_data)
                        print("visitor_provided_accessory_data", visitor_provided_accessory_data)

                        visitor_requests_data["visitor_have_accessory"] = visitor_have_accessory_data
                        visitor_requests_data["visitor_provided_accessory"] = visitor_provided_accessory_data
                        visitor_requests_data_list.append(visitor_requests_data)
                        visitor_requests_data_list = sorted(visitor_requests_data_list, key=lambda x: x['id'], reverse=True)
                        visitor_requests_data_list1 = visitor_requests_data_list[offset:limit+offset]
                        visitor_requests_data_list_count = len(visitor_requests_data_list)


                    return Response({"count": visitor_requests_data_list_count, "results": visitor_requests_data_list1})
                
                else:
                    return Response({"submit": "You are not Visitor."}, status=status.HTTP_400_BAD_REQUEST)

            
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def post(self, request):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'visitor_request_by_self' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['visitor_request_by_self']:
                    if get_user_data['role_detail']['role_name'] == 'Visitor':
                        acess_to_page = True
                if acess_to_page == True:
                    print(request.data)
                    # company_detail_id = request.user.company_detail_id
                    sub_company_detail_id = None
                    if len(get_user_data['sub_company']) > 0:
                        sub_company_detail_id = get_user_data['sub_company']['id']
                    company_detail_id = request.user.company_detail_id
                    print("company_detail_id: ", company_detail_id)
                    user_email = request.user
                    print("user email: ", user_email, type(user_email))

                    user_email = str(request.user.email)
                    print("user email: ", user_email, type(user_email))

                    from_date_str = request.data["from_date"]
                    to_date_str = request.data["to_date"]
                    from_date = datetime.fromisoformat(from_date_str[:-1])
                    to_date = datetime.fromisoformat(to_date_str[:-1])
                    duration = to_date - from_date
                    duration_in_days = duration.days
                    print("duration_in_days", duration_in_days)

                    # Fetch visitor_detail_id based on user_id and visitor_user_id
                    try:
                        visitor_detail = VisitorDetail.objects.get(user_id=request.user)
                    except VisitorDetail.DoesNotExist:
                        visitor_detail = None

                    if not visitor_detail:
                        return Response({"submit": "Visitor detail not found."}, status=status.HTTP_400_BAD_REQUEST)

                    to_date = request.data["from_date"]
                    from_date = request.data["to_date"]
                    # Convert the date strings to datetime objects
                    to_date = parser.isoparse(to_date_str)
                    from_date = parser.isoparse(from_date_str)
                    # Calculate the difference in days
                    visit_day = (to_date - from_date).days
                    #matching_approval_change_ids = []

                    # Query ApprovalChangeByNumberOfDays for matching date ranges
                    matching_approvals = ApprovalChangeByNumberOfDays.objects.filter(
                        from_days__lte=visit_day,
                        to_days__gte=visit_day, company_detail_id=company_detail_id, sub_company_id = sub_company_detail_id,
                    ).first()

                    if matching_approvals:
                        approval_change_by_number_of_days_id = matching_approvals.id
                    else:
                        return Response({"submit": "Please select other dates. Approval change by number of days range not matched"}, status=status.HTTP_400_BAD_REQUEST)
                    
                    visitor_request_data = {
                        "email": user_email,  # visitor email
                        "employee_name": None,
                        "department_id": request.data["department_id"],
                        "from_date": request.data["from_date"],
                        "to_date": request.data["to_date"],
                        "purpose_of_visit": request.data["purpose_of_visit"],

                        "duration": duration_in_days,
                        "company_detail_id":company_detail_id.id,
                        "sub_company_id": sub_company_detail_id,

                        "employee_id": None,
                        "visitor_user_id": request.user.id,
                        "visitor_detail_id": visitor_detail.id,
                        "approval_change_by_number_of_days_id": approval_change_by_number_of_days_id,
                        "type":"Self"

                    }
                    print("visitor_request_data: ", visitor_request_data)
                    serializer = VisitorRequestSerializer(data=visitor_request_data, partial=True)
                    visitor_request_id = None
                    if serializer.is_valid():
                        visitor_request = serializer.save()
                        visitor_request_id = visitor_request.id

                    else:
                        print("Serializer error")
                        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


                    print(request.data["visitor_have_accessory"])

                    data = request.data.get('visitor_have_accessory')
                    print("data: ", data)
                    for obj in data:
                        obj['user_id'] = None
                        obj['approval'] = False
                        obj['in_accessory'] = False
                        obj['out_accessory'] = False
                        obj['visitor_request_id'] = visitor_request_id
                        if obj["default_visitor_have_accessory_id"] == "null":
                            del obj["default_visitor_have_accessory_id"]

                        print("obj", obj)

                    # create an instance of the serializer with the default values set
                    serializer = VisitorHaveAccessorySerializer(data=data, many=True)

                    if serializer.is_valid():
                        serializer.save()
                    else:
                        print("serializer error")

                        VisitorRequest.objects.filter(id=visitor_request_id).delete()
                        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

                    request.data["visitor_provided_accessory"]
                    data = request.data.get('visitor_provided_accessory')
                    for obj in data:
                        obj['user_id'] = None
                        obj['approval'] = False
                        obj['in_accessory'] = False
                        obj['out_accessory'] = False
                        obj['visitor_request_id'] = visitor_request_id
                        if obj["default_accessory_provided_by_company_id"] == "null":
                            del obj["default_accessory_provided_by_company_id"]

                        print("obj", obj)

                    # create an instance of the serializer with the default values set
                    serializer = VisitorProvidedAccessorySerializer(data=data, many=True)

                    if serializer.is_valid():
                        serializer.save()

                    else:
                        print("serializer error")
                        VisitorHaveAccessory.objects.filter(visitor_request_id=visitor_request_id).delete()
                        VisitorRequest.objects.filter(id=visitor_request_id).delete()
                        # User.objects.filter(id=user_id).delete()
                        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                    
                    # First, filter ApprovalType objects based on company_detail_id
                    approval_types = ApprovalType.objects.filter(company_detail_id=company_detail_id)

                    # Check if there are any ApprovalType objects with default_approval=False
                    default_approval_false = approval_types.filter(default_approval=False).exists()

                    if default_approval_false:
                        # Get the ApprovalType with approval_name="Hold"
                        hold_approval_type = approval_types.filter(approval_name="Hold").first()


                    # Query ApprovalStepByRole based on the matching ids
                    approval_steps = ApproveStepByRole.objects.filter(
                        approval_change_by_number_of_days_id=approval_change_by_number_of_days_id, company_detail_id=company_detail_id,
                        sub_company_id = sub_company_detail_id
                    ).first()
                        

                    approval_data = {
                        "approval_type_id": hold_approval_type.id,
                        "visitor_request_id": visitor_request_id,
                        "role_id":approval_steps.role_id.id,
                        "final_approval": False,
                        "approval_change_by_number_of_days_id": approval_change_by_number_of_days_id,
                        "approval_step_by_role_id": approval_steps.id,
                    }

                    approval_serializer = ApprovalSerializer(data=approval_data)
                    approval_serializer_id = None
                    if approval_serializer.is_valid():
                        obj = approval_serializer.save()
                        approval_serializer_id = obj.id

                    else:
                        print("Approval Serializer error")
                        VisitorProvidedAccessory.objects.filter(visitor_request_id=visitor_request_id).delete()
                        VisitorHaveAccessory.objects.filter(visitor_request_id=visitor_request_id).delete()
                        VisitorRequest.objects.filter(id=visitor_request_id).delete()
                        return Response(approval_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

                    return Response({"success": "Visitor Request Successfully", "data": visitor_request_data})
                else:
                    return Response({"submit": "You are not Visitor."}, status=status.HTTP_400_BAD_REQUEST)

            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

class VisitorRequestBySelfDetailView(APIView):
    permission_classes = [IsAuthenticated]

    # pagination_class = LimitOffsetPagination

    def get_object(self, pk):
        try:
            return DefaultVisitorHaveAccessory.objects.get(pk=pk)
        except DefaultVisitorHaveAccessory.DoesNotExist:
            raise Http404

    def get(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'visitor_request_by_self' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['visitor_request_by_self']:
                    if get_user_data['role_detail']['role_name'] == 'Visitor':
                        acess_to_page = True
                if acess_to_page == True:

                    visitor_request_id = id
                    visitor_user_id = request.user.id
                    #  company_detail_id=request.user.id
                    try:
                        visitor = VisitorDetails.objects.get(user_id=visitor_user_id)
                        visitor_request = VisitorRequest.objects.get(id=visitor_request_id,
                                                                    visitor_user_id=visitor_user_id)
                        print("visitor_request specific", visitor_request)
                    except VisitorRequest.DoesNotExist:
                        return Response(status=status.HTTP_404_NOT_FOUND)

                    visitor_request_serializer = VisitorRequestSerializer(visitor_request)

                    visitor_have_accessory_queryset = VisitorHaveAccessory.objects.filter(visitor_request_id=visitor_request_id)
                    visitor_have_accessory_serializer = VisitorHaveAccessorySerializer(visitor_have_accessory_queryset,
                                                                                    many=True)

                    # default_visitor_have_accessory_queryset = DefaultVisitorHaveAccessory.objects.all()
                    # default_visitor_have_accessory_serializer = DefaultVisitorHaveAccessorySerializer(
                    #     default_visitor_have_accessory_queryset, many=True)

                    visitor_provided_accessory_queryset = VisitorProvidedAccessory.objects.filter(
                        visitor_request_id=visitor_request_id)
                    visitor_provided_accessory_serializer = VisitorProvidedAccessorySerializer(
                        visitor_provided_accessory_queryset,
                        many=True)
                    # default_accessory_provided_by_company_queryset = DefaultAccessoryProvidedByCompany.objects.all()
                    # default_accessory_provided_by_company_serializer = DefaultAccessoryProvidedByCompanySerializer(
                    #     default_accessory_provided_by_company_queryset, many=True)

                    data = {
                        'visitor_request': visitor_request_serializer.data,
                        'visitor_have_accessory': visitor_have_accessory_serializer.data, }

                    visitor_requests_data = {
                        "id": visitor_request_serializer.data["id"],
                        "email": visitor_request_serializer.data["email"],
                        "department_id": visitor_request_serializer.data["department_id"],
                        "department": visitor_request_serializer.data["department"],
                        "from_date": visitor_request_serializer.data["from_date"],
                        "to_date": visitor_request_serializer.data["to_date"],
                        "purpose_of_visit": visitor_request_serializer.data["purpose_of_visit"]
                    }

                    visitor_have_accessory_data = []
                    for data in visitor_have_accessory_serializer.data:
                        new_data = {
                            "id": data["id"],
                            "default_visitor_have_accessory": data.get("default_visitor_have_accessory", "N/A"),
                            "accessory_name": data.get("accessory_name", "N/A"),
                            "default_visitor_have_accessory_id": data.get("default_visitor_have_accessory_id", "N/A")
                        }
                        visitor_have_accessory_data.append(new_data)
                    print("visitor_have_accessory_data", visitor_have_accessory_data)

                    visitor_provided_accessory_data = []
                    for data in visitor_provided_accessory_serializer.data:
                        new_data = {
                            "id": data["id"],
                            "default_accessory_provided_by_company_id": data.get("default_accessory_provided_by_company_id",
                                                                                "N/A"),
                            "default_accessory_provided_by_company": data.get("default_accessory_provided_by_company", "N/A")
                        }
                        visitor_provided_accessory_data.append(new_data)
                    print("visitor_provided_accessory_data", visitor_provided_accessory_data)

                    visitor_requests_data["visitor_have_accessory"] = visitor_have_accessory_data
                    visitor_requests_data["visitor_provided_accessory"] = visitor_provided_accessory_data
                    return Response(visitor_requests_data)
               
                else:
                    return Response({"submit": "You are not Visitor."}, status=status.HTTP_400_BAD_REQUEST)

            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'visitor_request_by_self' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['visitor_request_by_self']:
                    if get_user_data['role_detail']['role_name'] == 'Visitor':
                        acess_to_page = True
                if acess_to_page == True:

                    # company_detail_id = request.user.company_detail_id_id
                    company_detail_id = 1  # change after appropriate method

                    try:
                        visitor_request1 = VisitorRequest.objects.get(pk=id)
                    except VisitorRequest.DoesNotExist:
                        raise Http404

                    from_date_str = request.data["from_date"]
                    to_date_str = request.data["to_date"]
                    from_date = datetime.fromisoformat(from_date_str[:-1])
                    to_date = datetime.fromisoformat(to_date_str[:-1])
                    duration = to_date - from_date
                    duration_in_days = duration.days
                    print("duration_in_days", duration_in_days)

                    try:
                        visitor = VisitorDetails.objects.get(user_id=request.user.id)
                    except VisitorDetails.DoesNotExist:
                        return Response({"message": "Visitor has not access to make visitor request"})

                    visitor_request_data = {
                        "employee_name": request.data["employee_name"],
                        "department_id": request.data["department_id"],
                        "from_date": request.data["from_date"],
                        "to_date": request.data["to_date"],
                        "purpose_of_visit": request.data["purpose_of_visit"],

                        "duration": duration_in_days,
                        "company_detail_id": company_detail_id,

                        "visitor_user_id": request.user.id  # visitor login User Id
                    }
                    visitor_serializer = VisitorRequestSerializer(visitor_request1, data=visitor_request_data, partial=True)
                    if visitor_serializer.is_valid():
                        visitor_serializer.save()
                    else:
                        print("Serializer error")
                        return Response(visitor_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

                    print(request.data["visitor_have_accessory"])

                    # get data of VisitorHaveAccessory
                    visitor_request_id = id

                    visitor_have_accessory_list = VisitorHaveAccessory.objects.filter(
                        visitor_request_id=visitor_request_id).values()

                    # visitor_have_accessory_list = VisitorHaveAccessory.objects.filter(visitor_request_id=visitor_request_id).values(
                    #     'id',
                    #     "accessory_name",
                    #     'default_visitor_have_accessory_id',  # Include the related default_visitor_have_accessory_id field
                    #     # 'visitor_request_id',
                    #     # 'user_id',
                    #     # 'approval',
                    #     # 'in_accessory',
                    #     # 'out_accessory',
                    # )

                    VisitorHaveAccessory.objects.filter(visitor_request_id=visitor_request_id).delete()

                    # visitor_have_accessory_list = list(visitor_have_accessory_list)
                    # print("Initial Data:", visitor_have_accessory_list)
                    #
                    data = request.data.get('visitor_have_accessory')
                    print("data for PUT: ", data)

                    visitor_request_id = id
                    for obj in data:
                        obj['user_id'] = None
                        obj['approval'] = False
                        obj['in_accessory'] = False
                        obj['out_accessory'] = False
                        obj['visitor_request_id'] = visitor_request_id
                        if obj["default_visitor_have_accessory_id"] == "null":
                            del obj["default_visitor_have_accessory_id"]

                        print("obj", obj)

                    # create an instance of the serializer with the default values set
                    serializer = VisitorHaveAccessorySerializer(data=data, many=True)

                    if serializer.is_valid():
                        serializer.save()
                    else:
                        print("serializer error")
                        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

                    VisitorProvidedAccessory.objects.filter(visitor_request_id=visitor_request_id).delete()
                    data = request.data.get('visitor_provided_accessory')
                    for obj in data:
                        obj['user_id'] = None
                        obj['approval'] = False
                        obj['in_accessory'] = False
                        obj['out_accessory'] = False
                        obj['visitor_request_id'] = visitor_request_id

                        print("obj", obj)

                    # create an instance of the serializer with the default values set
                    serializer = VisitorProvidedAccessorySerializer(data=data, many=True)

                    if serializer.is_valid():
                        serializer.save()

                    else:
                        print("serializer error")
                        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

                    return Response({"message": "end"})
                else:
                    return Response({"submit": "You are not Visitor."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'visitor_request_by_self' in get_user_data['permission'].keys():
                if 'delete' in get_user_data['permission']['visitor_request_by_self']:
                    if get_user_data['role_detail']['role_name'] == 'Visitor':
                        acess_to_page = True
                if acess_to_page == True:

                    company_detail_id = request.user.company_detail_id_id
                    sub_company_detail_id = None
                    if len(get_user_data['sub_company']) > 0:
                        sub_company_detail_id = get_user_data['sub_company']['id']
                    try:
                        visitor_request1 = VisitorRequest.objects.get(pk=id)
                    except VisitorRequest.DoesNotExist:
                        raise Http404

                    # try:
                    #     employee = Employee.objects.get(email=request.user)
                    #     employee_id = employee.id
                    #     employee_name = employee.name
                    # except Employee.DoesNotExist:
                    #     return Response({"message": "Employee has not access to make visitor request"})

                   

                    try:
                        VisitorRequest.objects.filter(pk=id, company_detail_id=company_detail_id, sub_company_id = sub_company_detail_id,
                                               ).delete()

                        return Response(status=status.HTTP_204_NO_CONTENT)
                    except Exception as e:
                        return Response({"submit": "Cannot delete. This request is used by approval and visitor accessory."}, status=status.HTTP_400_BAD_REQUEST)
                   
                else:
                    return Response({"submit": "You are not Visitor."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class VisitorRestrictionView(APIView):
    permission_classes = [IsAuthenticated]

    def get_object(self):
        try:
            return VisitorRestriction.objects.all()
        except VisitorRestriction.DoesNotExist:
            raise Http404
        
    ObjectSerializer = VisitorRestrictionSerializer
    model_name = 'VisitorRestriction'

    # def get_company(self):
    #     User = get_user_model()
    #     user_email = self.request.user
    #     return (User.objects.filter(email=user_email).values('company_detail_id')[0]['company_detail_id'])

    def get(self, request, format=None):
        limit = int(request.GET.get('limit',10))
        offset = int(request.GET.get('offset',0))
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'visitor_restriction' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['visitor_restriction']:
                    acess_to_page = True
            if acess_to_page == True:
                sub_company_detail_id = None
                if len(get_user_data['sub_company']) > 0:
                    sub_company_detail_id = get_user_data['sub_company']['id']

                visitor_queryset = VisitorRestriction.objects.filter(company_detail_id = get_user_data['company_detail']['id'],sub_company_id = sub_company_detail_id).order_by('-id').all()[offset:limit+offset]
                visitor_count = VisitorRestriction.objects.filter(company_detail_id = get_user_data['company_detail']['id'],sub_company_id = sub_company_detail_id).count()
                serializer = self.ObjectSerializer(visitor_queryset, many=True)
                return Response({'count':visitor_count, 'results': serializer.data})
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
        
                    
    def post(self, request, format=None):

        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'visitor_restriction' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['visitor_restriction']:
                    acess_to_page = True
            if acess_to_page == True:
                sub_company_detail_id = None
                if len(get_user_data['sub_company']) > 0:
                    sub_company_detail_id = get_user_data['sub_company']['id']
                data = request.data
                data['company_detail_id'] = get_user_data['company_detail']['id']
                data['sub_company_id'] = sub_company_detail_id
                serializer = self.ObjectSerializer(data=data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class VisitorRestrictionDetailView(APIView):
    permission_classes = [IsAuthenticated]

    def get_object(self, pk):
        try:
            return VisitorRestriction.objects.get(pk=pk)
        except VisitorRestriction.DoesNotExist:
            raise Http404
        
    ObjectSerializer = VisitorRestrictionSerializer
    model_name = 'VisitorRestriction'

    def get(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'visitor_restriction' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['visitor_restriction']:
                    acess_to_page = True
            if acess_to_page == True:
                print(r'get details of id: ', id)
                company_detail_id = request.user.company_detail_id
                sub_company_id = request.user.sub_company_id
                #queryset = self.get_object(pk=id)
                queryset = VisitorRestriction.objects.filter(pk=id,
                                                                    company_detail_id=company_detail_id, sub_company_id=sub_company_id).first()
                serializer = self.ObjectSerializer(queryset)
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
        

    def patch(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'visitor_restriction' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['visitor_restriction']:
                    acess_to_page = True
            if acess_to_page == True:
                sub_company = self.get_object(pk=id)
                print("sub_company", sub_company)
                data = request.data.copy()
                #data['company_detail_id'] = self.get_company()
                print("patch data", data)
                serializer = self.ObjectSerializer(sub_company, data=data, partial=True)
                if serializer.is_valid():
                    print("serializer is valid")
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
        

    def put(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'visitor_restriction' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['visitor_restriction']:
                    acess_to_page = True
            if acess_to_page == True:
                sub_company_detail_id = None
                if len(get_user_data['sub_company']) > 0:
                    sub_company_detail_id = get_user_data['sub_company']['id']
                data = request.data
                data['company_detail_id'] = get_user_data['company_detail']['id']
                data['sub_company_id'] = sub_company_detail_id
                queryset = self.get_object(pk=id)
                serializer = self.ObjectSerializer(queryset, data=data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
        

    # def delete(self, request, id, format=None):
    #     get_user_data = getUserDataLogin(request.user.id)
        
    #     if get_user_data['company_detail']['account_validity'] == True:
    #         acess_to_page = False
    #         if 'visitor_restriction' in get_user_data['permission'].keys():
    #             if 'delete' in get_user_data['permission']['visitor_restriction']:
    #                 acess_to_page = True
    #         if acess_to_page == True:
    #             company_detail_id = request.user.company_detail_id
    #             sub_company_id = request.user.sub_company_id
    #             #queryset = self.get_object(pk=id)
    #             queryset = VisitorRestriction.objects.filter(pk=id,
    #                                                                 company_detail_id=company_detail_id, sub_company_id=sub_company_id).first()
    #             queryset.delete()
    #             return Response(status=status.HTTP_204_NO_CONTENT)
    #         else:
    #             return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

    #     else:
    #         return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


# DropDown
class VisitorRequestListView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        company_detail_id = request.user.company_detail_id
        sub_company_id = request.user.sub_company_id

        if company_detail_id:
            visitor_request = VisitorRequest.objects.filter(company_detail_id=company_detail_id, sub_company_id=sub_company_id)
            
        if sub_company_id:
            visitor_request = VisitorRequest.objects.filter(sub_company_id=sub_company_id)


        visitor_request_serializer = VisitorRequestDetailSerializer(visitor_request, many=True)
        return Response(visitor_request_serializer.data)
    
#DropDown
class VisitorProvidedAccessoryListView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        visitor_accessory = VisitorProvidedAccessory.objects.all()
        visitor_accessory_serializer = VisitorProvidedAccessoryListSerializer(visitor_accessory, many=True)
        return Response(visitor_accessory_serializer.data)
    

# PassGeneration API
class PassGenerationAPIView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'pass_generation' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['pass_generation']:
                    if get_user_data['role_detail']['role_name'] == 'Visitor':
                        acess_to_page = True
                if acess_to_page == True:
                    try:
                        company_detail_id = request.user.company_detail_id
                        sub_company_id = request.user.sub_company_id
                        approval_layer = ApprovalLayer.objects.filter(company_detail_id=company_detail_id, sub_company_id=sub_company_id).first()
                        approval = Approval.objects.filter(visitor_id=id, final_approval=True).exists()
                        print(approval)

                        if approval or not approval_layer.all_layer_required:
                            # Retrieve visitor details
                            visitor = Visitor.objects.get(id=id)

                            # Construct pass details
                            company_detail = approval_layer.company_detail_id
                            company_detail_serializer = CompanyDetailListSerializer(company_detail)
                            status = True
                            pass_generated_datetime = datetime.now()

                            accessory_provided = AccessoryProvided.objects.filter(visitor_id=id).first()
                            Accessory_provided = []
                            if accessory_provided:
                                default_accessory = accessory_provided.default_accessory_id
                                Accessory_provided.append(default_accessory.accessory_name)

                            default_accessory_have = DefaultVisitorHaveAccessory.objects.filter(company_detail_id=company_detail_id, sub_company_id=sub_company_id).first()
                            Accessory_have = []
                            if default_accessory_have:
                                Accessory_have.append(default_accessory_have.accessory_name)

                            pass_details = {
                                "Visitor_id": id,
                                "Name": visitor.name,
                                "Email": visitor.email,
                                "Mobile_number": visitor.mobile_no,
                                "Id_proof_number": visitor.id_proof_no,
                                "Vehicle_number": visitor.vehicle_no,
                                "Address": visitor.address,
                                "From_date": visitor.from_date,
                                "To_date": visitor.to_date,
                                "Purpose_of_visit":visitor.purpose_of_visit,
                                "Accessory_provided": Accessory_provided,
                                "Accessory_have": Accessory_have,
                                "Company_details": company_detail_serializer.data,
                                "Status": status,
                                "Pass_generated_datetime": pass_generated_datetime
                            }

                            return Response(pass_details, status=200)
                        else:
                            return Response({'message': 'Pass generation not allowed.'}, status=400)

                    except ApprovalLayer.DoesNotExist:
                        return Response({'message': 'Approval layer not found.'}, status=400)
                    
                else:
                    return Response({"submit": "You are not visitor."},status=400)
                
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
                

class ApproveVisitorRequestView(APIView):
    permission_classes = [IsAuthenticated]

    def put(self, request, id, format=None):

        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'approve' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['approve']:
                    acess_to_page = True
            if acess_to_page == True:
                try:
                    company_detail_id = request.user.company_detail_id
                    approval_type_names = ApprovalType.objects.filter(company_detail_id=company_detail_id).values('approval_name')
                    approval_types = ApprovalType.objects.filter(approval_name__in=approval_type_names, company_detail_id=company_detail_id)
                    visitor_request = VisitorRequest.objects.filter(company_detail_id=company_detail_id).first()
                    visitor_request_id = visitor_request.id
                except VisitorRequest.DoesNotExist:
                    return Response({"submit": "Visitor request does not exist."}, status=status.HTTP_404_NOT_FOUND)

                # Check if any previous request has been rejected
                previous_rejected = Approval.objects.filter(
                    Q(pk=id) & Q(approval_type_id__approval_name='Reject')
                ).exists()

                if previous_rejected:
                    return Response({"submit": "Visitor request cannot be approved as there is a previous rejected request."}, status=status.HTTP_400_BAD_REQUEST)
                else:
                    approval_by_id = request.user.id
                    user_id = get_user_data['user_detail']['id']
                    user_instance = User.objects.get(id=user_id)
                    # Check the current approval type of the current request
                    existing_approval = Approval.objects.get(pk=id)
                    current_approval_type = existing_approval.approval_type_id.approval_name
                    accessory_approval = existing_approval.approval_step_by_role_id.accessory_approval
                    

                    # Check if the current approval type is 'Unhold'
                    if current_approval_type == 'Unhold':

                        if accessory_approval == True:
                            visitor_provided_accessory = request.data.get('visitor_provided_accessory')
                            visitor_have_accessory = request.data.get('visitor_have_accessory')

                            if visitor_provided_accessory:
                                if isinstance(visitor_provided_accessory, int):
                                    visitor_provided_accessory = [visitor_provided_accessory]

                                for accessory_id in visitor_provided_accessory:
                                    VisitorProvidedAccessory.objects.filter(id=accessory_id).update(approval=True)

                            if visitor_have_accessory:
                                if isinstance(visitor_have_accessory, int):
                                    visitor_have_accessory = [visitor_have_accessory]

                                for accessory_id in visitor_have_accessory:
                                    VisitorHaveAccessory.objects.filter(id=accessory_id).update(approval=True)

                        # Update the approval type of the current request to 'Approve'
                        approval_type = approval_types.get(approval_name="Approve")
                        existing_approval.approval_type_id = approval_type
                        existing_approval.approval_by_id = user_instance
                        existing_approval.save()



                        if existing_approval.approval_type_id.approval_name == 'Approve':
                            existing_step_by_role = existing_approval.approval_step_by_role_id
                            existing_visitor_request = existing_approval.visitor_request_id

                            approval_exclude = Approval.objects.filter(visitor_request_id = existing_visitor_request,  
                                                                       approval_change_by_number_of_days_id=existing_approval.approval_change_by_number_of_days_id).values_list('approval_step_by_role_id', flat=True)

                            approval_step = ApproveStepByRole.objects.filter(
                                approval_change_by_number_of_days_id=existing_approval.approval_change_by_number_of_days_id, company_detail_id=company_detail_id
                            ).exclude(id__in=approval_exclude).first()

                            if approval_step:
                                # First, filter ApprovalType objects based on company_detail_id
                                approval_types = ApprovalType.objects.filter(company_detail_id=company_detail_id)

                                # Check if there are any ApprovalType objects with default_approval=False
                                default_approval_false = approval_types.filter(default_approval=False).exists()

                                if default_approval_false:
                                    # Get the ApprovalType with approval_name="Hold"
                                    hold_approval_type = approval_types.filter(approval_name="Hold").first()

                                

                                approval_data = {
                                    "approval_type_id": hold_approval_type.id,  # Use the same approval type as existing
                                    "visitor_request_id": existing_visitor_request.id,
                                    "role_id": approval_step.role_id.id,
                                    "final_approval": False,
                                    "approval_change_by_number_of_days_id": existing_approval.approval_change_by_number_of_days_id.id,
                                    "approval_step_by_role_id": approval_step.id,
                                }

                                approval_serializer = ApprovalSerializer(data=approval_data)
                                if approval_serializer.is_valid():
                                    obj = approval_serializer.save()
                                    approval_serializer_id = obj.id
                                    return Response({"submit": "This layer has been approved and new layer has been added."}, status=status.HTTP_200_OK)
                                else:
                                    print("Approval Serializer error")
                                    return Response(approval_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                            else:
                                # All approvals for this layer have been added, update final_approval
                                approvals = Approval.objects.filter(
                                    visitor_request_id=existing_visitor_request,
                                    approval_change_by_number_of_days_id=existing_approval.approval_change_by_number_of_days_id
                                )

                                for approval in approvals:
                                    approval.final_approval = True
                                    approval.save()

                                
                                return Response({"submit": "All layers of this visitor request have been approved."}, status=status.HTTP_200_OK)

                    
                    elif current_approval_type == 'Hold':
                        return Response({"submit": "Visitor request is on hold and cannot be approved."}, status=status.HTTP_400_BAD_REQUEST)
                    
                    else:
                         return Response({"submit": "Visitor request has already approved."}, status=status.HTTP_400_BAD_REQUEST)
    
                   
            else:
                return Response({"submit": "You don't have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"submit": "Account Validity has expired."}, status=status.HTTP_400_BAD_REQUEST)

class HoldVisitorRequestView(APIView):
    permission_classes = [IsAuthenticated]

    def put(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'hold' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['hold']:
                    acess_to_page = True
            if acess_to_page == True:
                try:
                    company_detail_id = request.user.company_detail_id
                    approval_type_names = ApprovalType.objects.filter(company_detail_id=company_detail_id).values('approval_name')
                    approval_types = ApprovalType.objects.filter(approval_name__in=approval_type_names, company_detail_id=company_detail_id)
                    visitor_request = VisitorRequest.objects.filter(company_detail_id=company_detail_id).first()
                    visitor_request_id = visitor_request.id
                except VisitorRequest.DoesNotExist:
                    return Response({"submit": "Visitor request does not exist."}, status=status.HTTP_404_NOT_FOUND)

                # Check if any previous request has been rejected
                previous_rejected = Approval.objects.filter(
                    Q(pk=id) & Q(approval_type_id__approval_name='Reject')
                ).exists()
                print("previous_rejected : ", previous_rejected)

                previous_approved = Approval.objects.filter(
                    Q(pk=id) & Q(approval_type_id__approval_name='Approve')
                ).exists()

                if previous_rejected or previous_approved:
                    return Response({"submit": "Visitor request cannot be put on hold as there is a previous rejected request or approved request."}, status=status.HTTP_400_BAD_REQUEST)
                else:
                    # Check the current approval type of the current request
                    existing_approval = Approval.objects.get(pk=id)
                    current_approval_type = existing_approval.approval_type_id.approval_name

                    # Determine the new approval type based on the current one
                    new_approval_type = "Unhold" if current_approval_type == "Hold" else "Hold"

                    # Update the approval type of the current request
                    new_approval_type_instance = approval_types.get(approval_name=new_approval_type)
                    existing_approval.approval_type_id = new_approval_type_instance
                    existing_approval.save()

                    return Response({"submit": f"Visitor request has been {new_approval_type}."}, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class RejectVisitorRequestView(APIView):
    permission_classes = [IsAuthenticated]

    def put(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'reject' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['reject']:
                    acess_to_page = True
            if acess_to_page == True:
                try:
                    company_detail_id = request.user.company_detail_id
                    approval_type_names = ApprovalType.objects.filter(company_detail_id=company_detail_id).values('approval_name')
                    approval_types = ApprovalType.objects.filter(approval_name__in=approval_type_names, company_detail_id=company_detail_id)
                    visitor_request = VisitorRequest.objects.filter(company_detail_id=company_detail_id).first()
                    visitor_request_id = visitor_request.id
                except VisitorRequest.DoesNotExist:
                    return Response({"submit": "Visitor request does not exist."}, status=status.HTTP_404_NOT_FOUND)

                # Check if any previous request has been rejected
                previous_approved = Approval.objects.filter(
                    Q(pk=id) & Q(approval_type_id__approval_name='Approve')
                ).exists()

                if previous_approved:
                    return Response({"submit": "Visitor request cannot be rejected as there is a previous approved request."}, status=status.HTTP_400_BAD_REQUEST)
                else:
                    # Check the current approval type of the current request
                    existing_approval = Approval.objects.get(pk=id)
                    current_approval_type = existing_approval.approval_type_id.approval_name

                    # Check if the current approval type is 'Unhold'
                    if current_approval_type == 'Unhold':
                        # Update the approval type of the current request to 'Approve'
                        approval_type = approval_types.get(approval_name="Reject")
                        existing_approval.approval_type_id = approval_type
                        existing_approval.save()
                        return Response({"submit": "Visitor request has been rejected."}, status=status.HTTP_200_OK)
                    elif current_approval_type == 'Hold':
                        return Response({"submit": "Visitor request is on hold and cannot be rejected."}, status=status.HTTP_400_BAD_REQUEST)
                    else:
                        return Response({"submit": "Visitor request has already rejected."}, status=status.HTTP_400_BAD_REQUEST)

            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


# Approval API
class ApprovalList(APIView):
    permission_classes = (IsAuthenticated,)


    def get_object(self):
        try:
            return Approval.objects.all()
        except:
            raise Http404

    ObjectSerializer = ApprovalSerializer
    model_name = "Approval"

    def get(self, request, format=None):
        limit = int(request.GET.get('limit',10))
        offset = int(request.GET.get('offset',0))
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'approval' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['approval']:
                    acess_to_page = True
            if acess_to_page == True:

                queryset = Approval.objects.filter(role_id=get_user_data['role_detail']['id']).order_by('-id').all()[offset:limit+offset]
                quesryset_count = Approval.objects.filter(role_id=get_user_data['role_detail']['id']).count()

                serializer = self.ObjectSerializer(queryset, many=True)
                return Response({"count":quesryset_count, "results":serializer.data})
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
        
    

    # def get(self, request, format=None):
    #     limit = int(request.GET.get('limit', 10))
    #     offset = int(request.GET.get('offset', 0))
    #     get_user_data = getUserDataLogin(request.user.id)

    #     if get_user_data['company_detail']['account_validity'] == True:
    #         acess_to_page = False
    #         if 'approval' in get_user_data['permission'].keys():
    #             if 'view' in get_user_data['permission']['approval']:
    #                 acess_to_page = True
    #         if acess_to_page == True:
    #             approval_by_id = request.user.id
    #             role_id = get_user_data['role_detail']['id']
    #             company_detail_id = get_user_data['company_detail']['id']

    #             # Get all VisitorRequests for the given company_detail_id
    #             visitor_requests = VisitorRequest.objects.filter(company_detail_id=company_detail_id)

    #             approval_data = []

    #             for visitor_request in visitor_requests:
    #                 matching_approval_change_ids = []
    #                 hold_encountered = False

    #                 # Iterate through each VisitorRequest
    #                 from_date = visitor_request.from_date
    #                 to_date = visitor_request.to_date

    #                 visit_day = (to_date - from_date).days

    #                 # Query ApprovalChangeByNumberOfDays for matching date ranges
    #                 matching_approvals = ApprovalChangeByNumberOfDays.objects.filter(
    #                     from_days__lte=visit_day,
    #                     to_days__gte=visit_day
    #                 )

    #                 # Extract the matching approval_change_by_number_of_days_ids
    #                 matching_approval_change_ids.extend(
    #                     matching_approvals.values_list('id', flat=True)
    #                 )

    #                 # Query ApprovalStepByRole based on the matching ids
    #                 approval_steps = ApproveStepByRole.objects.filter(
    #                     approval_change_by_number_of_days_id__in=matching_approval_change_ids
    #                 )

    #                 for approval_step in approval_steps:
    #                     role_name = approval_step.role_id.role_name
    #                     approval_type_id = ApprovalType.objects.get(id=1)
    #                     approval = approval_type_id.approval_name

    #                     # Query for existing approvals with the same visitor_request_id
    #                     existing_approvals = Approval.objects.filter(visitor_request_id=visitor_request.id)

    #                     if approval != "Approve":
    #                         # If approval_name is "hold," set the hold_encountered flag
    #                         hold_encountered = True

    #                     elif approval == "Approve":
    #                         # If approval_name is "Approve," set final_approval to True for all rows
    #                         existing_approvals.update(final_approval=True)

    #                     approval = {
    #                         "approval_type_id": approval_type_id.id,
    #                          "approval_name": approval,
    #                         "visitor_request_id": visitor_request.id,
    #                         "visitor_email": visitor_request.email,
    #                         "approval_by_id": approval_by_id,
    #                         "role_id":approval_step.role_id.id,
    #                         "role_name": role_name,
    #                         "final_approval": False,
    #                         "approval_change_by_number_of_days_id": approval_step.approval_change_by_number_of_days_id.id,
    #                         "approval_step_by_role_id": approval_step.id,
    #                     }

    #                     approval_data.append(approval)

    #                     if hold_encountered:
    #                         break

    #             approval_data_list = approval_data[offset:offset + limit]
    #             approval_count = len(approval_data)

    #             return Response({"count": approval_count, "results": approval_data_list})
    #         else:
    #             return Response({"submit": "You don't have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)
    #     else:
    #         return Response({"submit": "Account validity has expired."}, status=status.HTTP_400_BAD_REQUEST)



    def post(self, request, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'approval' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['approval']:
                    acess_to_page = True
            if acess_to_page == True:
                data = request.data
                serializer = self.ObjectSerializer(data=data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class ApprovalDetail(APIView):
    permission_classes = (IsAuthenticated,)

    def get_object(self, pk):
        try:
            return Approval.objects.get(pk=pk)
        except:
            raise Http404

    ObjectSerializer = ApprovalSerializer

    def get(self, request, id=None, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'approval' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['approval']:
                    acess_to_page = True
            if acess_to_page == True:

                print(r'get details of id: ', id)
                queryset = Approval.objects.filter(pk=id, role_id = get_user_data['role_detail']['id'])
                # serializer = CompanyDetailSerializer(queryset)
                serializer = self.ObjectSerializer(queryset)
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


    def put(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'approval' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['approval']:
                    acess_to_page = True
            if acess_to_page == True:
                queryset = self.get_object(pk=id)
                print("PUT request ", id, queryset, request.data)
                # serializer = CompanyDetailSerializer(queryset, data=request.data)
                serializer = self.ObjectSerializer(queryset, data=request.data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'approval' in get_user_data['permission'].keys():
                if 'delete' in get_user_data['permission']['approval']:
                    acess_to_page = True
            if acess_to_page == True:
                queryset = self.get_object(pk=id)
                try:
                    queryset.delete()
                    return Response(status=status.HTTP_204_NO_CONTENT)
                except Exception as e:
                    return Response({"submit": "Cannot delete. This object is referenced by other objects."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
        

class MobileTypeView(APIView):
    permission_classes = [IsAuthenticated]

    def get_object(self):
        try:
            return MobileType.objects.all()
        except MobileType.DoesNotExist:
            raise Http404
        
    ObjectSerializer = MobileTypeSerializer
    model_name = 'MobileType'

    # def get_company(self):
    #     User = get_user_model()
    #     user_email = self.request.user
    #     return (User.objects.filter(email=user_email).values('company_detail_id')[0]['company_detail_id'])

    def get(self, request, format=None):
        limit = int(request.GET.get('limit',10))
        offset = int(request.GET.get('offset',0))
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'mobile_type' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['mobile_type']:
                    acess_to_page = True
            if acess_to_page == True:

                mobile_queryset = MobileType.objects.filter(company_detail_id = get_user_data['company_detail']['id']).order_by('-id').all()[offset:limit+offset]
                mobile_count = MobileType.objects.filter(company_detail_id = get_user_data['company_detail']['id']).count()
                serializer = self.ObjectSerializer(mobile_queryset, many=True)
                return Response({'count':mobile_count, 'results': serializer.data})
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
                    
    def post(self, request, format=None):

        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'mobile_type' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['mobile_type']:
                    acess_to_page = True
            if acess_to_page == True:
                data = request.data
                data['company_detail_id'] = get_user_data['company_detail']['id']
                serializer = self.ObjectSerializer(data=data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class MobileTypeDetailView(APIView):
    permission_classes = [IsAuthenticated]

    def get_object(self, pk):
        try:
            return MobileType.objects.get(pk=pk)
        except MobileType.DoesNotExist:
            raise Http404
        
    ObjectSerializer = MobileTypeSerializer

    def get(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'mobile_type' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['mobile_type']:
                    acess_to_page = True
            if acess_to_page == True:
                print(r'get details of id: ', id)
                queryset = self.get_object(pk=id)
                serializer = self.ObjectSerializer(queryset)
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def patch(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'mobile_type' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['mobile_type']:
                    acess_to_page = True
            if acess_to_page == True:
                sub_company = self.get_object(pk=id)
                print("sub_company", sub_company)
                data = request.data.copy()
                #data['company_detail_id'] = self.get_company()
                print("patch data", data)
                serializer = self.ObjectSerializer(sub_company, data=data, partial=True)
                if serializer.is_valid():
                    print("serializer is valid")
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'mobile_type' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['mobile_type']:
                    acess_to_page = True
            if acess_to_page == True:
                sub_company_detail_id = None
                if len(get_user_data['sub_company']) > 0:
                    sub_company_detail_id = get_user_data['sub_company']['id']
                data = request.data
                data['company_detail_id'] = get_user_data['company_detail']['id']
                data['sub_company_id'] = sub_company_detail_id
                queryset = self.get_object(pk=id)
                serializer = self.ObjectSerializer(queryset, data=data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'mobile_type' in get_user_data['permission'].keys():
                if 'delete' in get_user_data['permission']['mobile_type']:
                    acess_to_page = True
            if acess_to_page == True:
                queryset = self.get_object(pk=id)
                try:
                    queryset.delete()
                    return Response(status=status.HTTP_204_NO_CONTENT)
                except Exception as e:
                    return Response({"submit": "Cannot delete. This Mobile type is used by visitor."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class IdProofTypeView(APIView):
    permission_classes = [IsAuthenticated]

    def get_object(self):
        try:
            return IdProofType.objects.all()
        except IdProofType.DoesNotExist:
            raise Http404
        
    ObjectSerializer = IdProofTypeSerializer
    model_name = 'IdProofType'

    # def get_company(self):
    #     User = get_user_model()
    #     user_email = self.request.user
    #     return (User.objects.filter(email=user_email).values('company_detail_id')[0]['company_detail_id'])

    def get(self, request, format=None):
        limit = int(request.GET.get('limit',10))
        offset = int(request.GET.get('offset',0))
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'id_proof_type' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['id_proof_type']:
                    acess_to_page = True
            if acess_to_page == True:

                id_proof_queryset = IdProofType.objects.filter(company_detail_id = get_user_data['company_detail']['id']).order_by('-id').all()[offset:limit+offset]
                id_proof_count = IdProofType.objects.filter(company_detail_id = get_user_data['company_detail']['id']).count()
                serializer = self.ObjectSerializer(id_proof_queryset, many=True)
                return Response({'count':id_proof_count, 'results': serializer.data})
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
                    
    def post(self, request, format=None):

        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'id_proof_type' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['id_proof_type']:
                    acess_to_page = True
            if acess_to_page == True:
                data = request.data
                data['company_detail_id'] = get_user_data['company_detail']['id']
                serializer = self.ObjectSerializer(data=data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class IdProofTypeDetailView(APIView):
    permission_classes = [IsAuthenticated]

    def get_object(self, pk):
        try:
            return IdProofType.objects.get(pk=pk)
        except IdProofType.DoesNotExist:
            raise Http404
        
    ObjectSerializer = IdProofTypeSerializer

    def get(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'id_proof_type' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['id_proof_type']:
                    acess_to_page = True
            if acess_to_page == True:
                print(r'get details of id: ', id)
                queryset = self.get_object(pk=id)
                serializer = self.ObjectSerializer(queryset)
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def patch(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'id_proof_type' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['id_proof_type']:
                    acess_to_page = True
            if acess_to_page == True:
                sub_company = self.get_object(pk=id)
                print("sub_company", sub_company)
                data = request.data.copy()
                #data['company_detail_id'] = self.get_company()
                print("patch data", data)
                serializer = self.ObjectSerializer(sub_company, data=data, partial=True)
                if serializer.is_valid():
                    print("serializer is valid")
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'id_proof_type' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['id_proof_type']:
                    acess_to_page = True
            if acess_to_page == True:
                sub_company_detail_id = None
                if len(get_user_data['sub_company']) > 0:
                    sub_company_detail_id = get_user_data['sub_company']['id']
                data = request.data
                data['company_detail_id'] = get_user_data['company_detail']['id']
                data['sub_company_id'] = sub_company_detail_id
                queryset = self.get_object(pk=id)
                serializer = self.ObjectSerializer(queryset, data=data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'id_proof_type' in get_user_data['permission'].keys():
                if 'delete' in get_user_data['permission']['id_proof_type']:
                    acess_to_page = True
            if acess_to_page == True:
                queryset = self.get_object(pk=id)
                try:
                    queryset.delete()
                    return Response(status=status.HTTP_204_NO_CONTENT)
                except Exception as e:
                    return Response({"submit": "Cannot delete. This Id type is used by visitor."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


# DropDown
class IdProofTypeListView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        company_detail_id = request.user.company_detail_id
        id_proof_type= IdProofType.objects.filter(company_detail_id=company_detail_id)
        id_proof_type_serializer = IdProofTypeListSerializer(id_proof_type, many=True)
        return Response(id_proof_type_serializer.data)


# DropDown
class MobileTypeListView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        company_detail_id = request.user.company_detail_id
        mobile_type = MobileType.objects.filter(company_detail_id=company_detail_id)
        mobile_type_serializer = MobileTypeListSerializer(mobile_type, many=True)
        return Response(mobile_type_serializer.data)


#VisitorProvidedAccessoryView

class VisitorProvidedAccessoryView(APIView):
    permission_classes = [IsAuthenticated]

    def get_object(self):
        try:
            return VisitorProvidedAccessory.objects.all()
        except VisitorProvidedAccessory.DoesNotExist:
            raise Http404
        
    ObjectSerializer = VisitorProvidedAccessorySerializer
    model_name = 'VisitorProvidedAccessory'

    def get(self, request, format=None):
        limit = int(request.GET.get('limit', 10))
        offset = int(request.GET.get('offset', 0))
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            AccessToPage = False
            if 'visitor_provided_accessor' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['visitor_provided_accessor']:
                    AccessToPage = True
            if AccessToPage == True:

                queryset = VisitorProvidedAccessory.objects.order_by('-id').all()[offset:limit + offset]
                queryset_count = VisitorProvidedAccessory.objects.count()
                serializer = self.ObjectSerializer(queryset, many=True)
                return Response({'count': queryset_count, 'results': serializer.data})
            else:
                return Response({"submit": "You don't have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity has expired."}, status=status.HTTP_400_BAD_REQUEST)
                    
    def post(self, request, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            AccessToPage = False
            if 'visitor_provided_accessor' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['visitor_provided_accessor']:
                    AccessToPage = True
            if AccessToPage == True:
                data = request.data
                data['user_id'] = request.user.id
                serializer = self.ObjectSerializer(data=data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don't have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity has expired."}, status=status.HTTP_400_BAD_REQUEST)




class VisitorRequestBySelfGetDetailView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        get_user_data = getUserDataLogin(request.user.id)
        company_detail_id = get_user_data['company_detail']['id']

        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'visitor_request_by_self' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['visitor_request_by_self']:
                    if get_user_data['role_detail']['role_name'] == 'Visitor':
                        acess_to_page = True
                if acess_to_page == True:
                    print("Getting all Data")
                    print("user", request.user.id)
                    sub_company_id = None
                    if len(get_user_data['sub_company']) > 0:
                        sub_company_id = get_user_data['sub_company']['id']

                    visitor_id = VisitorDetail.objects.get(user_id=request.user.id)

                    visitor_requests = VisitorRequest.objects.filter(visitor_detail_id=visitor_id.id)

                    if not visitor_requests.exists():
                        return Response({"message": "No visitor requests data"})

                    visitor_detail_ids = set()
                    visitor_requests_data_list = []

                    for instance in visitor_requests:
                        visitor_detail_id = instance.visitor_detail_id_id
                        if visitor_detail_id not in visitor_detail_ids:
                            visitor_detail_ids.add(visitor_detail_id)

                            visitor_detail = VisitorDetail.objects.get(user_id=request.user, id=visitor_detail_id)

                            

                            # Access the related VisitorHaveAccessory using visitor_request_id
                            visitor_have_accessory = VisitorHaveAccessory.objects.filter(
                                visitor_request_id=instance.id
                            ).first()

                            default_accessory_have = []
                            if visitor_have_accessory:
                                # Access the related DefaultVisitorHaveAccessory using default_visitor_have_accessory_id
                                default_accessory_have = visitor_have_accessory.default_visitor_have_accessory_id
                            
                            # Access the related VisitorProvidedAccessory using visitor_request_id
                            visitor_provided_accessory = VisitorProvidedAccessory.objects.filter(
                                visitor_request_id=instance.id
                            ).first()

                            default_accessory_provided = []
                            if visitor_provided_accessory:
                                # Access the related DefaultAccessoryProvidedByCompany using default_accessory_provided_by_company_id
                                default_accessory_provided = visitor_provided_accessory.default_accessory_provided_by_company_id

                            approval_count = Approval.objects.filter(
                            visitor_request_id=instance.id, approval_type_id__approval_name = 'Approve').all().count()
                        
                            total_approval_required = Approval.objects.filter(visitor_request_id=instance.id).values('approval_change_by_number_of_days_id__layer_of_approval').first()

                            #approvals = approval_count+"/"+total_approval_required

                            

                            visitor_request = True

                            request = VisitorRequest.objects.filter(
                            Q(visitor_detail_id=visitor_detail_id) &
                            Q(Q(company_detail_id=company_detail_id) | Q(sub_company_id=sub_company_id))).exists()

                            approve_request = VisitorRequest.objects.filter(
                                Q(visitor_detail_id=visitor_detail_id) &
                                Q(Q(company_detail_id=company_detail_id) | Q(sub_company_id=sub_company_id)) &
                                Q(approval__final_approval=True)).first()
                            
                            reject_request = VisitorRequest.objects.filter(
                                Q(visitor_detail_id=visitor_detail_id) &
                                Q(Q(company_detail_id=company_detail_id) | Q(sub_company_id=sub_company_id)) &
                                Q(approval__approval_type_id__approval_name='Reject')).first()
                            
                            print(approve_request)

                            if request:
                                request_detail = VisitorRequest.objects.filter(
                                Q(visitor_detail_id=visitor_detail_id) &
                                Q(Q(company_detail_id=company_detail_id) | Q(sub_company_id=sub_company_id))).first()

                                if approve_request:
                                    current_date = timezone.now()
                                    time_difference = request_detail.to_date - current_date

                                    if time_difference.days > 1:
                                        visitor_request = False

                                elif reject_request:
                                    current_date = timezone.now()
                                    time_difference1 = current_date - request_detail.from_date
                                    if time_difference1.days <= 1:
                                        visitor_request = False

                                else:
                                    visitor_request = False

                            id_proof = None
                            if visitor_detail.id_proof_type_id:
                                id_proof = visitor_detail.id_proof_type_id.id_proof 
                            pass_generation = False
                            visitor = {
                                "first_name": visitor_detail.first_name,
                                    "last_name": visitor_detail.last_name,
                                    "phone_no": visitor_detail.phone_no,
                                    "id_proof_type": id_proof,
                                    "id_proof_no":visitor_detail.id_proof_no,
                                    
                            }
                            
                            final_approval = False
                            if approve_request:
                                final_approval = True

                            if all(visitor.values()) and approve_request:
                                pass_generation = True


                            visitor_requests_data = {
                                "id": instance.id,
                                "email": instance.email,
                                "department_id": instance.department_id.id,
                                "department": instance.department_id.department_name,
                                "from_date": instance.from_date,
                                "to_date": instance.to_date,
                                "purpose_of_visit": instance.purpose_of_visit,
                                "type":instance.type,
                                "visitor_detail": {
                                    "id": visitor_detail.id,
                                    "photo": visitor_detail.photo,
                                    "first_name": visitor_detail.first_name,
                                    "last_name": visitor_detail.last_name,
                                    "phone_no": visitor_detail.phone_no,
                                    "id_proof_type": id_proof,
                                    "id_proof_no":visitor_detail.id_proof_no,
                                    "id_proof_photo": visitor_detail.id_proof_photo,
                                    "vehicle_no":visitor_detail.vehicle_no,
                                    "address":visitor_detail.address
                                },
                                "default_accessory_have": {
                                    "accessory_name": default_accessory_have.accessory_name if default_accessory_have else "N/A"
                                },
                                "default_accessory_provided": {
                                    "accessory_name": default_accessory_provided.accessory_name if default_accessory_provided else "N/A"
                                },
                                "final_approval": final_approval,
                                "visitor_request": visitor_request,
                                "pass_generation": pass_generation,
                                "approval_count": approval_count,
                                "total_approval_required": total_approval_required['approval_change_by_number_of_days_id__layer_of_approval']
                            }

                            if pass_generation ==  True:
                                # Generate QR code
                                qr = qrcode.QRCode(
                                    version=1,
                                    error_correction=qrcode.constants.ERROR_CORRECT_L,
                                    box_size=10,
                                    border=4,
                                )
                                qr.add_data(f"http://127.0.0.1:3000/visitor_pass_detail/{instance.uuid}")
                                #http://ec2-35-154-60-126.ap-south-1.compute.amazonaws.com/ 
                                qr.make(fit=True)

                                # Create an image from the QR code
                                img = qr.make_image(fill_color="black", back_color="white")

                                # Save the image to a buffer
                                buffer = BytesIO()
                                img.save(buffer)
                                buffer.seek(0)
                                
                                # Encode the QR code image as base64
                                qr_code_base64 = base64.b64encode(buffer.getvalue()).decode()

                                # Include the QR code data in the response
                                visitor_requests_data["qr_code"] = qr_code_base64
                            else:
                                visitor_requests_data["qr_code"] = None
                            # Assuming qr_data contains the URL
                                # qr_data = f"http://127.0.0.1:8000/visitorapps/visitor_request_qr_detail/{instance.uuid}"

                                # # Generate the QR code
                                # qr = qrcode.QRCode(
                                #     version=1,
                                #     error_correction=qrcode.constants.ERROR_CORRECT_L,
                                #     box_size=10,
                                #     border=4,
                                # )
                                # qr.add_data(qr_data)
                                # qr.make(fit=True)

                                # img = qr.make_image(fill_color="black", back_color="white")

                                # # Save or display the image
                                # # img.save("my_qrcode.png")

                                # # Convert image to BytesIO
                                # img_io = BytesIO()
                                # img.save(img_io, format='JPEG')

                                # # Convert BytesIO to base64
                                # qr_code_base64 = base64.b64encode(img_io.getvalue()).decode()
                                # visitor_requests_data["qr_code"] = qr_code_base64

                            visitor_requests_data_list.append(visitor_requests_data)

                    return Response(visitor_requests_data_list)

                else:
                    return Response({"submit": "You are not Visitor."}, status=status.HTTP_400_BAD_REQUEST)

            else:
                return Response({"submit": "You don't have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity has expired."}, status=status.HTTP_400_BAD_REQUEST)


#DropDown
class VisitorProvidedAccessoryListForApprovalView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, id, format=None):

        approval = Approval.objects.get(pk=id)
        visitor_request_id = approval.visitor_request_id
        
        visitor_accessory = VisitorProvidedAccessory.objects.filter(visitor_request_id=visitor_request_id).all()
        visitor_accessory_serializer = VisitorProvidedAccessoryListSerializer(visitor_accessory, many=True)
        return Response(visitor_accessory_serializer.data)

#DropDown
class VisitorHaveAccessoryListForApprovalView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, id, format=None):

        approval = Approval.objects.get(pk=id)
        visitor_request_id = approval.visitor_request_id


        visitor_accessory = VisitorHaveAccessory.objects.filter(visitor_request_id=visitor_request_id).all()
        visitor_accessory_serializer = VisitorHaveAccessorySerializerList(visitor_accessory, many=True)
        return Response(visitor_accessory_serializer.data)
    


#DefaultVisitorHaveAccessory API

class DefaultVisitorHaveAccessoryView(APIView):
    permission_classes = [IsAuthenticated]

    pagination_class = LimitOffsetPagination

    def get_object(self, id):
        try:
            return DefaultVisitorHaveAccessory.objects.get(id=id)
        except DefaultVisitorHaveAccessory.DoesNotExist:
            raise Http404
        
    ObjectSerializer = DefaultVisitorHaveAccessorySerializer
    model_name = 'DefaultVisitorHaveAccessory'

    def get(self, request, format=None):
        limit = int(request.GET.get('limit',10))
        offset = int(request.GET.get('offset',0))
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'default_accessory' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['default_accessory']:
                    acess_to_page = True
            if acess_to_page == True:
                sub_company_detail_id = None
                if len(get_user_data['sub_company']) > 0:
                    sub_company_detail_id = get_user_data['sub_company']['id']

                default_accessory_queryset = DefaultVisitorHaveAccessory.objects.filter(company_detail_id = get_user_data['company_detail']['id'], sub_company_id=sub_company_detail_id).order_by('-id').all()[offset:limit+offset]
                default_accessory_count = DefaultVisitorHaveAccessory.objects.filter(company_detail_id = get_user_data['company_detail']['id'], sub_company_id = sub_company_detail_id).count()
                serializer = self.ObjectSerializer(default_accessory_queryset, many=True)
                return Response({'count':default_accessory_count, 'results': serializer.data})
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
                    
    def post(self, request, format=None):

        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'default_accessory' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['default_accessory']:
                    acess_to_page = True
            if acess_to_page == True:
                sub_company_detail_id = None
                if len(get_user_data['sub_company']) > 0:
                    sub_company_detail_id = get_user_data['sub_company']['id']
                data = request.data
                data['company_detail_id'] = get_user_data['company_detail']['id']
                data['sub_company_id'] = sub_company_detail_id
                serializer = self.ObjectSerializer(data=data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class DefaultVisitorHaveAccessoryDetailView(APIView):
    permission_classes = [IsAuthenticated]

    def get_object(self, pk):
        try:
            return DefaultVisitorHaveAccessory.objects.get(pk=pk)
        except DefaultVisitorHaveAccessory.DoesNotExist:
            raise Http404
        
    ObjectSerializer = DefaultVisitorHaveAccessorySerializer

    def get(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'default_accessory' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['default_accessory']:
                    acess_to_page = True
            if acess_to_page == True:
                print(r'get details of id: ', id)
                company_detail_id = request.user.company_detail_id
                sub_company_id = request.user.sub_company_id
                #queryset = self.get_object(pk=id)
                queryset = DefaultVisitorHaveAccessory.objects.filter(pk=id,
                                                                company_detail_id=company_detail_id, sub_company_id=sub_company_id).first()

                serializer = self.ObjectSerializer(queryset)
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def patch(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'default_accessory' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['default_accessory']:
                    acess_to_page = True
            if acess_to_page == True:
                sub_company = self.get_object(pk=id)
                print("sub_company", sub_company)
                data = request.data.copy()
                #data['company_detail_id'] = self.get_company()
                print("patch data", data)
                serializer = self.ObjectSerializer(sub_company, data=data, partial=True)
                if serializer.is_valid():
                    print("serializer is valid")
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'default_accessory' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['default_accessory']:
                    acess_to_page = True
            if acess_to_page == True:
                sub_company_detail_id = None
                if len(get_user_data['sub_company']) > 0:
                    sub_company_detail_id = get_user_data['sub_company']['id']
                data = request.data
                data['company_detail_id'] = get_user_data['company_detail']['id']
                data['sub_company_id'] = sub_company_detail_id
                queryset = self.get_object(pk=id)
                serializer = self.ObjectSerializer(queryset, data=data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'default_accessory' in get_user_data['permission'].keys():
                if 'delete' in get_user_data['permission']['default_accessory']:
                    acess_to_page = True
            if acess_to_page == True:
                company_detail_id = request.user.company_detail_id
                sub_company_id = request.user.sub_company_id
                #queryset = self.get_object(pk=id)
                queryset = DefaultVisitorHaveAccessory.objects.filter(pk=id,
                                                                company_detail_id=company_detail_id, sub_company_id=sub_company_id).first()
                try:
                    queryset.delete()
                    return Response(status=status.HTTP_204_NO_CONTENT)
                except Exception as e:
                    return Response({"submit": "Cannot delete. This Accessory is used for visitor accessory."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
        

#DropDown
class DefaultVisitorHaveAccessoryListView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        company_detail_id = request.user.company_detail_id
        sub_company_id = request.user.sub_company_id

        if company_detail_id:
            visitor_accessory = DefaultVisitorHaveAccessory.objects.filter(company_detail_id=company_detail_id,sub_company_id=sub_company_id)

        if sub_company_id:
            visitor_accessory = DefaultVisitorHaveAccessory.objects.filter(sub_company_id=sub_company_id)
            
        visitor_accessory_serializer = DefaultVisitorHaveAccessoryListSerializer(visitor_accessory, many=True)
        return Response(visitor_accessory_serializer.data)
    

#Dropdown
class VisitorProvidedAccessoryListForFineView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, id, format=None):

        # visitor_fine = VisitorFine.objects.get(pk=id)
        # visitor_request_id = visitor_fine.visitor_request_id
        
        visitor_accessory = VisitorProvidedAccessory.objects.filter(visitor_request_id=id).all()
        visitor_accessory_serializer = VisitorProvidedAccessoryListSerializer(visitor_accessory, many=True)
        return Response(visitor_accessory_serializer.data)



class VisitorRequestQRDetailView(APIView):

    def get(self, request, uuid):
        sub_company_id = None
        
        # visitor_id = VisitorDetail.objects.get(pk=id)

        visitor_requests = VisitorRequest.objects.filter(uuid=uuid)
        
        print("visitor_request", visitor_requests)
    
        if not visitor_requests.exists():
            return Response({"message": "No visitor requests data"})

        for visitor in visitor_requests:
            visitor_request_id = visitor.id
            visitor_detail_id = visitor.visitor_detail_id_id
            company_detail_id = visitor.company_detail_id
            sub_company_id = visitor.sub_company_id

            print("visitor_request_id", visitor_request_id)
            print("visitor_detail_id", visitor_detail_id)

            visitor_detail_ids = set()
            visitor_requests_data_list = []

            
            # visitor_detail_id = visitor_request.visitor_detail_id_id
            # company_detail_id = visitor_request.company_detail_id
            # sub_company_id = visitor_request.sub_company_id
            if visitor_detail_id not in visitor_detail_ids:
                visitor_detail_ids.add(visitor_detail_id)

                visitor_detail = VisitorDetail.objects.get(id=visitor_detail_id)

                

                # Access the related VisitorHaveAccessory using visitor_request_id
                visitor_have_accessory = VisitorHaveAccessory.objects.filter(
                    visitor_request_id=visitor_request_id
                ).first()

                default_accessory_have = []
                if visitor_have_accessory:
                    # Access the related DefaultVisitorHaveAccessory using default_visitor_have_accessory_id
                    default_accessory_have = visitor_have_accessory.default_visitor_have_accessory_id
                
                # Access the related VisitorProvidedAccessory using visitor_request_id
                visitor_provided_accessory = VisitorProvidedAccessory.objects.filter(
                    visitor_request_id=visitor_request_id
                ).first()

                default_accessory_provided = []
                if visitor_provided_accessory:
                    # Access the related DefaultAccessoryProvidedByCompany using default_accessory_provided_by_company_id
                    default_accessory_provided = visitor_provided_accessory.default_accessory_provided_by_company_id

                

                visitor_request = True

                request = VisitorRequest.objects.filter(
                Q(visitor_detail_id=visitor_detail_id) &
                Q(Q(company_detail_id=company_detail_id) | Q(sub_company_id=sub_company_id))).exists()

                approve_request = VisitorRequest.objects.filter(
                    Q(visitor_detail_id=visitor_detail_id) &
                    Q(Q(company_detail_id=company_detail_id) | Q(sub_company_id=sub_company_id)) &
                    Q(approval__final_approval=True)).first()
                
                reject_request = VisitorRequest.objects.filter(
                    Q(visitor_detail_id=visitor_detail_id) &
                    Q(Q(company_detail_id=company_detail_id) | Q(sub_company_id=sub_company_id)) &
                    Q(approval__approval_type_id__approval_name='Reject')).first()
                

                if request:
                    request_detail = VisitorRequest.objects.filter(
                    Q(visitor_detail_id=visitor_detail_id) &
                    Q(Q(company_detail_id=company_detail_id) | Q(sub_company_id=sub_company_id))).first()

                    if approve_request:
                        current_date = timezone.now()
                        time_difference = request_detail.to_date - current_date

                        if time_difference.days > 1:
                            visitor_request = False

                    elif reject_request:
                        current_date = timezone.now()
                        time_difference1 = current_date - request_detail.from_date
                        if time_difference1.days <= 1:
                            visitor_request = False

                    else:
                        visitor_request = False

                id_proof = None
                if visitor_detail.id_proof_type_id:
                    id_proof = visitor_detail.id_proof_type_id.id_proof 
                pass_generation = False
                visitor_data = {
                    "first_name": visitor_detail.first_name,
                        "last_name": visitor_detail.last_name,
                        "phone_no": visitor_detail.phone_no,
                        "id_proof_type": id_proof,
                        "id_proof_no":visitor_detail.id_proof_no,
                        
                }
                
                final_approval = False
                if approve_request:
                    final_approval = True

                if all(visitor_data.values()) and approve_request:
                    pass_generation = True


                visitor_requests_data = {
                    "id": visitor_request_id,
                    "email": visitor.email,
                    "department_id": visitor.department_id.id,
                    "department": visitor.department_id.department_name,
                    "from_date": visitor.from_date,
                    "to_date": visitor.to_date,
                    "purpose_of_visit": visitor.purpose_of_visit,
                    "type":visitor.type,
                    "visitor_detail": {
                        "id": visitor_detail.id,
                        "photo": visitor_detail.photo,
                        "first_name": visitor_detail.first_name,
                        "last_name": visitor_detail.last_name,
                        "phone_no": visitor_detail.phone_no,
                        "id_proof_type": id_proof,
                        "id_proof_no":visitor_detail.id_proof_no,
                        "id_proof_photo": visitor_detail.id_proof_photo,
                        "vehicle_no":visitor_detail.vehicle_no,
                        "address":visitor_detail.address
                    },
                    "default_accessory_have": {
                        "accessory_name": default_accessory_have.accessory_name if default_accessory_have else "N/A"
                    },
                    "default_accessory_provided": {
                        "accessory_name": default_accessory_provided.accessory_name if default_accessory_provided else "N/A"
                    },
                    "final_approval": final_approval,
                    "visitor_request": visitor_request,
                    "pass_generation": pass_generation
                }

                visitor_requests_data_list.append(visitor_requests_data)

        return Response(visitor_requests_data_list)
    

class DashboardView(APIView):
    def get(self,request):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'dashboard' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['dashboard']:
                    acess_to_page = True
            if acess_to_page == True:
                company_detail_id = request.user.company_detail_id
                sub_company_id = request.user.sub_company_id

                start_date = request.GET.get('start_date')
                end_date = request.GET.get('end_date')
                if start_date and end_date:

                    start_date = timezone.make_aware(datetime.strptime(start_date, '%Y-%m-%d'))
                    end_date = timezone.make_aware(datetime.strptime(end_date, '%Y-%m-%d'))

                    approved_visitor_requests_count = Approval.objects.filter(visitor_request_id__from_date__gte=start_date,visitor_request_id__to_date__lte=end_date,visitor_request_id__company_detail_id=company_detail_id,visitor_request_id__sub_company_id=sub_company_id,final_approval=True).count()
                    pending_visitor_request_count = Approval.objects.filter(visitor_request_id__from_date__gte=start_date,visitor_request_id__to_date__lte=end_date,approval_type_id__approval_name = 'Hold').count()
                    # visitors_list = Approval.objects.filter(visitor_request_id__from_date__gte=start_date,visitor_request_id__to_date__lte=end_date,final_approval=True).values_list('visitor_request_id.visitor_detail_id.first_name','visitor_request_id.visitor_detail_id.last_name','visitor_request_id.visitor_detail_id.photo')
                    
                    visitors_list = Approval.objects.filter(
                        visitor_request_id__from_date__gte=start_date,
                        visitor_request_id__to_date__lte=end_date,visitor_request_id__company_detail_id=company_detail_id,visitor_request_id__sub_company_id=sub_company_id,
                        final_approval=True
                    ).select_related('visitor_request_id__visitor_detail_id').annotate(
                        request_id=F('visitor_request_id'),
                        first_name=F('visitor_request_id__visitor_detail_id__first_name'),
                        last_name=F('visitor_request_id__visitor_detail_id__last_name'),
                        photo=F('visitor_request_id__visitor_detail_id__photo'),
                        from_date = F('visitor_request_id__from_date'),
                        to_date=F('visitor_request_id__to_date')
                    ).values('request_id','first_name', 'last_name', 'photo','from_date','to_date')
                    checked_in_count = CheckedInOut.objects.filter(in_datetime__gte=start_date,in_datetime__lte=end_date,out_datetime__isnull=True).count()
                    checked_out_count = CheckedInOut.objects.filter(out_datetime__gte=start_date,out_datetime__lte=end_date,out_datetime__isnull=False).count()
                    

                    results = {
                            'approved_visitor_requests_count': approved_visitor_requests_count,
                            'pending_visitor_request_count': pending_visitor_request_count,
                            'visitors_list': list(visitors_list),
                            'checked_in_count': checked_in_count,
                            'checked_out_count': checked_out_count
                        }
                    return JsonResponse(results, safe=False)
                else:
                    return Response({"detail": "Start date and End date are required"}, status=400)
            else:
                return Response({"detail": "you don't have permission."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
        


class GraphDashboardView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity']:
            if 'dashboard' in get_user_data['permission'] and 'view' in get_user_data['permission']['dashboard']:
                company_detail_id = request.user.company_detail_id
                sub_company_id = request.user.sub_company_id

                start_date = request.GET.get('start_date')
                end_date = request.GET.get('end_date')

                if start_date and end_date:
                    # start_date = datetime.strptime(start_date, '%Y-%m-%d')
                    # end_date = datetime.strptime(end_date, '%Y-%m-%d')
                    start_date = timezone.make_aware(datetime.strptime(start_date, '%Y-%m-%d'))
                    end_date = timezone.make_aware(datetime.strptime(end_date, '%Y-%m-%d'))
                    date_range = (end_date - start_date).days
                    print("days", date_range)

                    if date_range > 30:
                        period = 'month'
                    elif 7 <= date_range <= 30:
                        period = 'week'
                    # elif date_range > 3:
                    #     period = 'three_days'
                    elif date_range <= 7:
                        period = 'day'
                    else:
                        return Response({"detail": "Date range must be at least three days."}, status=400)
                    
                    if period == 'month':
                        results = self.get_monthly_data(start_date, end_date)
                    elif period == 'week':
                        results = self.get_weekly_data(start_date, end_date)
                    # elif period == 'three_days':
                    #     results = self.get_three_days_data(start_date, end_date)
                    elif period == 'day':
                        results = self.get_daily_data(start_date, end_date)

                    return JsonResponse(results, safe=False)
                else:
                    return Response({"detail": "Start date and End date are required"}, status=400)
            else:
                return Response({"detail": "You don't have permission."}, status=400)
        else:
            return Response({"detail": "Account validity has expired."}, status=400)

    def get_monthly_data(self, start_date, end_date):
        data = []
        current_date = start_date
        while current_date <= end_date:
            next_month = current_date + relativedelta(months=1)
            count = CheckedInOut.objects.filter(
                out_datetime__gte=current_date,
                out_datetime__lt=next_month,
                out_datetime__isnull=False
            ).count()
            data.append({
                'month': current_date.strftime('%B %Y'),
                'count': count
            })
            current_date = next_month
        return data

    def get_weekly_data(self, start_date, end_date):
        data = []
        current_date = start_date

        while current_date < end_date:
            # Calculate the end of the current week interval
            next_week = current_date + timedelta(days=7)
            if next_week > end_date:
                next_week = end_date

            count = CheckedInOut.objects.filter(
                out_datetime__gte=current_date,
                out_datetime__lt=next_week,
                out_datetime__isnull=False
            ).count()

            data.append({
                'week': f"{current_date.strftime('%Y-%m-%d')} to {next_week.strftime('%Y-%m-%d')}",
                'count': count
            })

            # Move to the next week
            current_date = next_week + timedelta(days=1)
            
        return data

    # def get_three_days_data(self, start_date, end_date):
    #     data = []
    #     current_date = start_date
    #     while current_date <= end_date:
    #         next_date = current_date + timedelta(days=3)
    #         count = CheckedInOut.objects.filter(
    #             out_datetime__gte=current_date,
    #             out_datetime__lt=next_date,
    #             out_datetime__isnull=False
    #         ).count()
    #         data.append({
    #             'period': f"{current_date.strftime('%Y-%m-%d')} to {next_date.strftime('%Y-%m-%d')}",
    #             'count': count
    #         })
    #         current_date = next_date
    #     return data

    def get_daily_data(self, start_date, end_date):
        data = []
        current_date = start_date
        while current_date <= end_date:
            next_date = current_date + timedelta(days=1)
            count = CheckedInOut.objects.filter(
                out_datetime__gte=current_date,
                out_datetime__lt=next_date,
                out_datetime__isnull=False
            ).count()
            data.append({
                'date': current_date.strftime('%Y-%m-%d'),
                'count': count
            })
            current_date = next_date
        return data

#CheckedInOut API

class CheckedInOutView(APIView):
    permission_classes = [IsAuthenticated]

    pagination_class = LimitOffsetPagination

    def get_object(self, id):
        try:
            return CheckedInOut.objects.get(id=id)
        except CheckedInOut.DoesNotExist:
            raise Http404
        
    ObjectSerializer = CheckedInOutSerializer
    model_name = 'CheckedInOut'

        

    def get(self, request, format=None):
        limit = int(request.GET.get('limit',10))
        offset = int(request.GET.get('offset',0))
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'checked' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['checked']:
                    acess_to_page = True
            if acess_to_page == True:

                checked_queryset = CheckedInOut.objects.filter(out_datetime__isnull=True).order_by('-id').all()[offset:limit+offset]
                checked_count = CheckedInOut.objects.filter(out_datetime__isnull=True).count()
                serializer = self.ObjectSerializer(checked_queryset, many=True)
                return Response({'count':checked_count, 'results': serializer.data})
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
        
                    
    def post(self, request, format=None):

        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'checked' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['checked']:
                    acess_to_page = True
            if acess_to_page == True:
                data = request.data
                serializer = self.ObjectSerializer(data=data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class CheckedInOutDetailView(APIView):
    permission_classes = [IsAuthenticated]

    def get_object(self, pk):
        try:
            return CheckedInOut.objects.get(pk=pk)
        except CheckedInOut.DoesNotExist:
            raise Http404
        
    ObjectSerializer = CheckedInOutSerializer

    def get(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'checked' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['checked']:
                    acess_to_page = True
            if acess_to_page == True:
                #queryset = self.get_object(pk=id)
                queryset = CheckedInOut.objects.filter(pk=id).first()

                serializer = self.ObjectSerializer(queryset)
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


    # def put(self, request, id, format=None):
    #     get_user_data = getUserDataLogin(request.user.id)
        
    #     if get_user_data['company_detail']['account_validity'] == True:
    #         acess_to_page = False
    #         if 'checked' in get_user_data['permission'].keys():
    #             if 'update' in get_user_data['permission']['checked']:
    #                 acess_to_page = True
    #         if acess_to_page == True:
                
    #             data = request.data

    #             queryset = self.get_object(pk=id)
    #             serializer = self.ObjectSerializer(queryset, data=data)
    #             if serializer.is_valid():
    #                 serializer.save()
    #                 return Response(serializer.data)
    #             return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    #         else:
    #             return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

    #     else:
    #         return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


    def put(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity']:
            access_to_page = False
            if 'checked' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['checked']:
                    access_to_page = True
            if access_to_page:
                try:
                    checked_in_out_instance = self.get_object(id)
                except Http404:
                    return Response({"detail": "Not found."}, status=status.HTTP_404_NOT_FOUND)

                # Only update the out_datetime field
                checked_in_out_instance.out_datetime = timezone.now()
                checked_in_out_instance.save()

                serializer = CheckedInOutSerializer(checked_in_out_instance)
                return Response(serializer.data)
            else:
                return Response({"detail": "You don't have permission to access."}, status=status.HTTP_403_FORBIDDEN)
        else:
            return Response({"detail": "Account validity has expired."}, status=status.HTTP_403_FORBIDDEN)


    # def delete(self, request, id, format=None):
    #     get_user_data = getUserDataLogin(request.user.id)
        
    #     if get_user_data['company_detail']['account_validity'] == True:
    #         acess_to_page = False
    #         if 'checked' in get_user_data['permission'].keys():
    #             if 'delete' in get_user_data['permission']['checked']:
    #                 acess_to_page = True
    #         if acess_to_page == True:
               
    #             queryset = CheckedInOut.objects.filter(pk=id).first()
    #             try:
    #                 queryset.delete()
    #                 return Response(status=status.HTTP_204_NO_CONTENT)
    #             except Exception as e:
    #                 return Response({"submit": "Cannot delete. This Accessory is used for visitor accessory."}, status=status.HTTP_400_BAD_REQUEST)
    #         else:
    #             return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

    #     else:
    #         return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
        



class CheckedOutView(APIView):
    permission_classes = [IsAuthenticated]

    pagination_class = LimitOffsetPagination

    def get_object(self, id):
        try:
            return CheckedInOut.objects.get(id=id)
        except CheckedInOut.DoesNotExist:
            raise Http404
        
    ObjectSerializer = CheckedInOutSerializer
    model_name = 'CheckedInOut'

    def get(self, request, format=None):
        limit = int(request.GET.get('limit',10))
        offset = int(request.GET.get('offset',0))
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'checked' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['checked']:
                    acess_to_page = True
            if acess_to_page == True:

                checked_queryset = CheckedInOut.objects.filter(out_datetime__isnull=False).order_by('-id').all()[offset:limit+offset]
                checked_count = CheckedInOut.objects.filter(out_datetime__isnull=False).count()
                serializer = self.ObjectSerializer(checked_queryset, many=True)
                return Response({'count':checked_count, 'results': serializer.data})
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class FetchAssociatedCompanies(APIView):
    permission_classes = (AllowAny,)

    def get(self, request, format=None):
        email = request.query_params.get('email')
        if not email:
            return Response({"detail": "Email is required."}, status=status.HTTP_400_BAD_REQUEST)

        try:
            user = User.objects.get(email=email)
        except User.DoesNotExist:
            return Response({"detail": "User with this email does not exist."}, status=status.HTTP_404_NOT_FOUND)

        existing_companies = VisitorDetail.objects.filter(user_id=user.id).values(
            'company_detail_id', 
            'company_detail_id__company_name'
        )

        if existing_companies.exists():
            result = [
                {
                    'company_detail_id': company['company_detail_id'],
                    'company_name': company['company_detail_id__company_name']
                }
                for company in existing_companies
            ]
            return Response({"results": result}, status=status.HTTP_200_OK)
        else:
            return Response({"detail": "No companies found for this user."}, status=status.HTTP_404_NOT_FOUND)


# sachin
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .models import VisitorRequest, Approval, ApprovalType, ApproveStepByRole
from .serializers import ApprovalSerializer

#
# class VisitorApprovalView(APIView):
#     permission_classes = [IsAuthenticated]
#
#     def get(self, request, format=None):
#         get_user_data = getUserDataLogin(request.user.id)
#
#         if get_user_data['company_detail']['account_validity'] == True:
#             access_to_page = False
#             if 'visitor_approval' in get_user_data['permission'].keys():
#                 if 'view' in get_user_data['permission']['visitor_approval']:
#                     access_to_page = True
#
#             if access_to_page:
#                 try:
#                     visitor_requests = VisitorRequest.objects.all()
#                     approvals = Approval.objects.filter(visitor_request__in=visitor_requests)
#
#                     data = []
#                     for visitor_request in visitor_requests:
#                         approval = approvals.filter(visitor_request=visitor_request).first()
#                         if approval:
#                             serializer = ApprovalSerializer(approval)
#                             approval_data = serializer.data
#                             approval_data.update({
#                                 'visitor_name': f"{visitor_request.visitor_detail.first_name} {visitor_request.visitor_detail.last_name}",
#                                 'purpose_of_visit': visitor_request.purpose_of_visit,
#                                 'from_date': visitor_request.from_date,
#                                 'to_date': visitor_request.to_date,
#                                 'department': visitor_request.department.department_name,
#                                 'host_name': visitor_request.employee.name
#                             })
#                             data.append(approval_data)
#
#                     if not data:
#                         return Response({"error": "No approvals found"}, status=status.HTTP_404_NOT_FOUND)
#
#                     return Response(data)
#
#                 except Exception as e:
#                     return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
#             else:
#                 return Response({"submit": "You don't have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)
#         else:
#             return Response({"submit": "Account Validity has expired."}, status=status.HTTP_400_BAD_REQUEST)
#
#     def post(self, request, visitor_request_id, format=None):
#         get_user_data = getUserDataLogin(request.user.id)
#
#         if get_user_data['company_detail']['account_validity'] == True:
#             access_to_page = False
#             if 'visitor_approval' in get_user_data['permission'].keys():
#                 if 'create' in get_user_data['permission']['visitor_approval']:
#                     access_to_page = True
#
#             if access_to_page:
#                 action = request.data.get('action')
#
#                 try:
#                     visitor_request = VisitorRequest.objects.get(id=visitor_request_id)
#                     approval, created = Approval.objects.get_or_create(
#                         visitor_request=visitor_request,
#                         defaults={
#                             'approval_by': request.user,
#                             'role': request.user.role,
#                             'approval_type': ApprovalType.objects.get(name='Pending'),
#                             'approval_step_by_role': ApproveStepByRole.objects.get(step=1),
#                             'approval_change_by_number_of_days': visitor_request.approval_change_by_number_of_days
#                         }
#                     )
#
#                     if action == 'approve':
#                         approval.approval_type = ApprovalType.objects.get(name='Approved')
#                     elif action == 'reject':
#                         approval.approval_type = ApprovalType.objects.get(name='Rejected')
#                     elif action == 'unhold':
#                         approval.approval_type = ApprovalType.objects.get(name='Pending')
#                     else:
#                         return Response({"error": "Invalid action"}, status=status.HTTP_400_BAD_REQUEST)
#
#                     approval.save()
#
#                     serializer = ApprovalSerializer(approval)
#                     return Response(serializer.data)
#
#                 except VisitorRequest.DoesNotExist:
#                     return Response({"error": "Visitor request not found"}, status=status.HTTP_404_NOT_FOUND)
#                 except Exception as e:
#                     return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
#             else:
#                 return Response({"submit": "You don't have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)
#         else:
#             return Response({"submit": "Account Validity has expired."}, status=status.HTTP_400_BAD_REQUEST)


class VisitorApprovalView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, format=None):
        get_user_data = getUserDataLogin(request.user.id)

        if get_user_data['company_detail']['account_validity'] == True:
            access_to_page = False
            if 'visitor_approval' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['visitor_approval']:
                    access_to_page = True

            if access_to_page:
                try:
                    visitor_requests = VisitorRequest.objects.all()
                    approvals = Approval.objects.filter(visitor_request__in=visitor_requests)

                    data = []
                    for visitor_request in visitor_requests:
                        approval = approvals.filter(visitor_request=visitor_request).first()
                        if approval:
                            serializer = ApprovalSerializer(approval)
                            approval_data = serializer.data
                            approval_data.update({
                                'visitor_name': f"{visitor_request.visitor_detail_id.first_name} {visitor_request.visitor_detail_id.last_name}",
                                'purpose_of_visit': visitor_request.purpose_of_visit,
                                'from_date': visitor_request.from_date,
                                'to_date': visitor_request.to_date,
                                'department': visitor_request.department_id.department_name,
                                'host_name': visitor_request.employee_id.name if visitor_request.employee_id else visitor_request.employee_name
                            })
                            data.append(approval_data)

                    if not data:
                        return Response({"error": "No approvals found"}, status=status.HTTP_404_NOT_FOUND)

                    return Response(data)

                except Exception as e:
                    return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
            else:
                return Response({"submit": "You don't have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"submit": "Account Validity has expired."}, status=status.HTTP_400_BAD_REQUEST)

    def post(self, request, visitor_request_id, format=None):
        get_user_data = getUserDataLogin(request.user.id)

        if get_user_data['company_detail']['account_validity'] == True:
            access_to_page = False
            if 'visitor_approval' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['visitor_approval']:
                    access_to_page = True

            if access_to_page:
                action = request.data.get('action')

                try:
                    visitor_request = VisitorRequest.objects.get(id=visitor_request_id)
                    approval, created = Approval.objects.get_or_create(
                        visitor_request=visitor_request,
                        defaults={
                            'approval_by': request.user,
                            'role': request.user.role,
                            'approval_type': ApprovalType.objects.get(name='Pending'),
                            'approval_step_by_role': ApproveStepByRole.objects.get(step=1),
                            'approval_change_by_number_of_days': visitor_request.approval_change_by_number_of_days
                        }
                    )

                    if action == 'approve':
                        approval.approval_type = ApprovalType.objects.get(name='Approved')
                    elif action == 'reject':
                        approval.approval_type = ApprovalType.objects.get(name='Rejected')
                    elif action == 'unhold':
                        approval.approval_type = ApprovalType.objects.get(name='Pending')
                    else:
                        return Response({"error": "Invalid action"}, status=status.HTTP_400_BAD_REQUEST)

                    approval.save()

                    serializer = ApprovalSerializer(approval)
                    return Response(serializer.data)

                except VisitorRequest.DoesNotExist:
                    return Response({"error": "Visitor request not found"}, status=status.HTTP_404_NOT_FOUND)
                except Exception as e:
                    return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
            else:
                return Response({"submit": "You don't have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"submit": "Account Validity has expired."}, status=status.HTTP_400_BAD_REQUEST)


class EmployeeVisitorRequestView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        if get_user_data['company_detail']['account_validity'] == True:
            access_to_page = False
            if 'visitor_request' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['visitor_request']:
                    access_to_page = True
            if access_to_page == True:
                # Handle request filtering
                filters = {}
                for field in ['name', 'email', 'from_date', 'to_date', 'department', 'host_name', 'purpose_of_visit']:
                    if request.query_params.get(field):
                        filters[field] = request.query_params.get(field)

                # Handle provided accessory and visitor accessory filters
                provided_accessory = request.query_params.get('provided_accessory')
                visitor_accessory = request.query_params.get('visitor_accessory')

                queryset = VisitorRequest.objects.filter(**filters)

                if provided_accessory:
                    queryset = queryset.filter(
                        visitorprovidedaccessory__default_accessory_provided_by_company__accessory_name=provided_accessory)

                if visitor_accessory:
                    queryset = queryset.filter(
                        visitorhaveaccessory__default_visitor_have_accessory__accessory_name=visitor_accessory)

                queryset = queryset
                serializer = VisitorRequestSerializer(queryset, many=True)
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "You don't have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"submit": "Account Validity has expired."}, status=status.HTTP_400_BAD_REQUEST)

    def post(self, request, format=None):
        get_user_data = getUserDataLogin(request.user.id)

        if get_user_data['company_detail']['account_validity'] == True:
            access_to_page = False
            if 'visitor_request' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['visitor_request']:
                    access_to_page = True
            if access_to_page == True:
                serializer = VisitorRequestSerializer(data=request.data)
                if serializer.is_valid():
                    serializer.save(employee=request.user.employee)
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don't have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"submit": "Account Validity has expired."}, status=status.HTTP_400_BAD_REQUEST)

class AccessoryOptionsView(APIView):
    permission_classes = (IsAuthenticated,)
    def get(self, request):
        provided_accessories = DefaultAccessoryProvidedByCompany.objects.values_list('accessory_name',
                                                                                     flat=True).distinct()
        visitor_accessories = DefaultVisitorHaveAccessory.objects.values_list('accessory_name', flat=True).distinct()

        return Response({
            'provided_accessories': list(provided_accessories),
            'visitor_accessories': list(visitor_accessories)
        })

class CheckedInOutAPIView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, format=None):
        get_user_data = getUserDataLogin(request.user.id)

        if get_user_data['company_detail']['account_validity'] == True:
            access_to_page = False
            if 'checked_in_out' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['checked_in_out']:
                    access_to_page = True
            if access_to_page == True:
                # Get all visitors who are currently checked in (out_datetime is None)
                queryset = CheckedInOut.objects.filter(out_datetime__isnull=True)
                serializer = CheckedInOutSerializer(queryset, many=True)
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "You don't have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"submit": "Account Validity has expired."}, status=status.HTTP_400_BAD_REQUEST)

    def post(self, request, format=None):
        get_user_data = getUserDataLogin(request.user.id)

        if get_user_data['company_detail']['account_validity'] == True:
            access_to_page = False
            if 'checked_in_out' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['checked_in_out']:
                    access_to_page = True
            if access_to_page == True:
                serializer = CheckedInOutSerializer(data=request.data)
                if serializer.is_valid():
                    serializer.save(in_datetime=django.utils.timezone.now(), out_datetime=None)
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don't have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"submit": "Account Validity has expired."}, status=status.HTTP_400_BAD_REQUEST)

class CheckedOutAPIView(APIView):
    permission_classes = (IsAuthenticated,)
    def get(self, request, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        if get_user_data['company_detail']['account_validity'] == True:
            access_to_page = False
            if 'checked_in_out' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['checked_in_out']:
                    access_to_page = True
            if access_to_page == True:
                # Get all visitors who have checked out (out_datetime is not None)
                visitors = CheckedInOut.objects.filter(out_datetime__isnull=False)
                serializer = CheckedInOutSerializer(visitors, many=True)
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "You don't have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"submit": "Account Validity has expired."}, status=status.HTTP_400_BAD_REQUEST)

    def post(self, request, format=None):
        get_user_data = getUserDataLogin(request.user.id)

        if get_user_data['company_detail']['account_validity'] == True:
            access_to_page = False
            if 'checked_in_out' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['checked_in_out']:
                    access_to_page = True
            if access_to_page == True:
                # Handle a visitor check-out
                try:
                    # Find the visitor with the given ID who has not yet checked out
                    visitor = CheckedInOut.objects.get(id=request.data['id'], out_datetime__isnull=True)
                    visitor.out_datetime = django.utils.timezone.now()
                    visitor.save()
                    serializer = CheckedInOutSerializer(visitor)
                    return Response(serializer.data, status=status.HTTP_200_OK)
                except CheckedInOut.DoesNotExist:
                    return Response({'error': 'Visitor not found or already checked out.'},
                                    status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don't have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"submit": "Account Validity has expired."}, status=status.HTTP_400_BAD_REQUEST)


class VisitorFineView(APIView):
    permission_classes = (IsAuthenticated,)
    def get(self, request, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        if get_user_data['company_detail']['account_validity'] == True:
            access_to_page = False
            if 'visitor_fine' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['visitor_fine']:
                    access_to_page = True
            if access_to_page == True:
                visitor_fines = VisitorFine.objects.all()
                serializer = VisitorFineSerializer(visitor_fines, many=True)
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "You don't have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"submit": "Account Validity has expired."}, status=status.HTTP_400_BAD_REQUEST)

    def post(self, request, format=None):
        get_user_data = getUserDataLogin(request.user.id)

        if get_user_data['company_detail']['account_validity'] == True:
            access_to_page = False
            if 'visitor_fine' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['visitor_fine']:
                    access_to_page = True
            if access_to_page == True:
                serializer = VisitorFineSerializer(data=request.data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don't have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"submit": "Account Validity has expired."}, status=status.HTTP_400_BAD_REQUEST)