from django.core.exceptions import ObjectDoesNotExist
from rest_framework import serializers
from rest_framework.validators import UniqueTogetherValidator
from django.db.models import OuterRef, Subquery
from datetime import timedelta
from django.utils import timezone


from .models import Visitor, DefaultVisitorHaveAccessory, VisitorAccessoryForFine, VisitorRequest, AccessoryProvided, \
                    AccessoryReturn, VisitorRestriction, VisitorDetail, VisitorHaveAccessory, AccessoryAllow, VisitorProvidedAccessory, VisitorFine, VisitorLoginLog, \
                    Approval, ApprovalPageGetDetail, MobileType, IdProofType, CheckedInOut

from account.models import User, CompanyDetail, ApprovalType, DefaultAccessoryProvidedByCompany, SubCompany

from account.serializers import DefaultAccessoryProvidedByCompanySerializer, ApprovalTypeSerializer, \
    ApprovalChangeByNumberOfDaysSerializer

from account.serializers import UserLoginSerializer, UserSerializer, CompanyDetailListSerializer

from .models import Employee,  Department

from django.db.models import Q
import base64

class VisitorSerializer(serializers.ModelSerializer):
    department = serializers.CharField(source='department_id.name', read_only=True)
    employee = serializers.CharField(source='employee_id.department_name', read_only=True)

    class Meta:
        model = Visitor
        fields = '__all__'

    def create(self, validated_data):
        fields_to_capitalize = ["name", "company_name", "type_of_mobile", "address", "employee_name", "purpose_of_visit"]

        for field_name in fields_to_capitalize:
            field_value = validated_data.get(field_name)
            if field_value:
                # Capitalize the first letter of the field value
                validated_data[field_name] = field_value.capitalize()

        email = validated_data.get('email')
        if Visitor.objects.filter(email=email).exists():
            raise serializers.ValidationError({"email": "Visitor email must be unique."})
        return super().create(validated_data)

    def update(self, instance, validated_data):
        fields_to_capitalize = ["name", "company_name", "type_of_mobile", "address", "employee_name", "purpose_of_visit"]

        for field_name in fields_to_capitalize:
            field_value = validated_data.get(field_name)
            if field_value:
                # Capitalize the first letter of the field value
                validated_data[field_name] = field_value.capitalize()

        email = validated_data.get('email', instance.email)
        if Visitor.objects.filter(email=email).exclude(id=instance.id).exclude(pk=getattr(self.instance, 'pk', None)).exists():
            raise serializers.ValidationError({"email": "Visitor email must be unique."})
        return super().update(instance, validated_data)

    def delete(self, instance):
        try:
            instance.delete()
        except  Exception as e:
            raise serializers.ValidationError(
                {'submit': 'Cannot delete. This object is referenced by other objects.'})



class DefaultVisitorHaveAccessorySerializer(serializers.ModelSerializer):
    company = serializers.CharField(source='company_detail_id.company_name', read_only=True)
    sub_company = serializers.CharField(source='sub_company_id.sub_company_name', read_only=True)

    class Meta:
        model = DefaultVisitorHaveAccessory
        fields = '__all__'

    def create(self,validated_data):
        sub_company_id = validated_data.get('sub_company_id')
        accessory_name = validated_data.get('accessory_name', '').strip()

        if accessory_name:
            # Capitalize the first letter of accessory_name
            validated_data['accessory_name'] = accessory_name.capitalize()
        if DefaultVisitorHaveAccessory.objects.filter(
                accessory_name=validated_data['accessory_name'],company_detail_id=validated_data['company_detail_id'],sub_company_id=sub_company_id).exists():
            raise serializers.ValidationError(
                    {'accessory_name': 'An entry with the same accessory name already exists.'}
                )
        return DefaultVisitorHaveAccessory.objects.create(**validated_data)



    def update(self, instance, validated_data):
        sub_company_id = validated_data.get('sub_company_id')
        accessory_name = validated_data.get('accessory_name', '').strip()

        if accessory_name:
            # Capitalize the first letter of accessory_name
            validated_data['accessory_name'] = accessory_name.capitalize()
        if DefaultVisitorHaveAccessory.objects.filter(
                accessory_name=validated_data['accessory_name'],company_detail_id=validated_data['company_detail_id'],sub_company_id=sub_company_id).exclude(pk=getattr(self.instance, 'pk', None)).exists():
            raise serializers.ValidationError(
                    {'accessory_name': 'An entry with the same accessory name already exists.'}
                )

        return super().update(instance, validated_data)

    def delete(self, instance):
        try:
            instance.delete()
        except  Exception as e:
            raise serializers.ValidationError(
                {'submit': 'Cannot delete. This object is referenced by other objects.'})


class VisitorAccessoryForFineSerializer(serializers.ModelSerializer):
    accessory_name = serializers.CharField(source='default_accessory.accessory_name', read_only=True)

    class Meta:
        model = VisitorAccessoryForFine
        fields = ['id', 'visitor_fine_id', 'default_accessory_id', 'accessory_name']


    def delete(self, instance):
        try:
            instance.delete()
        except  Exception as e:
            raise serializers.ValidationError(
                {'submit': 'Cannot delete. This object is referenced by other objects.'})





class AccessoryProvidedSerializer(serializers.ModelSerializer):
    default_accessory = serializers.CharField(source='default_accessory_id.accessory_name', read_only=True)

    class Meta:
        model = AccessoryProvided
        fields = '__all__'

    def delete(self, instance):
        try:
            instance.delete()
        except  Exception as e:
            raise serializers.ValidationError(
                {'submit': 'Cannot delete. This object is referenced by other objects.'})


class AccessoryReturnSerializer(serializers.ModelSerializer):
    default_accessory = serializers.CharField(source='default_accessory_id.accessory_name', read_only=True)

    class Meta:
        model = AccessoryReturn
        fields = '__all__'

    def delete(self, instance):
        try:
            instance.delete()
        except  Exception as e:
            raise serializers.ValidationError(
                {'submit': 'Cannot delete. This object is referenced by other objects.'})


class VisitorRestrictionSerializer(serializers.ModelSerializer):
    company = serializers.CharField(source='company_detail_id.company_name', read_only=True)
    sub_company = serializers.CharField(source='sub_company_id.sub_company_name', read_only=True)

    class Meta:
        model = VisitorRestriction
        fields = '__all__'

    def create(self, validated_data):
        company_detail_id = validated_data.get('company_detail_id')
        sub_company_id = validated_data.get('sub_company_id')

        # Check if a VisitorRestriction with the same company_detail_id already exists
        existing_visitor_restriction = VisitorRestriction.objects.filter(remove_restriction_after_days=validated_data['remove_restriction_after_days'], company_detail_id=company_detail_id,sub_company_id=sub_company_id).first()

        if existing_visitor_restriction:
            raise serializers.ValidationError({'remove_restriction_after_days': 'A VisitorRestriction for this company already exists.'})

        return super().create(validated_data)

    def update(self,instance, validated_data):
        company_detail_id = validated_data.get('company_detail_id')
        sub_company_id = validated_data.get('sub_company_id')

        # Check if a VisitorRestriction with the same company_detail_id already exists
        existing_visitor_restriction = VisitorRestriction.objects.filter(remove_restriction_after_days=validated_data['remove_restriction_after_days'], company_detail_id=company_detail_id,sub_company_id=sub_company_id).exclude(pk=getattr(self.instance, 'pk', None)).first()

        if existing_visitor_restriction:
            raise serializers.ValidationError({'remove_restriction_after_days': 'A VisitorRestriction for this company already exists.'})

        return super().update(instance, validated_data)

    def delete(self, instance):
        try:
            instance.delete()
        except Exception as e:
            raise serializers.ValidationError(
                {'submit': 'Cannot delete. This object is referenced by other objects.'})


class VisitorDetailSerializer(serializers.ModelSerializer):
    visiting_company_name = serializers.CharField(source="company_detail_id.company_name",read_only=True)
    class Meta:
        model = VisitorDetail
        fields = '__all__'
        # exclude = ['user_id']
        # fields = ['id',"first_name","last_name",]

    def create(self, validated_data):
        fields_to_capitalize = ["first_name", "last_name", "designation", "company_type", "company_name", "address"]

        for field_name in fields_to_capitalize:
            field_value = validated_data.get(field_name)
            if field_value:
                # Capitalize the first letter of the field value
                validated_data[field_name] = field_value.capitalize()

        return super().create(validated_data)

    def update(self, instance, validated_data):
        photo = validated_data.get('photo')
        if photo:
            validated_data['photo'] = self.validate_photo(photo)

        id_proof_photo = validated_data.get('id_proof_photo')
        if id_proof_photo:
            validated_data['id_proof_photo'] = self.validate_photo(id_proof_photo)

        fields_to_capitalize = ["first_name", "last_name", "designation", "company_type", "company_name", "address"]

        for field_name in fields_to_capitalize:
            field_value = validated_data.get(field_name)
            if field_value:
                # Capitalize the first letter of the field value
                validated_data[field_name] = field_value.capitalize()

        return super().update(instance, validated_data)

    def validate_photo(self, data):
        try:
            binary_data = base64.b64decode(data)
            data = data
            return data
        except Exception as e:
            raise serializers.ValidationError("Error decoding base64 data: {}".format(e))

    def delete(self, instance):
        try:
            instance.delete()
        except  Exception as e:
            raise serializers.ValidationError(
                {'submit': 'Cannot delete. This object is referenced by other objects.'})


class VisitorRequestSerializer(serializers.ModelSerializer):
    visitor_detail = VisitorDetailSerializer(read_only=True)
    approval_change_by_number_of_days = ApprovalChangeByNumberOfDaysSerializer(read_only=True)
    approval_status = ApprovalTypeSerializer(read_only=True)

    class Meta:
        model = VisitorRequest
        fields = '__all__'

    def create(self, validated_data):
        fields_to_capitalize = ["employee_name", "purpose_of_visit"]

        for field_name in fields_to_capitalize:
            field_value = validated_data.get(field_name)
            if field_value:
                # Capitalize the first letter of the field value
                validated_data[field_name] = field_value.capitalize()

        visitor_detail_id = validated_data.get('visitor_detail_id')
        company_detail_id = validated_data.get('company_detail_id')  # Get the company_detail_id
        from_date = validated_data.get('from_date')
        to_date = validated_data.get('to_date')
        email = validated_data.get('email')
        sub_company_id = validated_data.get('sub_company_id')
        if from_date and from_date <= timezone.now():
            raise serializers.ValidationError({'from_date': 'From date must be greater than the current date.'})

        if from_date and to_date and from_date >= to_date:
            raise serializers.ValidationError({'to_date': 'To date must be greater than from date.'})


        if visitor_detail_id:
            request = VisitorRequest.objects.filter(
                            Q(visitor_detail_id=visitor_detail_id) &
                            Q(Q(company_detail_id=company_detail_id) | Q(sub_company_id=sub_company_id))).exists()

            approve_request = VisitorRequest.objects.filter(
                Q(visitor_detail_id=visitor_detail_id) &
                Q(Q(company_detail_id=company_detail_id) | Q(sub_company_id=sub_company_id)) &
                Q(approval__approval_type_id__approval_name='Approve')).first()

            reject_request = VisitorRequest.objects.filter(
                Q(visitor_detail_id=visitor_detail_id) &
                Q(Q(company_detail_id=company_detail_id) | Q(sub_company_id=sub_company_id)) &
                Q(approval__approval_type_id__approval_name='Reject')).first()

            if request:
                request_detail = VisitorRequest.objects.filter(
                Q(visitor_detail_id=visitor_detail_id) &
                Q(Q(company_detail_id=company_detail_id) | Q(sub_company_id=sub_company_id))).first()

                if approve_request:
                    current_date = timezone.now()
                    time_difference = request_detail.to_date - current_date
                    print("triroe-  ",  time_difference.days)
                    if time_difference.days > 1:
                        raise serializers.ValidationError(
                        {'visitor_detail_id': f'Cannot add request. As there is an existing request for same visitor. Please add request after {time_difference.days - 1} days.'}
                    )

                elif reject_request:
                    current_date = timezone.now()
                    time_difference1 = current_date - request_detail.from_date
                    print("triroe+  ",  time_difference1)
                    if time_difference1.days <= 1:
                       raise serializers.ValidationError(
                        {'visitor_detail_id': 'Cannot add request. Please try to add request after one day.'}
                    )

                else:
                    raise serializers.ValidationError({"visitor_detail_id": "Cannot add request as there is already an existing request for this visitor that is neither approved nor rejected."})

        elif email:
            request = VisitorRequest.objects.filter(
                            Q(email=email) &
                            Q(Q(company_detail_id=company_detail_id)| Q(sub_company_id=sub_company_id))).exists()

            print(request)

            approve_request = VisitorRequest.objects.filter(
                Q(email=email) &
                Q(Q(company_detail_id=company_detail_id) | Q(sub_company_id=sub_company_id))&
                Q(approval__approval_type_id__approval_name='Approve')).first()

            reject_request = VisitorRequest.objects.filter(
                Q(email=email) &
                Q(Q(company_detail_id=company_detail_id) | Q(sub_company_id=sub_company_id))&
                Q(approval__approval_type_id__approval_name='Reject')).first()

            if request:
                request_detail = VisitorRequest.objects.filter(
                Q(email=email) &
                Q(Q(company_detail_id=company_detail_id) | Q(sub_company_id=sub_company_id))).first()

                if approve_request:
                    current_date = timezone.now()
                    time_difference = request_detail.to_date - current_date
                    print("triroe-  ",  time_difference.days)
                    if time_difference.days > 1:
                        raise serializers.ValidationError(
                        {'email': f'Cannot add request. As there is an existing request for same visitor. Please add request after {time_difference.days - 1} days.'}
                    )

                elif reject_request:
                    current_date = timezone.now()
                    time_difference1 = current_date - request_detail.from_date
                    print("triroe+  ",  time_difference1)
                    if time_difference1.days <= 1:
                       raise serializers.ValidationError(
                        {'email': 'Cannot add request. Please try to add request after one day.'}
                    )

                else:
                    raise serializers.ValidationError({"email": "Cannot add request as there is already an existing request for this visitor that is neither approved nor rejected."})


        return super().create(validated_data)

    def update(self, instance, validated_data):
        fields_to_capitalize = ["employee_name", "purpose_of_visit"]

        for field_name in fields_to_capitalize:
            field_value = validated_data.get(field_name)
            if field_value:
                # Capitalize the first letter of the field value
                validated_data[field_name] = field_value.capitalize()

        visitor_detail_id = validated_data.get('visitor_detail_id')
        company_detail_id = validated_data.get('company_detail_id')  # Get the company_detail_id
        from_date = validated_data.get('from_date')
        to_date = validated_data.get('to_date')
        email = validated_data.get('email')
        sub_company_id = validated_data.get('sub_company_id')

        if from_date and from_date <= timezone.now():
            raise serializers.ValidationError({'from_date': 'From date must be greater than the current date.'})

        if from_date and to_date and from_date >= to_date:
            raise serializers.ValidationError({'to_date': 'To date must be greater than from date.'})


        if visitor_detail_id:
            request = VisitorRequest.objects.filter(
                            Q(visitor_detail_id=visitor_detail_id) &
                            Q(Q(company_detail_id=company_detail_id) | Q(sub_company_id=sub_company_id))).exclude(pk=getattr(self.instance, 'pk', None)).exists()

            approve_request = VisitorRequest.objects.filter(
                Q(visitor_detail_id=visitor_detail_id) &
                Q(Q(company_detail_id=company_detail_id) | Q(sub_company_id=sub_company_id))&
                Q(approval__approval_type_id__approval_name='Approve')).exclude(pk=getattr(self.instance, 'pk', None)).first()

            reject_request = VisitorRequest.objects.filter(
                Q(visitor_detail_id=visitor_detail_id) &
                Q(Q(company_detail_id=company_detail_id) | Q(sub_company_id=sub_company_id)) &
                Q(approval__approval_type_id__approval_name='Reject')).exclude(pk=getattr(self.instance, 'pk', None)).first()

            if request:
                request_detail = VisitorRequest.objects.filter(
                Q(visitor_detail_id=visitor_detail_id) &
                Q(Q(company_detail_id=company_detail_id) | Q(sub_company_id=sub_company_id))).exclude(pk=getattr(self.instance, 'pk', None)).first()

                if approve_request:
                    current_date = timezone.now()
                    time_difference = request_detail.to_date - current_date
                    print("triroe-  ",  time_difference.days)
                    if time_difference.days > 1:
                        raise serializers.ValidationError(
                        {'visitor_detail_id': f'Cannot add request. As there is an existing request for same visitor. Please add request after {time_difference.days - 1} days.'}
                    )

                elif reject_request:
                    current_date = timezone.now()
                    time_difference1 = current_date - request_detail.from_date
                    print("triroe+  ",  time_difference1)
                    if time_difference1.days <= 1:
                       raise serializers.ValidationError(
                        {'visitor_detail_id': 'Cannot add request. Please try to add request after one day.'}
                    )

                else:
                    raise serializers.ValidationError({"visitor_detail_id": "Cannot add request as there is already an existing request for this visitor that is neither approved nor rejected."})


        elif email:
            request = VisitorRequest.objects.filter(
                            Q(email=email) &
                            Q(Q(company_detail_id=company_detail_id)| Q(sub_company_id=sub_company_id))).exclude(pk=getattr(self.instance, 'pk', None)).exists()

            approve_request = VisitorRequest.objects.filter(
                Q(email=email) &
                Q(Q(company_detail_id=company_detail_id) | Q(sub_company_id=sub_company_id)) &
                Q(approval__approval_type_id__approval_name='Approve')).exclude(pk=getattr(self.instance, 'pk', None)).first()

            reject_request = VisitorRequest.objects.filter(
                Q(email=email) &
                Q(Q(company_detail_id=company_detail_id) | Q(sub_company_id=sub_company_id)) &
                Q(approval__approval_type_id__approval_name='Reject')).exclude(pk=getattr(self.instance, 'pk', None)).first()

            if request:
                request_detail = VisitorRequest.objects.filter(
                Q(email=email) &
                Q(Q(company_detail_id=company_detail_id) | Q(sub_company_id=sub_company_id))).exclude(pk=getattr(self.instance, 'pk', None)).first()

                if approve_request:
                    current_date = timezone.now()
                    time_difference = request_detail.to_date - current_date

                    if time_difference.days > 1:
                        raise serializers.ValidationError(
                        {'email': f'Cannot add request. As there is an existing request for same visitor. Please add request after {time_difference.days - 1} days.'}
                    )

                elif reject_request:
                    current_date = timezone.now()
                    time_difference1 = current_date - request_detail.from_date
                    print("triroe+  ",  time_difference1)
                    if time_difference1.days <= 1:
                       raise serializers.ValidationError(
                        {'email': 'Cannot add request. Please try to add request after one day.'}
                    )

                else:
                    raise serializers.ValidationError({"email": "Cannot add request as there is already an existing request for this visitor that is neither approved nor rejected."})



        return super().update(instance, validated_data)


    def delete(self, instance):
        try:
            instance.delete()
        except  Exception as e:
            raise serializers.ValidationError(
                {'submit': 'Cannot delete. This object is referenced by other objects.'})

class VisitorHaveAccessorySerializer(serializers.ModelSerializer):
    default_visitor_have_accessory = serializers.CharField(source="default_visitor_have_accessory_id.accessory_name",
                                                           read_only=True)

    class Meta:
        model = VisitorHaveAccessory
        fields = '__all__'

    def create(self,validated_data):
        accessory_name = validated_data.get('accessory_name', '').strip()

        if accessory_name:
            # Capitalize the first letter of accessory_name
            validated_data['accessory_name'] = accessory_name.capitalize()
        if VisitorHaveAccessory.objects.filter(
                accessory_name=validated_data['accessory_name'], visitor_request_id=validated_data['visitor_request_id']).exists():
            raise serializers.ValidationError(
                    {'accessory_name': 'An entry with the same accessory name already exists.'}
                )
        return VisitorHaveAccessory.objects.create(**validated_data)



    def update(self, instance, validated_data):
        accessory_name = validated_data.get('accessory_name', '').strip()

        if accessory_name:
            # Capitalize the first letter of accessory_name
            validated_data['accessory_name'] = accessory_name.capitalize()
        if VisitorHaveAccessory.objects.filter(
                accessory_name=validated_data['accessory_name'],visitor_request_id=validated_data['visitor_request_id']).exclude(pk=getattr(self.instance, 'pk', None)).exists():
            raise serializers.ValidationError(
                    {'accessory_name': 'An entry with the same accessory name already exists.'}
                )

        return super().update(instance, validated_data)


    def delete(self, instance):
        try:
            instance.delete()
        except  Exception as e:
            raise serializers.ValidationError(
                {'submit': 'Cannot delete. This object is referenced by other objects.'})


class VisitorHaveAccessorySerializerList(serializers.ModelSerializer):
    # accessory_name = serializers.CharField(source="default_visitor_have_accessory_id.accessory_name", read_only=True)

    accessory_name = serializers.CharField(source="default_visitor_have_accessory_id.accessory_name",
                                                           read_only=True)

    class Meta:
        model = VisitorHaveAccessory
        # fields = '__all__'
        fields = ["id", "accessory_name"]

    def delete(self, instance):
        try:
            instance.delete()
        except  Exception as e:
            raise serializers.ValidationError(
                {'submit': 'Cannot delete. This object is referenced by other objects.'})

class VisitorProvidedAccessorySerializer(serializers.ModelSerializer):
    default_accessory_provided_by_company = serializers.CharField(source="default_accessory_provided_by_company_id"
                                                                         ".accessory_name", read_only=True)

    class Meta:
        model = VisitorProvidedAccessory
        fields = '__all__'

    def delete(self, instance):
        try:
            instance.delete()
        except  Exception as e:
            raise serializers.ValidationError(
                {'submit': 'Cannot delete. This object is referenced by other objects.'})


class VisitorRequestListSerializer(serializers.ModelSerializer):

    department_id = serializers.PrimaryKeyRelatedField(queryset=Department.objects.all())
    employee_id = serializers.PrimaryKeyRelatedField(queryset=Employee.objects.all())
    visitor_user_id = serializers.PrimaryKeyRelatedField(queryset=User.objects.all())
    company_detail_id = serializers.PrimaryKeyRelatedField(queryset=CompanyDetail.objects.all())
    visitor_have_accessory = VisitorHaveAccessorySerializer(many=True, read_only=True)
    default_visitor_have_accessory = DefaultVisitorHaveAccessorySerializer(read_only=True)
    visitor_provided_accessory = VisitorProvidedAccessorySerializer(many=True, read_only=True)
    default_accessory_provided_by_company = DefaultAccessoryProvidedByCompanySerializer(read_only=True)

    class Meta:
        model = VisitorRequest
        fields = ['id', "visitor_user_id", 'employee_name', 'email', 'department_id', 'from_date', 'to_date',
                  'duration', 'purpose_of_visit', 'employee_id', 'company_detail_id', 'visitor_have_accessory',
                  'default_visitor_have_accessory', 'visitor_provided_accessory',
                  'default_accessory_provided_by_company']


    def create(self, validated_data):
        fields_to_capitalize = ["employee_name", "purpose_of_visit"]

        for field_name in fields_to_capitalize:
            field_value = validated_data.get(field_name)
            if field_value:
                # Capitalize the first letter of the field value
                validated_data[field_name] = field_value.capitalize()


        return super().create(validated_data)

    def update(self, instance, validated_data):
        fields_to_capitalize = ["employee_name", "purpose_of_visit"]

        for field_name in fields_to_capitalize:
            field_value = validated_data.get(field_name)
            if field_value:
                # Capitalize the first letter of the field value
                validated_data[field_name] = field_value.capitalize()

        return super().update(instance, validated_data)

    def delete(self, instance):
        try:
            instance.delete()
        except  Exception as e:
            raise serializers.ValidationError(
                {'submit': 'Cannot delete. This object is referenced by other objects.'})



class AccessoryAllowSerializer(serializers.ModelSerializer):
    class Meta:
        model = AccessoryAllow
        fields = '__all__'

    def delete(self, instance):
        try:
            instance.delete()
        except  Exception as e:
            raise serializers.ValidationError(
                {'submit': 'Cannot delete. This object is referenced by other objects.'})


class VisitorProvidedAccessorySerializerList(serializers.ModelSerializer):
    default_accessory_provided_by_company = serializers.CharField(source="default_accessory_provided_by_company_id"
                                                                         ".accessory_name", read_only=True)

    class Meta:
        model = VisitorProvidedAccessory
        # fields = '__all__'
        fields = ["default_accessory_provided_by_company_id", "default_accessory_provided_by_company"]

    def delete(self, instance):
        try:
            instance.delete()
        except  Exception as e:
            raise serializers.ValidationError(
                {'submit': 'Cannot delete. This object is referenced by other objects.'})


class VisitorFineSerializer(serializers.ModelSerializer):
    accessory_name = serializers.CharField(source='default_accessory_provided_by_company.accessory_name', read_only=True)
    visitor_provided_accessory = serializers.CharField(source='default_accessory_provided_by_company.accessory_name', read_only=True)
    email = serializers.EmailField(source='visitor_request_id.email', read_only=True)
    fine_amount = serializers.IntegerField(source='default_accessory_provided_by_company.fines_charges', read_only=True)
    visitor_request = VisitorRequestSerializer(read_only=True)
    class Meta:
        model = VisitorFine
        fields = '__all__'
        read_only_fields = ['user_id']

    def validate_fields(self, data):
        existing_fields = set(self.fields.keys())
        request_fields = set(data.keys())
        non_existing_fields = request_fields - existing_fields

        if non_existing_fields:
            raise serializers.ValidationError(f"The following fields do not exist: {', '.join(non_existing_fields)}")

        return data

    def create(self, validated_data):
        validated_data = self.validate_fields(validated_data)

        # Get the logged-in user and set it as the user_id
        request = self.context.get('request')

        user = request.user if request else None
        if user:
            validated_data['user_id'] = user


        not_approved_request = Approval.objects.filter(visitor_request_id=validated_data['visitor_request_id'], final_approval=False).first()
        if not_approved_request:
            raise serializers.ValidationError(
                    {'Visitor_request_id': 'Visitor request has no approved'}
                )


        visitor_date = validated_data['visitor_request_id'].from_date
        current_date = timezone.now()

        if visitor_date > current_date:
            raise serializers.ValidationError({'Visitor_request_id': 'Cannot add visitor fine yet.'})


        if VisitorFine.objects.filter(
                visitor_provided_accessory_id=validated_data['visitor_provided_accessory_id'],visitor_request_id=validated_data['visitor_request_id']).exists():
            raise serializers.ValidationError(
                    {'visitor_provided_accessory_id': 'There is an existing record with this visitor_provided_accessory for this visitor'}
                )

        return super().create(validated_data)


    def update(self, instance, validated_data):
        validated_data = self.validate_fields(validated_data)

        not_approved_request = Approval.objects.filter(visitor_request_id=validated_data['visitor_request_id'], final_approval=False).first()
        if not_approved_request:
            raise serializers.ValidationError(
                    {'Visitor_request_id': 'Visitor request has no approved'}
                )

        visitor_date = validated_data['visitor_request_id'].from_date
        current_date = timezone.now()

        if visitor_date > current_date:
            raise serializers.ValidationError({'Visitor_request_id': 'Cannot add visitor fine yet.'})


        if VisitorFine.objects.filter(
                visitor_provided_accessory_id=validated_data['visitor_provided_accessory_id'],visitor_request_id=validated_data['visitor_request_id']).exclude(pk=getattr(self.instance, 'pk', None)).exists():
            raise serializers.ValidationError(
                    {'visitor_provided_accessory_id': 'There is an existing record with this visitor_provided_accessory for this visitor'}
                )

        return super().update(instance, validated_data)

    def delete(self, instance):
        try:
            instance.delete()
        except  Exception as e:
            raise serializers.ValidationError(
                {'submit': 'Cannot delete. This object is referenced by other objects.'})

class VisitorLoginLogSerializer(serializers.ModelSerializer):
    class Meta:
        model = VisitorLoginLog
        fields = '__all__'

    def delete(self, instance):
        try:
            instance.delete()
        except  Exception as e:
            raise serializers.ValidationError(
                {'submit': 'Cannot delete. This object is referenced by other objects.'})



class VisitorRequestDetailSerializer(serializers.ModelSerializer):
    first_name = serializers.CharField(source='visitor_detail_id.first_name', read_only=True)
    last_name = serializers.CharField(source='visitor_detail_id.last_name', read_only=True)

    class Meta:
        model = VisitorRequest
        # fields = '__all__'
        fields = ["id", "first_name","last_name", "email"]


class VisitorProvidedAccessoryListSerializer(serializers.ModelSerializer):
    accessory_name = serializers.CharField(source='default_accessory_provided_by_company_id.accessory_name', read_only=True)

    class Meta:
        model = VisitorProvidedAccessory
        # fields = '__all__'
        fields = ["id","accessory_name"]

class ApprovalSerializer(serializers.ModelSerializer):
    approval_type = serializers.CharField(source='approval_type.approval_name', read_only=True)
    first_name = serializers.CharField(source='visitor_request.visitor.first_name', read_only=True)
    last_name = serializers.CharField(source='visitor_request.visitor.last_name', read_only=True)
    phone_no = serializers.CharField(source='visitor_request.visitor.phone_no', read_only=True)
    id_proof_no = serializers.CharField(source='visitor_request.visitor.id_proof_no', read_only=True)
    address = serializers.CharField(source='visitor_request.visitor.address', read_only=True)
    email = serializers.EmailField(source='visitor_request.email', read_only=True)
    from_date = serializers.DateTimeField(source='visitor_request.from_date', read_only=True)
    to_date = serializers.DateTimeField(source='visitor_request.to_date', read_only=True)
    duration = serializers.CharField(source='visitor_request.duration', read_only=True)
    purpose_of_visit = serializers.CharField(source='visitor_request.purpose_of_visit', read_only=True)

    role = serializers.CharField(source='role.role_name', read_only=True)
    layer_step = serializers.CharField(source='approval_step_by_role.layer_step', read_only=True)
    accessory_approval = serializers.BooleanField(source='approval_step_by_role.accessory_approval', read_only=True)

    approval_by_email = serializers.EmailField(source='approval_by.email', read_only=True)



    class Meta:
        model = Approval
        fields = '__all__'

    def delete(self, instance):
        try:
            instance.delete()
        except  Exception as e:
            raise serializers.ValidationError(
                {'submit': 'Cannot delete. This object is referenced by other objects.'})


class ApprovalPageSerializer(serializers.ModelSerializer):

    class Meta:
        model = ApprovalPageGetDetail
        # fields = '__all__'
        depth = 2
        fields = ["name", "visitor", "email"]

    def create(self, validated_data):
        email = validated_data.get('email')
        if ApprovalPageGetDetail.objects.filter(email=email).exists():
            raise serializers.ValidationError({'email': 'Approval page email must be unique.'})
        return super().create(validated_data)

    def update(self, instance, validated_data):
        email = validated_data.get('email', instance.email)
        if ApprovalPageGetDetail.objects.filter(email=email).exclude(id=instance.id).exclude(pk=getattr(self.instance, 'pk', None)).exists():
            raise serializers.ValidationError({'email': 'Approval page email must be unique.'})
        return super().update(instance, validated_data)

    def delete(self, instance):
        try:
            instance.delete()
        except  Exception as e:
            raise serializers.ValidationError(
                {'submit': 'Cannot delete. This object is referenced by other objects.'})

class MobileTypeSerializer(serializers.ModelSerializer):
    company_detail = serializers.CharField(source='company_detail_id.company_name', read_only=True)

    class Meta:
        model = MobileType
        fields = '__all__'

    def create(self,validated_data):
        mobile = validated_data.get('mobile', '').strip()

        if mobile:

            validated_data['mobile'] = mobile.capitalize()
        if MobileType.objects.filter(
                mobile=validated_data['mobile'],company_detail_id=validated_data['company_detail_id']).exists():
            raise serializers.ValidationError(
                    {'mobile': 'An entry with the same mobile already exists.'}
                )
        return MobileType.objects.create(**validated_data)



    def update(self, instance, validated_data):
        mobile = validated_data.get('mobile', '').strip()

        if mobile:

            validated_data['mobile'] = mobile.capitalize()
        if MobileType.objects.filter(
                mobile=validated_data['mobile'],company_detail_id=validated_data['company_detail_id']).exclude(pk=getattr(self.instance, 'pk', None)).exists():
            raise serializers.ValidationError(
                    {'mobile': 'An entry with the same mobile already exists.'}
                )

        return super().update(instance, validated_data)


    def delete(self, instance):
        try:
            instance.delete()
        except  Exception as e:
            raise serializers.ValidationError(
                {'submit': 'Cannot delete. This object is referenced by other objects.'})


class IdProofTypeSerializer(serializers.ModelSerializer):
    company_detail = serializers.CharField(source='company_detail_id.company_name', read_only=True)

    class Meta:
        model = IdProofType
        fields = '__all__'

    def create(self,validated_data):
        id_proof = validated_data.get('id_proof', '').strip()

        if id_proof:

            validated_data['id_proof'] = id_proof.capitalize()
        if IdProofType.objects.filter(
                id_proof=validated_data['id_proof'],company_detail_id=validated_data['company_detail_id']).exists():
            raise serializers.ValidationError(
                    {'id_proof': 'An entry with the same id proof already exists.'}
                )
        return IdProofType.objects.create(**validated_data)



    def update(self, instance, validated_data):
        id_proof = validated_data.get('id_proof', '').strip()

        if id_proof:

            validated_data['id_proof'] = id_proof.capitalize()
        if IdProofType.objects.filter(
                id_proof=validated_data['id_proof'],company_detail_id=validated_data['company_detail_id']).exclude(pk=getattr(self.instance, 'pk', None)).exists():
            raise serializers.ValidationError(
                    {'id_proof': 'An entry with the same id proof already exists.'}
                )

        return super().update(instance, validated_data)

class IdProofTypeListSerializer(serializers.ModelSerializer):

    class Meta:
        model = IdProofType
        # fields = '__all__'
        fields = ["id", "id_proof"]


class MobileTypeListSerializer(serializers.ModelSerializer):

    class Meta:
        model = MobileType
        # fields = '__all__'
        fields = ["id", "mobile"]


class DefaultVisitorHaveAccessoryListSerializer(serializers.ModelSerializer):

    class Meta:
        model = DefaultVisitorHaveAccessory
        # fields = '__all__'
        fields = ["id", "accessory_name"]

class CheckedInOutSerializer(serializers.ModelSerializer):
    # visitor_first_name = serializers.CharField(source='visitor_request_id.visitor_detail_id.first_name', read_only=True)
    # visitor_last_name = serializers.CharField(source='visitor_request_id.visitor_detail_id.last_name', read_only=True)
    # purpose_of_visit = serializers.CharField(source='visitor_request_id.purpose_of_visit', read_only=True)
    # department = serializers.CharField(source='department_id.department_name', read_only=True)

    visitor_name = serializers.SerializerMethodField()
    host_name = serializers.CharField(source='visitor_request.employee_name', read_only=True)
    purpose_of_visit = serializers.CharField(source='visitor_request.purpose_of_visit', read_only=True)
    department = serializers.CharField(source='department.department_name', read_only=True)

    class Meta:
        model = CheckedInOut
        fields = '__all__'

    def create(self, validated_data):
        validated_data['in_datetime'] = timezone.now()
        validated_data['out_datetime'] = None
        return super().create(validated_data)

    def update(self, instance, validated_data):
        instance.out_datetime = timezone.now()
        instance.save()
        return instance


class VisitorRequestDetailListSerializer(serializers.ModelSerializer):
    purpose_of_visit = serializers.CharField(source='visitor_request_id.purpose_of_visit', read_only=True)

    class Meta:
        model = VisitorRequest
        # fields = '__all__'
        fields = ["id","purpose_of_visit"]


