from django.db import models
from account.models import User, CompanyDetail, SubCompany, DefaultAccessoryProvidedByCompany, Accessory, \
                            ApprovalType, Roles, ApproveStepByRole, AddUserEmail, ApprovalLayer, ApprovalChangeByNumberOfDays
from employeeapp.models import Employee,  Department, Roles
import uuid
import django


class Visitor(models.Model):
    name = models.CharField(max_length=17)
    email = models.EmailField()
    company_name = models.CharField(max_length=17)
    photo = models.TextField()
    mobile_no = models.CharField(max_length=20)
    # id_proof = models.CharField(max_length=17)
    id_proof_no = models.CharField(max_length=17)
    id_proof_photo = models.TextField()
    vehicle_no = models.CharField(max_length=17,blank=True, null=True)
    type_of_mobile = models.CharField(max_length=17)
    address = models.CharField(max_length=17)
    employee_name = models.CharField(max_length=17)
    department_id = models.ForeignKey(Department, on_delete=models.PROTECT)
    from_date = models.DateTimeField()
    to_date = models.DateTimeField()
    duration = models.CharField(max_length=12)
    purpose_of_visit = models.CharField(max_length=50)
    employee_id = models.ForeignKey(Employee, on_delete=models.PROTECT)
    accessory_provide_allowed = models.BooleanField()
    user_id = models.ForeignKey(User, on_delete=models.PROTECT)
    # visitor_fine_id=models.ForeignKey(VisitorFine, on_delete=models.PROTECT)


class DefaultVisitorHaveAccessory(models.Model):
    accessory_name = models.CharField(max_length=20)
    company_detail_id = models.ForeignKey(CompanyDetail, on_delete=models.PROTECT)
    sub_company_id = models.ForeignKey(SubCompany, on_delete=models.PROTECT, blank=True, null=True)
    soft_delete = models.BooleanField(default=False)

class MobileType(models.Model):
    mobile = models.CharField(max_length=17)
    company_detail_id = models.ForeignKey(CompanyDetail, on_delete=models.PROTECT)


class IdProofType(models.Model):
    id_proof = models.CharField(max_length=17)
    company_detail_id = models.ForeignKey(CompanyDetail, on_delete=models.PROTECT)

class VisitorAccessoryForFine(models.Model):
    visitor_fine_id = models.ForeignKey(Visitor, on_delete=models.PROTECT)
    default_accessory_id = models.ForeignKey(DefaultAccessoryProvidedByCompany, on_delete=models.PROTECT,
                                             related_name='default_accessory')


class AccessoryProvided(models.Model):
    default_accessory_id = models.ForeignKey(DefaultAccessoryProvidedByCompany, on_delete=models.PROTECT)
    accessory_provided = models.BooleanField()
    visitor_id = models.ForeignKey(Visitor, on_delete=models.PROTECT)


class AccessoryReturn(models.Model):
    default_accessory_id = models.ForeignKey(DefaultAccessoryProvidedByCompany, on_delete=models.PROTECT)
    accessory_return = models.BooleanField()
    visitor_id = models.ForeignKey(Visitor, on_delete=models.PROTECT)


class VisitorRestriction(models.Model):
    remove_restriction_after_days = models.IntegerField()
    company_detail_id = models.ForeignKey(CompanyDetail, on_delete=models.PROTECT)
    sub_company_id = models.ForeignKey(SubCompany, on_delete=models.PROTECT, null=True, blank=True)


class VisitorDetail(models.Model):
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    phone_no = models.CharField(max_length=50)
    designation = models.CharField(max_length=50)
    company_type = models.CharField(max_length=50)
    company_name = models.CharField(max_length=50)
    photo = models.TextField(blank=True, null=True)
    id_proof_type_id = models.ForeignKey(IdProofType, on_delete=models.PROTECT, blank=True, null=True)
    id_proof_no = models.CharField(max_length=50)
    id_proof_photo = models.TextField(blank=True, null=True)
    vehicle_no = models.CharField(max_length=17, blank=True, null=True)
    mobile_type_id = models.ForeignKey(MobileType, on_delete=models.PROTECT, blank=True, null=True)
    address = models.CharField(max_length=50)
    user_id = models.ForeignKey(User, on_delete=models.PROTECT, blank=True, null=True)
    company_detail_id = models.ForeignKey(CompanyDetail, on_delete=models.PROTECT, blank=True, null=True)


class VisitorRequest(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    employee_name = models.CharField(max_length=20, blank=True, null=True)
    email = models.EmailField()
    department_id = models.ForeignKey(Department, on_delete=models.PROTECT)
    from_date = models.DateTimeField()
    to_date = models.DateTimeField()
    duration = models.CharField(max_length=10)
    purpose_of_visit = models.CharField(max_length=30)
    employee_id = models.ForeignKey(Employee, on_delete=models.PROTECT, blank=True, null=True)
    # accessory_provided_allow = models.BooleanField
    visitor_user_id = models.ForeignKey(User, on_delete=models.PROTECT, blank=True, null=True)  # visitor User id
    # visitor_fine
    company_detail_id = models.ForeignKey(CompanyDetail, on_delete=models.PROTECT)
    sub_company_id = models.ForeignKey(SubCompany, on_delete=models.PROTECT, null=True, blank=True)
    visitor_detail_id = models.ForeignKey(VisitorDetail, on_delete=models.PROTECT, blank=True, null=True)
    approval_change_by_number_of_days_id = models.ForeignKey(ApprovalChangeByNumberOfDays, on_delete=models.PROTECT)
    type = models.CharField(max_length=30, blank=True, null=True)
    approval_status = models.ForeignKey(ApprovalType, on_delete=models.CASCADE, blank=True, null=True)


class VisitorHaveAccessory(models.Model):
    accessory_name = models.CharField(max_length=25)
    default_visitor_have_accessory_id = models.ForeignKey(DefaultVisitorHaveAccessory, on_delete=models.PROTECT,
                                                          blank=True, null=True,
                                                          related_name="default_visitor_have_accessory")
    visitor_request_id = models.ForeignKey(VisitorRequest, on_delete=models.PROTECT, related_name="visitor_request_vha")
    user_id = models.ForeignKey(User, on_delete=models.PROTECT, blank=True, null=True)
    approval = models.BooleanField()
    in_accessory = models.BooleanField()
    out_accessory = models.BooleanField()


class AccessoryAllow(models.Model):
    accessory_id = models.ForeignKey(Accessory, on_delete=models.PROTECT)
    visitor_id = models.ForeignKey(Visitor, on_delete=models.PROTECT)


class VisitorProvidedAccessory(models.Model):
    default_accessory_provided_by_company_id = models.ForeignKey(DefaultAccessoryProvidedByCompany,
                                                                 on_delete=models.PROTECT,blank=True, null=True,
                                                                 related_name="default_accessory_provided_by_company")
    visitor_request_id = models.ForeignKey(VisitorRequest, on_delete=models.PROTECT, related_name="visitor_request_vpa")
    user_id = models.ForeignKey(User, on_delete=models.PROTECT, blank=True, null=True)
    approval = models.BooleanField(default=False)
    in_accessory = models.BooleanField()
    out_accessory = models.BooleanField()


class VisitorFine(models.Model):
    fine_collected = models.BooleanField()
    #fine_collected_amount = models.IntegerField()
    visitor_request_id = models.ForeignKey(VisitorRequest, on_delete=models.PROTECT)
    user_id = models.ForeignKey(User, on_delete=models.PROTECT)
    default_accessory_provided_by_company = models.ForeignKey(DefaultAccessoryProvidedByCompany,
                                                              on_delete=models.PROTECT)
    visitor_provided_accessory_id = models.ForeignKey(VisitorProvidedAccessory, on_delete=models.PROTECT,
                                                      related_name="visitor_provided_accessory")


class VisitorLoginLog(models.Model):
    user_id = models.ForeignKey(User, on_delete=models.PROTECT)
    company_detail_id = models.ForeignKey(CompanyDetail, on_delete=models.PROTECT)
    date_time = models.DateTimeField(auto_now_add=True)
    sub_company_id = models.ForeignKey(SubCompany, on_delete=models.PROTECT, blank=True, null=True)


class Approval(models.Model):
    visitor_request = models.ForeignKey(VisitorRequest, on_delete=models.PROTECT)
    approval_by = models.ForeignKey(User, on_delete=models.PROTECT, blank=True, null=True)
    role = models.ForeignKey(Roles, on_delete=models.PROTECT)
    approval_type = models.ForeignKey(ApprovalType, on_delete=models.PROTECT, related_name="approval_type")
    approval_date_time = models.DateTimeField(auto_now_add=True)
    final_approval = models.BooleanField()
    approval_step_by_role = models.ForeignKey(ApproveStepByRole, on_delete=models.PROTECT,
                                              related_name="approval_step_by_role")
    approval_change_by_number_of_days = models.ForeignKey(ApprovalChangeByNumberOfDays, on_delete=models.PROTECT)

class ApprovalPageGetDetail(models.Model):
    name = models.ForeignKey(Visitor, on_delete=models.PROTECT)
    email = models.EmailField()
    company_name = models.ForeignKey(Visitor, on_delete=models.PROTECT, blank=True, null=True,
                                     related_name="company_name_1")


class CheckedInOut(models.Model):
    visitor_request_id = models.ForeignKey(VisitorRequest, on_delete=models.PROTECT)
    # checked_type = models.CharField(max_length=15)
    department_id = models.ForeignKey(Department, on_delete=models.PROTECT)
    host_name = models.CharField(max_length=30)
    in_datetime = models.DateTimeField(default=django.utils.timezone.now)
    out_datetime = models.DateTimeField(blank=True, null=True)
