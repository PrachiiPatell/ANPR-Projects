from django.contrib import admin

# Register your models here.

from .models import Visitor, VisitorDetail, VisitorFine, VisitorAccessoryForFine, VisitorHaveAccessory, \
    VisitorRestriction, AccessoryProvided, AccessoryAllow, AccessoryReturn, \
    Approval, ApprovalPageGetDetail, VisitorRequest, CheckedInOut, VisitorProvidedAccessory

admin.site.register(Visitor)
admin.site.register(VisitorDetail)
admin.site.register(VisitorFine)
admin.site.register(VisitorAccessoryForFine)
admin.site.register(VisitorHaveAccessory)
admin.site.register(VisitorRestriction)
admin.site.register(AccessoryProvided)
admin.site.register(AccessoryAllow)
admin.site.register(AccessoryReturn)
admin.site.register(Approval)
admin.site.register(VisitorRequest)

admin.site.register(ApprovalPageGetDetail)
admin.site.register(VisitorProvidedAccessory)
admin.site.register(CheckedInOut)