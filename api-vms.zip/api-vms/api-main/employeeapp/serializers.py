from rest_framework import serializers
from rest_framework.validators import UniqueTogetherValidator
import base64
from django.utils import timezone
from datetime import date


from .models import Employee, Department

from visitorapp.models import VisitorRequest, Approval

# class EmployeeImageSerializer(serializers.ModelSerializer):
#     employee = serializers.CharField(source='employee_id.department_name', read_only=True)

#     class Meta:
#         model = EmployeeImage
#         fields = '__all__'

#     def create(self, validated_data):
#         photo = validated_data.pop('photo')
#         validated_data['photo'] = self.validate_photo(photo)
#         return EmployeeImage.objects.create(**validated_data)

#     def update(self, instance, validated_data):
#         photo = validated_data.get('photo')
#         if photo:
#             validated_data['photo'] = self.validate_photo(photo)
#         return super().update(instance, validated_data)

#     def validate_photo(self, data):
#         try:
#             binary_data = base64.b64decode(data)
#             data = data
#             return data
#         except Exception as e:
#             raise serializers.ValidationError("Error decoding base64 data: {}".format(e))
        

#     def delete(self, instance):
#         try:
#             instance.delete()
#         except  Exception as e:
#             raise serializers.ValidationError(
#                 {'submit': 'Cannot delete. This object is referenced by other objects.'})
        
class EmployeeSerializer(serializers.ModelSerializer):
    company = serializers.CharField(source='company_detail_id.company_name', read_only=True)
    department = serializers.CharField(source='department_id.department_name', read_only=True)
    #employee_images = EmployeeImageSerializer(many=True, read_only=True)
    role_name =  serializers.CharField(source='role_id.role_name', read_only=True)

    class Meta:
        model = Employee
        fields = '__all__'

       

    def create(self, validated_data):
        fields_to_capitalize = ["name", "designation"]

        for field_name in fields_to_capitalize:
            field_value = validated_data.get(field_name)
            if field_value:
                # Capitalize the first letter of the field value
                validated_data[field_name] = field_value.capitalize()

        email = validated_data.get('email')
        department_id = validated_data.get('department_id')
        if Employee.objects.filter(department_id=department_id, email=email).exists():
            raise serializers.ValidationError({"email": "Employee email must be unique within the department."})
        
        # Add validation for date_of_birth
        date_of_birth = validated_data.get('date_of_birth')
        if date_of_birth and date_of_birth > date.today():
            raise serializers.ValidationError({"date_of_birth": "Date of birth must be before the current date."})
        
        
        
        return super().create(validated_data)


    def update(self, instance, validated_data):
        # photo=str(validated_data.get('photo'))
        # new_base64_file_index = photo.find(',')
        # emp_photo = photo[new_base64_file_index:]

        photo = validated_data.get('photo')
        if photo:
            validated_data['photo'] = self.validate_photo(photo)
        
        fields_to_capitalize = ["name", "designation"]

        for field_name in fields_to_capitalize:
            field_value = validated_data.get(field_name)
            if field_value:
                # Capitalize the first letter of the field value
                validated_data[field_name] = field_value.capitalize()

        email = validated_data.get('email', instance.email)
        department_id = validated_data.get('department_id', instance.department_id)
        if Employee.objects.filter(department_id=department_id, email=email).exclude(id=instance.id).exists():
            raise serializers.ValidationError({"email": "Employee email must be unique within the department."})
        
         # Add validation for date_of_birth
        date_of_birth = validated_data.get('date_of_birth')
        if date_of_birth and date_of_birth > date.today():
            raise serializers.ValidationError({"date_of_birth": "Date of birth must be before the current date."})

        # Update the Employee instance
        updated_instance = super().update(instance, validated_data)

        # employee_photo = EmployeeImage.objects.filter(employee_id = instance.id).first()
        
        # if employee_photo and employee_photo.photo:
        #     employee_image_updated = EmployeeImage.objects.filter(employee_id = instance.id).update(photo = emp_photo)
        #     # photo = {"photo":employee_photo.photo}
        #     # super().update(updated_instance, photo)

        # else:
        #     employee_image = EmployeeImage.objects.create(employee_id=instance.id, photo = emp_photo)
        #     # image_serializer = EmployeeImageSerializer(data=employee_image)
        #     # image_serializer.save()
        #     # photo = {"emolyee_image":employee_image.photo}
        #     # super().update(updated_instance, photo)

        return updated_instance
    
    def validate_photo(self, data):
        try:
            binary_data = base64.b64decode(data)
            data = data
            return data
        except Exception as e:
            raise serializers.ValidationError("Error decoding base64 data: {}".format(e))

    def delete(self, instance):
        try:
            instance.delete()
        except  Exception as e:
            raise serializers.ValidationError(
                {'submit': 'Cannot delete. This object is referenced by other objects.'})
        
class DepartmentSerializer(serializers.ModelSerializer):
    # company = serializers.CharField(source='company_detail_id.company_name', read_only=True)
    sub_company = serializers.CharField(source='sub_company_id.sub_company_name', read_only=True)

    class Meta:
        model = Department
        fields = '__all__'


    def create(self, validated_data):
        department_name = validated_data.get('department_name')
        sub_company_id = validated_data.get('sub_company_id')
        validated_data['department_name'] = department_name.capitalize()

        department_email = validated_data.get('department_email')
        if Department.objects.filter(department_email=department_email).exists():
            raise serializers.ValidationError({"department_email": "Department email must be unique."})

        if Department.objects.filter(department_name=validated_data['department_name'], company_detail_id=validated_data['company_detail_id'],sub_company_id=sub_company_id).exists():
            raise serializers.ValidationError({"department_name": "A department with this name already exists for this company."})

        return super().create(validated_data)

    def update(self, instance, validated_data):
        department_name = validated_data.get('department_name')
        sub_company_id = validated_data.get('sub_company_id')
        validated_data['department_name'] = department_name.capitalize()

        # Check if the department_name is being edited
        if instance.department_name != validated_data['department_name']:
            # Check if there are VisitorRequest records associated with this department_name
            visitor_requests =  VisitorRequest.objects.filter(department_id=instance.id, company_detail_id = validated_data['company_detail_id'],sub_company_id=sub_company_id)

            if visitor_requests.exists():
        # Check if there are Approval records for those VisitorRequests
                if Approval.objects.filter(visitor_request_id__department_id=instance.id, final_approval=True, visitor_request_id__to_date__gt=timezone.now()).exists():
                    raise serializers.ValidationError({"department_name": "Cannot edit department_name as it is assigned to visitor requests & status is approved."})
                        
        department_email = validated_data.get('department_email', instance.department_email)
        if Department.objects.filter(department_email=department_email).exclude(pk=getattr(self.instance, 'pk', None)).exists():
            raise serializers.ValidationError({"department_email": "Department email must be unique."})
        
        if Department.objects.filter(department_name=validated_data['department_name'], company_detail_id=validated_data['company_detail_id'],sub_company_id=sub_company_id).exclude(pk=getattr(self.instance, 'pk', None)).exists():
            raise serializers.ValidationError({"department_name": "A department with this name already exists for this company."})

        

        return super().update(instance, validated_data)
    

    def delete(self, instance):
        try:
            instance.delete()
        except  Exception as e:
            raise serializers.ValidationError(
                {'submit': 'Cannot delete. This object is referenced by other objects.'})


class DepartmentListSerializer(serializers.ModelSerializer):
    class Meta:
        model = Department
        fields = ["id", "department_name"]

    def create(self, validated_data):
        department_name = validated_data.get('department_name')
        sub_company_id = validated_data.get('sub_company_id')
        validated_data['department_name'] = department_name.capitalize()

        department_email = validated_data.get('department_email')
        if Department.objects.filter(department_email=department_email).exists():
            raise serializers.ValidationError({"department_email": "Department email must be unique."})

        if Department.objects.filter(department_name=validated_data['department_name'], company_detail_id=validated_data['company_detail_id'],sub_company_id=sub_company_id).exists():
            raise serializers.ValidationError({"department_name": "A department with this name already exists for this company."})

        return super().create(validated_data)

    def update(self, instance, validated_data):
        department_name = validated_data.get('department_name')
        sub_company_id = validated_data.get('sub_company_id')
        validated_data['department_name'] = department_name.capitalize()

        department_email = validated_data.get('department_email', instance.department_email)
        if Department.objects.filter(department_email=department_email).exclude(pk=getattr(self.instance, 'pk', None)).exists():
            raise serializers.ValidationError({"department_email": "Department email must be unique."})
        
        if Department.objects.filter(department_name=validated_data['department_name'], company_detail_id=validated_data['company_detail_id'],sub_company_id=sub_company_id).exclude(pk=getattr(self.instance, 'pk', None)).exists():
            raise serializers.ValidationError({"department_name": "A department with this name already exists for this company."})

        return super().update(instance, validated_data)

    def delete(self, instance):
        try:
            instance.delete()
        except  Exception as e:
            raise serializers.ValidationError(
                {'submit': 'Cannot delete. This object is referenced by other objects.'})
