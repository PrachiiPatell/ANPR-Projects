from django.shortcuts import render
from rest_framework import status
from rest_framework.response import Response
from django.http import Http404
from django.contrib.auth import authenticate
from django.http.response import JsonResponse

from rest_framework.views import APIView
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework_simplejwt.tokens import RefreshToken

from account.getUserData import getUserData
from account.getUserDataLogin import getUserDataLogin


from .models import Employee, Department

from .serializers import EmployeeSerializer,  DepartmentSerializer, DepartmentListSerializer

from account.models import *

from account.serializers import UserSerializer, UserRoleMappingSerializer, UserLoginSerializer

# Create your views here.


# Employee API
class EmployeeList(APIView):
    permission_classes = (IsAuthenticated,)


    def get_object(self):
        try:
            return Employee.objects.all()
        except:
            raise Http404

    ObjectSerializer = EmployeeSerializer
    model_name = "Employee"

    def get(self, request, format=None):
        limit = int(request.GET.get('limit',10))
        offset = int(request.GET.get('offset',0))
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'employee' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['employee']:
                    acess_to_page = True
            if acess_to_page == True:
                sub_company_detail_id = None
                if len(get_user_data['sub_company']) > 0:
                    sub_company_detail_id = get_user_data['sub_company']['id']
                employee_queryset = Employee.objects.filter(company_detail_id = get_user_data['company_detail']['id'],sub_company_id = sub_company_detail_id).order_by('-id').all()[offset:limit+offset]
                employee_count = Employee.objects.filter(company_detail_id = get_user_data['company_detail']['id'],sub_company_id = sub_company_detail_id).count()
                serializer = self.ObjectSerializer(employee_queryset, many=True)
                return Response({'count':employee_count, 'results': serializer.data})
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


              

    def post(self, request, format=None):
        # serializer = CompanyDetailSerializer(data=request.data)
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'employee' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['employee']:
                    acess_to_page = True
            if acess_to_page == True:
                sub_company_detail_id = None
                if len(get_user_data['sub_company']) > 0:
                    sub_company_detail_id = get_user_data['sub_company']['id']
                data = request.data
                data['company_detail_id'] = get_user_data['company_detail']['id']
                data['sub_company_id'] = sub_company_detail_id
                serializer = self.ObjectSerializer(data=data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class EmployeeDetail(APIView):
    permission_classes = (IsAuthenticated,)

    def get_object(self, pk):
        try:
            return Employee.objects.get(pk=pk)
        except:
            raise Http404

    ObjectSerializer = EmployeeSerializer

    def get(self, request, id=None, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'employee' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['employee']:
                    acess_to_page = True
            if acess_to_page == True:

                print(r'get details of id: ', id)

                company_detail_id = request.user.company_detail_id
                sub_company_id = request.user.sub_company_id
                #queryset = self.get_object(pk=id)
                queryset = Employee.objects.filter(pk=id,
                                                            company_detail_id=company_detail_id, sub_company_id=sub_company_id).first()
                serializer = self.ObjectSerializer(queryset)
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def patch(self, request, id, format=None):
        # pass
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'employee' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['employee']:
                    acess_to_page = True
            if acess_to_page == True:
                company_detail_id = request.user.company_detail_id
                sub_company_id = request.user.sub_company_id
                #queryset = self.get_object(pk=id)
                queryset = Employee.objects.filter(pk=id,
                                                            company_detail_id=company_detail_id, sub_company_id=sub_company_id).first()
                print("PATCH request ", id, queryset, request.data)
                serializer = self.ObjectSerializer(queryset, data=request.data, partial=True)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'employee' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['employee']:
                    acess_to_page = True
            if acess_to_page == True:
                sub_company_detail_id = None
                if len(get_user_data['sub_company']) > 0:
                    sub_company_detail_id = get_user_data['sub_company']['id']
                data = request.data
                data['company_detail_id'] = get_user_data['company_detail']['id']
                data['sub_company_id'] = sub_company_detail_id
                queryset = self.get_object(pk=id)
                serializer = self.ObjectSerializer(queryset, data=data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'employee' in get_user_data['permission'].keys():
                if 'delete' in get_user_data['permission']['employee']:
                    acess_to_page = True
            if acess_to_page == True:
                company_detail_id = request.user.company_detail_id
                sub_company_id = request.user.sub_company_id
                #queryset = self.get_object(pk=id)
                queryset = Employee.objects.filter(pk=id,
                                                            company_detail_id=company_detail_id, sub_company_id=sub_company_id).first()
                try:
                    queryset.delete()
                    return Response(status=status.HTTP_204_NO_CONTENT)
                except Exception as e:
                    return Response({"submit": "Cannot delete. This Employee is assigned for visitor request."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
        


class RegisterEmployee(APIView):
    permission_classes = (AllowAny,)

    def post(self, request, format=None):

        # Check if email exists in AddUserEmail
        add_user_email_exists = AddUserEmail.objects.filter(email=request.data['email']).exists()

        # Check if email exists in Employee
        employee_exists = Employee.objects.filter(email=request.data['email']).exists()
        print("add_user_email_exists:", add_user_email_exists, "employee_exists:", employee_exists)

        if (add_user_email_exists is False) and (employee_exists is False):
            return Response({"result": {}, "message": "User is not register with this email."},
                            status=status.HTTP_400_BAD_REQUEST)

        if (add_user_email_exists is True) and (employee_exists is True):
            return Response({"result": {}, "message": "Admin is Already  registered  with this email as Employee."},
                            status=status.HTTP_400_BAD_REQUEST)

        if (add_user_email_exists is True) and (employee_exists is False):
            # If email does not exist in Employee, create a new user and add email to Employee

            add_user_emails = AddUserEmail.objects.filter(email=request.data['email']).values('email',
                                                                                              'company_detail_id',
                                                                                              'sub_company_id','sub_company_id__sub_company_name',
                                                                                              'role_id').first()
            print("add_user_emails", add_user_emails)
            sub_id = None
            if add_user_emails != None:
                print("creating user: ")
                get_company_detail = CompanyDetail.objects.filter(
                    id=add_user_emails.get('company_detail_id')).values().first()
                
                if add_user_emails.get('sub_company_id'):
                    sub_id = int(add_user_emails.get('sub_company_id'))

                serializer = UserSerializer(
                    data={'email': request.data['email'],
                          'password': request.data['password'],
                          'password2': request.data['password2'],
                          'company_detail_id': int(add_user_emails.get('company_detail_id')),
                          'sub_company_id': sub_id,
                          'user_login_or_not': False,
                          'is_superuser': False,
                          'is_active': True,
                          "time_zone": "India",
                          "is_staff": True,
                          "user_type": "Admin"})

                print("user initial serializer: ", serializer.initial_data)
                user_id = None
                if serializer.is_valid():
                    print("user data saved")
                    # print("user post serializer: ", serializer.data)
                    print("user post serializer: ", serializer.validated_data)
                    obj = serializer.save()
                    user_id = obj.id
                    print("obj.id", obj.id)
                else:
                    print("UserSerializer error")
                    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

                # user_role_map
                user_role_map_serializer = UserRoleMappingSerializer(
                    data={'user_id': user_id,
                          'role_id': add_user_emails.get('role_id')})
                if user_role_map_serializer.is_valid():
                    user_role_map_serializer.save()
                else:
                    User.objects.filter(id=user_id).delete()
                    return Response(user_role_map_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                    print("role serializer:", serializer.data)

                user_select = User.objects.filter(id=user_id).last()

                refresh = RefreshToken.for_user(user_select)
                user_detail = getUserData(user_id)
                # user_detail['refresh'] = str(refresh)
                # user_detail['access'] = str(refresh.access_token)
                department_name = "Admin"
                if add_user_emails.get('sub_company_id'):
                    department_name = str(add_user_emails.get('sub_company_id__sub_company_name') )+ "_Admin"
                else:
                    department_name = "Admin"

                # create Department Admin
                department_data = {
                    "department_name": department_name,
                    'company_detail_id': int(add_user_emails.get('company_detail_id')),
                    'sub_company_id': sub_id,
                    "department_email": request.data['email']
                }

                department_serializer = DepartmentSerializer(data=department_data)
                if department_serializer.is_valid():
                    obj = department_serializer.save()
                    department_id = obj.id
                    print("obj.id", obj.id)
                else:
                    print(department_serializer.errors)
                    User.objects.filter(id=user_id).delete()
                    return Response(department_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                    print("Department  serializer:", department_serializer.data)

                # Add Admin to Admin Department as Employee
                employee_data = {
                    "name": "Admin",
                    "email": request.data['email'],
                    "designation": "Admin",
                    "date_of_joining": None,
                    "visitor_allow": True,
                    "company_detail_id": int(add_user_emails.get('company_detail_id')),
                    "sub_company_id": sub_id,
                    "department_id": department_id,
                    "role_id": int(add_user_emails.get('role_id')),
                    "mobile_no": request.data['mobile_no'],
                    "date_of_birth": None,
                    "Age": None
                }

                employee_serializer = EmployeeSerializer(data=employee_data)
                if employee_serializer.is_valid():
                    obj = employee_serializer.save()
                    employee_id = obj.id
                    print("emp_id", employee_id)
                else:
                    print(employee_serializer.errors)
                    User.objects.filter(id=user_id).delete()
                    return Response(employee_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                    print("Department  serializer:", employee_serializer.data)
                return Response({"message": "Admin Registered as Employee"}, status=status.HTTP_200_OK)

        if (add_user_email_exists is False) and (employee_exists is True):
            add_user_emails = Employee.objects.filter(email=request.data['email']).values('email',
                                                                                          'company_detail_id',
                                                                                          'sub_company_id',
                                                                                          'role_id').first()

            print("Employee Details: ", add_user_emails)

            if add_user_emails != None:
                print("creating user: ")
                get_company_detail = CompanyDetail.objects.filter(
                    id=add_user_emails.get('company_detail_id')).values().first()

                # Add Sub Company if exist
                sub_company_data = Employee.objects.filter(email=request.data["email"]).values("sub_company_id").first()
                print(sub_company_data)
                if sub_company_data is not None:
                    sub_company_id = sub_company_data["sub_company_id"]
                    if sub_company_id:
                        print(sub_company_id, type(sub_company_id))
                        assert isinstance(sub_company_id, int)
                serializer = UserSerializer(
                    data={'email': request.data['email'],
                          'password': request.data['password'],
                          'password2': request.data['password2'],
                          'company_detail_id': int(add_user_emails.get('company_detail_id')),
                          # 'company_detail_id': 1,
                          "sub_company_id": sub_company_id,
                          'user_login_or_not': False,
                          'is_superuser': False,
                          'is_active': True,
                          "time_zone": "India",
                          "is_staff": True,
                          "user_type": "Admin",
                          })

                print("user initial serializer: ", serializer.initial_data)
                user_id = None
                if serializer.is_valid():
                    print("user data saved")
                    # print("user post serializer: ", serializer.data)
                    print("user post serializer: ", serializer.validated_data)
                    obj = serializer.save()
                    user_id = obj.id
                    print("obj.id", obj.id)
                else:
                    print("UserSerializer error")
                    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

                # user_role_map
                user_role_map_serializer = UserRoleMappingSerializer(
                    data={'user_id': user_id,
                          'role_id': add_user_emails.get('role_id')})
                if user_role_map_serializer.is_valid():
                    user_role_map_serializer.save()
                else:
                    User.objects.filter(id=user_id).delete()
                    return Response(user_role_map_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                    print("role serializer:", serializer.data)

                user_select = User.objects.filter(id=user_id).last()

                refresh = RefreshToken.for_user(user_select)
                user_detail = getUserData(user_id)
                # user_detail['refresh'] = str(refresh)
                # user_detail['access'] = str(refresh.access_token)
                return Response(user_detail, status=status.HTTP_201_CREATED)
            else:
                print("Yes")
                return Response({"result": {}, "message": "Employee is not register with this email."},
                                status=status.HTTP_400_BAD_REQUEST)


# Edit Employee detail by Employee



class EmployeeLogin(APIView):
    permission_classes = (AllowAny,)

    def post(self, request, format=None):
        serializer = UserLoginSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        email = serializer.data.get('email')
        password = serializer.data.get('password')
        print(email, password)
        user = authenticate(email=email, password=password)
        employee = Employee.objects.filter(email=email).first()
        if employee is None:
            return Response({"submit":"Employee does not exist."}, status=status.HTTP_400_BAD_REQUEST)

        print("is user none ? ", user)

        if user:
            if user.is_active:
                    business_plan_history = BusinessPlanHistory.objects.filter(company_detail_id=user.company_detail_id).latest('id')
                    #if business_plan_history.payment_status:
                    if business_plan_history.plan_type == "Free Trail" or business_plan_history.payment_status:
                        refresh = RefreshToken.for_user(user)
                        user_detail = getUserData(user.id)
                        user_detail['refresh'] = str(refresh)
                        user_detail['access'] = str(refresh.access_token)
                        print(user_detail)
                        return JsonResponse(user_detail, status=status.HTTP_200_OK)
                    
                    else:
                        res = {"submit": "Payment is not completed. Please complete the payment to login."}
                        return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)
            #if User.objects.filter(email=email).values('is_verified') == True:
            print(user, user.id)
            user_detail = {}
            if user.is_active:
                if user.is_verified:
                    refresh = RefreshToken.for_user(user)

                    user_detail['refresh'] = str(refresh)
                    user_detail['access'] = str(refresh.access_token)
                    #
                    if user.user_type != "Visitor":
                        user_detail["data"] = getUserDataLogin(user.id)
                    print(user_detail)
                    return JsonResponse(user_detail, status=status.HTTP_200_OK)
                else:
                    return Response({"submit":"Please Verify your email."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                res = {"code": 400, "message": "Account is not active."}
                return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)
        else:
            res = {"code": 400, "message": "Invalid Username and Password."}
            return JsonResponse(res, status=status.HTTP_400_BAD_REQUEST)
        

class EmployeeAddSelfDetailView(APIView):
    permission_classes = [IsAuthenticated]
    def get(self, request):
        # Get the user ID from the JWT token
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'employee_add_self' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['employee_add_self']:
                    acess_to_page = True
            if acess_to_page == True:
                user_id = request.user.id

                user_email = request.user.email
                # Find the Employee instance with the matching user ID
                try:
                    company_detail_id = request.user.company_detail_id
                    sub_company_id = request.user.sub_company_id
                    employee = Employee.objects.filter(company_detail_id=company_detail_id, sub_company_id=sub_company_id).first()
                    # serializer = EmployeeSerializer(employee, many=True)
                    # return Response(serializer.data, status=status.HTTP_200_OK)
                except Employee.DoesNotExist:
                    return Response({'message': 'Employee not found for the authenticated user.'},
                                    status=status.HTTP_404_NOT_FOUND)

                # Serialize the VisitorDetail instance and return it in the response data
                serializer = EmployeeSerializer(employee)
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'employee_add_self' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['employee_add_self']:
                    acess_to_page = True
            if acess_to_page == True:
                print(request.data)
                # company_detail_id = request.user.company_detail_id
                company_detail_id = request.user.company_detail_id
                print("company_detail_id: ", company_detail_id)
                user_email = request.user
                print("user email: ", user_email)
                print(request.auth.payload)
                print(request.auth.payload["user_id"])
                print(" request.user.id", request.user.id)

                # Get the user ID from the JWT token
                user_id = request.user.id

                user_email = request.user.email
                # Find the VisitorDetail instance with the matching user email
                try:
                    sub_company_id = request.user.sub_company_id
                    employee = Employee.objects.filter(company_detail_id=company_detail_id, sub_company_id=sub_company_id).first()
                except Employee.DoesNotExist:
                    return Response({'message': 'Employee not found for the authenticated user.'},
                                    status=status.HTTP_404_NOT_FOUND)

                # Update the VisitorDetail instance with the request data
                serializer = EmployeeSerializer(employee, data=request.data, partial=True)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_200_OK)
                else:
                    print(serializer.errors)
                    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

                return Response({"Success": "Detail Added Successfully"})
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


# Department API
class DepartmentList(APIView):
    permission_classes = [IsAuthenticated]


    def get_object(self):
        try:
            return Department.objects.all()
        except:
            raise Http404

    ObjectSerializer = DepartmentSerializer
    model_name = "Department"

    def get(self, request, format=None):
        limit = int(request.GET.get('limit',10))
        offset = int(request.GET.get('offset',0))
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'department' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['department']:
                    acess_to_page = True
            if acess_to_page == True:
                sub_company_detail_id = None
                if len(get_user_data['sub_company']) > 0:
                    sub_company_detail_id = get_user_data['sub_company']['id']
                department_queryset = Department.objects.filter(company_detail_id = get_user_data['company_detail']['id'],sub_company_id = sub_company_detail_id).order_by('-id').all()[offset:limit+offset]
                department_count = Department.objects.filter(company_detail_id = get_user_data['company_detail']['id'],sub_company_id = sub_company_detail_id).count()
                serializer = self.ObjectSerializer(department_queryset, many=True)
                return Response({'count':department_count, 'results': serializer.data})
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


                
    def post(self, request, format=None):
        # serializer = CompanyDetailSerializer(data=request.data)
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'department' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['department']:
                    acess_to_page = True
            if acess_to_page == True:
                sub_company_detail_id = None
                if len(get_user_data['sub_company']) > 0:
                    sub_company_detail_id = get_user_data['sub_company']['id']
                data = request.data
                data['company_detail_id'] = get_user_data['company_detail']['id']
                data['sub_company_id'] = sub_company_detail_id
                serializer = self.ObjectSerializer(data=data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)



class DepartmentDetail(APIView):
    permission_classes = (IsAuthenticated,)

    def get_object(self, pk):
        try:
            return Department.objects.get(pk=pk)
        except:
            raise Http404

    ObjectSerializer = DepartmentSerializer

    def get(self, request, id=None, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'department' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['department']:
                    acess_to_page = True
            if acess_to_page == True:

                print(r'get details of id: ', id)

                company_detail_id = request.user.company_detail_id
                sub_company_id = request.user.sub_company_id
                #queryset = self.get_object(pk=id)
                queryset = Department.objects.filter(pk=id,
                                                                    company_detail_id=company_detail_id, sub_company_id=sub_company_id).first()
                serializer = self.ObjectSerializer(queryset)
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)



    def put(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'department' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['department']:
                    acess_to_page = True
            if acess_to_page == True:
                sub_company_detail_id = None
                if len(get_user_data['sub_company']) > 0:
                    sub_company_detail_id = get_user_data['sub_company']['id']
                data = request.data
                data['company_detail_id'] = get_user_data['company_detail']['id']
                data['sub_company_id'] = sub_company_detail_id
                queryset = self.get_object(pk=id)
                serializer = self.ObjectSerializer(queryset, data=data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


    def delete(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'department' in get_user_data['permission'].keys():
                if 'delete' in get_user_data['permission']['department']:
                    acess_to_page = True
            if acess_to_page == True:
                company_detail_id = request.user.company_detail_id
                sub_company_id = request.user.sub_company_id
                #queryset = self.get_object(pk=id)
                queryset = Department.objects.filter(pk=id,
                                                            company_detail_id=company_detail_id, sub_company_id=sub_company_id).first()
                try:
                    queryset.delete()
                    return Response(status=status.HTTP_204_NO_CONTENT)
                except Exception as e:
                    return Response({"submit": "Cannot delete. This department is used for visitor request or employee data."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


# DropDown
class DepartmentListView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        company_detail_id = request.user.company_detail_id
        sub_company_id = request.user.sub_company_id
        print("company_detail_id", company_detail_id)

        if company_detail_id:
            departments = Department.objects.filter(company_detail_id=company_detail_id,sub_company_id=sub_company_id)

        if sub_company_id:
            departments = Department.objects.filter(sub_company_id=sub_company_id)


        print("departments", departments)
        

        department_serializer = DepartmentListSerializer(departments, many=True)
        return Response(department_serializer.data)
