from django.urls import path
from employeeapp import views

urlpatterns = [

    path('EmployeeList/', views.EmployeeList.as_view()),
    path('EmployeeDetail/<int:id>', views.EmployeeDetail.as_view()),

    path('register_employee/', views.RegisterEmployee.as_view()),
    path('employee_login/', views.EmployeeLogin.as_view()),

    path('employee_profile/', views.EmployeeAddSelfDetailView.as_view()),
    path('employee_profile/<int:id>', views.EmployeeAddSelfDetailView.as_view()),

    path('DepartmentList/', views.DepartmentList.as_view()),
    path('DepartmentDetail/<int:id>', views.DepartmentDetail.as_view()),

    path('departments_dropdown/', views.DepartmentListView.as_view()),

]