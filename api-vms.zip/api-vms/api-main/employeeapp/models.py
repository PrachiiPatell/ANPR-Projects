from django.db import models
from account.models import CompanyDetail, SubCompany, Roles

# Create your models here.


class Department(models.Model):
    department_name = models.CharField(max_length=17)
    company_detail_id = models.ForeignKey(CompanyDetail, on_delete=models.CASCADE)
    sub_company_id = models.ForeignKey(SubCompany, on_delete=models.PROTECT, blank=True, null=True)
    department_email = models.EmailField()
    
class Employee(models.Model):
    name = models.CharField(max_length=17)
    email = models.EmailField()
    mobile_no = models.CharField(max_length=20, blank=True, null=True)
    age = models.IntegerField(blank=True, null=True)
    date_of_birth = models.DateField(blank=True, null=True)
    designation = models.CharField(max_length=17)
    date_of_joining = models.DateField(blank=True, null=True)
    visitor_allow = models.BooleanField()
    department_id = models.ForeignKey(Department, on_delete=models.PROTECT, related_name="department")
    company_detail_id = models.ForeignKey(CompanyDetail, on_delete=models.PROTECT)
    sub_company_id = models.ForeignKey(SubCompany, on_delete=models.PROTECT, blank=True, null=True)
    role_id = models.ForeignKey(Roles, on_delete=models.CASCADE)
    photo = models.TextField(blank=True, null=True)


# class EmployeeImage(models.Model):
#     photo = models.TextField(blank=True, null=True)
#     employee_id = models.ForeignKey(Employee, on_delete=models.PROTECT, related_name="employee")

