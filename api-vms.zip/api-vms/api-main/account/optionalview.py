from django.shortcuts import render
from rest_framework import status
from rest_framework.response import Response
from django.http import Http404

# view
from rest_framework.decorators import api_view
from rest_framework.generics import ListAPIView
from rest_framework.views import APIView

from rest_framework.permissions import AllowAny, IsAuthenticated

from rest_framework.parsers import JSONParser

# import model
from .models import Currency, CompanyDetail, User, Roles, UserRoleMapping, UserType, MenuPage, Action, \
    MenuActionMap, Permission

# import serializers
from .serializers import CurrencySerializer, CompanyDetailSerializer, UserSerializer, \
    RolesSerializer, UserRoleMappingSerializer, UserTypeSerializer, MenuPageSerializer, ActionSerializer, \
    MenuActionMapSerializer, PermissionSerializer

from .serializers import *


from .getUserDataLogin import getUserDataLogin

# Authentications

#from rest_framework_jwt.authentication import JSONWebTokenAuthentication
from rest_framework.permissions import IsAuthenticated


from .models import MenuActionMapVisitor
from .serializers import MenuActionMapVisitorSerializer
from rest_framework.permissions import IsAuthenticated


from django.forms.models import model_to_dict
from django.contrib.auth import get_user_model

from django.forms.models import model_to_dict
from account.getVisitorUserDataLogin import getVisitorUserDataLogin





# Currency API

class CurrencyList(APIView):
    permission_classes = (IsAuthenticated,)

    def get_object(self):
        try:
            return Currency.objects.all()
        except:
            raise Http404

    ObjectSerializer = CurrencySerializer
    model_name = 'Currency'

    def get(self, request, format=None):
        limit = int(request.GET.get('limit',10))
        offset = int(request.GET.get('offset',0))

        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'currency' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['currency']:
                    acess_to_page = True
            if acess_to_page == True:
                queryset = Currency.objects.all()[offset:limit+offset]
                serializer = self.ObjectSerializer(queryset, many=True)
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
        

    def post(self, request, format=None):
        # serializer = CompanyDetailSerializer(data=request.data)
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'currency' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['currency']:
                    acess_to_page = True
            if acess_to_page == True:
                data = request.data
                serializer = self.ObjectSerializer(data=data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class CurrencyDetail(APIView):
    permission_classes = (IsAuthenticated,)
    def get_object(self, pk):
        try:
            return Currency.objects.get(pk=pk)
        except:
            raise Http404

    ObjectSerializer = CurrencySerializer

    def get(self, request, id=None, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'currency' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['currency']:
                    acess_to_page = True
            if acess_to_page == True:
                print(r'get details of id: ', id)
                queryset = self.get_object(pk=id)
                # serializer = CompanyDetailSerializer(queryset)
                serializer = self.ObjectSerializer(queryset)
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
                
                    

    def patch(self, request, id, format=None):
        pass
        # queryset = self.get_object(pk=id)
        # print("PATCH request ",id,queryset,request.data)
        # serializer = CompanyDetailSerializer(queryset, data=request.data)
        # if serializer.is_valid():
        #     serializer.save()
        #     return Response(serializer.data)
        # return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'currency' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['currency']:
                    acess_to_page = True
            if acess_to_page == True:
                queryset = self.get_object(pk=id)
                print("PUT request ", id, queryset, request.data)
                # serializer = CompanyDetailSerializer(queryset, data=request.data)
                serializer = self.ObjectSerializer(queryset, data=request.data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'currency' in get_user_data['permission'].keys():
                if 'delete' in get_user_data['permission']['currency']:
                    acess_to_page = True
            if acess_to_page == True:
                queryset = self.get_object(pk=id)
                queryset.delete()
                return Response(status=status.HTTP_204_NO_CONTENT)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


# CompanyDetail API
class CompanyDetailList(APIView):
    permission_classes = (IsAuthenticated,)


    def get_object(self):
        try:
            return CompanyDetail.objects.all()
        except:
            raise Http404

    ObjectSerializer = CompanyDetailSerializer
    model_name = "CompanyDetail"

    def get(self, request, format=None):
        limit = int(request.GET.get('limit',10))
        offset = int(request.GET.get('offset',0))

        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'company_detail' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['company_detail']:
                    acess_to_page = True
            if acess_to_page == True:
                company_queryset = CompanyDetail.objects.filter(company_detail_id = get_user_data['company_detail']['id']).all()[offset:limit+offset]
                company_count = CompanyDetail.objects.filter(company_detail_id = get_user_data['company_detail']['id']).count()
                serializer = self.ObjectSerializer(company_queryset, many=True)
                return Response({'count':company_count, 'results': serializer.data})
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


    def post(self, request, format=None):
        # serializer = CompanyDetailSerializer(data=request.data)
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'company_detail' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['company_detail']:
                    acess_to_page = True
            if acess_to_page == True:
                data = request.data
                data['company_detail_id'] = get_user_data['company_detail']['id']
                serializer = self.ObjectSerializer(data=data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class CompanyDetailDetail(APIView):
    permission_classes = (IsAuthenticated,)

    def get_object(self, pk):
        try:
            return CompanyDetail.objects.get(pk=pk)
        except:
            raise Http404

    ObjectSerializer = CompanyDetailSerializer

    def get(self, request, id=None, format=None):

        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'company_detail' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['company_detail']:
                    acess_to_page = True
            if acess_to_page == True:

                print(r'get details of id: ', id)

                queryset = self.get_object(pk=id)
                # serializer = CompanyDetailSerializer(queryset)
                serializer = self.ObjectSerializer(queryset)
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
                    

    def patch(self, request, id, format=None):
        pass
        # queryset = self.get_object(pk=id)
        # print("PATCH request ",id,queryset,request.data)
        # serializer = CompanyDetailSerializer(queryset, data=request.data)
        # if serializer.is_valid():
        #     serializer.save()
        #     return Response(serializer.data)
        # return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'company_detail' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['company_detail']:
                    acess_to_page = True
            if acess_to_page == True:
                queryset = self.get_object(pk=id)
                print("PUT request ", id, queryset, request.data)
                # serializer = CompanyDetailSerializer(queryset, data=request.data)
                serializer = self.ObjectSerializer(queryset, data=request.data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
        

    def delete(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'company_detail' in get_user_data['permission'].keys():
                if 'delete' in get_user_data['permission']['company_detail']:
                    acess_to_page = True
            if acess_to_page == True:
                queryset = self.get_object(pk=id)
                queryset.delete()
                return Response(status=status.HTTP_204_NO_CONTENT)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
        


# User API
class UserList(APIView):

    def get_object(self):
        try:
            return User.objects.all()
        except:
            raise Http404

    ObjectSerializer = UserSerializer
    model_name = "User"

    def get(self, request, format=None):
        limit = int(request.GET.get('limit',10))
        offset = int(request.GET.get('offset',0))
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'user' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['user']:
                    acess_to_page = True
            if acess_to_page == True:
                sub_company_detail_id = None
                if len(get_user_data['sub_company']) > 0:
                    sub_company_detail_id = get_user_data['sub_company']['id']
                user_queryset = User.objects.filter(company_detail_id = get_user_data['company_detail']['id'], sub_company_id = sub_company_detail_id).all()[offset:limit+offset]
                user_count = User.objects.filter(company_detail_id = get_user_data['company_detail']['id'],sub_company_id = sub_company_detail_id).count()
                serializer = self.ObjectSerializer(user_queryset, many=True)
                return Response({'count':user_count, 'results': serializer.data})
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    

    def post(self, request, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'user' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['user']:
                    acess_to_page = True
            if acess_to_page == True:
                sub_company_detail_id = None
                if len(get_user_data['sub_company']) > 0:
                    sub_company_detail_id = get_user_data['sub_company']['id']
                data = request.data
                data['company_detail_id'] = get_user_data['company_detail']['id']
                data['sub_company_id'] = sub_company_detail_id
                serializer = self.ObjectSerializer(data=data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class UserDetail(APIView):
    permission_classes = (IsAuthenticated,)
    def get_object(self, pk):
        try:
            return User.objects.get(pk=pk)
        except:
            raise Http404

    ObjectSerializer = UserSerializer

    def get(self, request, id=None, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'user' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['user']:
                    acess_to_page = True
            if acess_to_page == True:
                print(r'get details of id: ', id)

                company_detail_id = request.user.company_detail_id
                sub_company_id = request.user.sub_company_id
                #queryset = self.get_object(pk=id)
                queryset = User.objects.filter(pk=id,
                                                    company_detail_id=company_detail_id, sub_company_id=sub_company_id).first()
                serializer = self.ObjectSerializer(queryset)
                return Response(serializer.data, status=status.HTTP_200_OK)
                # return Response({"data not exist"},status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def patch(self, request, id, format=None):
        pass
        # queryset = self.get_object(pk=id)
        # print("PATCH request ",id,queryset,request.data)
        # serializer = CompanyDetailSerializer(queryset, data=request.data)
        # if serializer.is_valid():
        #     serializer.save()
        #     return Response(serializer.data)
        # return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'user' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['user']:
                    acess_to_page = True
            if acess_to_page == True:
                sub_company_detail_id = None
                if len(get_user_data['sub_company']) > 0:
                    sub_company_detail_id = get_user_data['sub_company']['id']
                data = request.data
                data['company_detail_id'] = get_user_data['company_detail']['id']
                data['sub_company_id'] = sub_company_detail_id
                queryset = self.get_object(pk=id)
                serializer = self.ObjectSerializer(queryset, data=data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'user' in get_user_data['permission'].keys():
                if 'delete' in get_user_data['permission']['user']:
                    acess_to_page = True
            if acess_to_page == True:
                company_detail_id = request.user.company_detail_id
                sub_company_id = request.user.sub_company_id
                #queryset = self.get_object(pk=id)
                queryset = User.objects.filter(pk=id,
                                                    company_detail_id=company_detail_id, sub_company_id=sub_company_id).first()
                queryset.delete()
                return Response(status=status.HTTP_204_NO_CONTENT)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


# Roles API
class RolesList(APIView):
    permission_classes = (IsAuthenticated,)

    def get_object(self):
        try:
            return Roles.objects.all()
        except:
            raise Http404

    ObjectSerializer = RolesSerializer
    model_name = "Roles"

    def get(self, request, format=None):
        limit = int(request.GET.get('limit',10))
        offset = int(request.GET.get('offset',0))

        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'roles' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['roles']:
                    acess_to_page = True
            if acess_to_page == True:
                sub_company_detail_id = None
                if len(get_user_data['sub_company']) > 0:
                    sub_company_detail_id = get_user_data['sub_company']['id']
                role_queryset = Roles.objects.filter(company_detail_id = get_user_data['company_detail']['id'],sub_company_id = sub_company_detail_id).all()[offset:limit+offset]
                role_count = Roles.objects.filter(company_detail_id = get_user_data['company_detail']['id'],sub_company_id =sub_company_detail_id).count()
                serializer = self.ObjectSerializer(role_queryset, many=True)
                return Response({'count':role_count, 'results': serializer.data})
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

               
    def post(self, request, format=None):
        # serializer = CompanyDetailSerializer(data=request.data)
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'roles' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['roles']:
                    acess_to_page = True
            if acess_to_page == True:
                sub_company_detail_id = None
                if len(get_user_data['sub_company']) > 0:
                    sub_company_detail_id = get_user_data['sub_company']['id']
                data = request.data
                data['company_detail_id'] = get_user_data['company_detail']['id']
                data['sub_company_id'] = sub_company_detail_id
                serializer = self.ObjectSerializer(data=data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class RolesDetail(APIView):
    permission_classes = (IsAuthenticated,)
    def get_object(self, pk):
        try:
            return User.objects.get(pk=pk)
        except:
            raise Http404

    ObjectSerializer = UserSerializer

    def get(self, request, id=None, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'roles' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['roles']:
                    acess_to_page = True
            if acess_to_page == True:

               
                print(r'get details of id: ', id)
                company_detail_id = request.user.company_detail_id
                sub_company_id = request.user.sub_company_id
                #queryset = self.get_object(pk=id)
                queryset = Roles.objects.filter(pk=id,
                                                    company_detail_id=company_detail_id, sub_company_id=sub_company_id).first()
                serializer = self.ObjectSerializer(queryset)
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
        

    def patch(self, request, id, format=None):
        pass
        # queryset = self.get_object(pk=id)
        # print("PATCH request ",id,queryset,request.data)
        # serializer = CompanyDetailSerializer(queryset, data=request.data)
        # if serializer.is_valid():
        #     serializer.save()
        #     return Response(serializer.data)
        # return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'roles' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['roles']:
                    acess_to_page = True
            if acess_to_page == True:
                sub_company_detail_id = None
                if len(get_user_data['sub_company']) > 0:
                    sub_company_detail_id = get_user_data['sub_company']['id']
                data = request.data
                data['company_detail_id'] = get_user_data['company_detail']['id']
                data['sub_company_id'] = sub_company_detail_id
                queryset = self.get_object(pk=id)
                serializer = self.ObjectSerializer(queryset, data=data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'roles' in get_user_data['permission'].keys():
                if 'delete' in get_user_data['permission']['roles']:
                    acess_to_page = True
            if acess_to_page == True:
                company_detail_id = request.user.company_detail_id
                sub_company_id = request.user.sub_company_id
                #queryset = self.get_object(pk=id)
                queryset = Roles.objects.filter(pk=id,
                                                    company_detail_id=company_detail_id, sub_company_id=sub_company_id).first()
                queryset.delete()
                return Response(status=status.HTTP_204_NO_CONTENT)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


# UserRoleMapping API
class UserRoleMappingList(APIView):
    permission_classes = (IsAuthenticated,)

    def get_object(self):
        try:
            return UserRoleMapping.objects.all()
        except:
            raise Http404

    ObjectSerializer = UserRoleMappingSerializer
    model_name = "UserRoleMapping"

    def get(self, request, format=None):
        limit = int(request.GET.get('limit',10))
        offset = int(request.GET.get('offset',0))

        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'user_role_mapping' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['user_role_mapping']:
                    acess_to_page = True
            if acess_to_page == True:
                queryset = UserRoleMapping.objects.all()[offset:limit+offset]
                serializer = self.ObjectSerializer(queryset, many=True)
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

               

    def post(self, request, format=None):
        # serializer = CompanyDetailSerializer(data=request.data)
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'user_role_mapping' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['user_role_mapping']:
                    acess_to_page = True
            if acess_to_page == True:
                data = request.data
                serializer = self.ObjectSerializer(data=data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
            


class UserRoleMappingDetail(APIView):
    permission_classes = (IsAuthenticated,)

    def get_object(self, pk):
        try:
            return UserRoleMapping.objects.get(pk=pk)
        except:
            raise Http404

    ObjectSerializer = UserRoleMappingSerializer

    def get(self, request, id=None, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'user_role_mapping' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['user_role_mapping']:
                    acess_to_page = True
            if acess_to_page == True:

                print(r'get details of id: ', id)

                queryset = self.get_object(pk=id)
                # serializer = CompanyDetailSerializer(queryset)
                serializer = self.ObjectSerializer(queryset)
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


    def patch(self, request, id, format=None):
        pass
        # queryset = self.get_object(pk=id)
        # print("PATCH request ",id,queryset,request.data)
        # serializer = CompanyDetailSerializer(queryset, data=request.data)
        # if serializer.is_valid():
        #     serializer.save()
        #     return Response(serializer.data)
        # return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'user_role_mapping' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['user_role_mapping']:
                    acess_to_page = True
            if acess_to_page == True:
                queryset = self.get_object(pk=id)
                print("PUT request ", id, queryset, request.data)
                # serializer = CompanyDetailSerializer(queryset, data=request.data)
                serializer = self.ObjectSerializer(queryset, data=request.data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'user_role_mapping' in get_user_data['permission'].keys():
                if 'delete' in get_user_data['permission']['user_role_mapping']:
                    acess_to_page = True
            if acess_to_page == True:
                queryset = self.get_object(pk=id)
                queryset.delete()
                return Response(status=status.HTTP_204_NO_CONTENT)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
        

# UserType API
class UserTypeList(APIView):
    permission_classes = (IsAuthenticated,)

    def get_object(self):
        try:
            return UserType.objects.all()
        except:
            raise Http404

    ObjectSerializer = UserTypeSerializer
    model_name = "UserType"

    def get(self, request, format=None):
        limit = int(request.GET.get('limit',10))
        offset = int(request.GET.get('offset',0))

        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'user_type' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['user_type']:
                    acess_to_page = True
            if acess_to_page == True:
                queryset = UserType.objects.all()[offset:limit+offset]
                serializer = self.ObjectSerializer(queryset, many=True)
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

                

    def post(self, request, format=None):
        # serializer = CompanyDetailSerializer(data=request.data)
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'user_type' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['user_type']:
                    acess_to_page = True
            if acess_to_page == True:
                data = request.data
                serializer = self.ObjectSerializer(data=data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class UserTypeDetail(APIView):
    permission_classes = (IsAuthenticated,)
    def get_object(self, pk):
        try:
            return UserType.objects.get(pk=pk)
        except:
            raise Http404

    ObjectSerializer = UserTypeSerializer

    def get(self, request, id=None, format=None):

        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'user_type' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['user_type']:
                    acess_to_page = True
            if acess_to_page == True:

                print(r'get details of id: ', id)

                queryset = self.get_object(pk=id)
                # serializer = CompanyDetailSerializer(queryset)
                serializer = self.ObjectSerializer(queryset)
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def patch(self, request, id, format=None):
        pass
        # queryset = self.get_object(pk=id)
        # print("PATCH request ",id,queryset,request.data)
        # serializer = CompanyDetailSerializer(queryset, data=request.data)
        # if serializer.is_valid():
        #     serializer.save()
        #     return Response(serializer.data)
        # return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'user_type' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['user_type']:
                    acess_to_page = True
            if acess_to_page == True:
                queryset = self.get_object(pk=id)
                print("PUT request ", id, queryset, request.data)
                # serializer = CompanyDetailSerializer(queryset, data=request.data)
                serializer = self.ObjectSerializer(queryset, data=request.data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'user_type' in get_user_data['permission'].keys():
                if 'delete' in get_user_data['permission']['user_type']:
                    acess_to_page = True
            if acess_to_page == True:
                queryset = self.get_object(pk=id)
                queryset.delete()
                return Response(status=status.HTTP_204_NO_CONTENT)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


# MenuPage API
class MenuPageList(APIView):
    permission_classes = (IsAuthenticated,)

    def get_object(self):
        try:
            return MenuPage.objects.all()
        except:
            raise Http404

    ObjectSerializer = MenuPageSerializer
    model_name = "MenuPage"

    def get(self, request, format=None):
        limit = int(request.GET.get('limit',10))
        offset = int(request.GET.get('offset',0))

        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'menu_page' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['menu_page']:
                    acess_to_page = True
            if acess_to_page == True:
                queryset = MenuPage.objects.all()[offset:limit+offset]
                serializer = self.ObjectSerializer(queryset, many=True)
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

               

    def post(self, request, format=None):
        # serializer = CompanyDetailSerializer(data=request.data)
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'menu_page' in get_user_data['permission'].keys():
                if 'delete' in get_user_data['permission']['menu_page']:
                    acess_to_page = True
            if acess_to_page == True:
                data = request.data
                serializer = self.ObjectSerializer(data=data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class MenuPageDetail(APIView):
    permission_classes = (IsAuthenticated,)

    def get_object(self, pk):
        try:
            return MenuPage.objects.get(pk=pk)
        except:
            raise Http404

    ObjectSerializer = MenuPageSerializer

    def get(self, request, id=None, format=None):

        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'menu_page' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['menu_page']:
                    acess_to_page = True
            if acess_to_page == True:

                print(r'get details of id: ', id)
                
                queryset = self.get_object(pk=id)
                # serializer = CompanyDetailSerializer(queryset)
                serializer = self.ObjectSerializer(queryset)
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
        

    def patch(self, request, id, format=None):
        pass
        # queryset = self.get_object(pk=id)
        # print("PATCH request ",id,queryset,request.data)
        # serializer = CompanyDetailSerializer(queryset, data=request.data)
        # if serializer.is_valid():
        #     serializer.save()
        #     return Response(serializer.data)
        # return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'menu_page' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['menu_page']:
                    acess_to_page = True
            if acess_to_page == True:
                queryset = self.get_object(pk=id)
                print("PUT request ", id, queryset, request.data)
                # serializer = CompanyDetailSerializer(queryset, data=request.data)
                serializer = self.ObjectSerializer(queryset, data=request.data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'menu_page' in get_user_data['permission'].keys():
                if 'delete' in get_user_data['permission']['menu_page']:
                    acess_to_page = True
            if acess_to_page == True:
                queryset = self.get_object(pk=id)
                queryset.delete()
                return Response(status=status.HTTP_204_NO_CONTENT)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


# Action API
class ActionList(APIView):
    permission_classes = (IsAuthenticated,)


    def get_object(self):
        try:
            return Action.objects.all()
        except:
            raise Http404

    ObjectSerializer = ActionSerializer
    model_name = "Action"

    def get(self, request, format=None):
        limit = int(request.GET.get('limit',10))
        offset = int(request.GET.get('offset',0))

        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'action' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['action']:
                    acess_to_page = True
            if acess_to_page == True:
                queryset = Action.objects.all()[offset:limit+offset]
                serializer = self.ObjectSerializer(queryset, many=True)
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

                

    def post(self, request, format=None):
        # serializer = CompanyDetailSerializer(data=request.data)
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'action' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['action']:
                    acess_to_page = True
            if acess_to_page == True:
                data = request.data
                serializer = self.ObjectSerializer(data=data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class ActionDetail(APIView):
    permission_classes = (IsAuthenticated,)

    def get_object(self, pk):
        try:
            return Action.objects.get(pk=pk)
        except:
            raise Http404

    ObjectSerializer = ActionSerializer

    def get(self, request, id=None, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'action' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['action']:
                    acess_to_page = True
            if acess_to_page == True:

                print(r'get details of id: ', id)

                queryset = self.get_object(pk=id)
                # serializer = CompanyDetailSerializer(queryset)
                serializer = self.ObjectSerializer(queryset)
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def patch(self, request, id, format=None):
        pass
        # queryset = self.get_object(pk=id)
        # print("PATCH request ",id,queryset,request.data)
        # serializer = CompanyDetailSerializer(queryset, data=request.data)
        # if serializer.is_valid():
        #     serializer.save()
        #     return Response(serializer.data)
        # return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'action' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['action']:
                    acess_to_page = True
            if acess_to_page == True:
                queryset = self.get_object(pk=id)
                print("PUT request ", id, queryset, request.data)
                # serializer = CompanyDetailSerializer(queryset, data=request.data)
                serializer = self.ObjectSerializer(queryset, data=request.data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
                

    def delete(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'action' in get_user_data['permission'].keys():
                if 'delete' in get_user_data['permission']['action']:
                    acess_to_page = True
            if acess_to_page == True:
                queryset = self.get_object(pk=id)
                queryset.delete()
                return Response(status=status.HTTP_204_NO_CONTENT)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


# MenuActionMap API
class MenuActionMapList(APIView):
    permission_classes = (IsAuthenticated,)

    def get_object(self):
        try:
            return MenuActionMap.objects.all()
        except:
            raise Http404

    ObjectSerializer = MenuActionMapSerializer
    model_name = "MenuActionMap"

    def get(self, request, format=None):
        limit = int(request.GET.get('limit',10))
        offset = int(request.GET.get('offset',0))
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'menu_action_map' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['menu_action_map']:
                    acess_to_page = True
            if acess_to_page == True:
                queryset = MenuActionMap.objects.all()[offset:limit+offset]
                serializer = self.ObjectSerializer(queryset, many=True)
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)



    def post(self, request, format=None):
        # serializer = CompanyDetailSerializer(data=request.data)
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'menu_action_map' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['menu_action_map']:
                    acess_to_page = True
            if acess_to_page == True:
                data = request.data
                serializer = self.ObjectSerializer(data=data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class MenuActionMapDetail(APIView):
    permission_classes = (IsAuthenticated,)

    def get_object(self, pk):
        try:
            return MenuActionMap.objects.get(pk=pk)
        except:
            raise Http404

    ObjectSerializer = MenuActionMapSerializer

    def get(self, request, id=None, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'menu_action_map' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['menu_action_map']:
                    acess_to_page = True
            if acess_to_page == True:

                print(r'get details of id: ', id)
                
                queryset = self.get_object(pk=id)
                # serializer = CompanyDetailSerializer(queryset)
                serializer = self.ObjectSerializer(queryset)
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
                

    def patch(self, request, id, format=None):
        pass
        # queryset = self.get_object(pk=id)
        # print("PATCH request ",id,queryset,request.data)
        # serializer = CompanyDetailSerializer(queryset, data=request.data)
        # if serializer.is_valid():
        #     serializer.save()
        #     return Response(serializer.data)
        # return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'menu_action_map' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['menu_action_map']:
                    acess_to_page = True
            if acess_to_page == True:
                queryset = self.get_object(pk=id)
                print("PUT request ", id, queryset, request.data)
                # serializer = CompanyDetailSerializer(queryset, data=request.data)
                serializer = self.ObjectSerializer(queryset, data=request.data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'menu_action_map' in get_user_data['permission'].keys():
                if 'delete' in get_user_data['permission']['menu_action_map']:
                    acess_to_page = True
            if acess_to_page == True:
                queryset = self.get_object(pk=id)
                queryset.delete()
                return Response(status=status.HTTP_204_NO_CONTENT)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


# MenuActionMap API


class MenuActionMapVisitorList(APIView):
    permission_classes = (IsAuthenticated,)


    def get_object(self):
        try:
            return MenuActionMapVisitor.objects.all()
        except:
            raise Http404

    ObjectSerializer = MenuActionMapVisitorSerializer
    model_name = "MenuActionMapVisitor"

    def get(self, request, format=None):
        limit = int(request.GET.get('limit',10))
        offset = int(request.GET.get('offset',0))
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'menu_action_map_visitor' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['menu_action_map_visitor']:
                    acess_to_page = True
            if acess_to_page == True:
                queryset = MenuActionMapVisitor.objects.all()[offset:limit+offset]
                serializer = self.ObjectSerializer(queryset, many=True)
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

               

    def post(self, request, format=None):
        # serializer = CompanyDetailSerializer(data=request.data)
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'menu_action_map_visitor' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['menu_action_map_visitor']:
                    acess_to_page = True
            if acess_to_page == True:
                data = request.data
                serializer = self.ObjectSerializer(data=data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


# Permission API
class PermissionList(APIView):
    permission_classes = (IsAuthenticated,)


    def get_object(self):
        try:
            return Permission.objects.all()
        except:
            raise Http404

    ObjectSerializer = PermissionSerializer
    model_name = "Permission"

    def get(self, request, format=None):
        limit = int(request.GET.get('limit',10))
        offset = int(request.GET.get('offset',0))
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'permission' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['permission']:
                    acess_to_page = True
            if acess_to_page == True:
                queryset = Permission.objects.all()[offset:limit+offset]
                serializer = self.ObjectSerializer(queryset, many=True)
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

                

    def post(self, request, format=None):
        # serializer = CompanyDetailSerializer(data=request.data)
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'permission' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['permission']:
                    acess_to_page = True
            if acess_to_page == True:
                data = request.data
                serializer = self.ObjectSerializer(data=data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class PermissionDetail(APIView):
    permission_classes = (IsAuthenticated,)

    def get_object(self, pk):
        try:
            return Permission.objects.get(pk=pk)
        except:
            raise Http404

    ObjectSerializer = PermissionSerializer

    def get(self, request, id=None, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'permission' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['permission']:
                    acess_to_page = True
            if acess_to_page == True:

                print(r'get details of id: ', id)
                
                queryset = self.get_object(pk=id)
                # serializer = CompanyDetailSerializer(queryset)
                serializer = self.ObjectSerializer(queryset)
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

            

    def patch(self, request, id, format=None):
        pass
        # queryset = self.get_object(pk=id)
        # print("PATCH request ",id,queryset,request.data)
        # serializer = CompanyDetailSerializer(queryset, data=request.data)
        # if serializer.is_valid():
        #     serializer.save()
        #     return Response(serializer.data)
        # return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'permission' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['permission']:
                    acess_to_page = True
            if acess_to_page == True:
                queryset = self.get_object(pk=id)
                print("PUT request ", id, queryset, request.data)
                # serializer = CompanyDetailSerializer(queryset, data=request.data)
                serializer = self.ObjectSerializer(queryset, data=request.data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


    def delete(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'permission' in get_user_data['permission'].keys():
                if 'delete' in get_user_data['permission']['permission']:
                    acess_to_page = True
            if acess_to_page == True:
                queryset = self.get_object(pk=id)
                queryset.delete()
                return Response(status=status.HTTP_204_NO_CONTENT)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


        #             for role in roles:
        #                 role_data = {'role_id':role.id,'role_name': role.role_name, 'permissions': []}
        #                 role_permissions = role.permission_set.all()

        #                 for permission in role_permissions:
        #                     permission_data = {
        #                         'menu_name': permission.menu_page_id.menu_name,
        #                         'action': permission.action_id.action_name,
        #                         'user_action': self.get_user_action(request.method)  
        #                     }
        #                     role_data['permissions'].append(permission_data)

        #                 permissions.append(role_data)

        #             total_count = len(permissions)
        #             permissions = permissions[offset:offset+limit]

        #             return Response({"count": total_count, "results": permissions})
        #     else:
        #         return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        # else:
        #     return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)