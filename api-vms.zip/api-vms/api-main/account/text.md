# Approval web page
    default page: Table
        name 
        email_id
        company_name 
        photo 
        mobile_no
        id_proof 
        id_proof_no 
        id_proof_photo (show on detail)
        vehicle_no
        type_of_mobile
        address 
        employee_name 
        department_Id => fk dept name
        from_date 
        to_date 
        duration 
        purpose_of_visit 
        employee_id => fk employee name
        accessory_provide_allowed
        
        
        accessory provided name => Accesory Provided> default Accesory
        accessory return name => Accesory Return> default Accesory
        
        Approval Layer 
        Approval status
        user_id 