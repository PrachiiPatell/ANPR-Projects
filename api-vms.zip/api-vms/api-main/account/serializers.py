from rest_framework import serializers
from rest_framework.validators import UniqueValidator

from .models import *
from .models import DefaultAccessoryProvidedByCompany, Accessory
from .models import ApprovalType, ApprovalLayer, PassExtensionChangeApprovalRole, ApproveStepByRole
from .models import AddUserEmail, OTP
from django.contrib.auth.password_validation import validate_password
import base64
from django.contrib.auth.hashers import make_password
from rest_framework.validators import UniqueTogetherValidator
from .models import FineCollectedBy, ApprovalLayer, ApprovalChangeByNumberOfDays, ApproveStepByRole, ApprovalType
from .models import SubCompanyMenuActionMap
from .getUserDataLogin import getUserDataLogin
from django.db import IntegrityError
from django.db.models import Q



class CurrencySerializer(serializers.ModelSerializer):
    class Meta:
        model = Currency
        fields = '__all__'

    def validate(self, data):
        currency_type = data.get('currency_type', '').strip()

        if currency_type:
            # Capitalize the first letter of currency_type
            data['currency_type'] = currency_type.capitalize()

        return data

    def create(self, validated_data):
        return super().create(validated_data)

    def update(self, instance, validated_data):
        return super().update(instance, validated_data)



class CompanyDetailSerializer(serializers.ModelSerializer):
    currency = serializers.CharField(source='currency_id.currency_type', read_only=True)

    # print("currency",currency)
    class Meta:
        model = CompanyDetail
        # fields = '__all__'
        fields = ["id", "company_name", "company_type", "company_logo", "country", "uses_type", "start_date_time",
                  "end_date_time", "account_validity", "accessory_provide", "currency_id", "currency",
                  "days_to_expire"]
        
    def validate(self, data):
        fields_to_capitalize = ["company_name", "company_type", "country", "uses_type"]
        
        for field_name in fields_to_capitalize:
            field_value = data.get(field_name)
            if field_value:
                # Capitalize the first letter of the field value
                data[field_name] = field_value.capitalize()

        return data

    def create(self, validated_data):
        # Capitalize the first letter of specified fields during creation
        fields_to_capitalize = ["company_name", "company_type", "country", "uses_type"]
        
        for field_name in fields_to_capitalize:
            field_value = validated_data.get(field_name)
            if field_value:
                validated_data[field_name] = field_value.capitalize()

        return super().create(validated_data)

    def update(self, instance, validated_data):
        company_type = validated_data.get('company_type')

        # Check if company_type is 'multiple'
        if company_type == 'Multiple':
            # If company_type is 'multiple', allow adding sub_company
            instance.sub_company = validated_data.get('sub_company', instance.sub_company)

        return super().update(instance, validated_data)
        

    def delete(self, instance):
        try:
            instance.delete()
        except  Exception as e:
            raise serializers.ValidationError(
                {'submit': 'Cannot delete. This object is referenced by other objects.'})



class CompanyDetailListSerializer(serializers.ModelSerializer):
    class Meta:
        model = CompanyDetail
        # fields = '__all__'
        fields = ["id", "company_name"]

    def delete(self, instance):
        try:
            instance.delete()
        except  Exception as e:
            raise serializers.ValidationError(
                {'submit': 'Cannot delete. This object is referenced by other objects.'})


class SubCompanySerializer(serializers.ModelSerializer):
    company_detail = serializers.CharField(source='company_detail_id.company_name', read_only=True)

    class Meta:
        model = SubCompany
        fields = '__all__'
        # fields = ["id", "company_email", "company_detail"]

    def validate_company_email(self, value):
        # Check if the company_email already exists for any company_detail or sub_company
        if SubCompany.objects.filter(company_email=value).exists():
            raise serializers.ValidationError({'company_email':'This company_email already exists.'})
        return value

    def create(self, validated_data):
        company_detail_id = self.context['request'].user.company_detail_id

        # Check if company_type is 'multiple' for the logged-in company_detail_id
        if company_detail_id.company_type == 'Multiple':
            sub_company_name = validated_data.get('sub_company_name')
            company_email = validated_data.get('company_email')

            validated_data['sub_company_name'] = sub_company_name.capitalize()

            # Check if a sub_company with the same name already exists for the company_detail_id
            if SubCompany.objects.filter(sub_company_name=validated_data['sub_company_name']).exists():
                raise serializers.ValidationError({"sub_company_name": "A sub_company with the same name already exists."})

            # Validate the uniqueness of the company_email field
            self.validate_company_email(company_email)

            validated_data['company_detail_id'] = company_detail_id
            sub_company = SubCompany.objects.create(**validated_data)
            return sub_company
        else:
            raise serializers.ValidationError({'company_type':'Cannot create sub_company. Company type is not multiple.'})

    def update(self, instance, validated_data):
        company_detail_id = self.context['request'].user.company_detail_id

        # Check if company_type is 'multiple' for the logged-in company_detail_id
        if company_detail_id.company_type == 'multiple':
            instance.sub_company_name = validated_data.get('sub_company_name', instance.sub_company_name)
            company_email = validated_data.get('company_email', instance.company_email)

            validated_data['sub_company_name'] = instance.sub_company_name.capitalize()

            if SubCompany.objects.filter(sub_company_name= validated_data['sub_company_name']).exclude(pk=getattr(self.instance, 'pk', None)).exists():
                raise serializers.ValidationError({"sub_company_name": "A sub_company with the same name already exists."})

            # Validate the uniqueness of the company_email field
            self.validate_company_email(company_email)

            instance.company_email = company_email
            instance.save()
            return instance
        else:
            raise serializers.ValidationError({'company_type':'Cannot update sub_company. Company type is not multiple.'})

    def delete(self, instance):
        try:
            instance.delete()
        except Exception as e:
            raise serializers.ValidationError({'submit': 'Cannot delete. This object is referenced by other objects.'})


class UserSerializer(serializers.ModelSerializer):
    company_detail = serializers.CharField(source='company_detail_id.company_name', read_only=True)
    sub_company = serializers.CharField(source='sub_company_id.sub_company_name', read_only=True)

    class Meta:
        model = User
        # fields = '__all__'
        fields = ['id', 'email', 'password', 'password2', 'company_detail_id', 'company_detail', "sub_company_id",
                  'sub_company', 'user_login_or_not', 'is_superuser', 'is_active', 'time_zone', 'is_staff', 'user_type', 'phone_number' 
                  ]

    # email = serializers.EmailField(required=True, validators=[UniqueValidator(queryset=User.objects.all())])
    password = serializers.CharField(write_only=True, required=True, validators=[validate_password])
    password2 = serializers.CharField(write_only=True, required=True)
    email = serializers.EmailField(required=True, validators=[UniqueValidator(queryset=User.objects.all())])

    # company_detail_id = serializers.IntegerField()

    def validate(self, attrs):
        if attrs['password'] != attrs['password2']:
            raise serializers.ValidationError({"password": "Password fields didn't match."})
        return attrs

    def create(self, validated_data):
        user_type = validated_data.get('user_type')
        validated_data['user_type'] = user_type.capitalize()
        
        print("validated data", validated_data)
        self.validate(validated_data)
        print(validated_data)
        validated_data.pop('password2')
        password = validated_data.pop('password')
        validated_data['password'] = make_password(password)
        try:
            return User.objects.create(**validated_data)
        except IntegrityError:
            raise serializers.ValidationError({"email": "Email must be unique."})
        
    def delete(self, instance):
        try:
            instance.delete()
        except  Exception as e:
            raise serializers.ValidationError(
                {'submit': 'Cannot delete. This object is referenced by other objects.'})


class RolesSerializer(serializers.ModelSerializer):
    company_detail = serializers.CharField(source='company_detail_id.company_name', read_only=True)
    sub_company = serializers.CharField(source='sub_company_id.sub_company_name', read_only=True)

    class Meta:
        model = Roles
        fields = '__all__'

    def create(self,validated_data):
        sub_company_id = validated_data.get('sub_company_id')
        role_name = validated_data.get('role_name', '').strip()

        if role_name:
        
            validated_data['role_name'] = role_name.capitalize()
        if Roles.objects.filter(
                company_detail_id = validated_data['company_detail_id'],sub_company_id=sub_company_id,
                role_name=validated_data['role_name']).exists():
            raise serializers.ValidationError(
                    {'role_name': 'An entry with the same role name of this company already exists.'}
                )
        return Roles.objects.create(**validated_data)
        
 

    def update(self, instance, validated_data):
        sub_company_id = validated_data.get('sub_company_id')
        role_name = validated_data.get('role_name', '').strip()

        if role_name:
           
            validated_data['role_name'] = role_name.capitalize()
        if Roles.objects.filter(
                company_detail_id = validated_data['company_detail_id'],sub_company_id=sub_company_id,
                role_name=validated_data['role_name']).exclude(pk=getattr(self.instance, 'pk', None)).exists():
            raise serializers.ValidationError(
                    {'role_name': 'An entry with the same role name of this company already exists.'}
                )
        
        return super().update(instance, validated_data)
    
    def delete(self, instance):
        try:
            instance.delete()
        except  Exception as e:
            raise serializers.ValidationError(
                {'submit': 'Cannot delete. This object is referenced by other objects.'})


class AddUserEmailSerializer(serializers.ModelSerializer):
    email = serializers.EmailField(required=True, validators=[UniqueValidator(queryset=AddUserEmail.objects.all())])
    company_detail = serializers.CharField(source='company_detail_id.company_name', read_only=True)
    role = serializers.CharField(source='role_id.role_name', read_only=True)
    sub_company = serializers.CharField(source='sub_company_id.sub_company_name', read_only=True)

    class Meta:
        model = AddUserEmail
        fields = ['email', 'role_id', 'role', 'company_detail_id', 'company_detail', 'sub_company_id', 'sub_company']

    def create(self, validated_data):
        email = validated_data.get('email')
        if AddUserEmail.objects.filter(email=email).exists():
            raise serializers.ValidationError({"email": "Email must be unique."})
        return super().create(validated_data)

    def update(self, instance, validated_data):
        email = validated_data.get('email', instance.email)
        if AddUserEmail.objects.filter(email=email).exclude(id=instance.id).exists():
            raise serializers.ValidationError({"email": "Email must be unique."})
        return super().update(instance, validated_data)

    def delete(self, instance):
        try:
            instance.delete()
        except  Exception as e:
            raise serializers.ValidationError(
                {'submit': 'Cannot delete. This object is referenced by other objects.'})


class UserRoleMappingSerializer(serializers.ModelSerializer):
    role = serializers.CharField(source='role_id.role_name', read_only=True)

    class Meta:
        model = UserRoleMapping
        fields = '__all__'

    def delete(self, instance):
        try:
            instance.delete()
        except  Exception as e:
            raise serializers.ValidationError(
                {'submit': 'Cannot delete. This object is referenced by other objects.'})
        

class UserTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserType
        fields = '__all__'


class MenuPageSerializer(serializers.ModelSerializer):
    is_menu_type = serializers.CharField(source='is_menu_type_id.is_menu_visible', read_only=True)

    class Meta:
        model = MenuPage
        fields = '__all__'

    def delete(self, instance):
        try:
            instance.delete()
        except  Exception as e:
            raise serializers.ValidationError(
                {'submit': 'Cannot delete. This object is referenced by other objects.'})

class ActionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Action
        fields = '__all__'


class MenuActionMapSerializer(serializers.ModelSerializer):
    action = serializers.CharField(source='action_id.action_name', read_only=True)

    class Meta:
        model = MenuActionMap
        fields = '__all__'

    def delete(self, instance):
            try:
                instance.delete()
            except  Exception as e:
                raise serializers.ValidationError(
                    {'submit': 'Cannot delete. This object is referenced by other objects.'})
            
class MenuActionMapVisitorSerializer(serializers.ModelSerializer):
        action = serializers.CharField(source='action_id.action_name', read_only=True)

        class Meta:
            model = MenuActionMapVisitor
            fields = '__all__'

        def delete(self, instance):
            try:
                instance.delete()
            except  Exception as e:
                raise serializers.ValidationError(
                    {'submit': 'Cannot delete. This object is referenced by other objects.'})



class PermissionSerializer(serializers.ModelSerializer):
    role = RolesSerializer(read_only=True)  # Use the RolesSerializer for the role field
    action = serializers.CharField(source='action_id.action_name', read_only=True)
    menu_page = serializers.CharField(source='menu_page_id.menu_name', read_only=True)

    class Meta:
        model = Permission
        fields = '__all__'

    def validate(self, attrs):
        role_id = attrs.get('role_id')
        menu_page_id = attrs.get('menu_page_id')
        action_id = attrs.get('action_id')

        # Check if the combination of role_id, menu_page_id, and action_id already exists
        existing_qs = Permission.objects.filter(role_id=role_id, menu_page_id=menu_page_id, action_id=action_id)

        if self.instance:
            # Exclude the current instance from the queryset for updates
            existing_qs = existing_qs.exclude(pk=self.instance.pk)

        if existing_qs.exists():
            raise serializers.ValidationError({'submit': 'This combination of role, menu_page, and action already exists.'})

        return attrs
    

    def delete(self, instance):
        try:
            instance.delete()
        except  Exception as e:
            raise serializers.ValidationError(
                {'submit': 'Cannot delete. This object is referenced by other objects.'})


class RolesListSerializer(serializers.ModelSerializer):
    class Meta:
        model = Roles
        fields = ["id", "role_name"]


    def delete(self, instance):
        try:
            instance.delete()
        except  Exception as e:
            raise serializers.ValidationError(
                {'submit': 'Cannot delete. This object is referenced by other objects.'})






class DefaultAccessoryProvidedByCompanySerializer(serializers.ModelSerializer):
    company = serializers.CharField(source='company_detail_id.company_name', read_only=True)
    sub_company = serializers.CharField(source='sub_company_id.sub_company_name', read_only=True)

    class Meta:
        model = DefaultAccessoryProvidedByCompany
        fields = '__all__'


    def create(self,validated_data):
        accessory_name = validated_data.get('accessory_name', '').strip()

        if accessory_name:
            # Capitalize the first letter of accessory_name
            validated_data['accessory_name'] = accessory_name.capitalize()
        if DefaultAccessoryProvidedByCompany.objects.filter(
                accessory_name=validated_data['accessory_name'],company_detail_id=validated_data['company_detail_id'],sub_company_id=validated_data['sub_company_id']).exists():
            raise serializers.ValidationError(
                    {'accessory_name': 'An entry with the same accessory name already exists.'}
                )
        return DefaultAccessoryProvidedByCompany.objects.create(**validated_data)
        
 

    def update(self, instance, validated_data):
        accessory_name = validated_data.get('accessory_name', '').strip()

        if accessory_name:
            # Capitalize the first letter of accessory_name
            validated_data['accessory_name'] = accessory_name.capitalize()
        if DefaultAccessoryProvidedByCompany.objects.filter(
                accessory_name=validated_data['accessory_name'],company_detail_id=validated_data['company_detail_id'],sub_company_id=validated_data['sub_company_id']).exclude(pk=getattr(self.instance, 'pk', None)).exists():
            raise serializers.ValidationError(
                    {'accessory_name': 'An entry with the same accessory name already exists.'}
                )
        
        return super().update(instance, validated_data)

    def delete(self, instance):
        try:
            instance.delete()
        except  Exception as e:
            raise serializers.ValidationError(
                {'submit': 'Cannot delete. This object is referenced by other objects.'})
        

# class DefaultAccessoryHaveSerializer(serializers.ModelSerializer):
#     company = serializers.CharField(source='company_detail_id.company_name', read_only=True)
#     sub_company = serializers.CharField(source='sub_company_id.sub_company_name', read_only=True)

#     class Meta:
#         model = DefaultAccessoryHave
#         fields = '__all__'

#     def create(self,validated_data):
#         accessory_name = validated_data.get('accessory_name', '').strip()

#         if accessory_name:
#             # Capitalize the first letter of accessory_name
#             validated_data['accessory_name'] = accessory_name.capitalize()
#         if DefaultAccessoryHave.objects.filter(
#                 accessory_name=validated_data['accessory_name']).exists():
#             raise serializers.ValidationError(
#                     {'accessory_name': 'An entry with the same accessory name already exists.'}
#                 )
#         return DefaultAccessoryHave.objects.create(**validated_data)
        
 

#     def update(self, instance, validated_data):
#         accessory_name = validated_data.get('accessory_name', '').strip()

#         if accessory_name:
#             # Capitalize the first letter of accessory_name
#             validated_data['accessory_name'] = accessory_name.capitalize()
#         if DefaultAccessoryHave.objects.filter(
#                 accessory_name=validated_data['accessory_name']).exclude(pk=getattr(self.instance, 'pk', None)).exists():
#             raise serializers.ValidationError(
#                     {'accessory_name': 'An entry with the same accessory name already exists.'}
#                 )
        
#         return super().update(instance, validated_data)
    
#     def delete(self, instance):
#         try:
#             instance.delete()
#         except  Exception as e:
#             raise serializers.ValidationError(
#                 {'submit': 'Cannot delete. This object is referenced by other objects.'})


        

class AccessorySerializer(serializers.ModelSerializer):
    company = serializers.CharField(source='company_detail_id.company_name', read_only=True)
    sub_company = serializers.CharField(source='sub_company_id.sub_company_name', read_only=True)

    class Meta:
        model = Accessory
        fields = '__all__'


    def create(self,validated_data):
        accessory_name = validated_data.get('accessory_name', '').strip()

        if accessory_name:
            # Capitalize the first letter of accessory_name
            validated_data['accessory_name'] = accessory_name.capitalize()
        if Accessory.objects.filter(
                accessory_name=validated_data['accessory_name']).exists():
            raise serializers.ValidationError(
                    {'accessory_name': 'An entry with the same accessory name already exists.'}
                )
        return Accessory.objects.create(**validated_data)
        
 

    def update(self, instance, validated_data):
        accessory_name = validated_data.get('accessory_name', '').strip()

        if accessory_name:
            # Capitalize the first letter of accessory_name
            validated_data['accessory_name'] = accessory_name.capitalize()
        if Accessory.objects.filter(
                accessory_name=validated_data['accessory_name']).exclude(pk=getattr(self.instance, 'pk', None)).exists():
            raise serializers.ValidationError(
                    {'accessory_name': 'An entry with the same accessory name already exists.'}
                )
        
        return super().update(instance, validated_data)

    def delete(self, instance):
        try:
            instance.delete()
        except  Exception as e:
            raise serializers.ValidationError(
                {'submit': 'Cannot delete. This object is referenced by other objects.'})
        

# Configurations


class FineCollectedBySerializer(serializers.ModelSerializer):
    role_name = serializers.CharField(source='role_id.role_name', read_only=True)
    company_name = serializers.CharField(source='company_detail_id.company_name', read_only=True)
    sub_company_name = serializers.CharField(source='sub_company_id.sub_company_name', read_only=True)

    class Meta:
        model = FineCollectedBy
        fields = '__all__'
    
    def create(self,validated_data):
        sub_company_id = validated_data.get('sub_company_id')
        
        if FineCollectedBy.objects.filter(
                role_id = validated_data['role_id'],
                company_detail_id=validated_data['company_detail_id'],sub_company_id=sub_company_id).exists():
            raise serializers.ValidationError(
                    {'role_id': 'An entry with the same role and company already exists.'}
                )
        return FineCollectedBy.objects.create(**validated_data)
        
 

    def update(self, instance, validated_data):
        sub_company_id = validated_data.get('sub_company_id')
       
        if FineCollectedBy.objects.filter(
               role_id = validated_data['role_id'],
                company_detail_id=validated_data['company_detail_id'],sub_company_id=sub_company_id).exclude(pk=getattr(self.instance, 'pk', None)).exists():
            raise serializers.ValidationError(
                    {'role_id': 'An entry with the same role and company already exists.'}
                )
        
        return super().update(instance, validated_data)

    def delete(self, instance):
        try:
            instance.delete()
        except  Exception as e:
            raise serializers.ValidationError(
                {'submit': 'Cannot delete. This object is referenced by other objects.'})
        

class ApprovalLayerSerializer(serializers.ModelSerializer):
    company = serializers.CharField(source='company_detail_id.company_name', read_only=True)
    sub_company = serializers.CharField(source='sub_company_id.sub_company_name', read_only=True)

    class Meta:
        model = ApprovalLayer
        fields = '__all__'

    def create(self, validated_data):
        company_detail_id = validated_data.get('company_detail_id')
        sub_company_id = validated_data.get('sub_company_id')
        
        # Check if an ApprovalLayer with the same company_detail_id already exists
        existing_layer = ApprovalLayer.objects.filter(company_detail_id=company_detail_id,sub_company_id=sub_company_id).first()

        if existing_layer:
            raise serializers.ValidationError({'submit': 'An ApprovalLayer for this company already exists.'})

        return super().create(validated_data)
    
    def update(self, instance, validated_data):
        max_layer_of_approval = validated_data.get('max_layer_of_approval')
        company_detail_id = instance.company_detail_id
        sub_company_id = validated_data.get('sub_company_id')
        
        # Query the ApprovalChangeByNumberOfDays for the same company_detail_id
        approvals = ApprovalChangeByNumberOfDays.objects.filter(company_detail_id=company_detail_id,sub_company_id=sub_company_id)
        
        # Check if max_layer_of_approval is less than any layer_of_approval
        if any(max_layer_of_approval < approval.layer_of_approval for approval in approvals):
            raise serializers.ValidationError({'max_layer_of_approval': 'Max layer cannot be less than any layer in ApprovalChangeByNumberOfDays.'})
        
        return super().update(instance, validated_data)

    def delete(self, instance):
        try:
            instance.delete()
        except Exception as e:
            raise serializers.ValidationError(
                {'submit': 'Cannot delete. This object is referenced by other objects.'})



class ApprovalChangeByNumberOfDaysSerializer(serializers.ModelSerializer):
    class Meta:
        model = ApprovalChangeByNumberOfDays
        fields = '__all__'

    
    def create(self,validated_data):
        from_days = validated_data.get('from_days')
        to_days = validated_data.get('to_days')
        layer_of_approval = validated_data.get('layer_of_approval')
        company_detail_id = validated_data.get('company_detail_id')
        sub_company_id = validated_data.get('sub_company_id')

        if from_days == to_days or from_days > to_days:
            raise serializers.ValidationError({"to_days": "to_days cannot be the same as from_days or less than from_days."})

        existing_entrys = ApprovalChangeByNumberOfDays.objects.filter(
            company_detail_id=company_detail_id, sub_company_id=sub_company_id
        )

        for existing_entry in existing_entrys:
            if existing_entry:
                existing_from_days = existing_entry.from_days
                existing_to_days = existing_entry.to_days

                # if (to_days - from_days) == (existing_to_days - existing_from_days):
                #     raise serializers.ValidationError(
                #         {"from_days": "The range between from days and to days already exist."}
                #     )
                
                if (from_days >= existing_from_days and from_days <= existing_to_days) or (to_days >= existing_from_days and to_days <= existing_to_days):
                    raise serializers.ValidationError(
                        {"from_days": "New entry overlaps with an existing range."}
                    )


        approval_max_layers = ApprovalLayer.objects.filter(company_detail_id=validated_data['company_detail_id'],sub_company_id=sub_company_id).values_list('max_layer_of_approval', flat=True)
        max_layer = max(approval_max_layers)
        if layer_of_approval > max_layer:
            raise serializers.ValidationError({"layer_of_approval": f"Layer of approval cannot be greater than {max_layer}"})
        
        # if ApprovalChangeByNumberOfDays.objects.filter(
        #         from_days = validated_data['from_days'],
        #         to_days = validated_data['to_days'],
        #         company_detail_id=validated_data['company_detail_id']).exists():
        #     raise serializers.ValidationError(
        #             {'days': 'An entry with the same days and layer of approval already exists.'}
        #         )
        return ApprovalChangeByNumberOfDays.objects.create(**validated_data)
        
 

    def update(self, instance, validated_data):
        from_days = validated_data.get('from_days')
        to_days = validated_data.get('to_days')
        layer_of_approval = validated_data.get('layer_of_approval')
        company_detail_id = validated_data.get('company_detail_id')
        sub_company_id = validated_data.get('sub_company_id')

        if from_days == to_days or from_days > to_days:
            raise serializers.ValidationError({"to_days": "to_days cannot be the same as from_days or less than from_days."})

        existing_entrys = ApprovalChangeByNumberOfDays.objects.filter(
            company_detail_id=company_detail_id,sub_company_id=sub_company_id
        ).exclude(pk=getattr(self.instance, 'pk', None))

        for existing_entry in existing_entrys:
            if existing_entry:
                existing_from_days = existing_entry.from_days
                existing_to_days = existing_entry.to_days

                # if (to_days - from_days) == (existing_to_days - existing_from_days):
                #     raise serializers.ValidationError(
                #         {"from_days": "The range between from days and to days already exist."}
                #     )
                
                if (from_days >= existing_from_days and from_days <= existing_to_days) or (to_days >= existing_from_days and to_days <= existing_to_days):
                    raise serializers.ValidationError(
                        {"from_days": "New entry overlaps with an existing range."}
                    )

        approval_max_layers = ApprovalLayer.objects.filter(company_detail_id=validated_data['company_detail_id'],sub_company_id=sub_company_id).values_list('max_layer_of_approval', flat=True)
        max_layer = max(approval_max_layers)
        if layer_of_approval > max_layer:
            raise serializers.ValidationError({"layer_of_approval": f"Layer of approval cannot be greater than {max_layer}"})
       
        # if ApprovalChangeByNumberOfDays.objects.filter(
        #        from_days = validated_data['from_days'],
        #         to_days = validated_data['to_days'],
        #         company_detail_id=validated_data['company_detail_id']).exclude(pk=getattr(self.instance, 'pk', None)).exists():
        #     raise serializers.ValidationError(
        #             {'days': 'An entry with the same days and layer of approval already exists.'}
        #         )
        
        return super().update(instance, validated_data)

    # def delete(self, instance):
    #     try:
    #         instance.delete()
    #     except  Exception as e:
    #         raise serializers.ValidationError(
    #             {'submit': 'Cannot delete. This object is referenced by other objects.'})

        

class ApproveStepByRoleSerializer(serializers.ModelSerializer):
    approval_change_by_number_of_days  = ApprovalChangeByNumberOfDaysSerializer(read_only=True)
    company = serializers.CharField(source='company_detail_id.company_name', read_only=True)
    sub_company = serializers.CharField(source='sub_company_id.sub_company_name', read_only=True)
    role = serializers.CharField(source='role_id.role_name', read_only=True)
    #approval_change_by_number_of_days = serializers.IntegerField(source='approval_change_by_number_of_days_id.days', read_only=True)

    class Meta:
        model = ApproveStepByRole
        fields = '__all__'

    def create(self, validated_data):
        layer_step = validated_data.get('layer_step')
        role_id = validated_data.get('role_id')
        company_detail_id = validated_data.get('company_detail_id')
        approval_change_by_number_of_days_id = validated_data.get('approval_change_by_number_of_days_id')
        sub_company_id = validated_data.get('sub_company_id')

        # Check if accessory_approval is already True for the given approval_change_by_number_of_days_id and company_detail_id
        existing_approve_steps = ApproveStepByRole.objects.filter(
        Q(accessory_approval=True) &
        Q( approval_change_by_number_of_days_id=approval_change_by_number_of_days_id) &
        Q(Q(company_detail_id=company_detail_id) | Q(sub_company_id=sub_company_id))).first()

        #print(existing_approve_steps)
        # if existing_approve_steps is not None:
        #     # for step in existing_approve_steps:
        #     #     if step.accessory_approval == validated_data['accessory_approval']:
        #     #         return  serializers.ValidationError({"accessory_approval": "Accessory approval is already True for this approval change."})
        #     if existing_approve_steps.accessory_approval == validated_data['accessory_approval']:
        #         raise serializers.ValidationError({"accessory_approval": "Accessory approval is already True for this approval change."})

        # Check if layer_step is greater than layer_of_approval 
        approval_change_instance = ApprovalChangeByNumberOfDays.objects.get(id = approval_change_by_number_of_days_id.id)

        layer_approval = approval_change_instance.layer_of_approval
        if layer_step > layer_approval:
            raise serializers.ValidationError({"layer_step": "Layer step cannot be greater than layer of approval."})

        # Check if a role with the same role_id already exists for the same company_detail_id
        existing_role = ApproveStepByRole.objects.filter(
            approval_change_by_number_of_days_id =approval_change_by_number_of_days_id,
            role_id=role_id,
            company_detail_id=company_detail_id, sub_company_id=sub_company_id
        )
        if existing_role.exists():
            raise serializers.ValidationError({"role_id": "Role with the same role_id already exists for this Approve step."})

        # Check if the number of rows is not greater than layer_of_approval
        num_rows = ApproveStepByRole.objects.filter(approval_change_by_number_of_days_id = approval_change_by_number_of_days_id,company_detail_id=company_detail_id,sub_company_id=sub_company_id).count()
        if num_rows > layer_approval:
            raise serializers.ValidationError({"layer_step": "Number of rows cannot be greater than layer of approval."})
        
        if ApproveStepByRole.objects.filter(layer_step=layer_step, approval_change_by_number_of_days_id = approval_change_by_number_of_days_id,
                                            company_detail_id=company_detail_id, sub_company_id=sub_company_id).exists():
           raise serializers.ValidationError({"layer_step": "Layer step must be unique."})

        #return ApproveStepByRole.objects.create(**validated_data)
        return super().create(validated_data)

    def update(self, instance, validated_data):
        layer_step = validated_data.get('layer_step')
        role_id = validated_data.get('role_id')
        company_detail_id = validated_data.get('company_detail_id')
        approval_change_by_number_of_days_id = validated_data.get('approval_change_by_number_of_days_id')
        sub_company_id = validated_data.get('sub_company_id')

        # Check if accessory_approval is already True for the given approval_change_by_number_of_days_id and company_detail_id
        existing_approve_steps = ApproveStepByRole.objects.filter(
        Q(accessory_approval=True) &
        Q( approval_change_by_number_of_days_id=approval_change_by_number_of_days_id) &
        Q(Q(company_detail_id=company_detail_id) | Q(sub_company_id=sub_company_id))).exclude(pk=getattr(self.instance, 'pk', None)).first()


        if existing_approve_steps is not None:
            # for step in existing_approve_steps:
            #     if step.accessory_approval == validated_data['accessory_approval']:
            #         raise serializers.ValidationError({"accessory_approval": "Accessory approval is already True for this approval change."})
            if existing_approve_steps.accessory_approval == validated_data['accessory_approval']:
                raise serializers.ValidationError({"accessory_approval": "Accessory approval is already True for this approval change."})

        # Check if layer_step is greater than layer_of_approval for the given company_detail_id
        approval_change_instance = ApprovalChangeByNumberOfDays.objects.get(id = approval_change_by_number_of_days_id.id)
        layer_approval = approval_change_instance.layer_of_approval
        if layer_step > layer_approval:
            raise serializers.ValidationError({"layer_step": "Layer step cannot be greater than layer of approval."})

        # Check if a role with the same role_id already exists for the same company_detail_id
        existing_role = ApproveStepByRole.objects.filter(
            approval_change_by_number_of_days_id =approval_change_by_number_of_days_id,
            role_id=role_id,
            company_detail_id=company_detail_id, sub_company_id=sub_company_id
        ).exclude(pk=getattr(self.instance, 'pk', None))
        if existing_role.exists():
            raise serializers.ValidationError({"role_id": "Role with the same role_id already exists for this Approve step."})

        if ApproveStepByRole.objects.filter(layer_step=layer_step, approval_change_by_number_of_days_id = approval_change_by_number_of_days_id,
                                            company_detail_id=company_detail_id, sub_company_id=sub_company_id).exclude(pk=getattr(self.instance, 'pk', None)).exists():
           raise serializers.ValidationError({"layer_step": "Layer step must be unique."})

        
        return super().update(instance, validated_data)


    def delete(self, instance):
        try:
            instance.delete()
        except  Exception as e:
            raise serializers.ValidationError(
                {'submit': 'Cannot delete. This object is referenced by other objects.'})



class ApprovalTypeSerializer(serializers.ModelSerializer):
    company = serializers.CharField(source='company_detail_id.company_name', read_only=True)
    role = serializers.CharField(source='role_id.role_name', read_only=True)

    class Meta:
        model = ApprovalType
        fields = '__all__'

    def create(self, validated_data):
        approval_name = validated_data.get('approval_name', '').strip()

        if approval_name:
            # Capitalize the first letter of approval_name
            validated_data['approval_name'] = approval_name.capitalize()
        if ApprovalType.objects.filter(approval_name=validated_data['approval_name'],company_detail_id=validated_data['company_detail_id']).exists():
            raise serializers.ValidationError(
                    {'approval_name': 'An entry with the same approval name already exists.'}
                )

        return ApprovalType.objects.create(**validated_data)

    def update(self, instance, validated_data):
        approval_name = validated_data.get('approval_name', '').strip()

        if approval_name:
            # Capitalize the first letter of approval_name
            validated_data['approval_name'] = approval_name.capitalize()

        # Check if the approval_name is one of the restricted values
        restricted_approval_names = ["Approve", "Hold", "Unhold", "Reject"]
        if instance.approval_name in restricted_approval_names:
            raise serializers.ValidationError({'approval_name': f'Editing {instance.approval_name} is not allowed.'})

        if ApprovalType.objects.filter(approval_name=validated_data['approval_name'],
                                       company_detail_id=validated_data['company_detail_id']).exclude(pk=getattr(self.instance, 'pk', None)).exists():
            raise serializers.ValidationError(
                    {'approval_name': 'An entry with the same approval name already exists.'}
                )

        return super().update(instance, validated_data)

    def delete(self, instance): 
        try:
            instance.delete()
        except  Exception as e:
            raise serializers.ValidationError(
                {'submit': 'Cannot delete. This object is referenced by other objects.'})
        
        
                


class PassExtensionChangeApprovalRoleSerializer(serializers.ModelSerializer):
    company = serializers.CharField(source='company_detail_id.company_name', read_only=True)

    class Meta:
        model = PassExtensionChangeApprovalRole
        fields = '__all__'

    def delete(self, instance):
        try:
            instance.delete()
        except  Exception as e:
            raise serializers.ValidationError(
                {'submit': 'Cannot delete. This object is referenced by other objects.'})
        


class UserLoginSerializer(serializers.ModelSerializer):
    email = serializers.EmailField(max_length=255)

    class Meta:
        model = User
        fields = ['email', 'password']

    def delete(self, instance):
        try:
            instance.delete()
        except  Exception as e:
            raise serializers.ValidationError(
                {'submit': 'Cannot delete. This object is referenced by other objects.'})


        
class SubCompanyMenuActionMapSerializer(serializers.ModelSerializer):
    action = serializers.CharField(source='action_id.action_name', read_only=True)

    class Meta:
        model = SubCompanyMenuActionMap
        fields = '__all__'

    def delete(self, instance):
        try:
            instance.delete()
        except  Exception as e:
            raise serializers.ValidationError(
                {'submit': 'Cannot delete. This object is referenced by other objects.'})


class SubCompanyListSerializer(serializers.ModelSerializer):

    class Meta:
        model = SubCompany
        # fields = '__all__'
        fields = ["id", "sub_company_name"]



class UserListSerializer(serializers.ModelSerializer):

    class Meta:
        model = User
        # fields = '__all__'
        fields = ["id", "user_type"]


class DefaultAccessoryProvidedByCompanyListSerializer(serializers.ModelSerializer):

    class Meta:
        model = DefaultAccessoryProvidedByCompany
        # fields = '__all__'
        fields = ["id", "accessory_name"]


class FineCollectedByListSerializer(serializers.ModelSerializer):
    role = serializers.CharField(source='role_id.role_name', read_only=True)

    class Meta:
        model = FineCollectedBy
        # fields = '__all__'
        fields = ["id", "role"]
        
class ApprovalChangeByNumberOfDaysListSerializer(serializers.ModelSerializer):
    class Meta:
        model = ApprovalChangeByNumberOfDays
        fields = ["id","days"]

class OTPSerializer(serializers.ModelSerializer):
    class Meta:
        model = OTP
        fields = '__all__'


class BusinessPlanHistorySerializer(serializers.ModelSerializer):
  # business_pricing_tiers = BusinessPricingTierSerializer(source='businesspricingtier_set', many=True)
    #plan_features_pricing_categories = serializers.SerializerMethodField()
    class Meta:
        model = BusinessPlanHistory
        # fields = ['id','uuid','plan_name','price','price_after_discount','price_after_tax','days_price','currency','currency_type','currency_symbol','country_category','country_type','plan_id','plan_days_id','plan_days','discount_in_percentage','discount_in_currency','buy_datetime','plan_end_datetime','minutes_to_expire','active_plan','plan_type']
        fields = ['id','uuid','plan_name','price','price_after_discount','price_after_tax','days_price','days_price_after_discount','days_price_after_tax','currency_id','currency_type','currency_symbol','country_category_id','country_type','plan_id','plan_days_and_discount_id','plan_days','discount_in_percentage','discount_in_currency','total_discount','total_tax_in_percentage','total_tax_in_currency','buy_datetime','plan_start_datetime','plan_expire_datetime','minutes_to_expire','days_to_expire','plan_validity','current_active','plan_status','plan_type','company_detail_id','upgrade_plan_id']
        #fields = '__all__'
class BusinessPricingTierSerializer(serializers.ModelSerializer):
    class Meta:
        model = BusinessPricingTier
        fields=['id','uuid','backup_days_id','backup_days','quantity','price','days_price','currency_id','default_product_id','default_product_feature_id','plan_feature_pricing_category_id','category_name','plan_id','business_plan_history_id','plan_feature_pricing_tier_id','company_detail_id','plan_pricing_description']

class BusinessPlanPricingTaxSerializer(serializers.ModelSerializer):
    class Meta:
        model = BusinessPlanPricingTax
        fields = ['id','uuid','business_plan_history_id','tax_percentage_detail_id','tax_type','tax_percentage','tax_amount','company_detail_id']