import django
import logging
django.setup()

from account.models import *
from celery import shared_task
from django.utils import timezone
from django.contrib.auth import get_user_model
import requests
from django.core.mail import send_mail as django_send_mail
from django.template.loader import render_to_string
from django.utils.html import strip_tags
from datetime import timedelta
from django.utils import timezone
from django.core.mail import send_mail

@shared_task
def notify_expired_plans():
    now = timezone.now()

    for schedule in Schedule.objects.all():
        #days_threshold = schedule.days
        #expiration_date = now - timezone.timedelta(days=days_threshold)
        reminder_days = schedule.days  
        reminder_date = now + timezone.timedelta(days=reminder_days)
        
       
        plans_to_remind = BusinessPlanHistory.objects.filter(
            plan_expire_datetime__lte=reminder_date,
            plan_expire_datetime__gt=now
        )
        
        for plan in plans_to_remind:
            company_detail = plan.company_detail_id
            user = User.objects.filter(company_detail_id=company_detail).first()
            
            if user:
                user_email = user.email
                plan_name = plan.plan_name
                plan_expire_date = plan.plan_expire_datetime.strftime('%Y-%m-%d')
                send_mail(
                    'Plan Expiry Reminder',
                    f'Dear User,\n\nYour plan "{plan_name}" is set to expire on {plan_expire_date}. Please take necessary action.\n\nThank you!',
                    'anprsolutionsllp@gmail.com',
                    [user_email],
                    fail_silently=False,
                )
                print(f'Sent reminder email for plan {plan.uuid} to {user_email}')

@shared_task
def delete_unpaid_business_plans():
    now = timezone.now()
    time_threshold = now - timezone.timedelta(minutes=5)
    #cutoff_time = now - timedelta(hours=5, minutes=35)
    # logger.debug(f"Current server time (UTC): {now}")
    # logger.debug(f"Cutoff time for unpaid plans (server time): {time_threshold}")
    # logger.info('Starting to delete unpaid business plans older than 5 minutes.')
    unpaid_business_plans = BusinessPlanHistory.objects.filter(
        plan_type='Buy Plan', 
        payment_status=False, 
        buy_datetime__lt=time_threshold
    #     businessplanhistory__payment_status=False, 
    #     businessplanhistory__buy_datetime__lt=time_threshold
     )
    
    
    # logger.debug(f'Found {unpaid_business_plans.count()} unpaid business plans to delete.')
    for business_plan in unpaid_business_plans:
        business_detail_id = business_plan.company_detail_id
        # logger.debug(f'Deleting data for business_detail_id: {business_detail_id}')
       
        BusinessPlanHistory.objects.filter(company_detail_id=business_detail_id).delete()
        # logger.debug(f'Deleted BusinessPlanHistory for business_detail_id: {business_detail_id}')

        UserRoleMapping.objects.filter(company_detail_id=business_detail_id).delete()
        # logger.debug(f'Deleted UserRoleMapping for business_detail_id: {business_detail_id}')

        User.objects.filter(company_detail_id=business_detail_id).delete()
        # logger.debug(f'Deleted User for business_detail_id: {business_detail_id}')
        
        roles = Roles.objects.filter(company_detail_id=business_detail_id)
        for role in roles:
            AddUserEmail.objects.filter(role=role).delete()
            # logger.debug(f'Deleted AddUserEmail for role: {role.id}')
            Permission.objects.filter(role=role).delete()
            # logger.debug(f'Deleted Permission for role: {role.id}')
            role.delete()
            # logger.debug(f'Deleted Role for business_detail_id: {business_detail_id}')

        
        business_plan.delete()
        # logger.debug(f'Deleted business plan with id: {business_plan.id}') 
    # logger.info('Unpaid business plans older than 5 minutes have been deleted successfully.')
    return 'Unpaid business plans older than 5 minutes have been deleted successfully.'