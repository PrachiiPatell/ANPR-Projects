from rest_framework.permissions import BasePermission


class IsAdmin(BasePermission):
    def has_permission(self, request, view):
        user_type = request.user.user_type
        return user_type == 'Admin'


class IsEmployee(BasePermission):
    def has_permission(self, request, view):
        user_type = request.user.user_type
        return user_type == 'Employee'


class IsVisitor(BasePermission):
    def has_permission(self, request, view):
        user_type = request.user.user_type
        return user_type == 'Visitor'
