from datetime import datetime, timedelta
from .models import User, CompanyDetail, UserRoleMapping, Roles, Permission


def getUserData(user_id):
    user_detail = User.objects.filter(id=user_id).values('id', 'email', 'company_detail_id').first()
    print("user_detail", user_detail)
    company_details = CompanyDetail.objects.filter(id=user_detail['company_detail_id']).values('id',
                                                                                               'company_name',
                                                                                               'country',
                                                                                               'start_date_time',
                                                                                               'end_date_time',
                                                                                               'account_validity').first()

    user_role_maps = UserRoleMapping.objects.filter(user_id=user_detail['id']).values('id', 'role_id').first()
    print("end_date_time", company_details['end_date_time'])
    # '%Y-%m-%d %H:%M:%S+00:00'
    # '%Y-%m-%d %H:%M:%S.%f'
    # '%Y-%m-%d %H:%M:%S.%f+00:00' addcompany
    # '%Y-%m-%d %H:%M:%S+00:00' for login
    diff = None
    try:
        diff = datetime.strptime(str(company_details['end_date_time']), '%Y-%m-%d %H:%M:%S.%f+00:00') - datetime.strptime(
            str(datetime.now()), '%Y-%m-%d %H:%M:%S.%f')
    except:
        diff = datetime.strptime(str(company_details['end_date_time']), '%Y-%m-%d %H:%M:%S+00:00') - datetime.strptime(
            str(datetime.now()), '%Y-%m-%d %H:%M:%S.%f')
         
    if diff.days > 0 and int(diff.total_seconds() / 60.0) > 0:
        if company_details['account_validity'] != True:
            CompanyDetail.objects.filter(id=user_detail['company_detail_id']).update(account_validity=True,
                                                                                     days_to_expire=diff.days)
        else:
            CompanyDetail.objects.filter(id=user_detail['company_detail_id']).update(account_validity=True,
                                                                                     days_to_expire=diff.days)
    else:
        CompanyDetail.objects.filter(id=user_detail['company_detail_id']).update(account_validity=False,
                                                                                 days_to_expire=diff.days)
    company_details = CompanyDetail.objects.filter(id=user_detail['company_detail_id']).values('id', 'company_name',
                                                                                               'country',
                                                                                               'start_date_time',
                                                                                               'end_date_time',
                                                                                               'days_to_expire',
                                                                                               ).first()

    role_detail = Roles.objects.filter(id=user_role_maps['role_id']).values('id', 'role_name').last()

    get_menu_data = Permission.objects.filter(role_id=user_role_maps['role_id']).values('id', 'menu_page_id',
                                                                                        'menu_page_id__menu_name').distinct(
        'menu_page_id')

    permissions = {}
    for get_menu in get_menu_data:
        get_action = Permission.objects.filter(role_id=user_role_maps['role_id'],
                                               menu_page_id=get_menu['menu_page_id']).values(
            'id', 'menu_page_id', 'action_id', 'action_id__action_name').distinct('action_id')
        permissions[get_menu['menu_page_id__menu_name']] = []
        print("get_action: ", get_action)
        print("permissions:", permissions, type(permissions))
        for get_action1 in get_action:
            permissions[get_menu['menu_page_id__menu_name']].append(get_action1.get('action_id__action_name'))
    data = {'user_detail': user_detail, 'company_detail': company_details, 'role_detail': role_detail,
            'permission': permissions}
    return data
