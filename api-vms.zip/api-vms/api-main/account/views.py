from django.shortcuts import render
from rest_framework import status
from rest_framework.response import Response
from django.http import Http404
from datetime import datetime, timedelta, timezone
from django.contrib.auth import authenticate, login, logout
from rest_framework.exceptions import PermissionDenied


# view
from rest_framework.views import APIView
from rest_framework.pagination import LimitOffsetPagination
from rest_framework.permissions import AllowAny, IsAuthenticated


# import model
from .models import *
from .models import DefaultAccessoryProvidedByCompany, Accessory

from .models import ApprovalType, ApprovalLayer, PassExtensionChangeApprovalRole, ApproveStepByRole
from .models import AddUserEmail

# import serializers
from .serializers import CurrencySerializer, CompanyDetailSerializer, SubCompanySerializer, UserSerializer, \
    RolesSerializer, UserRoleMappingSerializer, UserTypeSerializer, MenuPageSerializer, ActionSerializer, \
    MenuActionMapSerializer, PermissionSerializer
from .serializers import DefaultAccessoryProvidedByCompanySerializer, AccessorySerializer
from .serializers import ApprovalTypeSerializer, ApprovalLayerSerializer, \
    PassExtensionChangeApprovalRoleSerializer, ApproveStepByRoleSerializer
from .serializers import AddUserEmailSerializer, UserLoginSerializer, CompanyDetailListSerializer
from .serializers import *

from .connectDatabase import get_data
from .getUserDataLogin import getUserDataLogin

# Authentications
from rest_framework import authentication, permissions
#from rest_framework_jwt.authentication import JSONWebTokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework_simplejwt.views import TokenVerifyView, TokenRefreshView
from rest_framework_simplejwt.authentication import JWTAuthentication


# configurations
from .models import FineCollectedBy, ApprovalLayer, ApprovalChangeByNumberOfDays, ApproveStepByRole, ApprovalType, MenuActionMapVisitor

from .serializers import FineCollectedBySerializer, ApprovalLayerSerializer, ApprovalChangeByNumberOfDaysSerializer, \
    ApproveStepByRoleSerializer, ApprovalTypeSerializer
from datetime import datetime

from .models import SubCompanyMenuActionMap
from .serializers import SubCompanyMenuActionMapSerializer
from rest_framework.permissions import IsAuthenticated
from rest_framework_simplejwt.views import TokenVerifyView, TokenRefreshView
from rest_framework_simplejwt.authentication import JWTAuthentication
from .serializers import RolesListSerializer
from .permissions import IsEmployee, IsVisitor, IsAdmin

from .utils import *

from visitorapp.models import  VisitorRestriction, MobileType, IdProofType, DefaultVisitorHaveAccessory

from visitorapp.serializers import VisitorRestrictionSerializer, MobileTypeSerializer, IdProofTypeSerializer, DefaultVisitorHaveAccessorySerializer
from employeeapp.serializers import *

import random
from django.core.mail import send_mail
from django.template.loader import render_to_string
from django.http.response import JsonResponse,Http404
from django.db import transaction
import json

import logging
logger = logging.getLogger(__name__)


# Create your views here.

class AddCompany(APIView):
    # authentication_classes = (TokenAuthentication,)
    permission_classes = (AllowAny,)

    def post(self, request, format=None):

        currency_detail = {'currency_type': request.data['currency_type'],
                           'currency_symbol': request.data['currency_symbol']}
        currency_serializer = CurrencySerializer(data=currency_detail)
        currency_id = None
        if currency_serializer.is_valid():
            obj = currency_serializer.save()
            currency_id = obj.id
        else:
            return Response(currency_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        # ComponyDetail
        company_detail = {'company_name': request.data['company_name'],
                          'country': request.data['country'],
                          'uses_type': 'free trail',
                          "company_type": request.data['company_type'],
                          'start_date_time': datetime.now(), 
                          'end_date_time': datetime.now() + timedelta(days=15),
                          'days_to_expire': 15, 
                          'account_validity': True,
                          "accessory_provide": True,
                          'currency': currency_id}
        company_serializer = CompanyDetailSerializer(data=company_detail)
        company_detail_id = None
        if company_serializer.is_valid():
            obj = company_serializer.save()
            company_detail_id = obj.id
        else:
            return Response(company_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        # Employee Roles
        role_detail = {'role_name': 'Admin', 'company_detail_id': company_detail_id}
        role_serializer = RolesSerializer(data=role_detail, context={'company_detail_id': company_detail_id})
        role_id = None
        if role_serializer.is_valid():
            obj = role_serializer.save()
            role_id = obj.id
        else:
            CompanyDetail.objects.filter(id=company_detail_id).delete()
            return Response(role_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        
        # AddUserEmail
        add_user_email_serializer = AddUserEmailSerializer(data={'email': request.data['email'], 'role_id': role_id, 'company_detail_id': company_detail_id})
        add_user_email_id = None
        if add_user_email_serializer.is_valid():
            obj = add_user_email_serializer.save()
            add_user_email_id = obj.id
        else:
            Roles.objects.filter(id=role_id).delete()
            CompanyDetail.objects.filter(id=company_detail_id).delete()
            
            print(add_user_email_serializer)
            return Response(add_user_email_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        # Employee Permission
        #
        permission_id = []
        get_menu_data = MenuPage.objects.exclude(is_menu_type_id__is_menu_visible='SuperAdmin').all().values('id',
                                                                                                             'menu_name')
        print("get_menu_data", get_menu_data)
        # for perm in range(len(PermissionDetail)):
        for menus in get_menu_data:
            get_menu_action_data = MenuActionMap.objects.filter(menu_page_id=menus['id'], role_type = 'Admin').values('id', 'menu_page_id',
                                                                                                 'action_id').all()
            for menu_action in get_menu_action_data:
                print("menu_action", menu_action)
                permission_serializer = PermissionSerializer(
                    data={'role_id': role_id, 'menu_page_id': menu_action['menu_page_id'],
                          'action_id': menu_action['action_id']})
                if permission_serializer.is_valid():
                    obj = permission_serializer.save()
                    permission_id.append(obj.id)
                else:
                    print(permission_serializer.errors)
                    AddUserEmail.objects.filter(id=add_user_email_id).delete()
                    Roles.objects.filter(id=role_id).delete()
                    CompanyDetail.objects.filter(id=company_detail_id).delete()
                    
                    
                    for perm_id in permission_id:
                        Permission.objects.filter(id=perm_id).delete()
                    return Response(permission_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        # Visitor
        role_detail = {'role_name': 'Visitor', 'company_detail_id': company_detail_id}
        role_serializer = RolesSerializer(data=role_detail, context={'company_detail_id': company_detail_id})
        role_id1 = None
        if role_serializer.is_valid():
            obj = role_serializer.save()
            role_id1 = obj.id
        else:
            CompanyDetail.objects.filter(id=company_detail_id).delete()
            return Response(role_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        # add_user_email_serializer = AddUserEmailSerializer(
        #     data={'email': request.data['email'], 'role_id': role_id, 'company_detail_id': company_detail_id})

        # # AddUserEmail
        # add_user_emailid = None
        # if add_user_email_serializer.is_valid():
        #     obj = add_user_email_serializer.save()
        #     add_user_emailid = obj.id
        # else:
        #     CompanyDetail.objects.filter(id=company_detail_id).delete()
        #     Roles.objects.filter(id=role_id).delete()
        #     return Response(add_user_email_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        # Visitor Permission

        permission_id = []
        get_menu_data = MenuPage.objects.exclude(is_menu_type_id__is_menu_visible='SuperAdmin').all().values('id',
                                                                                                             'menu_name')
        print("get_menu_data", get_menu_data)
        # for perm in range(len(PermissionDetail)):
        for menus in get_menu_data:
            get_menu_action_data = MenuActionMap.objects.filter(menu_page_id=menus['id'], role_type = 'Visitor').values('id',
                                                                                                        'menu_page_id',
                                                                                                        'action_id').all()
            for menu_action in get_menu_action_data:
                print("menu_action", menu_action)
                permission_serializer = PermissionSerializer(
                    data={'role_id': role_id1, 'menu_page_id': menu_action['menu_page_id'],
                          'action_id': menu_action['action_id']})
                if permission_serializer.is_valid():
                    obj = permission_serializer.save()
                    permission_id.append(obj.id)
                else:
                    for perm_id in permission_id:
                        Permission.objects.filter(id=perm_id).delete()
                    AddUserEmail.objects.filter(id=add_user_email_id).delete()
                    Roles.objects.filter(id=role_id).delete()
                    CompanyDetail.objects.filter(id=company_detail_id).delete()
                    # AddUserEmail.objects.filter(id=add_user_emailid).delete()
                    
                    return Response(permission_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                
        # MobileType
        mobile_types = request.data.get('mobile', [])
        for mobile_type in mobile_types:
            mobile_type['company_detail_id'] = company_detail_id
            mobile_type_serializer = MobileTypeSerializer(data=mobile_type)
            if mobile_type_serializer.is_valid():
                mobile_type_serializer.save()
            else:
                for perm_id in permission_id:
                        Permission.objects.filter(id=perm_id).delete()
                AddUserEmail.objects.filter(id=add_user_email_id).delete()
                Roles.objects.filter(id=role_id).delete()
                CompanyDetail.objects.filter(id=company_detail_id).delete()
                return Response(mobile_type_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        # DefaultVisitorAccessoryHave
        default_accessories = request.data.get('accessory_name', [])
        for default_accessory in default_accessories:
            default_accessory['company_detail_id'] = company_detail_id
            default_accessory_serializer = DefaultVisitorHaveAccessorySerializer(data=default_accessory)
            if default_accessory_serializer.is_valid():
                default_accessory_serializer.save()
            else:
                MobileType.objects.filter(company_detail_id=company_detail_id).delete()
                for perm_id in permission_id:
                        Permission.objects.filter(id=perm_id).delete()
                AddUserEmail.objects.filter(id=add_user_email_id).delete()
                Roles.objects.filter(id=role_id).delete()
                CompanyDetail.objects.filter(id=company_detail_id).delete()
               
                return Response(default_accessory_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        # IdProofType
        id_proofs = request.data.get('id_proof', [])
        for id_proof in id_proofs:
            id_proof['company_detail_id'] = company_detail_id
            id_proof_serializer = IdProofTypeSerializer(data=id_proof)
            if id_proof_serializer.is_valid():
                id_proof_serializer.save()
            else:
                DefaultVisitorHaveAccessory.objects.filter(company_detail_id=company_detail_id).delete()
                MobileType.objects.filter(company_detail_id=company_detail_id).delete()
                for perm_id in permission_id:
                        Permission.objects.filter(id=perm_id).delete()
                AddUserEmail.objects.filter(id=add_user_email_id).delete()
                Roles.objects.filter(id=role_id).delete()
                CompanyDetail.objects.filter(id=company_detail_id).delete()
                
                return Response(id_proof_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        #FineCollectedBy
        fine_collected = {'role_id': role_id, 'company_detail_id': company_detail_id}
        fine_collected_serializer = FineCollectedBySerializer(data=fine_collected)
        fine_collected_id = None
        if fine_collected_serializer.is_valid():
            obj = fine_collected_serializer.save()
            fine_collected_id = obj.id
        else:
            print(fine_collected_serializer.errors)
            IdProofType.objects.filter(company_detail_id=company_detail_id).delete()
            DefaultVisitorHaveAccessory.objects.filter(company_detail_id=company_detail_id).delete()
            MobileType.objects.filter(company_detail_id=company_detail_id).delete()
            for perm_id in permission_id:
                    Permission.objects.filter(id=perm_id).delete()
            AddUserEmail.objects.filter(id=add_user_email_id).delete()
            Roles.objects.filter(id=role_id).delete()
            CompanyDetail.objects.filter(id=company_detail_id).delete()
            
            return Response(fine_collected_serializer.errors, status=status.HTTP_400_BAD_REQUEST)


        #ApprovalLayer
        approval_layer = {'max_layer_of_approval': request.data['max_layer_of_approval'], 'company_detail_id': company_detail_id, 'all_layer_required':True,
                          'approval_layer_change_by_days':request.data['approval_layer_change_by_days']}
        approval_layer_serializer = ApprovalLayerSerializer(data=approval_layer)
        approval_layer_id = None
        if approval_layer_serializer.is_valid():
            obj = approval_layer_serializer.save()
            approval_layer_id = obj.id
        else:
            FineCollectedBy.objects.filter(company_detail_id=company_detail_id).delete()
            IdProofType.objects.filter(company_detail_id=company_detail_id).delete()
            DefaultVisitorHaveAccessory.objects.filter(company_detail_id=company_detail_id).delete()
            MobileType.objects.filter(company_detail_id=company_detail_id).delete()
            for perm_id in permission_id:
                    Permission.objects.filter(id=perm_id).delete()
            AddUserEmail.objects.filter(id=add_user_email_id).delete()
            Roles.objects.filter(id=role_id).delete()
            CompanyDetail.objects.filter(id=company_detail_id).delete()
            
            return Response(approval_layer_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

         #ApprovalChangeByNumberOfDays
        approval_change = {'from_days': 1, 'to_days': 3, 'layer_of_approval':1,
                          'company_detail_id': company_detail_id}
        approval_change_serializer = ApprovalChangeByNumberOfDaysSerializer(data=approval_change)
        approval_change_id = None
        if approval_change_serializer.is_valid():
            obj = approval_change_serializer.save()
            approval_change_id = obj.id
        else:
            print(approval_change_serializer.errors)
            ApprovalLayer.objects.filter(company_detail_id=company_detail_id).delete()
            FineCollectedBy.objects.filter(company_detail_id=company_detail_id).delete()
            IdProofType.objects.filter(company_detail_id=company_detail_id).delete()
            DefaultVisitorHaveAccessory.objects.filter(company_detail_id=company_detail_id).delete()
            MobileType.objects.filter(company_detail_id=company_detail_id).delete()
            for perm_id in permission_id:
                    Permission.objects.filter(id=perm_id).delete()
            AddUserEmail.objects.filter(id=add_user_email_id).delete()
            Roles.objects.filter(id=role_id).delete()
            CompanyDetail.objects.filter(id=company_detail_id).delete()
            
            return Response(approval_change_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        
        #ApproveStepByRole
        approve_step = {'layer_step':1, 'role_id': role_id,
                          'company_detail_id': company_detail_id, 'approval_change_by_number_of_days_id':approval_change_id, 
                          'accessory_approval':True}
        approve_step_serializer = ApproveStepByRoleSerializer(data=approve_step)
        approve_step_id = None
        if approve_step_serializer.is_valid():
            obj = approve_step_serializer.save()
            approve_step_id = obj.id
        else:
            print(approve_step_serializer.errors)
            ApprovalChangeByNumberOfDays.objects.filter(company_detail_id=company_detail_id).delete()
            ApprovalLayer.objects.filter(company_detail_id=company_detail_id).delete()
            FineCollectedBy.objects.filter(company_detail_id=company_detail_id).delete()
            IdProofType.objects.filter(company_detail_id=company_detail_id).delete()
            DefaultVisitorHaveAccessory.objects.filter(company_detail_id=company_detail_id).delete()
            MobileType.objects.filter(company_detail_id=company_detail_id).delete()
            for perm_id in permission_id:
                    Permission.objects.filter(id=perm_id).delete()
            AddUserEmail.objects.filter(id=add_user_email_id).delete()
            Roles.objects.filter(id=role_id).delete()
            CompanyDetail.objects.filter(id=company_detail_id).delete()
            
            return Response(approve_step_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        
        #VisitorRestriction
        visitor_restriction = {'remove_restriction_after_days': request.data['remove_restriction_after_days'],
                          'company_detail_id': company_detail_id}
        visitor_restriction_serializer = VisitorRestrictionSerializer(data=visitor_restriction)
        visitor_restriction_id = None
        if visitor_restriction_serializer.is_valid():
            obj = visitor_restriction_serializer.save()
            visitor_restriction_id = obj.id
        else:
            ApproveStepByRole.objects.filter(company_detail_id=company_detail_id).delete()
            ApprovalChangeByNumberOfDays.objects.filter(company_detail_id=company_detail_id).delete()
            ApprovalLayer.objects.filter(company_detail_id=company_detail_id).delete()
            FineCollectedBy.objects.filter(company_detail_id=company_detail_id).delete()
            IdProofType.objects.filter(company_detail_id=company_detail_id).delete()
            DefaultVisitorHaveAccessory.objects.filter(company_detail_id=company_detail_id).delete()
            MobileType.objects.filter(company_detail_id=company_detail_id).delete()
            for perm_id in permission_id:
                    Permission.objects.filter(id=perm_id).delete()
            AddUserEmail.objects.filter(id=add_user_email_id).delete()
            Roles.objects.filter(id=role_id).delete()
            CompanyDetail.objects.filter(id=company_detail_id).delete()
            
            return Response(visitor_restriction_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        

        # ApprovalType
        approval_types = request.data.get('approval_name', [])
        for approval_type in approval_types:
            approval_type['company_detail_id'] = company_detail_id
            approval_type_serializer = ApprovalTypeSerializer(data=approval_type)
            if approval_type_serializer.is_valid():
                approval_type_serializer.save()
            else:
                VisitorRestriction.objects.filter(company_detail_id=company_detail_id).delete()
                ApproveStepByRole.objects.filter(company_detail_id=company_detail_id).delete()
                ApprovalChangeByNumberOfDays.objects.filter(company_detail_id=company_detail_id).delete()
                ApprovalLayer.objects.filter(company_detail_id=company_detail_id).delete()
                FineCollectedBy.objects.filter(company_detail_id=company_detail_id).delete()
                IdProofType.objects.filter(company_detail_id=company_detail_id).delete()
                DefaultVisitorHaveAccessory.objects.filter(company_detail_id=company_detail_id).delete()
                MobileType.objects.filter(company_detail_id=company_detail_id).delete()
                for perm_id in permission_id:
                        Permission.objects.filter(id=perm_id).delete()
                AddUserEmail.objects.filter(id=add_user_email_id).delete()
                Roles.objects.filter(id=role_id).delete()
                CompanyDetail.objects.filter(id=company_detail_id).delete()
                
                return Response(approval_type_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        return Response({'Success': 'Company Created Successfully.', "addUser": add_user_email_serializer.data}, status.HTTP_201_CREATED)



def get_user_data_page_plans(user,menu_name,action):
    user_detail = User.objects.filter(id=user).values('id','email','company_detail_id').first()
    
    if user_detail is None:
        # handle the case where the user is not found
        return None
    #business_details = BusinessDetail.objects.filter(id=user_detail['business_detail_id']).values('id','business_name').first()
    # business_details = BusinessDetail.objects.filter(id=user_detail['business_detail_id']).values('id','business_name', 'plan_expire_datetime','plan_validity','timezones').first()
    company_details = CompanyDetail.objects.filter(id=user_detail['company_detail_id']).values('id','start_date_time','end_date_time','days_to_expire','account_validity').first()
    print("company_details",company_details)
    business_plan_history_by_datetime = BusinessPlanHistory.objects.filter(Q(company_detail_id=user_detail['company_detail_id']) & (Q(plan_expire_datetime__gte=datetime.now()) | Q(current_active=True))).all()
   
    business_plan_history_details = None
    if len(business_plan_history_by_datetime) == 1:
        
        # business_plan_history_current_active = business_plan_history_by_datetime.filter(plan_status='active',current_active=True).first()
        business_plan_history_current_active = business_plan_history_by_datetime.filter(current_active=True).first()

        # plan_working = False
        # business_plan_history_details = None
        # if business_plan_history_current_active != None:
        diff = None
        try:
            diff = datetime.strptime(str(business_plan_history_by_datetime[0]['plan_expire_datetime']), '%Y-%m-%d %H:%M:%S.%f+00:00') - datetime.strptime(str(datetime.now()), '%Y-%m-%d %H:%M:%S.%f')
        except Exception as e:
            #diff = datetime.strptime(str(business_plan_history_by_datetime[0].plan_expire_datetime), '%Y-%m-%d %H:%M:%S+00:00') - datetime.strptime(str(datetime.now()), '%Y-%m-%d %H:%M:%S.%f')
            # diff = timezone.datetime.strptime(str(business_plan_history_by_datetime[0].plan_expire_datetime), '%Y-%m-%d %H:%M:%S.%f+00:00') - datetime.strptime(str(datetime.now()), '%Y-%m-%d %H:%M:%S.%f')
            diff = timezone.datetime.strptime(str(business_plan_history_current_active.plan_expire_datetime), '%Y-%m-%d %H:%M:%S+00:00') - datetime.strptime(str(datetime.now()), '%Y-%m-%d %H:%M:%S.%f')

        if int(diff.total_seconds() / 60.0) > 0:
            plan_working = True
            BusinessPlanHistory.objects.filter(id=business_plan_history_by_datetime[0].id).update(plan_validity=True,plan_status='active',current_active=True,days_to_expire=diff.days,minutes_to_expire=int(diff.total_seconds() / 60.0))
            business_plan_history_details = BusinessPlanHistory.objects.filter(id=business_plan_history_by_datetime[0].id).first()
        else:
            plan_working = False
            BusinessPlanHistory.objects.filter(id=business_plan_history_by_datetime[0].id).update(plan_validity=False,plan_status='expire',current_active=True,days_to_expire=diff.days,minutes_to_expire=int(diff.total_seconds() / 60.0))
            business_plan_history_details = BusinessPlanHistory.objects.filter(id=business_plan_history_by_datetime[0].id).first()
    
    elif len(business_plan_history_by_datetime) > 1:
        
        business_plan_history_current_active = business_plan_history_by_datetime.filter(current_active=True).first()
        if business_plan_history_current_active != None:
            diff = None
            try:
                diff = datetime.strptime(str(business_plan_history_current_active.plan_expire_datetime), '%Y-%m-%d %H:%M:%S.%f+00:00') - datetime.strptime(str(datetime.now()), '%Y-%m-%d %H:%M:%S.%f')
            except Exception as e:
                diff = datetime.strptime(str(business_plan_history_current_active.plan_expire_datetime), '%Y-%m-%d %H:%M:%S+00:00') - datetime.strptime(str(datetime.now()), '%Y-%m-%d %H:%M:%S.%f')
            if int(diff.total_seconds() / 60.0) > 0:
                plan_working = True
                BusinessPlanHistory.objects.filter(id=business_plan_history_current_active.id).update(plan_validity=True,plan_status='active',current_active=True,days_to_expire=diff.days,minutes_to_expire=int(diff.total_seconds() / 60.0))
                business_plan_history_details = BusinessPlanHistory.objects.filter(id=business_plan_history_current_active.id).first()
            else:
                plan_working = False
                business_plan_history_current_pending = business_plan_history_by_datetime.filter(plan_status='pending').first()
                if business_plan_history_current_pending != None:
                    try:
                        diff = datetime.strptime(str(business_plan_history_current_pending.plan_expire_datetime), '%Y-%m-%d %H:%M:%S.%f+00:00') - datetime.strptime(str(datetime.now()), '%Y-%m-%d %H:%M:%S.%f')
                    except Exception as e:
                        diff = datetime.strptime(str(business_plan_history_current_pending.plan_expire_datetime), '%Y-%m-%d %H:%M:%S+00:00') - datetime.strptime(str(datetime.now()), '%Y-%m-%d %H:%M:%S.%f')
                    if int(diff.total_seconds() / 60.0) > 0:
                        plan_working = True
                        BusinessPlanHistory.objects.filter(id=business_plan_history_current_pending.id).update(plan_validity=True,plan_status='active',current_active=True,days_to_expire=diff.days,minutes_to_expire=int(diff.total_seconds() / 60.0))
                        business_plan_history_details = BusinessPlanHistory.objects.filter(id=business_plan_history_current_pending.id).first()
                    else:
                        BusinessPlanHistory.objects.filter(id=business_plan_history_current_pending.id).update(plan_validity=False,plan_status='expire',current_active=True,days_to_expire=diff.days,minutes_to_expire=int(diff.total_seconds() / 60.0))
                        business_plan_history_details = BusinessPlanHistory.objects.filter(id=business_plan_history_current_pending.id).first()
                else:
                    BusinessPlanHistory.objects.filter(id=business_plan_history_current_active.id).update(plan_validity=False,plan_status='expire',current_active=True,days_to_expire=diff.days,minutes_to_expire=int(diff.total_seconds() / 60.0))
                    business_plan_history_details = BusinessPlanHistory.objects.filter(id=business_plan_history_current_active.id).first()
    
    business_pricing_tier = BusinessPricingTier.objects.filter(business_plan_history_id=business_plan_history_details.id).all()
    product_detail = business_pricing_tier.filter(category_name='Product').values('id','uuid','quantity','default_product_id','default_product_id__product_name','plan_feature_pricing_category_id','category_name','plan_feature_pricing_tier_id','plan_pricing_description').all()
    plans_pricing_tier = []
    for product_data in product_detail:
        if product_data['default_product_id__product_name'] == 'Visitor management system':
       
            # camera_detail = business_pricing_tier.filter(default_product_id=product_data['default_product_id'],category_name='Camera').values('id','uuid','quantity','default_product_id','plan_feature_pricing_category_id','category_name','plan_feature_pricing_tier_id','plan_pricing_description').first()
            # # default_product_id = camera_detail.get('default_product_id')
            # # print("Default Product ID:", default_product_id)
          
            # print("cd", camera_detail)
            # # parking_slot_detail = business_pricing_tier.filter(default_product_id=product_data['default_product_id'],category_name='Parking Slot').values('id','uuid','quantity','default_product_id','plan_feature_pricing_category_id','category_name','plan_feature_pricing_tier_id','plan_pricing_description').first()
            # online_dashboard_detail = business_pricing_tier.filter(default_product_id=product_data['default_product_id'],category_name='Online Dashboard').values('id','uuid','default_product_id','plan_feature_pricing_category_id','category_name','plan_feature_pricing_tier_id','plan_pricing_description').first()
            # online_data_backup_detail = business_pricing_tier.filter(default_product_id=product_data['default_product_id'],category_name='Online Data Backup').values('id','uuid','backup_days_id','backup_days','default_product_id','plan_feature_pricing_category_id','category_name','plan_feature_pricing_tier_id','plan_pricing_description').first()
            # offline_dashboard_detail = business_pricing_tier.filter(default_product_id=product_data['default_product_id'],category_name='Offline Dashboard').values('id','uuid','default_product_id','plan_feature_pricing_category_id','category_name','plan_feature_pricing_tier_id','plan_pricing_description').first()
            # offline_data_backup_detail = business_pricing_tier.filter(default_product_id=product_data['default_product_id'],category_name='Offline Data Backup').values('id','uuid','backup_days_id','backup_days','default_product_id','plan_feature_pricing_category_id','category_name','plan_feature_pricing_tier_id','plan_pricing_description').first()
            product_feature_detail = business_pricing_tier.filter(default_product_id=product_data['default_product_id'],category_name='Feature').values('id','uuid','default_product_id','default_product_id__product_name','default_product_feature_id','default_product_feature_id__feature','plan_feature_pricing_category_id','category_name','plan_feature_pricing_tier_id','plan_pricing_description').all()
            plans_pricing_tier.append({
                # 'camera_detail':camera_detail,
                # #'parking_slot_detail':parking_slot_detail,
                # 'online_dashboard_detail':online_dashboard_detail,
                # 'online_data_backup_detail':online_data_backup_detail,
                # 'offline_dashboard_detail':offline_dashboard_detail,
                # 'offline_data_backup_detail':offline_data_backup_detail,
                'product_detail':product_data,
                'product_feature_detail':product_feature_detail
            })
    
    
    user_role_maps = UserRoleMapping.objects.filter(user_id=user_detail['id']).values('id','role_id').first()
   # TimeZoneLoc = pytz.timezone(company_details['timezones'])
    # diff = None
    # try:
    #     diff = datetime.strptime(str(business_details['plan_expire_datetime']), '%Y-%m-%d %H:%M:%S.%f+00:00') - datetime.strptime(str(datetime.now()), '%Y-%m-%d %H:%M:%S.%f')
    # except Exception as e:
    #     diff = datetime.strptime(str(business_details['plan_expire_datetime']), '%Y-%m-%d %H:%M:%S+00:00') - datetime.strptime(str(datetime.now()), '%Y-%m-%d %H:%M:%S.%f')
    # if int(diff.total_seconds() / 60.0) > 0:
    #     BusinessDetail.objects.filter(id=user_detail['business_detail_id']).update(plan_validity=True,days_to_expire=diff.days,minutes_to_expire=int(diff.total_seconds() / 60.0))
    # else:
    #     BusinessDetail.objects.filter(id=user_detail['business_detail_id']).update(plan_validity=False,days_to_expire=diff.days,minutes_to_expire=int(diff.total_seconds() / 60.0))
    
    # business_details = BusinessDetail.objects.filter(id=user_detail['business_detail_id']).values('id','business_name','business_type','business_logo','country','uses_type','plan_validity','timezones','currency__currency_symbol').first()  ##'anpr_check_allowed','blacklist_check_allowed','plan_start_datetime','plan_expire_datetime','days_to_expire','minutes_to_expire'
    role_detail = Roles.objects.filter(id=user_role_maps['role_id']).values('id','role_name').last()
    permissions = Permission.objects.filter(
        role_id=user_role_maps['role_id'],
            menu_page_id__menu_name=menu_name,
            action_id__action_name=action
        ).order_by('menu_page_id').distinct('menu_page_id').values(
            'id', 'role_id', 'role_id__role_name', 'menu_page_id', 'menu_page_id__menu_name', 'action_id__action_name'
        ).first()
    data = {'user_detail':user_detail,'company_detail':company_details,'business_plan_history_detail':business_plan_history_details,'plans_detail':plans_pricing_tier,'role_detail':role_detail,'permission':permissions}
    return data

# SubCompany API
class SubCompanyList(APIView):
    permission_classes = (IsAuthenticated,)

    def get_object(self):
        try:
            return SubCompany.objects.all()
        except:
            raise Http404

    ObjectSerializer = SubCompanySerializer
    model_name = "SubCompany"

    def get(self, request, format=None):
        limit = int(request.GET.get('limit',10))
        offset = int(request.GET.get('offset',0))

        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'sub_company' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['sub_company']:
                    acess_to_page = True
            if acess_to_page == True:
                sub_company_queryset = SubCompany.objects.filter(company_detail_id = get_user_data['company_detail']['id']).order_by('-id').all()[offset:limit+offset]
                sub_company_count = SubCompany.objects.filter(company_detail_id = get_user_data['company_detail']['id']).count()
                serializer = self.ObjectSerializer(sub_company_queryset, many=True)
                return Response({'count':sub_company_count, 'results': serializer.data})
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

                

    def post(self, request, format=None):
        # serializer = CompanyDetailSerializer(data=request.data)
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'sub_company' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['sub_company']:
                    acess_to_page = True
            if acess_to_page == True:
                data = request.data
                data['company_detail_id'] = get_user_data['company_detail']['id']
                sub_company_serializer = SubCompanySerializer(data=data, context={'request': request})
                
                sub_company_id = None
                if sub_company_serializer.is_valid():
                    obj = sub_company_serializer.save()
                    sub_company_id = obj.id
                else:
                    return Response(sub_company_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

                # Employee Roles
                role_detail = {'role_name': request.data['sub_company_name'] + "_Admin",'company_detail_id':get_user_data['company_detail']['id'],'sub_company_id': sub_company_id }
                role_serializer = RolesSerializer(data=role_detail)
                role_id = None
                if role_serializer.is_valid():
                    obj = role_serializer.save()
                    role_id = obj.id
                else:
                    SubCompany.objects.filter(id=sub_company_id).delete()
                    return Response(role_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                add_user_email_serializer = AddUserEmailSerializer(
                    data={'email': request.data['company_email'], 'role_id': role_id, 'company_detail_id':get_user_data['company_detail']['id'], 'sub_company_id': sub_company_id})

                # AddUserEmail
                add_user_emailid = None
                if add_user_email_serializer.is_valid():
                    obj = add_user_email_serializer.save()
                    add_user_emailid = obj.id
                else:
                    Roles.objects.filter(id=role_id).delete()
                    SubCompany.objects.filter(id=sub_company_id).delete()
                    return Response(add_user_email_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

                # Employee Permission
                #
                permission_id = []
                get_menu_data = MenuPage.objects.exclude(is_menu_type_id__is_menu_visible='SuperAdmin').all().values('id',
                                                                                                                    'menu_name')
                print("get_menu_data", get_menu_data)
                # for perm in range(len(PermissionDetail)):
                for menus in get_menu_data:
                    get_menu_action_data = MenuActionMap.objects.filter(menu_page_id=menus['id'],role_type = 'Admin').values('id', 'menu_page_id',
                                                                                                        'action_id').all()
                    for menu_action in get_menu_action_data:
                        print("menu_action", menu_action)
                        permission_serializer = PermissionSerializer(
                            data={'role_id': role_id, 'menu_page_id': menu_action['menu_page_id'],
                                'action_id': menu_action['action_id']})
                        if permission_serializer.is_valid():
                            obj = permission_serializer.save()
                            permission_id.append(obj.id)
                        else:
                            SubCompany.objects.filter(id=sub_company_id).delete()
                            Roles.objects.filter(id=role_id).delete()
                            AddUserEmail.objects.filter(id=add_user_emailid).delete()
                            for perm_id in permission_id:
                                Permission.objects.filter(id=perm_id).delete()
                            return Response(permission_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                        

                # Visitor
                role_detail = {'role_name': request.data['sub_company_name'] + "_Visitor",'company_detail_id':get_user_data['company_detail']['id'],'sub_company_id': sub_company_id }
                role_serializer = RolesSerializer(data=role_detail)
                role_id1 = None
                if role_serializer.is_valid():
                    obj = role_serializer.save()
                    role_id1 = obj.id
                else:
                    SubCompany.objects.filter(id=sub_company_id).delete()
                    return Response(role_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                        

                # Visitor Permission

                permission_id = []
                get_menu_data = MenuPage.objects.exclude(is_menu_type_id__is_menu_visible='SuperAdmin').all().values('id',
                                                                                                                    'menu_name')
                print("get_menu_data", get_menu_data)
                # for perm in range(len(PermissionDetail)):
                for menus in get_menu_data:
                    get_menu_action_data = MenuActionMap.objects.filter(menu_page_id=menus['id'], role_type = 'Visitor').values('id',
                                                                                                                'menu_page_id',
                                                                                                                'action_id').all()
                    for menu_action in get_menu_action_data:
                        print("menu_action", menu_action)
                        permission_serializer = PermissionSerializer(
                            data={'role_id': role_id1, 'menu_page_id': menu_action['menu_page_id'],
                                'action_id': menu_action['action_id']})
                        if permission_serializer.is_valid():
                            obj = permission_serializer.save()
                            permission_id.append(obj.id)
                        else:
                            for perm_id in permission_id:
                                Permission.objects.filter(id=perm_id).delete()
                            AddUserEmail.objects.filter(id=add_user_emailid).delete()
                            Roles.objects.filter(id=role_id).delete()
                            SubCompany.objects.filter(id=sub_company_id).delete()
                            
                            return Response(permission_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                
                return Response({"Success": "SubCompany added successfully"}, status=status.HTTP_201_CREATED)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class SubCompanyDetail(APIView):
    permission_classes = (IsAuthenticated,)
   
    def get_object(self, pk):
        try:
            return SubCompany.objects.get(pk=pk)
        except:
            raise Http404

    ObjectSerializer = SubCompanySerializer

    def get(self, request, id=None, format=None):

        
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'sub_company' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['sub_company']:
                    acess_to_page = True
            if acess_to_page == True:
                
                print(r'get details of id: ', id)

                queryset = self.get_object(pk=id)
                # serializer = CompanyDetailSerializer(queryset)
                serializer = self.ObjectSerializer(queryset)
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
                

    def put(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'sub_company' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['sub_company']:
                    acess_to_page = True
            if acess_to_page == True:
                data = request.data
                data['company_detail_id'] = get_user_data['company_detail']['id']
                queryset = self.get_object(pk=id)
                serializer = self.ObjectSerializer(queryset, data=data, context={'request': request})
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_200_OK)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'sub_company' in get_user_data['permission'].keys():
                if 'delete' in get_user_data['permission']['sub_company']:
                    acess_to_page = True
            if acess_to_page == True:
                try:
                    queryset = self.get_object(pk=id)
                    queryset.delete()
                    return Response(status=status.HTTP_204_NO_CONTENT)
                except Exception as e:
                    return Response({"submit": 'Cannot delete. This object is referenced by other objects.'},
                                    status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


# DefaultAccessoryProvidedByCompany API
class DefaultAccessoryProvidedByCompanyList(APIView):
    permission_classes = (IsAuthenticated,)


    def get_object(self):
        try:
            return DefaultAccessoryProvidedByCompany.objects.all()
        except:
            raise Http404

    ObjectSerializer = DefaultAccessoryProvidedByCompanySerializer
    model_name = "DefaultAccessoryProvidedByCompany"

    def get(self, request, format=None):
        limit = int(request.GET.get('limit',10))
        offset = int(request.GET.get('offset',0))

        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'default_accessory_provide' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['default_accessory_provide']:
                    acess_to_page = True
            if acess_to_page == True:
                sub_company_detail_id = None
                if len(get_user_data['sub_company']) > 0:
                    sub_company_detail_id = get_user_data['sub_company']['id']
                accessory_queryset = DefaultAccessoryProvidedByCompany.objects.filter(company_detail_id = get_user_data['company_detail']['id'],sub_company_id = sub_company_detail_id).order_by('-id').all()[offset:limit+offset]
                accessory_count = DefaultAccessoryProvidedByCompany.objects.filter(company_detail_id = get_user_data['company_detail']['id'],sub_company_id = sub_company_detail_id).count()
                serializer = self.ObjectSerializer(accessory_queryset, many=True)
                return Response({'count':accessory_count, 'results': serializer.data})
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def post(self, request, format=None):
        # serializer = CompanyDetailSerializer(data=request.data)
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'default_accessory_provide' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['default_accessory_provide']:
                    acess_to_page = True
            if acess_to_page == True:
                sub_company_detail_id = None
                if len(get_user_data['sub_company']) > 0:
                    sub_company_detail_id = get_user_data['sub_company']['id']
                data = request.data
                data['company_detail_id'] = get_user_data['company_detail']['id']
                data['sub_company_id'] = sub_company_detail_id
                serializer = self.ObjectSerializer(data=data, context={'request': request})
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class DefaultAccessoryProvidedByCompanyDetail(APIView):
    permission_classes = (IsAuthenticated,)

    def get_object(self, pk):
        try:
            return DefaultAccessoryProvidedByCompany.objects.get(pk=pk)
        except:
            raise Http404

    ObjectSerializer = DefaultAccessoryProvidedByCompanySerializer

    def get(self, request, id=None, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'default_accessory_provide' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['default_accessory_provide']:
                    acess_to_page = True
            if acess_to_page == True:

                print(r'get details of id: ', id)
                
                company_detail_id = request.user.company_detail_id
                sub_company_id = request.user.sub_company_id
                #queryset = self.get_object(pk=id)
                queryset = DefaultAccessoryProvidedByCompany.objects.filter(pk=id,
                                                                            company_detail_id=company_detail_id, sub_company_id=sub_company_id).first()
                serializer = self.ObjectSerializer(queryset)
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


    def put(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'default_accessory_provide' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['default_accessory_provide']:
                    acess_to_page = True
            if acess_to_page == True:
                sub_company_detail_id = None
                if len(get_user_data['sub_company']) > 0:
                    sub_company_detail_id = get_user_data['sub_company']['id']
                data = request.data
                data['company_detail_id'] = get_user_data['company_detail']['id']
                data['sub_company_id'] = sub_company_detail_id
                queryset = self.get_object(pk=id)
                serializer = self.ObjectSerializer(queryset, data=data, context={'request': request})
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'default_accessory_provide' in get_user_data['permission'].keys():
                if 'delete' in get_user_data['permission']['default_accessory_provide']:
                    acess_to_page = True
            if acess_to_page == True:
                company_detail_id = request.user.company_detail_id
                sub_company_id = request.user.sub_company_id
                #queryset = self.get_object(pk=id)
                queryset = DefaultAccessoryProvidedByCompany.objects.filter(pk=id,
                                                                            company_detail_id=company_detail_id, sub_company_id=sub_company_id).first()
                try:
                    queryset.delete()
                    return Response(status=status.HTTP_204_NO_CONTENT)
                except Exception as e:
                    return Response({"submit": "Cannot delete. This Accessory is being used for visitor accessory."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)



# Accessory API
class AccessoryList(APIView):
    permission_classes = (IsAuthenticated,)


    def get_object(self):
        try:
            return Accessory.objects.all()
        except:
            raise Http404

    ObjectSerializer = AccessorySerializer
    model_name = "Accessory"

    def get(self, request, format=None):
        limit = int(request.GET.get('limit', 10))
        offset = int(request.GET.get('offset', 0))
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'accessory' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['accessory']:
                    acess_to_page = True
            if acess_to_page == True:
                sub_company_detail_id = None
                if len(get_user_data['sub_company']) > 0:
                    sub_company_detail_id = get_user_data['sub_company']['id']
                accessory_queryset = Accessory.objects.filter(company_detail_id = get_user_data['company_detail']['id'], sub_company_id = sub_company_detail_id).order_by('-id').all()[offset:limit+offset]
                accessory_count = Accessory.objects.filter(company_detail_id = get_user_data['company_detail']['id'], sub_company_id = sub_company_detail_id).all().count()
                serializer = self.ObjectSerializer(accessory_queryset, many=True)
                return Response({'count':accessory_count, 'results': serializer.data})
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)    

    def post(self, request, format=None):
        # serializer = CompanyDetailSerializer(data=request.data)
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'accessory' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['accessory']:
                    acess_to_page = True
            if acess_to_page == True:
                sub_company_detail_id = None
                if len(get_user_data['sub_company']) > 0:
                    sub_company_detail_id = get_user_data['sub_company']['id']
                data = request.data
                data['company_detail_id'] = get_user_data['company_detail']['id']
                data['sub_company_id'] = sub_company_detail_id
                serializer = self.ObjectSerializer(data=data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class AccessoryDetail(APIView):
    permission_classes = (IsAuthenticated,)

    def get_object(self, pk):
        try:
            return Accessory.objects.get(pk=pk)
        except:
            raise Http404

    ObjectSerializer = AccessorySerializer

    def get(self, request, id=None, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'accessory' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['accessory']:
                    acess_to_page = True
            if acess_to_page == True:
                print(r'get details of id: ', id)
                company_detail_id = request.user.company_detail_id
                sub_company_id = request.user.sub_company_id
                #queryset = self.get_object(pk=id)
                queryset = Accessory.objects.filter(pk=id,
                                                        company_detail_id=company_detail_id, sub_company_id=sub_company_id).first()
                serializer = self.ObjectSerializer(queryset)
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


    def put(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'accessory' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['accessory']:
                    acess_to_page = True
            if acess_to_page == True:
                sub_company_detail_id = None
                if len(get_user_data['sub_company']) > 0:
                    sub_company_detail_id = get_user_data['sub_company']['id']
                data = request.data
                data['company_detail_id'] = get_user_data['company_detail']['id']
                data['sub_company_id'] = sub_company_detail_id
                queryset = self.get_object(pk=id)
                serializer = self.ObjectSerializer(queryset, data=data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'accessory' in get_user_data['permission'].keys():
                if 'delete' in get_user_data['permission']['accessory']:
                    acess_to_page = True
            if acess_to_page == True:
                company_detail_id = request.user.company_detail_id
                sub_company_id = request.user.sub_company_id
                #queryset = self.get_object(pk=id)
                queryset = Accessory.objects.filter(pk=id,
                                                        company_detail_id=company_detail_id, sub_company_id=sub_company_id).first()
                try:
                    queryset.delete()
                    return Response(status=status.HTTP_204_NO_CONTENT)
                except Exception as e:
                    return Response({"submit": "Cannot delete. This object is referenced by other objects."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)



# ApprovalType API
class ApprovalTypeList(APIView):
    permission_classes = (IsAuthenticated,)


    def get_object(self):
        try:
            return ApprovalType.objects.all()
        except:
            raise Http404

    ObjectSerializer = ApprovalTypeSerializer
    model_name = "ApprovalType"

    def get(self, request, format=None):
        limit = int(request.GET.get('limit',10))
        offset = int(request.GET.get('offset',0))
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'approval_type' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['approval_type']:
                    acess_to_page = True
            if acess_to_page == True:

                approval_queryset = ApprovalType.objects.filter(company_detail_id = get_user_data['company_detail']['id']).order_by('-id').all()[offset:limit+offset]
                approval_count = ApprovalType.objects.filter(company_detail_id = get_user_data['company_detail']['id']).count()
                serializer = self.ObjectSerializer(approval_queryset, many=True)
                return Response({'count':approval_count, 'results': serializer.data})
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def post(self, request, format=None):
        # serializer = CompanyDetailSerializer(data=request.data)
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'approval_type' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['approval_type']:
                    acess_to_page = True
            if acess_to_page == True:
                data = request.data
                data['company_detail_id'] = get_user_data['company_detail']['id']
                serializer = self.ObjectSerializer(data=data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)



class ApprovalTypeDetail(APIView):
    permission_classes = (IsAuthenticated,)

    def get_object(self, pk):
        try:
            return ApprovalType.objects.get(pk=pk)
        except:
            raise Http404

    ObjectSerializer = ApprovalTypeSerializer

    def get(self, request, id=None, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'approval_type' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['approval_type']:
                    acess_to_page = True
            if acess_to_page == True:

                print(r'get details of id: ', id)

                queryset = self.get_object(pk=id)
                # serializer = CompanyDetailSerializer(queryset)
                serializer = self.ObjectSerializer(queryset)
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)




    def put(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'approval_type' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['approval_type']:
                    acess_to_page = True
            if acess_to_page == True:
                data = request.data
                data['company_detail_id'] = get_user_data['company_detail']['id']
                queryset = self.get_object(pk=id)
                serializer = self.ObjectSerializer(queryset, data=data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


    def delete(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'approval_type' in get_user_data['permission'].keys():
                if 'delete' in get_user_data['permission']['approval_type']:
                    acess_to_page = True
            if acess_to_page == True:
                queryset = self.get_object(pk=id)
                approval_names_not_deletable = ["Approve", "Hold", "Unhold", "Reject"]
                if queryset.approval_name in approval_names_not_deletable:
                    return Response({"submit": f"Cannot delete {queryset.approval_name}. This approval type cannot be deleted."}, status=status.HTTP_400_BAD_REQUEST)

                try:
                    queryset.delete()
                    return Response(status=status.HTTP_204_NO_CONTENT)
                except Exception as e:
                    return Response({"submit": "Cannot delete. This object is referenced by other objects."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


# ApprovalLayer API
class ApprovalLayerList(APIView):
    permission_classes = (IsAuthenticated,)


    def get_object(self):
        try:
            return ApprovalLayer.objects.all()
        except:
            raise Http404

    ObjectSerializer = ApprovalLayerSerializer
    model_name = "ApprovalLayer"

    def get(self, request, format=None):
        limit = int(request.GET.get('limit',10))
        offset = int(request.GET.get('offset',0))

        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'approval_layer' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['approval_layer']:
                    acess_to_page = True
            if acess_to_page == True:
                sub_company_detail_id = None
                if len(get_user_data['sub_company']) > 0:
                    sub_company_detail_id = get_user_data['sub_company']['id']

                approval_queryset = ApprovalLayer.objects.filter(company_detail_id = get_user_data['company_detail']['id'],sub_company_id = sub_company_detail_id).order_by('-id').all()[offset:limit+offset]
                approval_count = ApprovalLayer.objects.filter(company_detail_id = get_user_data['company_detail']['id'],sub_company_id = sub_company_detail_id).count()
                serializer = self.ObjectSerializer(approval_queryset, many=True)
                return Response({'count':approval_count, 'results': serializer.data})
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def post(self, request, format=None):
        # serializer = CompanyDetailSerializer(data=request.data)
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'approval_layer' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['approval_layer']:
                    acess_to_page = True
            if acess_to_page == True:
                sub_company_detail_id = None
                if len(get_user_data['sub_company']) > 0:
                    sub_company_detail_id = get_user_data['sub_company']['id']
                data = request.data
                data['company_detail_id'] = get_user_data['company_detail']['id']
                data['sub_company_id'] = sub_company_detail_id
                serializer = self.ObjectSerializer(data=data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class ApprovalLayerDetail(APIView):
    permission_classes = (IsAuthenticated,)

    def get_object(self, pk):
        try:
            return ApprovalLayer.objects.get(pk=pk)
        except:
            raise Http404

    ObjectSerializer = ApprovalLayerSerializer

    def get(self, request, id=None, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'approval_layer' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['approval_layer']:
                    acess_to_page = True
            if acess_to_page == True:
                print(r'get details of id: ', id)

                company_detail_id = request.user.company_detail_id
                sub_company_id = request.user.sub_company_id
                #queryset = self.get_object(pk=id)
                queryset = ApprovalLayer.objects.filter(pk=id,
                                                                    company_detail_id=company_detail_id, sub_company_id=sub_company_id).first()
                serializer = self.ObjectSerializer(queryset)
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


    def put(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'approval_layer' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['approval_layer']:
                    acess_to_page = True
            if acess_to_page == True:
                sub_company_detail_id = None
                if len(get_user_data['sub_company']) > 0:
                    sub_company_detail_id = get_user_data['sub_company']['id']
                data = request.data
                data['company_detail_id'] = get_user_data['company_detail']['id']
                data['sub_company_id'] = sub_company_detail_id
                queryset = self.get_object(pk=id)
                serializer = self.ObjectSerializer(queryset, data=data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    # def delete(self, request, id, format=None):
    #     get_user_data = getUserDataLogin(request.user.id)
        
    #     if get_user_data['company_detail']['account_validity'] == True:
    #         acess_to_page = False
    #         if 'approval_layer' in get_user_data['permission'].keys():
    #             if 'delete' in get_user_data['permission']['approval_layer']:
    #                 acess_to_page = True
    #         if acess_to_page == True:
    #             company_detail_id = request.user.company_detail_id
    #             sub_company_id = request.user.sub_company_id
    #             #queryset = self.get_object(pk=id)
    #             queryset = ApprovalLayer.objects.filter(pk=id,
    #                                                                 company_detail_id=company_detail_id, sub_company_id=sub_company_id).first()
    #             queryset.delete()
    #             return Response(status=status.HTTP_204_NO_CONTENT)
    #         else:
    #             return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

    #     else:
    #         return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


# PassExtensionChangeApprovalRole API
class PassExtensionChangeApprovalRoleList(APIView):
    permission_classes = (IsAuthenticated,)


    def get_object(self):
        try:
            return PassExtensionChangeApprovalRole.objects.all()
        except:
            raise Http404

    ObjectSerializer = PassExtensionChangeApprovalRoleSerializer
    model_name = "PassExtensionChangeApprovalRole"

    def get(self, request, format=None):
        limit = int(request.GET.get('limit',10))
        offset = int(request.GET.get('offset',0))

        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'pass_extension_change' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['pass_extension_change']:
                    acess_to_page = True
            if acess_to_page == True:
                approval_queryset = PassExtensionChangeApprovalRole.objects.filter(company_detail_id = get_user_data['company_detail']['id']).order_by('-id').all()[offset:limit+offset]
                approval_count = PassExtensionChangeApprovalRole.objects.filter(company_detail_id = get_user_data['company_detail']['id']).count()
                serializer = self.ObjectSerializer(approval_queryset, many=True)
                return Response({'count':approval_count, 'results': serializer.data})
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def post(self, request, format=None):
        # serializer = CompanyDetailSerializer(data=request.data)
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'company_detail' in get_user_data['permission'].keys():
                if 'pass_extension_change' in get_user_data['permission']['pass_extension_change']:
                    acess_to_page = True
            if acess_to_page == True:
                data = request.data
                data['company_detail_id'] = get_user_data['company_detail']['id']
                serializer = self.ObjectSerializer(data=data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class PassExtensionChangeApprovalRoleDetail(APIView):
    permission_classes = (IsAuthenticated,)

    def get_object(self, pk):
        try:
            return PassExtensionChangeApprovalRole.objects.get(pk=pk)
        except:
            raise Http404

    ObjectSerializer = PassExtensionChangeApprovalRoleSerializer

    def get(self, request, id=None, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'pass_extension_change' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['pass_extension_change']:
                    acess_to_page = True
            if acess_to_page == True:
                print(r'get details of id: ', id)
                
                queryset = self.get_object(pk=id)
                # serializer = CompanyDetailSerializer(queryset)
                serializer = self.ObjectSerializer(queryset)
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)



    def put(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'pass_extension_change' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['pass_extension_change']:
                    acess_to_page = True
            if acess_to_page == True:
                data = request.data
                data['company_detail_id'] = get_user_data['company_detail']['id']
                queryset = self.get_object(pk=id)
                serializer = self.ObjectSerializer(queryset, data=data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'pass_extension_change' in get_user_data['permission'].keys():
                if 'delete' in get_user_data['permission']['pass_extension_change']:
                    acess_to_page = True
            if acess_to_page == True:
                queryset = self.get_object(pk=id)
                try:
                    queryset.delete()
                    return Response(status=status.HTTP_204_NO_CONTENT)
                except Exception as e:
                    return Response({"submit": "Cannot delete. This object is referenced by other objects."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class GetUserDetail(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, format=None):
        # try:
        #     token = request.META.get('HTTP_AUTHORIZATION', " ").split(' ')[1]
        #     if token != '':
        #         data = {'token': token}
        #         valid_data = TokenBackend(algorithm='HS256').decode(token, verify=False)
        #         user = valid_data['user_id']
        #         request.user = user
        #     else:
        #         return Response({"result": {}, "message": "Invalid Token."}, status=status.HTTP_201_CREATED)
        # except ValidationError as v:
        #     print("validation error", v)
        get_user_data = getUserDataLogin(request.user.id)

        
        return Response(get_user_data)

        

# DropDown
class CompanyListView(APIView):
    

    def get(self, request):
        company = CompanyDetail.objects.all()
        print("company", company)
        company_serializer = CompanyDetailListSerializer(company, many=True)
        return Response(company_serializer.data)


# DropDown
class RoleListView(APIView):
    permission_classes = [IsAuthenticated]
    pagination_class = LimitOffsetPagination

    def get(self, request):
    
        company_detail_id = request.user.company_detail_id
        sub_company_id = request.user.sub_company_id
        print("company_detail_id", company_detail_id)

        if company_detail_id:
            roles = Roles.objects.filter(company_detail_id=company_detail_id, sub_company_id=sub_company_id).exclude(role_name='Visitor')

        if sub_company_id:
            roles = Roles.objects.filter(sub_company_id=sub_company_id).exclude(role_name='Visitor')

        print("roles", roles)
        roles_serializer = RolesListSerializer(roles, many=True)
        return Response(roles_serializer.data)


# configurations

class FineCollectedByView(APIView):
    permission_classes = [IsAuthenticated]

    def get_object(self):
        try:
            return FineCollectedBy.objects.all()
        except FineCollectedBy.DoesNotExist:
            raise Http404
        
    ObjectSerializer = FineCollectedBySerializer
    model_name = 'FineCollectedBy'

    # def get_company(self):
    #     User = get_user_model()
    #     user_email = self.request.user
    #     return (User.objects.filter(email=user_email).values('company_detail_id')[0]['company_detail_id'])

    def get(self, request, format=None):
        limit = int(request.GET.get('limit',10))
        offset = int(request.GET.get('offset',0))
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'fine_collected_by' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['fine_collected_by']:
                    acess_to_page = True
            if acess_to_page == True:
                sub_company_detail_id = None
                if len(get_user_data['sub_company']) > 0:
                    sub_company_detail_id = get_user_data['sub_company']['id']

                fine_queryset = FineCollectedBy.objects.filter(company_detail_id = get_user_data['company_detail']['id'],sub_company_id = sub_company_detail_id).order_by('-id').all()[offset:limit+offset]
                fine_count = FineCollectedBy.objects.filter(company_detail_id = get_user_data['company_detail']['id'],sub_company_id = sub_company_detail_id).count()
                serializer = self.ObjectSerializer(fine_queryset, many=True)
                return Response({'count':fine_count, 'results': serializer.data})
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
                    
    def post(self, request, format=None):

        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'fine_collected_by' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['fine_collected_by']:
                    acess_to_page = True
            if acess_to_page == True:
                sub_company_detail_id = None
                if len(get_user_data['sub_company']) > 0:
                    sub_company_detail_id = get_user_data['sub_company']['id']
                data = request.data
                data['company_detail_id'] = get_user_data['company_detail']['id']
                data['sub_company_id'] = sub_company_detail_id 
                serializer = self.ObjectSerializer(data=data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class FineCollectedByDetailView(APIView):
    permission_classes = [IsAuthenticated]

    def get_object(self, pk):
        try:
            return FineCollectedBy.objects.get(pk=pk)
        except FineCollectedBy.DoesNotExist:
            raise Http404
        
    ObjectSerializer = FineCollectedBySerializer

    def get(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'fine_collected_by' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['fine_collected_by']:
                    acess_to_page = True
            if acess_to_page == True:
                print(r'get details of id: ', id)
                company_detail_id = request.user.company_detail_id
                sub_company_id = request.user.sub_company_id
                #queryset = self.get_object(pk=id)
                queryset = FineCollectedBy.objects.filter(pk=id,
                                                                company_detail_id=company_detail_id, sub_company_id=sub_company_id).first()
                serializer = self.ObjectSerializer(queryset)
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def patch(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'fine_collected_by' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['fine_collected_by']:
                    acess_to_page = True
            if acess_to_page == True:
                sub_company = self.get_object(pk=id)
                print("sub_company", sub_company)
                data = request.data.copy()
                #data['company_detail_id'] = self.get_company()
                print("patch data", data)
                serializer = self.ObjectSerializer(sub_company, data=data, partial=True)
                if serializer.is_valid():
                    print("serializer is valid")
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'fine_collected_by' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['fine_collected_by']:
                    acess_to_page = True
            if acess_to_page == True:
                sub_company_detail_id = None
                if len(get_user_data['sub_company']) > 0:
                    sub_company_detail_id = get_user_data['sub_company']['id']
                data = request.data
                data['company_detail_id'] = get_user_data['company_detail']['id']
                data['sub_company_id'] = sub_company_detail_id
                queryset = self.get_object(pk=id)
                serializer = self.ObjectSerializer(queryset, data=data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'fine_collected_by' in get_user_data['permission'].keys():
                if 'delete' in get_user_data['permission']['fine_collected_by']:
                    acess_to_page = True
            if acess_to_page == True:
                company_detail_id = request.user.company_detail_id
                sub_company_id = request.user.sub_company_id
                #queryset = self.get_object(pk=id)
                queryset = FineCollectedBy.objects.filter(pk=id,
                                                                company_detail_id=company_detail_id, sub_company_id=sub_company_id).first()
                try:
                    queryset.delete()
                    return Response(status=status.HTTP_204_NO_CONTENT)
                except Exception as e:
                    return Response({"submit": "Cannot delete. This object is referenced by other objects."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)



class ApprovalChangeByNumberOfDaysView(APIView):
    permission_classes = [IsAuthenticated]

    def get_object(self):
        try:
            return ApprovalChangeByNumberOfDays.objects.all()
        except ApprovalChangeByNumberOfDays.DoesNotExist:
            raise Http404
        
    ObjectSerializer = ApprovalChangeByNumberOfDaysSerializer
    model_name = 'ApprovalChangeByNumberOfDays'

    # def get_company(self):
    #     User = get_user_model()
    #     user_email = self.request.user
    #     return (User.objects.filter(email=user_email).values('company_detail_id')[0]['company_detail_id'])

    def get(self, request, format=None):
        limit = int(request.GET.get('limit',10))
        offset = int(request.GET.get('offset',0))
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'approval_change_by_number' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['approval_change_by_number']:
                    acess_to_page = True
            if acess_to_page == True:
                sub_company_detail_id = None
                if len(get_user_data['sub_company']) > 0:
                    sub_company_detail_id = get_user_data['sub_company']['id']

                approval_queryset = ApprovalChangeByNumberOfDays.objects.filter(company_detail_id = get_user_data['company_detail']['id'],sub_company_id = sub_company_detail_id).order_by('-id').all()[offset:limit+offset]
                approval_count = ApprovalChangeByNumberOfDays.objects.filter(company_detail_id = get_user_data['company_detail']['id'],sub_company_id = sub_company_detail_id).count()


                serializer = self.ObjectSerializer(approval_queryset, many=True)
                return Response({'count':approval_count, 'results': serializer.data})
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
                    
    def post(self, request, format=None):

        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'approval_change_by_number' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['approval_change_by_number']:
                    acess_to_page = True
            if acess_to_page == True:
                sub_company_detail_id = None
                if len(get_user_data['sub_company']) > 0:
                    sub_company_detail_id = get_user_data['sub_company']['id']
                data = request.data
                data['company_detail_id'] = get_user_data['company_detail']['id']
                data['sub_company_id'] = sub_company_detail_id
                serializer = self.ObjectSerializer(data=data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class ApprovalChangeByNumberOfDaysDetailView(APIView):
    permission_classes = [IsAuthenticated]

    def get_object(self, pk):
        try:
            return ApprovalChangeByNumberOfDays.objects.get(pk=pk)
        except ApprovalChangeByNumberOfDays.DoesNotExist:
            raise Http404
        
    ObjectSerializer = ApprovalChangeByNumberOfDaysSerializer

    def get(self, request, id):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'approval_change_by_number' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['approval_change_by_number']:
                    acess_to_page = True
            if acess_to_page == True:
                print(r'get details of id: ', id)
                company_detail_id = request.user.company_detail_id
                sub_company_id = request.user.sub_company_id
                #queryset = self.get_object(pk=id)
                queryset = ApprovalChangeByNumberOfDays.objects.filter(pk=id,
                                                                    company_detail_id=company_detail_id, sub_company_id=sub_company_id).first()
                serializer = self.ObjectSerializer(queryset)
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def patch(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'approval_change_by_number' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['approval_change_by_number']:
                    acess_to_page = True
            if acess_to_page == True:
                sub_company = self.get_object(pk=id)
                print("sub_company", sub_company)
                data = request.data.copy()
                #data['company_detail_id'] = self.get_company()
                print("patch data", data)
                serializer = self.ObjectSerializer(sub_company, data=data, partial=True)
                if serializer.is_valid():
                    print("serializer is valid")
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'approval_change_by_number' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['approval_change_by_number']:
                    acess_to_page = True
            if acess_to_page == True:
                sub_company_detail_id = None
                if len(get_user_data['sub_company']) > 0:
                    sub_company_detail_id = get_user_data['sub_company']['id']
                data = request.data
                data['company_detail_id'] = get_user_data['company_detail']['id']
                data['sub_company_id'] = sub_company_detail_id
                queryset = self.get_object(pk=id)
                serializer = self.ObjectSerializer(queryset, data=data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'approval_change_by_number' in get_user_data['permission'].keys():
                if 'delete' in get_user_data['permission']['approval_change_by_number']:
                    acess_to_page = True
            if acess_to_page == True:
                company_detail_id = request.user.company_detail_id
                sub_company_id = request.user.sub_company_id
                #queryset = self.get_object(pk=id)
                queryset = ApprovalChangeByNumberOfDays.objects.filter(pk=id,
                                                                    company_detail_id=company_detail_id, sub_company_id=sub_company_id).first()
                
                
                try:
                    queryset.delete()
                    return Response(status=status.HTTP_204_NO_CONTENT)
                except Exception as e:
                    return Response({"submit": "Cannot delete. This object is used by Approval step by role."}, status=status.HTTP_400_BAD_REQUEST)

            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)



class ApproveStepByRoleView(APIView):
    permission_classes = [IsAuthenticated]


    def get_object(self):
        try:
            return ApproveStepByRole.objects.all()
        except ApproveStepByRole.DoesNotExist:
            raise Http404
        
    ObjectSerializer = ApproveStepByRoleSerializer
    model_name = 'ApproveStepByRole'

    # def get_company(self):
    #     User = get_user_model()
    #     user_email = self.request.user
    #     return (User.objects.filter(email=user_email).values('company_detail_id')[0]['company_detail_id'])

    def get(self, request,pk, format=None):
        limit = int(request.GET.get('limit',10))
        offset = int(request.GET.get('offset',0))
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'approval_step_by_role' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['approval_step_by_role']:
                    acess_to_page = True
            if acess_to_page == True:
                sub_company_detail_id = None
                if len(get_user_data['sub_company']) > 0:
                    sub_company_detail_id = get_user_data['sub_company']['id']

                approval_queryset = ApproveStepByRole.objects.filter(approval_change_by_number_of_days_id = pk , company_detail_id = get_user_data['company_detail']['id'],sub_company_id = sub_company_detail_id).order_by('layer_step').all()[offset:limit+offset]
                approval_count = ApproveStepByRole.objects.filter(approval_change_by_number_of_days_id = pk, company_detail_id = get_user_data['company_detail']['id'],sub_company_id = sub_company_detail_id).count()


                serializer = self.ObjectSerializer(approval_queryset, many=True)
                return Response({'count':approval_count, 'results': serializer.data})
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
        
class ApproveStepByRolePostView(APIView):
    permission_classes = [IsAuthenticated]


    def get_object(self):
        try:
            return ApproveStepByRole.objects.all()
        except ApproveStepByRole.DoesNotExist:
            raise Http404
        
    ObjectSerializer = ApproveStepByRoleSerializer
    model_name = 'ApproveStepByRole'
                    
    def post(self, request, format=None):

        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'approval_step_by_role' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['approval_step_by_role']:
                    acess_to_page = True
            if acess_to_page == True:
                sub_company_detail_id = None
                if len(get_user_data['sub_company']) > 0:
                    sub_company_detail_id = get_user_data['sub_company']['id']
                data = request.data
                data['company_detail_id'] = get_user_data['company_detail']['id']
                data['sub_company_id'] = sub_company_detail_id
                serializer = self.ObjectSerializer(data=data)
                if serializer.is_valid():
                    serializer.save()
                    print(serializer.data)
                    print(serializer.errors)
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class ApproveStepByRoleDetailView(APIView):
    permission_classes = [IsAuthenticated]

    def get_object(self, pk):
        try:
            return ApproveStepByRole.objects.get(pk=pk)
        except ApproveStepByRole.DoesNotExist:
            raise Http404
        
    ObjectSerializer = ApproveStepByRoleSerializer

    def get(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'approval_step_by_role' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['approval_step_by_role']:
                    acess_to_page = True
            if acess_to_page == True:
                print(r'get details of id: ', id)
                company_detail_id = request.user.company_detail_id
                sub_company_id = request.user.sub_company_id
                #queryset = self.get_object(pk=id)
                queryset = ApproveStepByRole.objects.filter(pk=id,
                                                                    company_detail_id=company_detail_id, sub_company_id=sub_company_id).first()
                serializer = self.ObjectSerializer(queryset)
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def patch(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'approval_step_by_role' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['approval_step_by_role']:
                    acess_to_page = True
            if acess_to_page == True:
                sub_company = self.get_object(pk=id)
                print("sub_company", sub_company)
                data = request.data.copy()
                #data['company_detail_id'] = self.get_company()
                print("patch data", data)
                serializer = self.ObjectSerializer(sub_company, data=data, partial=True)
                if serializer.is_valid():
                    print("serializer is valid")
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'approval_step_by_role' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['approval_step_by_role']:
                    acess_to_page = True
            if acess_to_page == True:
                sub_company_detail_id = None
                if len(get_user_data['sub_company']) > 0:
                    sub_company_detail_id = get_user_data['sub_company']['id']
                data = request.data
                data['company_detail_id'] = get_user_data['company_detail']['id']
                data['sub_company_id'] = sub_company_detail_id
                queryset = self.get_object(pk=id)
                serializer = self.ObjectSerializer(queryset, data=data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'approval_step_by_role' in get_user_data['permission'].keys():
                if 'delete' in get_user_data['permission']['approval_step_by_role']:
                    acess_to_page = True
            if acess_to_page == True:
                company_detail_id = request.user.company_detail_id
                sub_company_id = request.user.sub_company_id
                #queryset = self.get_object(pk=id)
                queryset = ApproveStepByRole.objects.filter(pk=id,
                                                                    company_detail_id=company_detail_id, sub_company_id=sub_company_id).first()
                try:
                    queryset.delete()
                    return Response(status=status.HTTP_204_NO_CONTENT)
                except Exception as e:
                    return Response({"submit": "Cannot delete. This object is used for visitor request Approval."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)



# DropDown
class SubCompanyListView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        sub_company = SubCompany.objects.all()
        sub_company_serializer = SubCompanyListSerializer(sub_company, many=True)
        return Response(sub_company_serializer.data)



# DropDown
class UserListView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        company_detail_id = request.user.company_detail_id
        sub_company_id = request.user.sub_company_id

        if company_detail_id:
            user = User.objects.filter(company_detail_id=company_detail_id,sub_company_id=sub_company_id)

        if sub_company_id:
            user= User.objects.filter(sub_company_id=sub_company_id)
            
        user_serializer = UserListSerializer(user, many=True)
        return Response(user_serializer.data)



# SubCompanyMenuActionMap API
class SubCompanyMenuActionMapView(APIView):
    permission_classes = (IsAuthenticated,)

    def get_object(self):
        try:
            return SubCompanyMenuActionMap.objects.all()
        except:
            raise Http404

    ObjectSerializer = SubCompanyMenuActionMapSerializer
    model_name = "SubCompanyMenuActionMap"

    def get(self, request, format=None):
        limit = int(request.GET.get('limit',10))
        offset = int(request.GET.get('offset',0))
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'menu_action_map' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['menu_action_map']:
                    acess_to_page = True
            if acess_to_page == True:
                queryset = SubCompanyMenuActionMap.objects.all()[offset:limit+offset]
                serializer = self.ObjectSerializer(queryset, many=True)
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)



    def post(self, request, format=None):
        # serializer = CompanyDetailSerializer(data=request.data)
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'menu_action_map' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['menu_action_map']:
                    acess_to_page = True
            if acess_to_page == True:
                data = request.data
                serializer = self.ObjectSerializer(data=data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class SubCompanyMenuActionMapDetailView(APIView):
    permission_classes = (IsAuthenticated,)

    def get_object(self, pk):
        try:
            return SubCompanyMenuActionMap.objects.get(pk=pk)
        except:
            raise Http404

    ObjectSerializer = SubCompanyMenuActionMapSerializer

    def get(self, request, id=None, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'menu_action_map' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['menu_action_map']:
                    acess_to_page = True
            if acess_to_page == True:

                print(r'get details of id: ', id)
                
                queryset = self.get_object(pk=id)
                serializer = self.ObjectSerializer(queryset)
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


    def put(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'menu_action_map' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['menu_action_map']:
                    acess_to_page = True
            if acess_to_page == True:
                queryset = self.get_object(pk=id)
                print("PUT request ", id, queryset, request.data)
                serializer = self.ObjectSerializer(queryset, data=request.data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'menu_action_map' in get_user_data['permission'].keys():
                if 'delete' in get_user_data['permission']['menu_action_map']:
                    acess_to_page = True
            if acess_to_page == True:
                queryset = self.get_object(pk=id)
                try:
                    queryset.delete()
                    return Response(status=status.HTTP_204_NO_CONTENT)
                except Exception as e:
                    return Response({"submit": "Cannot delete. This object is referenced by other objects."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)




class RolesAndPermissionView(APIView):
    permission_classes = (IsAuthenticated,)


    def get(self, request):
        limit = int(request.GET.get('limit', 10))
        offset = int(request.GET.get('offset', 0))

        get_user_data = getUserDataLogin(request.user.id)

        if get_user_data['company_detail']['account_validity'] == True:
            AccessToPage = False
            if 'roles_permission' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['roles_permission']:
                    AccessToPage = True

            if AccessToPage == True:
                sub_company_detail_id = None
                if len(get_user_data['sub_company']) > 0:
                    sub_company_detail_id = get_user_data['sub_company']['id']
                roles = Roles.objects.filter(company_detail_id = get_user_data['company_detail']['id'],sub_company_id = sub_company_detail_id).all()
                permissions = []

                for role in roles:
                    role_data = {'role_id': role.id, 'role_name': role.role_name, 'permissions': []}
                    role_permissions = role.permission_set.all()

                    for permission in role_permissions:
                        menu_page_id = permission.menu_page_id.id
                        menu_name = permission.menu_page_id.menu_name
                        action_name = permission.action_id.action_name

                        # Check if the menu already exists in the permissions list
                        menu_exists = next((menu for menu in role_data['permissions'] if menu['menu_page_id'] == menu_page_id), None)

                        if menu_exists:
                            # Check if the action already exists for this menu
                            action_exists = next((act for act in menu_exists['action'] if act['action_id'] == permission.action_id.id), None)

                            if not action_exists:
                                menu_exists['action'].append({
                                    'action_id': permission.action_id.id,
                                    'action_name': action_name
                                })
                        else:
                            role_data['permissions'].append({
                                'menu_page_id': menu_page_id,
                                'menu_name': menu_name,
                                'action': [{
                                    'action_id': permission.action_id.id,
                                    'action_name': action_name
                                }]
                            })

                    permissions.append(role_data)

                total_count = len(roles)
                permissions = permissions[offset:offset + limit]
                

                return Response({"count": total_count, "results": permissions})
            else:
                return Response({"submit": "You don't have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"submit": "Account validity has expired."}, status=status.HTTP_400_BAD_REQUEST)




    def post(self, request):
        user_id = request.user.id
        get_user_data = getUserDataLogin(user_id)  
        if get_user_data['company_detail']['account_validity'] == True:
            AccessToPage = False
            if 'roles_permission' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['roles_permission']:
                    AccessToPage = True

            if AccessToPage == True:
                sub_company_detail_id = None
                if len(get_user_data['sub_company']) > 0:
                    sub_company_detail_id = get_user_data['sub_company']['id']
                    
                data = request.data
                data['company_detail_id'] = get_user_data['company_detail']['id']
                data['sub_company_id'] = sub_company_detail_id
                role_serializer = RolesSerializer(data=data)
                
                if role_serializer.is_valid():
                    role = role_serializer.save()
                else:
                    return Response(role_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                
                permissions_data = data.get('permission')
                if not permissions_data:
                    return Response({"submit": "Permission data is missing or empty."}, status=status.HTTP_400_BAD_REQUEST)

                # Create Permissions for the Role
                for permission_data in permissions_data:
                    permission_serializer = PermissionSerializer(data={
                        'role_id': role.id,
                        'menu_page_id': permission_data.get('menu_page_id'),
                        'action_id': permission_data.get('action_id')
                    })
                    if permission_serializer.is_valid():
                        permission_serializer.save()
                    else:
                        # If any permission data is invalid, delete the created role and return error response
                        print("deleted")
                        role.delete()
                        return Response(permission_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                print(permission_serializer.data)
                return Response({"submit": f"Role '{role.role_name}' with permissions has been created."}, status=status.HTTP_201_CREATED)
                    
            else:
                return Response({"submit": "You don't have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity has expired."}, status=status.HTTP_400_BAD_REQUEST)



class RolesAndPermissionDetailView(APIView):
    permission_classes = (IsAuthenticated,)

    # def get_user_action(self, method):
    #     if method == 'GET':
    #         return 'view'
    #     elif method == 'POST':
    #         return 'create'
    #     elif method == 'PUT':
    #         return 'update'
    #     elif method == 'DELETE':
    #         return 'delete'
    #     else:
    #         return 'unknown'

    

    def get(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)
        if get_user_data['company_detail']['account_validity'] == True:
            AccessToPage = False
            if 'roles_permission' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['roles_permission']:
                    AccessToPage = True

            if AccessToPage == True:
                try:
                    company_detail_id = request.user.company_detail_id
                    sub_company_id = request.user.sub_company_id
                    role = Roles.objects.get(pk=id, company_detail_id=company_detail_id, sub_company_id=sub_company_id)
                except Roles.DoesNotExist:
                    return Response({"submit": "ID not found."}, status=status.HTTP_404_NOT_FOUND)

                role_data = {'role_id': role.id, 'role_name': role.role_name, 'permissions': []}
                role_permissions = role.permission_set.all()

                for permission in role_permissions:
                    menu_name = permission.menu_page_id.menu_name
                    action_name = permission.action_id.action_name
                    menu_page_id = permission.menu_page_id.id

                    # Find if the menu already exists in permissions list
                    menu_exists = next((menu for menu in role_data['permissions'] if menu['menu_page_id'] == menu_page_id), None)

                    if menu_exists:
                            # Check if the action already exists for this menu
                            action_exists = next((act for act in menu_exists['action'] if act['action_id'] == permission.action_id.id), None)

                            if not action_exists:
                                menu_exists['action'].append({
                                    'action_id': permission.action_id.id,
                                    'action_name': action_name
                                })
                    else:
                        # If menu doesn't exist, create a new menu entry and add action_name to it
                        role_data['permissions'].append({
                            'menu_page_id': menu_page_id,
                            'menu_name': menu_name,
                            'action': [{
                                'action_id': permission.action_id.id,
                                'action_name': action_name
                            }]
                        })

                return Response(role_data)
            else:
                return Response({"submit": "You don't have permission to access."}, status=status.HTTP_403_FORBIDDEN)
        else:
            return Response({"submit": "Account validity has expired."}, status=status.HTTP_400_BAD_REQUEST)

 


    def put(self, request,id, format=None):
        get_user_data = getUserDataLogin(request.user.id)  
        if get_user_data['company_detail']['account_validity'] == True:
            AccessToPage = False
            if 'roles_permission' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['roles_permission']:
                    AccessToPage = True

            if AccessToPage == True:
                try:
                    company_detail_id = request.user.company_detail_id
                    sub_company_id = request.user.sub_company_id
                    role = Roles.objects.get(pk=id, company_detail_id=company_detail_id, sub_company_id=sub_company_id)
                except Roles.DoesNotExist:
                    return Response({"submit": "Role not found."}, status=status.HTTP_404_NOT_FOUND)
                

                # Check if role_name is "Admin" or "Visitor"
                if role.role_name in ["Admin", "Visitor"]:
                    return Response({"submit": f"The role '{role.role_name}' cannot be updated."}, status=status.HTTP_400_BAD_REQUEST)
                
                if role.id == get_user_data['role_detail']['id']:
                    raise PermissionDenied({"submit":"You cannot change your own role name."})

                role_id = request.data.get('role_id')
                role_name = request.data.get('role_name')
                prev_permissions_data = request.data.get('prev_permission', [])
                new_permissions_data = request.data.get('new_permission', [])

                # Update the role_name if provided
                if role_name:
                    role.role_name = role_name
                    role.save()

                # Process previous permissions
                for prev_permission_data in prev_permissions_data:
                    menu_page_id = prev_permission_data.get('menu_page_id')
                    action_id = prev_permission_data.get('action_id')
                    permission = Permission.objects.filter(role_id=role_id, menu_page_id=menu_page_id, action_id=action_id).first()

                    if permission:
                        permission.delete()

                # Process new permissions
                for new_permission_data in new_permissions_data:
                    menu_page_id = new_permission_data.get('menu_page_id')
                    action_id = new_permission_data.get('action_id')
                    permission_data = {
                        'role_id': role_id,
                        'menu_page_id': menu_page_id,
                        'action_id': action_id
                    }
                    permission_serializer = PermissionSerializer(data=permission_data)

                    if permission_serializer.is_valid():
                        permission_serializer.save()
                        print(permission_serializer)
                    else:
                        return Response(permission_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                    
                return Response({"submit": f"Role '{role.role_name}' permissions have been updated."}, status=status.HTTP_200_OK)

            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


    

    def delete(self, request,id, format=None):
        get_user_data = getUserDataLogin(request.user.id)  
        if get_user_data['company_detail']['account_validity'] == True:
            AccessToPage = False
            if 'roles_permission' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['roles_permission']:
                    AccessToPage = True

            if AccessToPage == True:
                try:
                    company_detail_id = request.user.company_detail_id
                    sub_company_id = request.user.sub_company_id
                    role = Roles.objects.get(pk=id, company_detail_id=company_detail_id, sub_company_id=sub_company_id)
                except Roles.DoesNotExist:
                    return Response({"submit": "Role not found."}, status=status.HTTP_404_NOT_FOUND)
                
                # Check if action_perform is True for the role and allowed is True for the permissions
                if not role.action_perform and not role.permission_set.filter(allowed=True).exists():
                    return Response({"submit": "You don't have permissions to delete this role."}, status=status.HTTP_400_BAD_REQUEST)

                # Check if the role is assigned to some user
                assigned_users = AddUserEmail.objects.filter(role_id=id)
                if assigned_users.exists():
                    return Response({"submit": "Cannot delete this role. It is assigned to some user."}, status=status.HTTP_400_BAD_REQUEST)
                
                # Check if the role is referenced by UserRoleMapping
                if UserRoleMapping.objects.filter(role_id=id).exists():
                    return Response({"submit": "Cannot delete this role. It is referenced by UserRoleMapping."}, status=status.HTTP_400_BAD_REQUEST)

                # Check if the role is referenced by FineCollectedBy
                if FineCollectedBy.objects.filter(role_id=id).exists():
                    return Response({"submit": "Cannot delete this role. It is referenced by FineCollectedBy."}, status=status.HTTP_400_BAD_REQUEST)

                # Check if the role_name is "Admin" or "Visitor"
                if role.role_name in ["Admin", "Visitor"]:
                    return Response({"submit": f"The role '{role.role_name}' cannot be deleted."}, status=status.HTTP_400_BAD_REQUEST)

                # Delete the associated permissions first
                Permission.objects.filter(role_id=id).delete()

                # Now, delete the role
                role.delete()

                return Response({"submit": f"Role '{role.role_name}' and its permissions have been deleted."}, status=status.HTTP_204_NO_CONTENT)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)



# DropDown
class DefaultAccessoryProvidedByCompanyListView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        company_detail_id = request.user.company_detail_id
        sub_company_id = request.user.sub_company_id

        if company_detail_id:
            default_accessory = DefaultAccessoryProvidedByCompany.objects.filter(company_detail_id=company_detail_id,sub_company_id=sub_company_id)

        if sub_company_id:
            default_accessory= DefaultAccessoryProvidedByCompany.objects.filter(sub_company_id=sub_company_id)
            
        default_accessory_serializer = DefaultAccessoryProvidedByCompanyListSerializer(default_accessory, many=True)
        return Response(default_accessory_serializer.data)



# DropDown
class FineCollectedByListView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        company_detail_id = request.user.company_detail_id
        sub_company_id = request.user.sub_company_id

        if company_detail_id:
            fine_collected = FineCollectedBy.objects.filter(company_detail_id=company_detail_id,sub_company_id=sub_company_id)

        if sub_company_id:
            fine_collected= FineCollectedBy.objects.filter(sub_company_id=sub_company_id)
            
        fine_collected_serializer = FineCollectedByListSerializer(fine_collected, many=True)
        return Response(fine_collected_serializer.data)
    


#Dropdown
class ApprovalChangeByNumberOfDaysListView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        company_detail_id = request.user.company_detail_id
        sub_company_id = request.user.sub_company_id

        if company_detail_id:
            approval_change = ApprovalChangeByNumberOfDays.objects.filter(company_detail_id=company_detail_id,sub_company_id=sub_company_id)

        if sub_company_id:
            approval_change= ApprovalChangeByNumberOfDays.objects.filter(sub_company_id=sub_company_id)
            
        approval_change_serializer = ApprovalChangeByNumberOfDaysListSerializer(approval_change, many=True)
        return Response(approval_change_serializer.data)


class GetRolesAndPermissionView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request):
        get_user_data = getUserDataLogin(request.user.id)  
        if get_user_data['company_detail']['account_validity'] == True:
            AccessToPage = False
            if 'roles_permission' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['roles_permission']:
                    AccessToPage = True

            if AccessToPage == True:
                sub_company_detail_id = None
                if len(get_user_data['sub_company']) > 0:
                    sub_company_detail_id = get_user_data['sub_company']['id']
                user_role = get_user_data['role_detail']['id']

                # Fetch the role that belongs to the logged-in user
                role = Roles.objects.filter(id=user_role, company_detail_id = get_user_data['company_detail']['id'], sub_company_id = sub_company_detail_id).first()

                if role is not None:
                    # Create a dictionary to store permissions
                    permissions_dict = {}

                    role_permissions = role.permission_set.select_related('menu_page_id', 'action_id').all()

                    for permission in role_permissions:
                        menu_page_id = permission.menu_page_id.id
                        menu_name = permission.menu_page_id.menu_name
                        action_id = permission.action_id.id
                        action_name = permission.action_id.action_name

                        if menu_page_id not in permissions_dict:
                            permissions_dict[menu_page_id] = {
                                'menu_page_id': menu_page_id,
                                'menu_name': menu_name,
                                'action': []
                            }

                        # Check if the action already exists for this menu
                        action_exists = next((act for act in permissions_dict[menu_page_id]['action'] if act['action_id'] == action_id), None)

                        if not action_exists:
                            permissions_dict[menu_page_id]['action'].append({
                                'action_id': action_id,
                                'action_name': action_name
                            })

                    # Convert the permissions_dict to a list of permissions
                    permissions = list(permissions_dict.values())

                    return Response({'role_name' : role.role_name,'permission': permissions})
                else:
                    return Response({"submit": "Role not found."}, status=status.HTTP_404_NOT_FOUND)
            else:
                return Response({"submit": "You don't have permissions to access."}, status=status.HTTP_403_FORBIDDEN)
        else:
            return Response({"submit": "Account validity has expired."}, status=status.HTTP_400_BAD_REQUEST)



# DropDown
class SubCompanyListViewDetail(APIView):

    def get(self, request, id):
        sub_company = SubCompany.objects.filter(company_detail_id=id).all()
        sub_company_serializer = SubCompanyListSerializer(sub_company, many=True)
        return Response(sub_company_serializer.data)


#OTP view

class SendOTP(APIView):
    def post(self, request):
        email = request.data.get('email')
        
        if not email:
            return Response({"error": "Email is required."}, status=status.HTTP_400_BAD_REQUEST)
        
        if User.objects.filter(email=email).exists():
            # Generate a random 6-digit OTP
            print(User.objects.get(email=email).is_verified)
            if User.objects.get(email=email).is_verified == False:
                otp = ''.join([str(random.randint(0, 9)) for _ in range(6)])

                user = User.objects.filter(email=email).first()

                # Store OTP in your database
                otp_instance, created = OTP.objects.get_or_create(user=user, email=email, defaults={'otp': otp, 'otp_validity': datetime.now()})
                if not created:
                    otp_instance.otp = otp
                    otp_instance.otp_validity = datetime.now()
                    otp_instance.save()

                # Send OTP via email
                # subject = 'OTP Verification for VMS'
                # message = f'Your OTP is: {otp}'
                # from_email = 'anprsolutionsllp@gmail.com'
                # recipient_list = [email]
                
                # send_mail(subject, message, from_email, recipient_list)
                context = {'otp': otp}
                email_html = render_to_string('emails.html', context)
                send_mail(
                    'OTP Verification for VMS',
                    '',
                    'anprsolutionsllp@gmail.com',
                    [email],
                    html_message=email_html,
                    fail_silently=False,
                )

                return Response({"submit": "OTP sent successfully."}, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "Your email is already verified."})
        else:
            return Response({"email": "Email not found."}, status=status.HTTP_400_BAD_REQUEST)


class VerifyOTP(APIView):

    def post(self, request):
        email = request.data.get('email')
        otp = request.data.get('otp')

        if not email or not otp:
            return Response({"submit": "Email and OTP are required."}, status=status.HTTP_400_BAD_REQUEST)
        
        user = User.objects.filter(email=email).first()

        if user:
            otp_model = OTP.objects.filter(email=email).last()
            if otp_model.otp == otp:
                # current_time = datetime.now()
                # time_difference = (current_time - otp_model.otp_validity).total_seconds() / 60
                # print("time", time_difference)
                # if time_difference > 11:
                diff = None
                try:
                    diff = datetime.strptime(str(datetime.now()), '%Y-%m-%d %H:%M:%S.%f') - datetime.strptime(str(otp_model.otp_validity), '%Y-%m-%d %H:%M:%S.%f+00:00')
                except Exception as e:
                    diff = datetime.strptime(str(datetime.now()), '%Y-%m-%d %H:%M:%S.%f') - datetime.strptime(str(otp_model.otp_validity), '%Y-%m-%d %H:%M:%S+00:00') 

                print(int(diff.total_seconds() / 60.0))
                if int(diff.total_seconds() / 60.0) <= 10:
                    otp_model.is_verified = True
                    user.is_verified = True
                    otp_model.save()
                    user.save()
                    return Response({"submit": "OTP verified successfully."}, status=status.HTTP_200_OK)
                else:
                    return Response({"submit": "OTP expired."}, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "Invalid OTP."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"submit": "This email is not registered."}, status=status.HTTP_400_BAD_REQUEST)
        
class FreeTrailView(APIView):
    permission_classes = (AllowAny,)

    def post(self, request):        
        data = request.data
        total_price = 0.0
        days_total_price = 0.0
        discount_amount = 0.0
        total_price_after_discount = 0.0
        days_total_price_after_discount = 0.0
        total_price_after_tax = 0.0
        total_tax_in_currency = 0.0
        total_tax_percentage = 0.0  
        days_total_price_after_tax = 0.0
        if 'user_detail' not in data or 'email' not in data['user_detail']:
            return Response({'error': 'Email is required in user_detail'}, status=status.HTTP_400_BAD_REQUEST)

        email = data['user_detail']['email']

        currency_detail = Currency.objects.filter(currency_type=request.data['currency_type']).values('id','currency_type','currency_symbol').first()
        print("currdet",currency_detail)
        created_objects = []
        company_detail = request.data.get('company_detail', {})
        company_name = company_detail.get('company_name')
        country = company_detail.get('country')
        uses_type = company_detail.get('uses_type')
        company_type = company_detail.get('company_type')
        currency_detail = company_detail.get('currency')
        print("cd",currency_detail)
        company_detail = data['company_detail']
        company_detail_data = {
            'company_name': company_name,
            'country': country,
            'uses_type': uses_type,
            'company_type': company_type,
            'start_date_time': datetime.now(),
            'end_date_time': datetime.now() + timedelta(days=15),
            'days_to_expire': 15,
            'account_validity': True,
            'accessory_provide': True,
            'currency_id': currency_detail 
        }
        print(company_detail_data)
        company_serializer = CompanyDetailSerializer(data=company_detail_data)
        company_id = None
        if company_serializer.is_valid():
            company_obj = company_serializer.save()
            company_id = company_obj.id
            created_objects.insert(0, company_obj)
            
        else:
            for obj in reversed(created_objects):
                    obj.delete()
            return Response(company_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        # if business_serializer.is_valid():
        #     business_obj = business_serializer.save()
        #     business_id = business_obj.id
        # else:
        #     return Response(business_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        
        role_detail = {'role_name': 'Admin', 'company_detail_id': company_id}
        role_serializer = RolesSerializer(data=role_detail)
        if role_serializer.is_valid():
            role_obj = role_serializer.save()
            role_id = role_obj.id
            print(role_id)
            #created_objects.append(role_obj)
            created_objects.insert(1, role_obj)
        else:
            # for obj in created_objects:
            #     obj.delete()
            #created_objects[0].delete()
            for obj in reversed(created_objects):
                    obj.delete()
            return Response(role_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        print(role_serializer)
        # role_detail = {'role_name': 'Admin', 'business_detail_id': business_id}

        # role_serializer = RolesSerializer(data=role_detail)
        # role_id = None
        # if role_serializer.is_valid():
        #     role_obj = role_serializer.save()
        #     role_id = role_obj.id
        # else:
        #     BusinessDetail.objects.filter(id=business_id).delete()
        #     return Response(role_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        permission_ids = []
        get_menu_data = MenuPage.objects.exclude(is_menu_type_id__is_menu_visible='SuperAdmin').all().values('id',
                                                                                                             'menu_name')
        print("get_menu_data", get_menu_data)
        # for perm in range(len(PermissionDetail)):
        for menus in get_menu_data:
            get_menu_action_data = MenuActionMap.objects.filter(menu_page_id=menus['id'], role_type = 'Visitor').values('id',
                                                                                                  'menu_page_id',
                                                                                                        'action_id').all()
            print(get_menu_action_data)
            for menu_action in get_menu_action_data:
                print("menu_action", menu_action)
                permission_serializer = PermissionSerializer(
                    data={'role_id': role_id, 'menu_page_id': menu_action['menu_page_id'],
                          'action_id': menu_action['action_id']})
        # permission_ids = []
        # get_menu_data = MenuPage.objects.exclude(is_menu_type__is_menu_visible='SuperAdmin').all().values('id', 'menu_name')
        # print(get_menu_data)
        # for menu in get_menu_data:
        #     #get_menu_action_data = MenuActionMap.objects.filter(menu_page=menu['id']).values('id', 'menu_page', 'action').all()
        #     get_menu_action_data = MenuActionMap.objects.filter(menu_page=menu['id'], plan_id=1).values('id', 'menu_page', 'action').all()
        #     print(get_menu_action_data)
        #     for menu_action in get_menu_action_data:
            
                # permission_serializer = PermissionSerializer(data={'role': role_id, 'menu_page': menu_action['menu_page'], 'action': menu_action['action']})
                # if permission_serializer.is_valid():
                #     permission_obj = permission_serializer.save()
                #     permission_ids.append(permission_obj.id)
                # else:
                #     BusinessDetail.objects.filter(id=business_id).delete()
                #     Roles.objects.filter(id=role_id).delete()
                #     AddUserEmail.objects.filter(id=add_user_email_id).delete()
                #     for permission_id in permission_ids:
                #         Permission.objects.filter(id=permission_id).delete()
                #     return Response(permission_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                permission_serializer = PermissionSerializer(
                    data={'role_id': role_id, 'menu_page_id': menu_action['menu_page_id'],
                          'action_id': menu_action['action_id']})
                #permission_serializer = PermissionSerializer(data={'role': role_id, 'menu_page': menu_action['menu_page'], 'action': menu_action['action']})
                if permission_serializer.is_valid():
                    permission_obj = permission_serializer.save()
                    permission_ids.append(permission_obj.id)
                    
                    #created_objects.append(permission_obj)
                    created_objects.insert(2, permission_obj)
                else:
                    # for obj in created_objects:
                    #     obj.delete()
                    # role_obj.delete()
                    # business_obj.delete()
                    for obj in reversed(created_objects):
                        obj.delete()
                    return Response(permission_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

                print("ps",permission_serializer)
        
        # add_user_email_serializer = AddUserEmailSerializer(data={'email': data['user_detail']['email'], 'role': role_id, 'business_detail_id': business_id})
        # add_user_email_id = None
        # if add_user_email_serializer.is_valid():
        #     add_user_email_obj = add_user_email_serializer.save()
        #     add_user_email_id = add_user_email_obj.id
        # else:
        #     for permission_id in permission_ids:
        #         Permission.objects.filter(id=permission_id).delete()
        #     Roles.objects.filter(id=role_id).delete()
        #     BusinessDetail.objects.filter(id=business_id).delete()
        #     return Response(add_user_email_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        add_user_email_serializer = AddUserEmailSerializer(data={'email': data['user_detail']['email'], 'role_id': role_id, 'company_detail_id': company_id})
       # add_user_email_serializer = AddUserEmailSerializer(data={'email': data['user_detail']['email'], 'role': role_id, 'company_detail_id': company_id})
        add_user_email_id = None
        if add_user_email_serializer.is_valid():
            add_user_email_obj = add_user_email_serializer.save()
            add_user_email_id = add_user_email_obj.id
            #created_objects.append(add_user_email_obj)
            created_objects.insert(3, add_user_email_obj)
        else:
            # for obj in created_objects:
            #     obj.delete()
            # for obj in created_objects[:3]:
            #     obj.delete()
            for obj in reversed(created_objects):
                    obj.delete()
            return Response(add_user_email_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        # add_user_emails = AddUserEmail.objects.filter(email=request.data['email']).values('email','role','business_detail_id').first()
        # if add_user_emails != None:
        #     business_detail_id = add_user_emails.get('business_detail_id')
        get_company_detail = CompanyDetail.objects.filter(id=company_id).first() 
        # data={'email': request.data['email'],
        #                   'password': request.data['password'],
        #                   'password2': request.data['password2'],
        #                   'company_detail_id': int(add_user_emails.get('company_detail_id')),
        #                   'sub_company_id': sub_id,
        #                   'user_login_or_not': False,
        #                   'is_superuser': False,
        #                   'is_active': True,
        #                   "time_zone": "India",
        #                   "is_staff": True,
        #                   "user_type": "Admin"})
        print("Request data:", data)
        user_data = {
            'email': email,
            'phone_number': data['user_detail'].get('phone_number', None),
            'password': data['user_detail'].get('password', None),
            'password2': data['user_detail'].get('password2', None),         
            'company_detail_id': company_id,
            'is_superuser': False,
            'is_active': False,
            'user_login_or_not': False,
            "time_zone": "India",
            "is_staff": False,
            "user_type": "Visitor"
        }
        print("User data:", user_data)

        serializer = UserSerializer(data=user_data)

        #serializer = UserSerializer(data={'email':request.data['email'],'phone_number':request.data['phone_number'],'password':request.data['password'],'password2':request.data['password2'],'business_detail_id': business_id,'user_login_or_not':False,'is_superuser':False,'is_active':False})
        #user_id = None
        # if serializer.is_valid():
        #     obj = serializer.save()
        #     user_id = obj.id
        # else:
        #     print("Serializer errors:", serializer.errors)
        #     AddUserEmail.objects.filter(id=add_user_email_id).delete()
        #     for permission_id in permission_ids:
        #         Permission.objects.filter(id=permission_id).delete()
        #     Roles.objects.filter(id=role_id).delete()
        #     BusinessDetail.objects.filter(id=business_id).delete()
        #     return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        if serializer.is_valid():
            obj = serializer.save()
            user_id = obj.id
            #created_objects.append(obj)
            created_objects.insert(4, obj)
        else:
            # for obj in created_objects:
            #     obj.delete()
            # for obj in created_objects[:4]:
            #     obj.delete()
            for obj in reversed(created_objects):
                     obj.delete()
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        user_role_map_serializer = UserRoleMappingSerializer(data={'user_id':user_id,'role_id':role_id,'company_detail_id': company_id})
        user_role_map_id = None
        # if user_role_map_serializer.is_valid():
        #     obj = user_role_map_serializer.save()
        #     user_role_map_id = obj.id
        # else:
        #     User.objects.filter(id=user_id).delete()
        #     AddUserEmail.objects.filter(id=add_user_email_id).delete()
        #     for permission_id in permission_ids:
        #         Permission.objects.filter(id=permission_id).delete()
        #     Roles.objects.filter(id=role_id).delete()
        #     BusinessDetail.objects.filter(id=business_id).delete()
        #     #return Response(user_role_map_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        #     return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        if user_role_map_serializer.is_valid():
            obj = user_role_map_serializer.save()
            #created_objects.append(obj)
            user_role_map_id = obj.id
            created_objects.insert(5, obj)
        else:
            # for obj in created_objects:
            #     obj.delete()
            # for obj in created_objects[:5]:
            #     obj.delete()
            for obj in reversed(created_objects):
                    obj.delete()
            return Response(user_role_map_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        plans_detail = data['plans_detail']
        get_plan = Plans.objects.filter(id=plans_detail['id'],plan_name='free trail').first()
        if get_plan != None:
            id = get_plan.id
            plan_name = get_plan.plan_name
            get_plan_days_and_discount = PlanDaysAndDiscount.objects.filter(plan_id=id,default_select=True).first()

            if get_plan_days_and_discount != None:
                plans_data= []
                plan_days = get_plan_days_and_discount.plan_days
                parking_product_data = PlanFeaturePricingTier.objects.filter(plan_id=id,pricing_feature_category_id__category_name="Product",default_product_id__product_name='Visitor management system').values('id','uuid','default_product_id','default_product_id__product_name','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                all_product_total_price = 0.0
                if parking_product_data != None:

                    # plan_features_pricing_tier_camera = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Camera').values('id','uuid','min_quantity','max_quantity','default_quantity','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                    # camera_quantity = 1
                    # if plan_features_pricing_tier_camera != None:
                    #     camera_quantity = plan_features_pricing_tier_camera['default_quantity']
                    
                    product_data_json = {}
                    # product_data_json['id'] = parking_product_data['id']
                    # product_data_json['product_name'] = 'Parking Management'

                    product_selected_exist = True
                    default_product_price = 0.0
                    default_product_price_days = 0.0
                    plans_data.append({
                        'price':default_product_price,
                        'days_price':default_product_price_days,
                        'currency_id':currency_detail,
                        'default_product_id':parking_product_data['default_product_id'],
                        'plan_feature_pricing_category_id':parking_product_data['pricing_feature_category_id'],
                        'category_name':parking_product_data['pricing_feature_category_id__category_name'],
                        'plan_id':id,
                        'plan_feature_pricing_tier_id':parking_product_data['id'],
                        'company_detail_id':company_id,
                        'plan_pricing_description':parking_product_data['plan_pricing_description']
                    })
                    
                    default_parking_product_feature_data = PlanFeaturePricingTier.objects.filter(plan_id=id,pricing_feature_category_id__category_name="Feature",default_product_id=parking_product_data['default_product_id'],is_encluded_plan_feature_id__isnull=False,default_product_feature_id__isnull=False).values('id','uuid','default_product_id','default_product_id__product_name','default_product_feature_id','default_product_feature_id__feature','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').all()
                    product_data_json['plan_product_feature_default'] = []
                    for default_product_feature in default_parking_product_feature_data:
                        plans_data.append({
                            'price':0.0,
                            'days_price':0.0,
                            'currency_id':currency_detail['id'],
                            'default_product_id':parking_product_data['default_product_id'],
                            'default_product_feature_id':default_product_feature['default_product_feature_id'],
                            'plan_feature_pricing_category_id':default_product_feature['pricing_feature_category_id'],
                            'category_name':default_product_feature['pricing_feature_category_id__category_name'],
                            'plan_id':id,
                            'plan_feature_pricing_tier_id':default_product_feature['id'],
                            'company_detail_id':company_id,
                            'plan_pricing_description':default_product_feature['plan_pricing_description']
                        })
                        
                    parking_product_feature_data = PlanFeaturePricingTier.objects.filter(plan_id=id,pricing_feature_category_id__category_name="Feature",default_product_id=parking_product_data['default_product_id'],is_encluded_plan_feature_id__isnull=True,default_product_feature_id__isnull=False).values('id','uuid','default_product_id','default_product_id__product_name','default_product_feature_id','default_product_feature_id__feature','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').all()
                    product_data_json['plan_product_feature'] = []
                    default_product_feature_price = 0.0
                    for product_feature in parking_product_feature_data:
                        plan_feature_days_price_product_feature = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=product_feature['id'],currency_id=currency_detail).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                        for feature in plan_feature_days_price_product_feature:
                            if plan_feature_days_price_product_feature['default_selected'] == True:
                                product_feature_price = 0.0
                                product_feature_price_days = 0.0
                                plans_data.append({
                                    'price':0.0,
                                    'days_price':0.0,
                                    'currency_id':currency_detail,
                                    'default_product_id':parking_product_data['default_product_id'],
                                    'default_product_feature_id':product_feature['default_product_feature_id'],
                                    'plan_feature_pricing_category_id':product_feature['pricing_feature_category_id'],
                                    'category_name':product_feature['pricing_feature_category_id__category_name'],
                                    'plan_id':id,
                                    'plan_feature_pricing_tier_id':product_feature['id'],
                                    'company_detail_id':company_id,
                                    'plan_pricing_description':product_feature['plan_pricing_description']
                                })
                            

                    # plan_feature_days_price_camera = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount['id'],plan_feature_pricing_tier_id=plan_features_pricing_tier_camera['id'],currency_id=currency_detail['id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol').first()
                    # camera_price = plan_days * camera_quantity * plan_feature_days_price_camera['days_price']
                    # camera_price_days = camera_quantity * plan_feature_days_price_camera['days_price']
                    # plans_data.append({
                    #     'quantity':camera_quantity,
                    #     'price':camera_price,
                    #     'days_price':camera_price_days,
                    #     'currency_id':currency_detail['id'],
                    #     'default_product_id':parking_product_data['default_product_id'],
                    #     'plan_feature_pricing_category_id':plan_features_pricing_tier_camera['pricing_feature_category_id'],
                    #     'category_name':plan_features_pricing_tier_camera['pricing_feature_category_id__category_name'],
                    #     'plan_id':id,
                    #     'plan_feature_pricing_tier_id':plan_features_pricing_tier_camera['id'],
                    #     'company_detail':company_id,
                    #     'plan_pricing_description':plan_features_pricing_tier_camera['plan_pricing_description']
                    # })
                    # # plan_features_pricing_tier_parking_slot = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Parking Slot').values('id','uuid','min_quantity','max_quantity','default_quantity','default_product_id','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                    # # parking_slot = 1
                    # # if plan_features_pricing_tier_parking_slot != None:
                    # #     parking_slot = plan_features_pricing_tier_parking_slot['default_quantity']
                    # # default_parking_slot_price = 0.0
                    # # praking_slot_days_price = 0.0
                    # # plans_data.append({
                    # #     'quantity':parking_slot,
                    # #     'price':default_parking_slot_price,
                    # #     'days_price':praking_slot_days_price,
                    # #     'currency_id':currency_detail['id'],
                    # #     'default_product_id':parking_product_data['default_product_id'],
                    # #     'plan_feature_pricing_category_id':plan_features_pricing_tier_parking_slot['pricing_feature_category_id'],
                    # #     'category_name':plan_features_pricing_tier_parking_slot['pricing_feature_category_id__category_name'],
                    # #     'plan_id':id,
                    # #     'plan_feature_pricing_tier_id':plan_features_pricing_tier_parking_slot['id'],
                    # #     'business_detail_id':business_id,
                    # #     'plan_pricing_description':plan_features_pricing_tier_parking_slot['plan_pricing_description']
                    # # })
                    
                    # plan_features_pricing_tier_online_dashboard = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Online Dashboard').values('id','uuid','default_product_id','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                    # online_dashboard_price = 0.0
                    # days_online_dashboard_price = 0.0
                    # plans_data.append({
                    #     'quantity':camera_quantity,
                    #     'price':online_dashboard_price,
                    #     'days_price':days_online_dashboard_price,
                    #     'currency_id':currency_detail['id'],
                    #     'default_product_id':parking_product_data['default_product_id'],
                    #     'plan_feature_pricing_category_id':plan_features_pricing_tier_online_dashboard['pricing_feature_category_id'],
                    #     'category_name':plan_features_pricing_tier_online_dashboard['pricing_feature_category_id__category_name'],
                    #     'plan_id':id,
                    #     'plan_feature_pricing_tier_id':plan_features_pricing_tier_online_dashboard['id'],
                    #     'company_detail':company_id,
                    #     'plan_pricing_description':plan_features_pricing_tier_online_dashboard['plan_pricing_description']
                    # })

                    # plan_features_pricing_tier_online_dashboard_data_backup = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Online Data Backup').values('id','uuid','default_product_id','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                    # plan_feature_days_price_online_dashboard_data_backup = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount['id'],plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard['id'],currency_id=currency_detail['id'],default_selected=True).values('id','uuid','backup_days_id','backup_days_id__days','backup_days_id__category','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').first()
                    # online_data_backup_price = 0.0
                    # days_online_data_backup_price = 0.0
                    # plans_data.append({
                    #     'backup_days_id':plan_feature_days_price_online_dashboard_data_backup['backup_days_id'],
                    #     'backup_days':plan_feature_days_price_online_dashboard_data_backup['backup_days_id__days'],
                    #     'quantity':camera_quantity,
                    #     'price':online_data_backup_price,
                    #     'days_price':days_online_data_backup_price,
                    #     'currency_id':currency_detail['id'],
                    #     'default_product_id':parking_product_data['default_product_id'],
                    #     'plan_feature_pricing_category_id':plan_features_pricing_tier_online_dashboard_data_backup['pricing_feature_category_id'],
                    #     'category_name':plan_features_pricing_tier_online_dashboard_data_backup['pricing_feature_category_id__category_name'],
                    #     'plan_id':id,
                    #     'plan_feature_pricing_tier_id':plan_features_pricing_tier_online_dashboard_data_backup['id'],
                    #     'company_detail':company_id,
                    #     'plan_pricing_description':plan_features_pricing_tier_online_dashboard_data_backup['plan_pricing_description']
                    # })

                    # plan_features_pricing_tier_offline_dashboard = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Offline Dashboard').values('id','uuid','default_product_id','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                    # offline_dashboard_price = 0.0
                    # days_offline_dashboard_price = 0.0
                    # plans_data.append({
                    #     'quantity':camera_quantity,
                    #     'price':offline_dashboard_price,
                    #     'days_price':days_offline_dashboard_price,
                    #     'currency_id':currency_detail['id'],
                    #     'default_product_id':parking_product_data['default_product_id'],
                    #     'plan_feature_pricing_category_id':plan_features_pricing_tier_offline_dashboard['pricing_feature_category_id'],
                    #     'category_name':plan_features_pricing_tier_offline_dashboard['pricing_feature_category_id__category_name'],
                    #     'plan_id':id,
                    #     'plan_feature_pricing_tier_id':plan_features_pricing_tier_offline_dashboard['id'],
                    #     'company_detail':company_id,
                    #     'plan_pricing_description':plan_features_pricing_tier_offline_dashboard['plan_pricing_description']
                    # })

                    # plan_features_pricing_tier_offline_dashboard_data_backup = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Offline Data Backup').values('id','uuid','default_product_id','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                    # plan_feature_days_price_offline_dashboard_data_backup = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount['id'],plan_feature_pricing_tier_id=plan_features_pricing_tier_offline_dashboard['id'],currency_id=currency_detail['id'],default_selected=True).values('id','uuid','backup_days_id','backup_days_id__days','backup_days_id__category','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').first()
                    # offline_data_backup_price = 0.0
                    # days_offline_data_backup_price = 0.0
                    # plans_data.append({
                    #     'backup_days_id':plan_feature_days_price_offline_dashboard_data_backup['backup_days_id'],
                    #     'backup_days':plan_feature_days_price_offline_dashboard_data_backup['backup_days_id__days'],
                    #     'quantity':camera_quantity,
                    #     'price':offline_data_backup_price,
                    #     'days_price':days_offline_data_backup_price,
                    #     'currency_id':currency_detail['id'],
                    #     'default_product_id':parking_product_data['default_product_id'],
                    #     'plan_feature_pricing_category_id':plan_features_pricing_tier_offline_dashboard_data_backup['pricing_feature_category_id'],
                    #     'category_name':plan_features_pricing_tier_offline_dashboard_data_backup['pricing_feature_category_id__category_name'],
                    #     'plan_id':id,
                    #     'plan_feature_pricing_tier_id':plan_features_pricing_tier_offline_dashboard_data_backup['id'],
                    #     'company_detail':company_id,
                    #     'plan_pricing_description':plan_features_pricing_tier_offline_dashboard_data_backup['plan_pricing_description']
                    # })

                plan_start_datetime = timezone.datetime.now()
                plan_expire_datetime = timezone.datetime.now() + timedelta(days=get_plan_days_and_discount.plan_days)
                time_diff = plan_expire_datetime - plan_start_datetime
                total_minutes = int(time_diff.total_seconds()/60)
                total_days = time_diff.days

                #get_plan_pricing = PlanPricing.objects.filter(plan_id=get_plan.id,currency_id=currency_detail['id']).values('id','country_type_id','country_type_id__country')
                get_plan_pricing = PlanPricing.objects.filter(plan_id=get_plan.id, currency_id=currency_detail).first()

                currency_id = currency_detail  


                currency_obj = Currency.objects.get(id=currency_id)
                business_plan_history = {
                    'plan_name':get_plan.plan_name,
                    'price':total_price,
                    'price_after_discount':total_price_after_discount,
                    'price_after_tax':total_price_after_tax,
                    'days_price':days_total_price,
                    'days_price_after_discount': days_total_price_after_discount,
                    'days_price_after_tax': days_total_price_after_tax,
                    'currency_id':currency_id,
                    'currency_type':currency_obj.currency_type,
                    'currency_symbol':currency_obj.currency_symbol,
                    'country_category_id':get_plan_pricing.country_type_id.id,
                    'country_type':get_plan_pricing.country_type_id.country,
                    'plan_id':get_plan.id,
                    'plan_days_and_discount_id':get_plan_days_and_discount.id,
                    'plan_days':get_plan_days_and_discount.plan_days,
                    'discount_in_percentage':get_plan_days_and_discount.discount_percentage,
                    'discount_in_currency': discount_amount,
                    'total_discount': total_price_after_discount,
                    'total_tax_in_percentage':total_tax_percentage,
                    'total_tax_in_currency':total_tax_in_currency,
                    'buy_datetime':timezone.datetime.now(),
                    'plan_start_datetime':timezone.datetime.now(),
                    #'plan_expire_datetime': datetime.datetime.now()+get_plan_days_and_discount.plan_days,
                    'plan_expire_datetime': timezone.datetime.now() + timedelta(days=get_plan_days_and_discount.plan_days),
                    'minutes_to_expire':total_minutes,
                    'days_to_expire':total_days,
                    'plan_validity':True,
                    'plan_status':'active',
                    'current_active':True,
                    'plan_type':'Free Trail',
                    'company_detail_id':company_id,
                    'payment_status': True
                }
                print("businessplanhistory",business_plan_history)
                # if get_plan_pricing:
                #     business_plan_history['country_category_id'] = get_plan_pricing.country_type_id
                #     business_plan_history['country_type'] = get_plan_pricing.country_type_id__country
                business_plan_history_serializer = BusinessPlanHistorySerializer(data=business_plan_history)
                business_plan_history_id = None
                if business_plan_history_serializer.is_valid():
                    business_plan_history_obj = business_plan_history_serializer.save()
                    business_plan_history_id = business_plan_history_obj.id
                    print(business_plan_history_serializer)
                else:
                    for obj in reversed(created_objects):
                                obj.delete()
                    UserRoleMapping.objects.filter(id=user_role_map_id).delete()
                    User.objects.filter(id=user_id).delete()
                    AddUserEmail.objects.filter(id=add_user_email_id).delete()
                    for permission_id in permission_ids:
                        Permission.objects.filter(id=permission_id).delete()
                    Roles.objects.filter(id=role_id).delete()
                    CompanyDetail.objects.filter(id=company_id).delete()
                    return Response(business_plan_history_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                business_pricing_tier_ids = []
                for plans in plans_data:
                    plans['business_plan_history_id'] = business_plan_history_id
                    business_pricing_tier_serializer = BusinessPricingTierSerializer(data=plans)
                    business_pricing_tier_id = None
                    print("businesspricingtierser",business_pricing_tier_serializer)
                    if business_pricing_tier_serializer.is_valid():
                        business_pricing_tier_obj = business_pricing_tier_serializer.save()
                        business_pricing_tier_id = business_pricing_tier_obj.id
                        business_pricing_tier_ids.append(business_pricing_tier_id)
                    else:
                        for obj in reversed(created_objects):
                                obj.delete()
                        for business_pricing_id in business_pricing_tier_ids:
                            BusinessPricingTier.objects.filter(id=business_pricing_id).delete()
                        BusinessPlanHistory.objects.filter(id=business_plan_history_id).delete()
                        UserRoleMapping.objects.filter(id=user_role_map_id)
                        User.objects.filter(id=user_id).delete()
                        AddUserEmail.objects.filter(id=add_user_email_id).delete()
                        for permission_id in permission_ids:
                            Permission.objects.filter(id=permission_id).delete()
                        Roles.objects.filter(id=role_id).delete()
                        CompanyDetail.objects.filter(id=company_id).delete()
                        return Response(business_pricing_tier_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                return Response({"detail": "Plans processed successfully."}, status=status.HTTP_201_CREATED)

            
            else:
                for obj in reversed(created_objects):
                                obj.delete()
                return Response({"detail": "Plans days doesn't exist."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            for obj in reversed(created_objects):
                                obj.delete()
            return Response({"detail": "Plans not exist."}, status=status.HTTP_400_BAD_REQUEST)
        
class BuyPlanView(APIView):
    permission_classes = (AllowAny,)
    #template_name = 'autopay.html'

    # def get(self, request, *args, **kwargs):
    #     return render(request, self.template_name)
    def post(self, request):
        all_product_total_price = 0.0
        default_product_price = 0.0
        default_product_price_days=0.0
        total_price_after_discount = 0.0        
        total_price = 0.0
        default_product_feature_price = 0.0
        total_tax_in_currency = 0.0
        total_tax_percentage = 0.0
        days_total_price=0.0
        discount_amount=0.0
        data = request.data
        # currency_type = request.data.get('currency_type')
        # currency_detail = Currency.objects.filter(currency_type=currency_type).values('id', 'currency_type', 'currency_symbol').first()
        # currency_detail = Currency.objects.filter(currency_type=request.data['currency_type']).values('id','currency_type','currency_symbol').first()
        
        company_detail = data['company_detail']
   
        created_objects = []

        # currency_detail = Currency.objects.filter(currency_type=request.data['currency_type']).values('id','currency_type','currency_symbol').first()
        #print("currdet",currency_detail)
        created_objects = []
        company_detail = request.data.get('company_detail', {})
        company_name = company_detail.get('company_name')
        country = company_detail.get('country')
        uses_type = company_detail.get('uses_type')
        company_type = company_detail.get('company_type')
        currency_detail = company_detail.get('currency')
        print("cd",currency_detail)
        company_detail = data['company_detail']
        company_detail_data = {
            'company_name': company_name,
            'country': country,
            'uses_type': uses_type,
            'company_type': company_type,
            'start_date_time': datetime.now(),
            'end_date_time': datetime.now() + timedelta(days=15),
            'days_to_expire': 15,
            'account_validity': True,
            'accessory_provide': True,
            'currency_id': currency_detail 
        }
           
        company_serializer = CompanyDetailSerializer(data=company_detail_data)
        if company_serializer.is_valid():
            company_obj = company_serializer.save()
            company_id = company_obj.id
            #created_objects.append(business_obj)
            created_objects.insert(0, company_obj)
        else:
            for obj in reversed(created_objects):
                    obj.delete()
            return Response(company_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        
        role_detail = {'role_name': 'Admin', 'company_detail_id': company_id}
        role_serializer = RolesSerializer(data=role_detail)
        if role_serializer.is_valid():
            role_obj = role_serializer.save()
            role_id = role_obj.id
            #created_objects.append(role_obj)
            created_objects.insert(1, role_obj)
        else:
            # for obj in created_objects:
            #     obj.delete()
            #created_objects[0].delete()
            for obj in reversed(created_objects):
                    obj.delete()
            return Response(role_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        # Permission Serializer
        permission_ids = []
        
        permission_ids = []
        get_menu_data = MenuPage.objects.exclude(is_menu_type_id__is_menu_visible='SuperAdmin').all().values('id',
                                                                                                             'menu_name')
        print("get_menu_data", get_menu_data)
        # for perm in range(len(PermissionDetail)):
        for menus in get_menu_data:
            get_menu_action_data = MenuActionMap.objects.filter(menu_page_id=menus['id'], role_type = 'Visitor').values('id',
                                                                                                  'menu_page_id',
                                                                                                        'action_id').all()

            for menu_action in get_menu_action_data:
                permission_serializer = PermissionSerializer(
                    data={'role_id': role_id, 'menu_page_id': menu_action['menu_page_id'],
                        'action_id': menu_action['action_id']})
                if permission_serializer.is_valid():
                    permission_obj = permission_serializer.save()
                    permission_ids.append(permission_obj.id)
                    #created_objects.append(permission_obj)
                    created_objects.insert(2, permission_obj)
                else:
                    # for obj in created_objects:
                    #     obj.delete()
                    # role_obj.delete()
                    # business_obj.delete()
                    for obj in reversed(created_objects):
                        obj.delete()
                    return Response(permission_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        # Add User Email Serializer
        add_user_email_serializer = AddUserEmailSerializer(data={'email': data['user_detail']['email'], 'role_id': role_id, 'company_detail_id': company_id})
        if add_user_email_serializer.is_valid():
            add_user_email_obj = add_user_email_serializer.save()
            add_user_email_id = add_user_email_obj.id
            #created_objects.append(add_user_email_obj)
            created_objects.insert(3, add_user_email_obj)
        else:
            # for obj in created_objects:
            #     obj.delete()
            # for obj in created_objects[:3]:
            #     obj.delete()
            for obj in reversed(created_objects):
                    obj.delete()
            return Response(add_user_email_serializer.errors, status=status.HTTP_400_BAD_REQUEST)


        # serializer = UserSerializer(data={
        #     'email': request.data['user_detail']['email'],
        #     'phone_number': request.data['user_detail']['phone_number'],
        #     'password': request.data['user_detail']['password'],
        #     'password2': request.data['user_detail']['password2'],
        #     'company_detail': company_id,
        #     'user_login_or_not': False,
        #     'is_superuser': False,
        #     'is_active': False
        # })
        email = data['user_detail']['email']
        serializer = UserSerializer(data={
            'email': email,
            'phone_number': data['user_detail'].get('phone_number', None),
            'password': data['user_detail'].get('password', None),
            'password2': data['user_detail'].get('password2', None),         
            'company_detail_id': company_id,
            'is_superuser': False,
            'is_active': False,
            'user_login_or_not': False,
            "time_zone": "India",
            "is_staff": False,
            "user_type": "Visitor"
        })
        if serializer.is_valid():
            obj = serializer.save()
            user_id = obj.id
            #created_objects.append(obj)
            created_objects.insert(4, obj)
        else:
            # for obj in created_objects:
            #     obj.delete()
            # for obj in created_objects[:4]:
            #     obj.delete()
            for obj in reversed(created_objects):
                     obj.delete()
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        
        department_data = {
                'department_name': 'Admin',
                'company_detail_id': company_obj.id,
                'sub_company_id': None,
                'department_email': data['user_detail']['email']
            }
        department_serializer = DepartmentSerializer(data=department_data)
        if department_serializer.is_valid():
            department_obj = department_serializer.save()
            created_objects.insert(5, department_obj)
        else:
            for obj in reversed(created_objects):
                obj.delete()
            return Response(department_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        employee_data = {
                'name': 'Admin',
                'email': data['user_detail']['email'],
                'mobile_no': data['user_detail'].get('phone_number', None),
                'age': data['user_detail'].get('age', 30),
                'date_of_birth': '1994-06-15',
                'designation': 'Admin',
                'date_of_joining': datetime.now().date(),
                'visitor_allow': True,
                'department_id': department_obj.id,
                'company_detail_id': company_obj.id,
                'sub_company_id': None,
                'role_id': role_obj.id,
            #     'photo': 1
            }

        employee_serializer = EmployeeSerializer(data=employee_data)
        if employee_serializer.is_valid():
            employee_obj = employee_serializer.save()
            created_objects.insert(5, employee_obj)
        else:
            for obj in reversed(created_objects):
                obj.delete()
            return Response(employee_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

            # return Response({"success": "Plan, Company, User, and Employee created successfully."}, status=status.HTTP_201_CREATED)

            # except Exception as e:
            #     for obj in reversed(created_objects):
            #         obj.delete()
            #     return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        user_role_map_serializer = UserRoleMappingSerializer(data={'user_id':user_id,'role_id':role_id,'company_detail_id': company_id})
        if user_role_map_serializer.is_valid():
            obj = user_role_map_serializer.save()
            #created_objects.append(obj)
            user_role_map_id = obj.id
            created_objects.insert(5, obj)
        else:
            # for obj in created_objects:
            #     obj.delete()
            # for obj in created_objects[:5]:
            #     obj.delete()
            for obj in reversed(created_objects):
                    obj.delete()
            return Response(user_role_map_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        plans_detail = data['plans_detail']
        get_plan = Plans.objects.filter(id=plans_detail['id'],plan_name=plans_detail['plan_name']).first()
        if get_plan != None:
            id = get_plan.id
            plan_name = get_plan.plan_name
            #get_plan_days_and_discount = PlanDaysAndDiscount.objects.filter(plan_id=id,id=plans_detail['plan_days_id'],default_select=True).first()
            get_plan_days_and_discount = PlanDaysAndDiscount.objects.filter(plan_id=id,default_select=True).first()

            if get_plan_days_and_discount != None:
                plans_data= []
                plan_days = get_plan_days_and_discount.plan_days
                parking_product_data = PlanFeaturePricingTier.objects.filter(
                        plan_id=id,
                        pricing_feature_category_id__category_name="Product",
                        default_product_id__product_name='Visitor management system',
                        id=data['plans_detail']['plan_product'][0]['plan_feature_pricing_tier_id'],
                        show_plan_pricing=True
                    ).values('id', 'uuid', 'default_product_id', 'default_product_id__product_name', 'pricing_feature_category_id', 'pricing_feature_category_id__category_name', 'plan_id', 'plan_pricing_description', 'show_plan_pricing').first()
                if parking_product_data != None:
                    #plan_features_pricing_tier_camera = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data.default_product_id,pricing_feature_category_id__category_name='Camera').values('id','uuid','min_quantity','max_quantity','default_quantity','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                    # plan_features_pricing_tier_camera = PlanFeaturePricingTier.objects.filter(
                    #     plan_id=id,
                    #     default_product_id=parking_product_data['default_product_id'],
                    #     pricing_feature_category_id__category_name='Camera'
                    # ).first()
                    #print(plan_features_pricing_tier_camera)
                    # if parking_product_data is not None:
                    #     print(parking_product_data['default_product_id'])
                    # else:
                    #     print("No matching record found.")
                    product_data = plans_detail['plan_product'][0]
                    #product_data = data['plans_detail']['plan_product'][0]
                    
                    # camera_quantity = product_data['plan_camera_detail']['camera_quantity']

                    # parking_product_data = PlanFeaturePricingTier.objects.filter(plan_id=id,pricing_feature_category_id__category_name="Product",default_product_id__product_name='Visitor management system',id=data['plans_detail']['plan_product'][0]['plan_feature_pricing_tier_id'],show_plan_pricing=True).values('id','uuid','default_product_id','default_product_id__product_name','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                    # print("parking product data:", parking_product_data)
                    # #all_product_total_price = 0.0
                    # if parking_product_data != None:
                        #print(data)
                    plan_feature_days_price_product = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=parking_product_data['id'],currency_id=currency_detail).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                    
                    plan_feature_days_price_product_instance = plan_feature_days_price_product.first()
                    print("plan_feature_days_price_product_instance",plan_feature_days_price_product_instance)
                    if plan_feature_days_price_product_instance:
                           default_product_price = plan_days *  plan_feature_days_price_product_instance['days_price']
                           print("dpp",default_product_price)
                           default_product_price_days =  plan_feature_days_price_product_instance['days_price']
                    else:
                            #print("error in defaultproductprice")
                             default_product_price = 0 
                             default_product_price_days = 0
                    product_selected_exist = True
                       # default_product_price = plan_days * camera_quantity * plan_feature_days_price_product['days_price']
                        #default_product_price_days = camera_quantity * plan_feature_days_price_product['days_price']
                        #default_product_price_days = camera_quantity * plan_feature_days_price_product_instance.days_price
                    print("Value of plan_feature_pricing_category_id1:",
                            parking_product_data['pricing_feature_category_id'])

                    plans_data.append({
                        'price':default_product_price,
                        'days_price':default_product_price_days,
                        'currency_id':currency_detail,
                        'default_product_id':parking_product_data['default_product_id'],
                        'plan_feature_pricing_category_id':parking_product_data['pricing_feature_category_id'],
                        'category_name':parking_product_data['pricing_feature_category_id__category_name'],
                        'plan_id':id,
                        'plan_feature_pricing_tier_id':parking_product_data['id'],
                        'company_detail_id':company_id,
                        'plan_pricing_description':parking_product_data['plan_pricing_description']
                    })
                    default_parking_product_feature_data = PlanFeaturePricingTier.objects.filter(plan_id=id,pricing_feature_category_id__category_name="Feature",default_product_id__product_name='Visitor management system',is_encluded_plan_feature_id__isnull=False,default_product_feature_id__isnull=False).values('id','uuid','default_product_id','default_product_id__product_name','default_product_feature_id','default_product_feature_id__feature','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').all()

                    for default_product_feature in default_parking_product_feature_data:
                        print("Value of plan_feature_pricing_category_id2:",
                            default_product_feature['pricing_feature_category_id'])
                        plans_data.append({
                            'price':0.0,
                            'days_price':0.0,
                            'currency_id':currency_detail,
                            'default_product_id':parking_product_data['default_product_id'],
                            'default_product_feature_id':default_product_feature['default_product_feature_id'],
                            'plan_feature_pricing_category_id':default_product_feature['pricing_feature_category_id'],
                            'category_name':default_product_feature['pricing_feature_category_id__category_name'],
                            'plan_id':id,
                            'plan_feature_pricing_tier_id':default_product_feature['id'],
                            'company_detail_id':company_id,
                            'plan_pricing_description':default_product_feature['plan_pricing_description']
                        })

                        parking_product_feature_data = PlanFeaturePricingTier.objects.filter(plan_id=id,pricing_feature_category_id__category_name="Feature",default_product_id__product_name='Visitor management system',is_encluded_plan_feature_id__isnull=True,default_product_feature_id__isnull=False).values('id','uuid','default_product_id','default_product_id__product_name','default_product_feature_id','default_product_feature_id__feature','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').all()
                       
                        for product_feature in parking_product_feature_data:
                            plan_feature_days_price_product_feature = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=product_feature['id'],currency_id=currency_detail).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                            plan_feature_days_price_product_feature_instance = plan_feature_days_price_product_feature.first()  
                            if plan_feature_days_price_product_feature_instance:
                                product_feature_price = plan_days  * plan_feature_days_price_product_feature_instance['days_price']
                                product_feature_price_days =  plan_feature_days_price_product_feature_instance['days_price']
                            else:
                                
                                product_feature_price = 0  
                            # product_feature_price = plan_days * camera_quantity * plan_feature_days_price_product_feature_instance['days_price']
                            # product_feature_price_days = camera_quantity * plan_feature_days_price_product_feature_instance['days_price']
                            default_selected = False
                            feature_plan_selected = [feature_plan for feature_plan in product_data['plan_feature_detail'] if feature_plan['plan_feature_pricing_tier_id']==product_feature['id'] and feature_plan['selected']==True]
                            if len(feature_plan_selected) > 0:

                                default_selected = True
                                default_product_feature_price += product_feature_price
                                print("Value of plan_feature_pricing_category_id3:",
                                  product_feature['pricing_feature_category_id'])
                                plans_data.append({
                                    'price':product_feature_price,
                                    'days_price':product_feature_price_days,
                                    'currency_id':currency_detail,
                                    'default_product_id':parking_product_data['default_product_id'],
                                    'default_product_feature_id':product_feature['default_product_feature_id'],
                                    'plan_feature_pricing_category_id':product_feature['pricing_feature_category_id'],
                                    'category_name':product_feature['pricing_feature_category_id__category_name'],
                                    'plan_id':id,
                                    'plan_feature_pricing_tier_id':product_feature['id'],
                                    'company_detail_id':company_id,
                                    'plan_pricing_description':product_feature['plan_pricing_description']
                                })
                            
                
                    if product_selected_exist == False:
                        UserRoleMapping.objects.filter(id=user_role_map_id).delete()
                        User.objects.filter(id=user_id).delete()
                        AddUserEmail.objects.filter(id=add_user_email_id).delete()
                        for permission_id in permission_ids:
                            Permission.objects.filter(id=permission_id).delete()
                        Roles.objects.filter(id=role_id).delete()
                        CompanyDetail.objects.filter(id=company_id).delete()
                        return Response({'detail':'please select any one dashboard type.'},status.HTTP_400_BAD_REQUEST)
                    total_price = default_product_price + default_product_feature_price
                    all_product_total_price+=total_price
                    days_total_price = all_product_total_price / plan_days
                    discount_amount = (all_product_total_price * get_plan_days_and_discount.discount_percentage)/100
                    total_price_after_discount = all_product_total_price - discount_amount
                    business_coupon = None
                    if plans_detail['coupon_code'] != None:
                        print(type(plans_detail))
                        print(type(plans_data))
                        print(plans_detail)
                        print(type(plans_detail['coupon_code']))
                        print(plans_data)
                        get_coupon = Coupon.objects.filter(code=plans_detail['coupon_code'],currency_id=currency_detail,plan_buy_days__gte=plan_days,coupon_expiry_datetime__gte= datetime.now(),is_active=True).values('id','uuid','code','description','discount_type','discount_value','currency_id','currency_id__currency_type').first()
                        if get_coupon != None:
                            total_coupon_amount = 0.0
                            if get_coupon['discount_type'] == 'percentage':
                                total_coupon_amount =  (all_product_total_price * get_coupon['discount_value'])/100
                            elif get_coupon['discount_type'] == 'fixed amount':
                                total_coupon_amount = all_product_total_price - get_coupon['discount_value']
                            total_price_after_discount -= total_coupon_amount

                            business_coupon ={
                                'coupon_code':get_coupon['code'],
                                'description':get_coupon['description'],
                                'discount_type':get_coupon['discount_type'],
                                'discount_value':get_coupon['discount_value'],
                                'coupon_id':get_coupon['id'],
                                'total_coupon_amount':total_coupon_amount,
                                'company_detail_id':company_detail
                            }
                        else:
                            
                            UserRoleMapping.objects.filter(id=user_role_map_id).delete()
                            User.objects.filter(id=user_id).delete()
                            AddUserEmail.objects.filter(id=add_user_email_id).delete()
                            for permission_id in permission_ids:
                                Permission.objects.filter(id=permission_id).delete()
                            Roles.objects.filter(id=role_id).delete()
                            CompanyDetail.objects.filter(id=company_id).delete()
                            return Response({'detail':"coupon code is not valid."},status.HTTP_400_BAD_REQUEST)
                days_total_price_after_discount = total_price_after_discount / plan_days
                plan_pricing_tax_detail = PlanPricingTax.objects.filter(plan_pricing_id = get_plan_days_and_discount.plan_pricing_id).values('id','uuid','plan_pricing_id','tax_percentage_detail_id','tax_percentage_detail_id__tax_percentage','tax_percentage_detail_id__tax_type')
                tax_detail = []
                total_price_after_tax = total_price_after_discount
                for pricing_tax in plan_pricing_tax_detail:
                    tax_amount = (total_price_after_discount*pricing_tax['tax_percentage_detail_id__tax_percentage'])/100
                    total_price_after_tax += tax_amount
                    tax_detail.append({
                        'tax_percentage_detail_id':pricing_tax['tax_percentage_detail_id'],
                        'tax_percentage':pricing_tax['tax_percentage_detail_id__tax_percentage'],
                        'tax_type':pricing_tax['tax_percentage_detail_id__tax_type'],
                        'tax_amount':tax_amount,
                        'company_detail_id':company_id
                    })
                    total_tax_percentage+=pricing_tax['tax_percentage_detail_id__tax_percentage']
                    total_tax_in_currency+=tax_amount
                days_total_price_after_tax = total_price_after_tax / plan_days
                plan_start_datetime = timezone.datetime.now()
                plan_expire_datetime = timezone.datetime.now()+timezone.timedelta(days=get_plan_days_and_discount.plan_days)
                time_diff = plan_expire_datetime - plan_start_datetime
                total_minutes = int(time_diff.total_seconds()/60)
                total_days = time_diff.days
                #get_plan_pricing = PlanPricing.objects.filter(plan_id=get_plan.id,currency_id=currency_detail.id).values('id','country_type_id','country_type_id__country')
                #get_plan_pricing = PlanPricing.objects.filter(plan_id=get_plan[0]['id'], currency_id=currency_detail['id']).values('id', 'country_type_id', 'country_type_id__country')
                get_plan_pricing = PlanPricing.objects.filter(plan_id=get_plan.id, currency_id=currency_detail).first()
                now = timezone.now()
                plan_expire_datetime = now + timezone.timedelta(days=get_plan_days_and_discount.plan_days)
                currency_id = currency_detail  


                currency_obj = Currency.objects.get(id=currency_id)
                business_plan_history = {
                    'plan_name':get_plan.plan_name,
                    'price':total_price,
                    'price_after_discount':total_price_after_discount,
                    'price_after_tax':total_price_after_tax,
                    'days_price':days_total_price,
                    'days_price_after_discount': days_total_price_after_discount,
                    'days_price_after_tax': days_total_price_after_tax,
                    'currency_id':currency_id,
                    'currency_type':currency_obj.currency_type,
                    'currency_symbol':currency_obj.currency_symbol,
                    'country_category_id':get_plan_pricing.country_type_id.id,
                    #'country_category_id': country_category_instance.pk,
                    #'country_type':get_plan_pricing.country_type_id__country,
                    #'country_type': str(get_plan_pricing.country_type_id),
                    #'country_category_id':get_plan_pricing.country_type_id,
                    'country_type':get_plan_pricing.country_type_id.country,
                    #'country_type':get_plan_pricing.country_type_id,
                    'plan_id':get_plan.id,
                    'plan_days_and_discount_id':get_plan_days_and_discount.id,
                    'plan_days':get_plan_days_and_discount.plan_days,
                    'discount_in_percentage':get_plan_days_and_discount.discount_percentage,
                    'discount_in_currency': discount_amount,
                    'total_discount': total_price_after_discount,
                    'total_tax_in_percentage':total_tax_percentage,
                    'total_tax_in_currency':total_tax_in_currency,
                    #'buy_datetime':timezone.datetime.now(),
                    'buy_datetime': timezone.datetime.now(),
                    #'plan_start_datetime':timezone.datetime.now(),
                    'plan_start_datetime': timezone.datetime.now(),
                    #'plan_expire_datetime':timezone.datetime.now()+get_plan_days_and_discount.plan_days,
                    'plan_expire_datetime': timezone.datetime.now() + timezone.timedelta(days=get_plan_days_and_discount.plan_days),
                    #'plan_expire_datetime': str(plan_expire_datetime),
                    'minutes_to_expire':total_minutes,
                    'days_to_expire':total_days,
                    'plan_validity':True,
                    'plan_status':'active',
                    'current_active':True,
                    'plan_type':'Buy Plan',
                    'company_detail_id':company_id
                }
                
                print(business_plan_history)
                #request.session['business_plan_history'] = business_plan_history
                    #return JsonResponse({'An ERROR OCCURRED': str(e)}, status=500)
    #def save_and_update_database(self, event_data):
                business_plan_history_serializer = BusinessPlanHistorySerializer(data=business_plan_history)
                business_plan_history_id = None
                if business_plan_history_serializer.is_valid():
                    business_plan_history_obj = business_plan_history_serializer.save()
                    business_plan_history_id = business_plan_history_obj.id

                    # business_plan_history['id'] = business_plan_history_id
                    # request.session['business_plan_history'] = business_plan_history
                    # print("bph",business_plan_history)

                else:
                    UserRoleMapping.objects.filter(id=user_role_map_id).delete()
                    User.objects.filter(id=user_id).delete()
                    AddUserEmail.objects.filter(id=add_user_email_id).delete()
                    for permission_id in permission_ids:
                        Permission.objects.filter(id=permission_id).delete()
                    Roles.objects.filter(id=role_id).delete()
                    CompanyDetail.objects.filter(id=company_id).delete()
                    return Response(business_plan_history_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                
                business_pricing_tax_ids = []
                for business_pricing_tax in tax_detail:
                    business_pricing_tax['business_plan_history_id'] = business_plan_history_id
                    business_pricing_tax_serializer = BusinessPlanPricingTaxSerializer(data=business_pricing_tax)
                    business_pricing_tax_id = None
                    if business_pricing_tax_serializer.is_valid():
                        business_pricing_tax_obj = business_pricing_tax_serializer.save()
                        business_pricing_tax_id = business_pricing_tax_obj.id
                        business_pricing_tax_ids.append(business_pricing_tax_id)
                    else:
                        BusinessPlanHistory.objects.filter(id=business_plan_history_id).delete()
                        UserRoleMapping.objects.filter(id=user_role_map_id).delete()
                        User.objects.filter(id=user_id).delete()
                        AddUserEmail.objects.filter(id=add_user_email_id).delete()
                        for permission_id in permission_ids:
                            Permission.objects.filter(id=permission_id).delete()
                        Roles.objects.filter(id=role_id).delete()
                        CompanyDetail.objects.filter(id=company_id).delete()
                        return Response(business_plan_history_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                business_plan_coupon_id = None
                business_coupon = None
                if business_coupon != None:
                    business_coupon['business_plan_history_id'] = business_plan_history_id
                    business_coupon_serializer = BusinessPlanCoupon(data=business_coupon)
                    if business_coupon_serializer.is_valid():
                        business_coupon_obj = business_coupon_serializer.save()
                        business_plan_coupon_id = business_coupon_obj.id
                    else:
                        for business_plan_pricing_tax_id in business_pricing_tax_ids:
                            BusinessPlanPricingTax.objects.filter(id=business_plan_pricing_tax_id).delete()
                        for business_pricing_id in business_pricing_tier_ids:
                            BusinessPricingTier.objects.filter(id=business_pricing_id).delete()
                        BusinessPlanHistory.objects.filter(id=business_plan_history_id).delete()
                        UserRoleMapping.objects.filter(id=user_role_map_id).delete()
                        User.objects.filter(id=user_id).delete()
                        AddUserEmail.objects.filter(id=add_user_email_id).delete()
                        for permission_id in permission_ids:
                            Permission.objects.filter(id=permission_id).delete()
                        Roles.objects.filter(id=role_id).delete()
                        CompanyDetail.objects.filter(id=company_id).delete()
                
                business_pricing_tier_ids = []
                for plans in plans_data:
                    plans['business_plan_history_id'] = business_plan_history_id
                    business_pricing_tier_serializer = BusinessPricingTierSerializer(data=plans)
                    business_pricing_tier_id = None
                    if business_pricing_tier_serializer.is_valid():
                        business_pricing_tier_obj = business_pricing_tier_serializer.save()
                        business_pricing_tier_id = business_pricing_tier_obj.id
                        business_pricing_tier_ids.append(business_pricing_tier_id)
                    else:
                        if business_plan_coupon_id != None:
                            BusinessPlanCoupon.objects.filter(id=business_plan_coupon_id).delete()
                        for business_plan_pricing_tax_id in business_pricing_tax_ids:
                            BusinessPlanPricingTax.objects.filter(id=business_plan_pricing_tax_id).delete()
                        for business_pricing_id in business_pricing_tier_ids:
                            BusinessPricingTier.objects.filter(id=business_pricing_id).delete()
                        BusinessPlanHistory.objects.filter(id=business_plan_history_id).delete()
                        UserRoleMapping.objects.filter(id=user_role_map_id).delete()
                        User.objects.filter(id=user_id).delete()
                        AddUserEmail.objects.filter(id=add_user_email_id).delete()
                        for permission_id in permission_ids:
                            Permission.objects.filter(id=permission_id).delete()
                        Roles.objects.filter(id=role_id).delete()
                        CompanyDetail.objects.filter(id=company_id).delete()
                        return Response(business_pricing_tier_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                # if business_plan_coupon_id != None:
                #     BusinessPlanCoupon.objects.filter(id=business_plan_coupon_id).delete()
                # for business_plan_pricing_tax_id in business_pricing_tax_ids:
                #     BusinessPlanPricingTax.objects.filter(id=business_plan_pricing_tax_id).delete()
                # for business_pricing_id in business_pricing_tier_ids:
                #     BusinessPricingTier.objects.filter(id=business_pricing_id).delete()
                # BusinessPlanHistory.objects.filter(id=business_plan_history_id).delete()
                UserRoleMapping.objects.filter(id=user_role_map_id).delete()
                User.objects.filter(id=user_id).delete()
                AddUserEmail.objects.filter(id=add_user_email_id).delete()
                for permission_id in permission_ids:
                    Permission.objects.filter(id=permission_id).delete()
                Roles.objects.filter(id=role_id).delete()
                CompanyDetail.objects.filter(id=company_id).delete()
                return Response({"detail": "Plans days doesn't exist."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            # if business_plan_coupon_id != None:
            #     BusinessPlanCoupon.objects.filter(id=business_plan_coupon_id).delete()
            # for business_plan_pricing_tax_id in business_pricing_tax_ids:
            #     BusinessPlanPricingTax.objects.filter(id=business_plan_pricing_tax_id).delete()
            # for business_pricing_id in business_pricing_tier_ids:
            #     BusinessPricingTier.objects.filter(id=business_pricing_id).delete()
            # BusinessPlanHistory.objects.filter(id=business_plan_history_id).delete()
            UserRoleMapping.objects.filter(id=user_role_map_id).delete()
            User.objects.filter(id=user_id).delete()
            AddUserEmail.objects.filter(id=add_user_email_id).delete()
            for permission_id in permission_ids:
                Permission.objects.filter(id=permission_id).delete()
            Roles.objects.filter(id=role_id).delete()
            CompanyDetail.objects.filter(id=company_id).delete()
            return Response({"detail": "Plans not exist."}, status=status.HTTP_400_BAD_REQUEST)
        # try:
        try:


            user = User.objects.get(id=user_id)
            
            email = user.email
            phone_number = user.phone_number
            print("pn",phone_number)

            autopay_option = request.POST.get('autopay_option', None)

            
            if autopay_option == 'enable':
                
                response = create_subscription(request, business_plan_history, email, phone_number)


            #logger.info(f"create_subscription response: {response}")


            #return response

                if not response.get('success', False):

                    print("Error details:")
                    # traceback.print_exc()

                    # # for obj in created_objects:
                    # #     obj.delete()
                    
                    
                    # logger.info(f"create_subscription response: {response}")

                    return response
                
                return JsonResponse({'An ERROR OCCURRED': response.get('message', 'Failed to create subscription')}, status=500)
        
        
            api_response_data, payment_session_id = process_cashfree_payment(request, business_plan_history, email, phone_number)

            if api_response_data is None:
                for obj in reversed(created_objects):
                    obj.delete()
                return JsonResponse({'An ERROR OCCURRED': 'No data returned'}, status=500)
            
            if payment_session_id:
            
                # return JsonResponse({'payment_session_id': payment_session_id})
                # return Response(api_response_data)
                # response_data = {
                #     'api_response_data': api_response_data,
                #     'payment_session_id': payment_session_id
                # }
                # return Response(response_data)
                return render(request, 'checkout.html', {'payment_session_id': payment_session_id})
            else:
                
                
                for obj in reversed(created_objects):
                    obj.delete()
                return JsonResponse({'An ERROR OCCURRED': 'Payment session ID not found'}, status=500)


        except Exception as e:
            # for obj in created_objects:
            #     obj.delete()
            for obj in reversed(created_objects):
                    obj.delete()
            return JsonResponse({'AN ERROR OCCURRED': str(e)}, status=500)

    def put(self, request,id,format=None):
            # user_detail_page = get_user_data_page_plans(request.user.id,'upgrade_plan','view')
            # AccessToPage = False
            # if user_detail_page['permission'] != None:
            #     AccessToPage = True
            # if AccessToPage == True:
                data = request.data
                all_product_total_price = 0.0
                default_product_price = 0.0
                default_product_price_days=0.0
                total_price_after_discount = 0.0        
                total_price = 0.0
                default_product_feature_price = 0.0
                total_tax_in_currency = 0.0
                total_tax_percentage = 0.0
                days_total_price=0.0
                discount_amount=0.0
                camera_price_days=0.0
                camera_price=0.0
                default_online_dashboard_backup_price=0.0
                default_offline_dashboard_backup_price=0.0
                days_price=0.0
                product_feature_price_days=0.0
                
            # print(data)
                plans_data = {}
                plans_detail = data['plans_detail']
                plan_days = data['plan_days_id']
                plans_detail = data['plans_detail']
                plan_products = plans_detail['plan_product']
                currency_detail = Currency.objects.filter(currency_type=request.data['currency_type']).values('id','currency_type','currency_symbol').first()
                get_plan = Plans.objects.filter(id=plans_detail['id'],plan_name=plans_detail['plan_name']).first()
                #get_plan = Plans.objects.filter(id=id).first()
                #print(get_plan)
                id = get_plan.id
                plan_name = get_plan.plan_name
                get_plan_days_and_discount_all = PlanDaysAndDiscount.objects.filter(plan_id=id).all()
                plans_data['plan_days']= []
                plan_days = 0
            
                for plan_days_detail in get_plan_days_and_discount_all:
                    selected = False
                    if data['plan_days_id'] == plan_days_detail.id:
                        selected = True
                        plan_days = plan_days_detail.plan_days
                        plan_pricing_id = plan_days_detail.plan_pricing_id.id
                        print("plan_days_detail",plan_days_detail)
                    plans_data['plan_days'].append({
                        #'id':plan_days_detail.id,
                        'plan_days':plan_days_detail.plan_days,
                        'discount_percentage':plan_days_detail.discount_percentage,
                        'category':plan_days_detail.category,
                        'default_select':selected,
                        #'plan_pricing_id':plan_days_detail.plan_pricing_id
                        #'plan_pricing_id': plan_pricing_id
                        
                    })
                get_plan_days_and_discount = PlanDaysAndDiscount.objects.filter(plan_id=id,id=data['plan_days_id']).first()
                plans_data['product_data'] = []
                if get_plan_days_and_discount != None:
                    plan_days = get_plan_days_and_discount.plan_days
                    product_data = plans_detail['plan_product'][0]
                    
                    parking_product_data = PlanFeaturePricingTier.objects.filter(plan_id=id,pricing_feature_category_id__category_name="Product",default_product_id__product_name='Visitor management system',id=plans_detail['plan_product'][0]['plan_feature_pricing_tier_id'],show_plan_pricing=True).values('id','uuid','default_product_id','default_product_id__product_name','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                    product_data = plans_detail['plan_product'][0]
                    #camera_quantity = product_data['plan_camera_detail']['camera_quantity']
                    product_data_json = {}
                    #product_data_json['id'] = parking_product_data['id']
                    product_data_json['product_name'] = parking_product_data['default_product_id__product_name']
                    if parking_product_data != None:

                        plan_feature_days_price_product = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=parking_product_data['id'],currency_id=data['currency_type_id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                        plan_feature_days_price_product_instance = plan_feature_days_price_product.first()
                        product_data_json['plan_product'] = []
                        if plan_feature_days_price_product_instance:
                            default_product_price = plan_days* plan_feature_days_price_product_instance['days_price']
                            default_product_price_days = plan_feature_days_price_product_instance['days_price']
                        else:
                            #print("error in defaultproductprice")
                                default_product_price = 0 
                                default_product_price_days = 0
                        product_selected_exist = True
                        # product_selected_exist = True
                        # default_product_price = plan_days * camera_quantity * plan_feature_days_price_product['days_price']
                        # default_product_price_days = camera_quantity * plan_feature_days_price_product['days_price']

                        product_data_json['plan_product'].append({
                            #'id':parking_product_data['id'],
                            #'uuid':parking_product_data['uuid'],
                            'days_price':default_product_price_days,
                            'price': default_product_price,
                            #'currency_symbol':plan_feature_days_price_product_instance['currency_id__currency_symbol'],
                            #'currency_id':currency_detail['id'],
                            #'pricing_feature_category_id':parking_product_data['pricing_feature_category_id'],
                        # 'category_name':parking_product_data['pricing_feature_category_id__category_name'],
                            'default_selected':product_selected_exist,
                            #'plan_id':parking_product_data['plan_id'],
                            'plan_pricing_description':parking_product_data['plan_pricing_description'],
                            #'show_plan_pricing':parking_product_data['show_plan_pricing']
                        })
                        print(product_data_json)
                        default_parking_product_feature_data = PlanFeaturePricingTier.objects.filter(plan_id=id,pricing_feature_category_id__category_name="Feature",default_product_id__product_name='Visitor management system',is_encluded_plan_feature_id__isnull=False,default_product_feature_id__isnull=False).values('id','uuid','default_product_id','default_product_id__product_name','default_product_feature_id','default_product_feature_id__feature','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').all()
                        product_data_json['plan_product_feature_default'] = []
                        for default_product_feature in default_parking_product_feature_data:
                            product_data_json['plan_product_feature_default'].append({
                                # 'id':default_product_feature['id'],
                                # 'uuid':default_product_feature['uuid'],
                                # 'default_product_feature_id':default_product_feature['default_product_feature_id'],
                                # 'pricing_feature_category_id':default_product_feature['pricing_feature_category_id'],
                                # 'category_name':default_product_feature['pricing_feature_category_id__category_name'],
                                'feature_name':default_product_feature['default_product_feature_id__feature'],
                                'plan_pricing_description':default_product_feature['plan_pricing_description'],       
                            })
                        parking_product_feature_data = PlanFeaturePricingTier.objects.filter(plan_id=id,pricing_feature_category_id__category_name="Feature",default_product_id__product_name='Visitor management system',is_encluded_plan_feature_id__isnull=False,default_product_feature_id__isnull=False).values('id','uuid','default_product_id','default_product_id__product_name','default_product_feature_id','default_product_feature_id__feature','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').all()
                        print("parking_product_feature_data",parking_product_feature_data)
                        product_data_json['plan_product_feature'] = []
                        default_product_feature_price = 0.0
                        for product_feature in parking_product_feature_data:
                            # plan_feature_days_price_product_feature = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=product_feature['id'],currency_id=data['currency_type_id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                            # product_feature_price = plan_days * camera_quantity * plan_feature_days_price_product_feature['days_price']
                            # product_feature_price_days = camera_quantity * plan_feature_days_price_product_feature['days_price']
                            # default_selected = False
                            plan_feature_days_price_product_feature = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=product_feature['id'],currency_id=currency_detail['id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                            plan_feature_days_price_product_feature_instance = plan_feature_days_price_product_feature.first()  
                            if plan_feature_days_price_product_feature_instance:
                                product_feature_price = plan_days *  plan_feature_days_price_product_feature_instance['days_price']
                                product_feature_price_days =  plan_feature_days_price_product_feature_instance['days_price']
                            else:
                                
                                product_feature_price = 0  
                            # product_feature_price = plan_days * camera_quantity * plan_feature_days_price_product_feature_instance['days_price']
                            # product_feature_price_days = camera_quantity * plan_feature_days_price_product_feature_instance['days_price']
                            default_selected = False
                            feature_plan_selected = [feature_plan for feature_plan in product_data['plan_feature_detail'] if feature_plan['plan_feature_pricing_tier_id']==product_feature['id'] and feature_plan['selected']==True]
                            if len(feature_plan_selected) > 0:
                                default_selected = True
                                default_product_feature_price += product_feature_price
                            product_data_json['plan_product_feature'].append({
                                # 'id':product_feature['id'],
                                # 'uuid':product_feature['uuid'],
                                'days_price':product_feature_price_days,
                                'price': product_feature_price,
                                'currency_symbol':plan_feature_days_price_product_instance['currency_id__currency_symbol'],
                                # 'default_product_feature_id':product_feature['default_product_feature_id'],
                                'feature_name':product_feature['default_product_feature_id__feature'],
                                # 'pricing_feature_category_id':product_feature['pricing_feature_category_id'],
                                #'category_name':product_feature['pricing_feature_category_id__category_name'],
                                'default_selected':default_selected,
                                # 'plan_id':product_feature['plan_id'],
                                'plan_pricing_description':product_feature['plan_pricing_description'],
                                #'show_plan_pricing':product_feature['show_plan_pricing']
                            })

                        total_price = default_offline_dashboard_backup_price +  default_product_price+default_product_feature_price
                        all_product_total_price+=total_price
                        plans_data['product_data'].append(product_data_json)
                    discount_amount = (all_product_total_price * get_plan_days_and_discount.discount_percentage)/100
                    total_price_after_discount = all_product_total_price - discount_amount
                    if plans_detail['coupon_code'] != None:
                        get_coupon = Coupon.objects.filter(code=plans_detail['coupon_code'],currency_id=data['currency_type_id'],plan_buy_days__gte=plan_days,coupon_expiry_datetime__gte= timezone.datetime.now(),is_active=True).values('id','uuid','code','description','discount_type','discount_value','currency_id','currency_id__currency_type').first()
                        if get_coupon != None:
                            total_coupon_amount = 0.0
                            if get_coupon['discount_type'] == 'percentage':
                                total_coupon_amount =  (all_product_total_price * get_coupon['discount_value'])/100
                            elif get_coupon['discount_type'] == 'fixed amount':
                                total_coupon_amount = all_product_total_price - get_coupon['discount_value']
                            total_price_after_discount -= total_coupon_amount

                            plans_data['coupon_code'] ={
                                # 'id':get_coupon['id'],
                                # 'uuid':get_coupon['uuid'],
                                'code':get_coupon['code'],
                                'description':get_coupon['description'],
                                'discount_type':get_coupon['discount_type'],
                                'discount_value':get_coupon['discount_value'],
                                # 'currency_id':get_coupon['currency_id'],
                                'total_coupon_amount':total_coupon_amount
                            }

                        else:
                            return Response({'detail':"coupon code is not valid."},status.HTTP_400_BAD_REQUEST)

                    plan_pricing_tax_detail = PlanPricingTax.objects.filter(plan_pricing_id = get_plan_days_and_discount.plan_pricing_id).values('id','uuid','plan_pricing_id','tax_percentage_detail_id','tax_percentage_detail_id__tax_percentage','tax_percentage_detail_id__tax_type')
                    tax_detail = []
                    total_price_after_tax = total_price_after_discount
                    for pricing_tax in plan_pricing_tax_detail:
                        tax_amount = (total_price_after_discount*pricing_tax['tax_percentage_detail_id__tax_percentage'])/100
                        total_price_after_tax += tax_amount
                        tax_detail.append({
                            # 'id':pricing_tax['id'],
                            # 'uuid':pricing_tax['uuid'],
                            # 'tax_percentage_detail_id':pricing_tax['tax_percentage_detail_id'],
                            'tax_percentage':pricing_tax['tax_percentage_detail_id__tax_percentage'],
                            'tax_type':pricing_tax['tax_percentage_detail_id__tax_type'],
                            'tax_amount':tax_amount
                        })
                    plans_data['plan_pricing'] ={
                        'total_price':total_price,
                        'discount_amount':discount_amount,
                        'total_price_after_discount':total_price_after_discount,
                        'total_price_after_tax':total_price_after_tax,
                        'tax_detail':tax_detail
                    }
                    
                return Response(plans_data, status=status.HTTP_200_OK)

class PlanPricingView:
    def __init__(self, total_price, discount_amount, total_price_after_discount, total_price_after_tax, tax_detail):
        self.total_price = total_price
        self.discount_amount = discount_amount
        self.total_price_after_discount = total_price_after_discount
        self.total_price_after_tax = total_price_after_tax
        self.tax_detail = tax_detail

    def to_dict(self):
        return {
            'total_price': self.total_price,
            'discount_amount': self.discount_amount,
            'total_price_after_discount': self.total_price_after_discount,
            'total_price_after_tax': self.total_price_after_tax,
            'tax_detail': self.tax_detail,
        }


class GetBuyPlanDetail(APIView):
    permission_classes = (AllowAny,)
    def get(self, request,id):
        # user_detail_page = get_user_data_page_plans(request.user.id,'upgrade_plan','view')  
        # print("udp", user_detail_page)
        # AccessToPage = False
        # if user_detail_page['permission'] != None:
        #     AccessToPage = True
        # if AccessToPage == True:
            # plan_id = request.GET.get('plan_id')
            # if not plan_id:
            #      return JsonResponse({"error": "Plan ID is required"}, status=400)


    
            # plan = get_object_or_404(Plans, id=plan_id)
            default_camera_price = 0.0
            currency_type_id = request.GET.get('currency',1)
            print("currencytypeid:", currency_type_id)
            plans_data = {}
            get_plan = Plans.objects.filter(id=id).first()
            plans_data['id'] = get_plan.id
            plans_data['plan_name'] = get_plan.plan_name
            get_plan_days_and_discount_all = PlanDaysAndDiscount.objects.filter(plan_id=id).all()
            plans_data['plan_days']= []

            for plan_days_detail in get_plan_days_and_discount_all:
            #plan_days = user_detail_page['business_plan_history_detail'].plan_days
                plan_days=30
                default_selected = False
                if plan_days == plan_days_detail.plan_days:
                    default_selected = True
                # plan_days_and_discount_id = user_detail_page['business_plan_history_detail']['plan_days_and_discount_id']
                    plans_data['plan_days'].append({
                        #'id':plan_days_detail.id,
                        'plan_days':plan_days_detail.plan_days,
                        'discount_percentage':plan_days_detail.discount_percentage,
                       # 'category':plan_days_detail.category,
                       # 'default_select':default_selected,
                       # 'plan_pricing_id':plan_days_detail.plan_pricing_id
                    })
                    print("pd",plans_data)

            get_plan_days_and_discount = PlanDaysAndDiscount.objects.filter(plan_id=id,default_select=True).first()
            plans_data['product_data'] = []
            if get_plan_days_and_discount != None:
                plan_days = get_plan_days_and_discount.plan_days
                print("PLAN DAYS:", plan_days)
                parking_product_data = PlanFeaturePricingTier.objects.filter(plan_id=id,pricing_feature_category_id__category_name="Product",default_product_id__product_name='Visitor management system').values('id','uuid','default_product_id','default_product_id__product_name','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                print("parking product data", parking_product_data)
                all_product_total_price = 0.0
                if parking_product_data != None:
                    # plan_features_pricing_tier_camera = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Camera').values('id','uuid','min_quantity','max_quantity','default_quantity','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                    # print("pfptc", plan_features_pricing_tier_camera)
                    # camera_quantity = 1
                    # if plan_features_pricing_tier_camera != None:
                        # camera_quantity = plan_features_pricing_tier_camera['default_quantity']

                        product_data_json = {}
                        #product_data_json['id'] = parking_product_data['id']
                        product_data_json['product_name'] = 'Visitor management system'

                        plan_feature_days_price_product = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=parking_product_data['id'],currency_id=currency_type_id).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                    # plan_feature_days_price_product = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=parking_product_data['id'],currency_id=data['currency_type_id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                        plan_feature_days_price_product_instance = plan_feature_days_price_product.first()

                        if plan_feature_days_price_product_instance:
                            default_product_price = plan_days * plan_feature_days_price_product_instance['days_price']
                            default_product_price_days = plan_feature_days_price_product_instance['days_price']
                        else:
                            #print("error in defaultproductprice")
                                default_product_price = 0 
                                default_product_price_days = 0
                        product_selected_exist = True
                        # product_selected_exist = True
                        # default_product_price = plan_days * camera_quantity * plan_feature_days_price_product['days_price']
                        # default_product_price_days = camera_quantity * plan_feature_days_price_product['days_price']
                        product_data_json['plan_product']={
                            # 'id':parking_product_data['id'],
                            # 'uuid':parking_product_data['uuid'],
                            'days_price':default_product_price_days,
                            'price': default_product_price,
                            'currency_symbol':plan_feature_days_price_product_instance['currency_id__currency_symbol'],
                            # 'pricing_feature_category_id':parking_product_data['pricing_feature_category_id'],
                            # 'category_name':parking_product_data['pricing_feature_category_id__category_name'],
                            # 'default_selected':product_selected_exist,
                            # 'plan_id':parking_product_data['plan_id'],
                            # 'plan_pricing_description':parking_product_data['plan_pricing_description'],
                            # 'show_plan_pricing':parking_product_data['show_plan_pricing']
                        }
                        
                        default_parking_product_feature_data = PlanFeaturePricingTier.objects.filter(plan_id=id,pricing_feature_category_id__category_name="Feature",default_product_id__product_name='Visitor management system',is_encluded_plan_feature_id__isnull=False,default_product_feature_id__isnull=False).values('id','uuid','default_product_id','default_product_id__product_name','default_product_feature_id','default_product_feature_id__feature','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').all()
                        product_data_json['plan_product_feature_default'] = []
                        for default_product_feature in default_parking_product_feature_data:
                            
                            product_data_json['plan_product_feature_default'].append({
                                # 'id':default_product_feature['id'],
                                # 'uuid':default_product_feature['uuid'],
                                # 'default_product_feature_id':default_product_feature['default_product_feature_id'],
                                # 'pricing_feature_category_id':default_product_feature['pricing_feature_category_id'],
                                'category_name':default_product_feature['pricing_feature_category_id__category_name'],
                                'feature_name':default_product_feature['default_product_feature_id__feature'],
                                'plan_pricing_description':default_product_feature['plan_pricing_description'],

                            })
                        parking_product_feature_data = PlanFeaturePricingTier.objects.filter(plan_id=id,pricing_feature_category_id__category_name="Feature",default_product_id__product_name='Visitor management system',is_encluded_plan_feature_id__isnull=False,default_product_feature_id__isnull=False).values('id','uuid','default_product_id','default_product_id__product_name','default_product_feature_id','default_product_feature_id__feature','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').all()
                        product_data_json['plan_product_feature'] = []
                        default_product_feature_price = 0.0
                        for product_feature in parking_product_feature_data:
                            plan_feature_days_price_product_feature = list(PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=product_feature['id'],currency_id=currency_type_id).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected'))
                            print("plan_feature_days_price_product_feature:",plan_feature_days_price_product_feature)
                            #product_feature_price = plan_days * camera_quantity * plan_feature_days_price_product_feature['days_price']
                            if plan_feature_days_price_product_feature:
                                    for feature in plan_feature_days_price_product_feature:
                                        
                                        product_feature_price = plan_days * feature['days_price']
                                        print("Product feature price:", product_feature_price)
                                        product_feature_price_days =feature['days_price']
                                        print("product feature price days", product_feature_price_days)
                            else:
                                print("No matching plan feature days price found")
                    
                            plan_feature_days_price_product_feature = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=product_feature['id'],currency_id=currency_type_id).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                            plan_feature_days_price_product_feature_instance = plan_feature_days_price_product_feature.first()  
                            if plan_feature_days_price_product_feature_instance:
                                product_feature_price = plan_days  * plan_feature_days_price_product_feature_instance['days_price']
                                product_feature_price_days = plan_feature_days_price_product_feature_instance['days_price']
                                print("product_feature_price", product_feature_price)
                                print("product_feature_price_days",product_feature_price_days)
                            else:
                                
                                product_feature_price = 0  

                            default_selected = False
                            product_feature_price_days = 0
                            # if len(product_feature_detail) > 0:
                            default_product_feature_price += product_feature_price
                            default_selected = True
                            product_data_json['plan_product_feature'].append({
                                # 'id':product_feature['id'],
                                # 'uuid':product_feature['uuid'],
                                'days_price':product_feature_price_days,
                                'price': product_feature_price,
                                'currency_symbol':plan_feature_days_price_product_instance['currency_id__currency_symbol'],
                                # 'default_product_feature_id':product_feature['default_product_feature_id'],
                                'feature_name':product_feature['default_product_feature_id__feature'],
                                # 'pricing_feature_category_id':product_feature['pricing_feature_category_id'],
                                # 'category_name':product_feature['pricing_feature_category_id__category_name'],
                                # 'default_selected':default_selected,
                                # 'plan_id':product_feature['plan_id'],
                                'plan_pricing_description':product_feature['plan_pricing_description'],
                                # 'show_plan_pricing':product_feature['show_plan_pricing']
                            })

                                                
                        total_price =   default_product_price + default_product_feature_price
                        all_product_total_price+=total_price
                        plans_data['product_data'].append(product_data_json)

                        discount_amount = (all_product_total_price * get_plan_days_and_discount.discount_percentage)/100
                        total_price_after_discount = all_product_total_price - discount_amount
                        plans_data['coupon_code'] = None
                        plan_pricing_tax_detail = PlanPricingTax.objects.filter(plan_pricing_id = get_plan_days_and_discount.plan_pricing_id).values('id','uuid','plan_pricing_id','tax_percentage_detail_id','tax_percentage_detail_id__tax_percentage','tax_percentage_detail_id__tax_type')
                        tax_detail = []
                        total_price_after_tax = total_price_after_discount
                        for pricing_tax in plan_pricing_tax_detail:
                            tax_amount = (total_price_after_discount*pricing_tax['tax_percentage_detail_id__tax_percentage'])/100
                            total_price_after_tax += tax_amount
                            tax_detail.append({
                                # 'id':pricing_tax['id'],
                                # 'uuid':pricing_tax['uuid'],
                                #'tax_percentage_detail_id':pricing_tax['tax_percentage_detail_id'],
                                'tax_percentage':pricing_tax['tax_percentage_detail_id__tax_percentage'],
                                'tax_type':pricing_tax['tax_percentage_detail_id__tax_type'],
                                'tax_amount':tax_amount
                            })

                        plan_pricing = PlanPricingView(
                        total_price=all_product_total_price,
                        discount_amount=discount_amount,
                        total_price_after_discount=total_price_after_discount,
                        total_price_after_tax=total_price_after_tax,
                        tax_detail=tax_detail
                    )

               
                        response_data = {
                            'plan_pricing': plan_pricing.to_dict(),
                            #'plan_offline_dashboard_data_backup': product_data_json.get('plan_offline_dashboard_data_backup', {}),
                            'product_data': product_data_json
                        }
                    

                        return JsonResponse(response_data, status=status.HTTP_200_OK)
                
class UpgradePlanView(APIView):
    permission_classes = (IsAuthenticated,)
    def calculate_remaining_days(self, existing_plan):
        now = timezone.now()
        remaining_days = (existing_plan.plan_expire_datetime - now).days
        return max(0, remaining_days)

    
    def calculate_pro_rated_refund(self, existing_plan, remaining_days):
        original_price = existing_plan.price_after_tax  
        total_days = existing_plan.plan_days  
        daily_rate = original_price / total_days
        return daily_rate * remaining_days
    def calculate_remaining_value(self, existing_plan):
        now = timezone.now()
        remaining_days = (existing_plan.plan_expire_datetime - now).days
        remaining_days = max(0, remaining_days)
        original_price = existing_plan.price_after_tax  
        total_days = existing_plan.plan_days  
        daily_rate = original_price / total_days
        remaining_value = daily_rate * remaining_days
        return remaining_value

  

    def post(self, request):
        user_detail_page = get_user_data_page_plans(request.user.id,'upgrade_plan','create')  
        print("udp",user_detail_page)
        default_product_feature_price = 0.0
        all_product_total_price = 0.0
        total_tax_in_currency = 0.0
        total_tax_percentage = 0.0
        default_product_price = 0.0
        default_product_price_days=0.0
        total_price_after_discount = 0.0        
        total_price = 0.0
        
        total_tax_in_currency = 0.0
        total_tax_percentage = 0.0
        days_total_price=0.0
        discount_amount=0.0
        
        company_id = user_detail_page['company_detail']['id']
        print("company_id",company_id)

        user = request.user
        AccessToPage = False
        if user_detail_page['permission'] != None:
            AccessToPage = True
        if AccessToPage == True:
            #plans_detail =  request.data
            data = request.data
            currency_detail = Currency.objects.filter(currency_type=request.data['currency_type']).values('id','currency_type','currency_symbol').first()
            #get_plan = Plans.objects.filter(id=plans_detail['id'],plan_name=plans_detail['plan_name']).first()
            plans_detail = data['plans_detail']
            get_plan = Plans.objects.filter(id=plans_detail['id'],plan_name=plans_detail['plan_name']).first()
            if get_plan != None:
                id = get_plan.id
                plan_name = get_plan.plan_name
                get_plan_days_and_discount = PlanDaysAndDiscount.objects.filter(plan_id=id,id=plans_detail['plan_days_id'],default_select=True).first()
                if get_plan_days_and_discount != None:
                    plans_data= []
                    plan_days = get_plan_days_and_discount.plan_days
                    product_data = plans_detail['plan_product'][0]
                    # camera_quantity = product_data['plan_camera_detail']['camera_quantity']
                    parking_product_data = PlanFeaturePricingTier.objects.filter(plan_id=id,pricing_feature_category_id__category_name="Product",default_product_id__product_name='Visitor management system',id=product_data['plan_feature_pricing_tier_id'],show_plan_pricing=True).values('id','uuid','default_product_id','default_product_id__product_name','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                    if parking_product_data != None:
                        # plan_features_pricing_tier_camera = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Camera').values('id','uuid','min_quantity','max_quantity','default_quantity','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                        plan_feature_days_price_product = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=parking_product_data['id'],currency_id=currency_detail['id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                        plan_feature_days_price_product_instance = plan_feature_days_price_product.first()

                        if plan_feature_days_price_product_instance:
                           default_product_price = plan_days  * plan_feature_days_price_product_instance['days_price']
                           default_product_price_days = plan_feature_days_price_product_instance['days_price']
                        else:
                            #print("error in defaultproductprice")
                             default_product_price = 0 
                             default_product_price_days = 0
                        product_selected_exist = True
                       # product_selected_exist = True
                        # default_product_price = plan_days * camera_quantity * plan_feature_days_price_product['days_price']
                        # default_product_price_days = camera_quantity * plan_feature_days_price_product['days_price']
                        plans_data.append({
                            'price':default_product_price,
                            'days_price':default_product_price_days,
                            'currency_id':currency_detail['id'],
                            'default_product_id':parking_product_data['default_product_id'],
                            'plan_feature_pricing_category_id':parking_product_data['pricing_feature_category_id'],
                            'category_name':parking_product_data['pricing_feature_category_id__category_name'],
                            'plan_id':id,
                            'plan_feature_pricing_tier_id':parking_product_data['id'],
                            'company_detail_id':user_detail_page['company_detail']['id'],
                            'plan_pricing_description':parking_product_data['plan_pricing_description']
                        })
                        default_parking_product_feature_data = PlanFeaturePricingTier.objects.filter(plan_id=id,pricing_feature_category_id__category_name="Feature",default_product_id__product_name='Visitor management system',is_encluded_plan_feature_id__isnull=False,default_product_feature_id__isnull=False).values('id','uuid','default_product_id','default_product_id__product_name','default_product_feature_id','default_product_feature_id__feature','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').all()
                        for default_product_feature in default_parking_product_feature_data:
                            plans_data.append({
                                'price':0.0,
                                'days_price':0.0,
                                'currency_id':currency_detail['id'],
                                'default_product_id':parking_product_data['default_product_id'],
                                'default_product_feature_id':default_product_feature['default_product_feature_id'],
                                'plan_feature_pricing_category_id':default_product_feature['pricing_feature_category_id'],
                                'category_name':default_product_feature['pricing_feature_category_id__category_name'],
                                'plan_id':id,
                                'plan_feature_pricing_tier_id':default_product_feature['id'],
                                'company_detail_id':user_detail_page['company_detail']['id'],
                                'plan_pricing_description':default_product_feature['plan_pricing_description']
                            })
                        parking_product_feature_data = PlanFeaturePricingTier.objects.filter(plan_id=id,pricing_feature_category_id__category_name="Feature",default_product_id__product_name='Visitor management system',is_encluded_plan_feature_id__isnull=True,default_product_feature_id__isnull=False).values('id','uuid','default_product_id','default_product_id__product_name','default_product_feature_id','default_product_feature_id__feature','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').all()
                        for product_feature in parking_product_feature_data:
                            #plan_feature_days_price_product_feature = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount['id'],plan_feature_pricing_tier_id=product_feature['id'],currency_id=currency_detail['id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                            plan_feature_days_price_product_feature = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=product_feature['id'],currency_id=currency_detail['id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                            plan_feature_days_price_product_feature_instance = plan_feature_days_price_product_feature.first()  
                            if plan_feature_days_price_product_feature_instance:
                                product_feature_price = plan_days  * plan_feature_days_price_product_feature_instance['days_price']
                                product_feature_price_days =  plan_feature_days_price_product_feature_instance['days_price']
                            else:
                                
                                product_feature_price = 0  
                            # product_feature_price = plan_days * camera_quantity * plan_feature_days_price_product_feature_instance['days_price']
                            # product_feature_price_days = camera_quantity * plan_feature_days_price_product_feature_instance['days_price']
                            default_selected = False
                           
                            product_feature_price = plan_days  * plan_feature_days_price_product_feature_instance['days_price']
                            product_feature_price_days =  plan_feature_days_price_product_feature_instance['days_price']
                            default_selected = False
                            feature_plan_selected = [feature_plan for feature_plan in product_data['plan_feature_detail'] if feature_plan['plan_feature_pricing_tier_id']==product_feature['id'] and feature_plan['selected']==True]
                            if len(feature_plan_selected) > 0:
                                default_selected = True
                                default_product_feature_price += product_feature_price
                                plans_data.append({
                                    'price':product_feature_price,
                                    'days_price':product_feature_price_days,
                                    'currency_id':currency_detail['id'],
                                    'default_product_id':parking_product_data['default_product_id'],
                                    'default_product_feature_id':product_feature['default_product_feature_id'],
                                    'plan_feature_pricing_category_id':product_feature['pricing_feature_category_id'],
                                    'category_name':product_feature['pricing_feature_category_id__category_name'],
                                    'plan_id':id,
                                    'plan_feature_pricing_tier_id':product_feature['id'],
                                    'company_detail_id':user_detail_page['company_detail']['id'],
                                    'plan_pricing_description':product_feature['plan_pricing_description']
                                })
                       
                        if product_selected_exist == False:
                            return Response({'detail':'please select any one dashboard type.'},status.HTTP_400_BAD_REQUEST)
                        total_price = default_product_price + default_product_feature_price
                        print("tp",total_price)
                        all_product_total_price+=total_price
                    days_total_price = all_product_total_price / plan_days
                    discount_amount = (all_product_total_price * get_plan_days_and_discount.discount_percentage)/100
                    total_price_after_discount = all_product_total_price - discount_amount
                    business_coupon = None
                    if plans_detail['coupon_code'] != None:
                        get_coupon = Coupon.objects.filter(code=plans_detail['coupon_code'],currency_id=currency_detail['id'],plan_buy_days__gte=plan_days,coupon_expiry_datetime__gte= timezone.datetime.now(),is_active=True).values('id','uuid','code','description','discount_type','discount_value','currency_id','currency_id__currency_type').first()
                        if get_coupon != None:
                            total_coupon_amount = 0.0
                            if get_coupon['discount_type'] == 'percentage':
                                total_coupon_amount =  (all_product_total_price * get_coupon['discount_value'])/100
                            elif get_coupon['discount_type'] == 'fixed amount':
                                total_coupon_amount = all_product_total_price - get_coupon['discount_value']
                            total_price_after_discount -= total_coupon_amount
                            business_coupon ={
                                'coupon_code':get_coupon['code'],
                                'description':get_coupon['description'],
                                'discount_type':get_coupon['discount_type'],
                                'discount_value':get_coupon['discount_value'],
                                'coupon_id':get_coupon['id'],
                                'total_coupon_amount':total_coupon_amount,
                                'company_detail_id':user_detail_page['company_detail']['id']
                            }
                        else:
                            return Response({'detail':"coupon code is not valid."},status.HTTP_400_BAD_REQUEST)
                    days_total_price_after_discount = total_price_after_discount / plan_days
                    plan_pricing_tax_detail = PlanPricingTax.objects.filter(plan_pricing_id = get_plan_days_and_discount.plan_pricing_id).values('id','uuid','plan_pricing_id','tax_percentage_detail_id','tax_percentage_detail_id__tax_percentage','tax_percentage_detail_id__tax_type')
                    tax_detail = []
                    total_price_after_tax = total_price_after_discount
                    for pricing_tax in plan_pricing_tax_detail:
                        tax_amount = (total_price_after_discount*pricing_tax['tax_percentage_detail_id__tax_percentage'])/100
                        total_price_after_tax += tax_amount
                        tax_detail.append({
                            'tax_percentage_detail_id':pricing_tax['tax_percentage_detail_id'],
                            'tax_percentage':pricing_tax['tax_percentage_detail_id__tax_percentage'],
                            'tax_type':pricing_tax['tax_percentage_detail_id__tax_type'],
                            'tax_amount':tax_amount,
                            'company_detail_id':user_detail_page['company_detail']['id']
                        })
                        total_tax_percentage+=pricing_tax['tax_percentage_detail_id__tax_percentage']
                        total_tax_in_currency+=tax_amount
                    days_total_price_after_tax = total_price_after_tax / plan_days
                    plan_start_datetime = timezone.datetime.now()
                    #plan_expire_datetime = timezone.datetime.now()+get_plan_days_and_discount.plan_days
                    plan_expire_datetime = timezone.now() + timedelta(days=get_plan_days_and_discount.plan_days)
                    plan_start_datetime = timezone.make_aware(plan_start_datetime)
                    time_diff = plan_expire_datetime - plan_start_datetime
                    total_minutes = time_diff.total_seconds()/60
                    total_days = time_diff.days
                    #get_plan_pricing = PlanPricing.objects.filter(plan_id=get_plan.id,currency_id=currency_detail['id']).values('id','country_type_id','country_type_id__country')
                    get_plan_pricing = PlanPricing.objects.filter(plan_id=get_plan.id, currency_id=currency_detail['id']).first()
                    try:
                        # Fetch the existing plan
                        existing_plan_id = request.data.get('existing_plan_id')
                        existing_plan = BusinessPlanHistory.objects.get(id=existing_plan_id)

                        # Calculate remaining days and pro-rated refund
                        # remaining_days = self.calculate_remaining_days(existing_plan)
                        # pro_rated_refund = self.calculate_pro_rated_refund(existing_plan, remaining_days)
                        remaining_value = self.calculate_remaining_value(existing_plan)
                    except :
                        return Response({'error': 'Invalid existing_plan_id'}, status=status.HTTP_400_BAD_REQUEST)

                    # Extracting new plan details from the request data
                    plans_detail = request.data.get('plans_detail')
                    plan_days_id = plans_detail.get('plan_days_id')
                    currency_type_id = request.data.get('currency_type_id')
                    country_category_id = request.data.get('country_category_id')
                    # business_id = request.user.businessdetail.id  
                    #user_detail_page = request.user.user_detail_page  # Assuming user_detail_page is linked to the user
                    currency_id = user_detail_page['company_detail']['id'] 

                    try:
                        
                        plan_days_instance = PlanDaysAndDiscount.objects.get(id=plan_days_id)
                        currency_instance = Currency.objects.get(id=currency_type_id)
                        country_instance = CountryCategory.objects.get(id=country_category_id)

                        
                        total_days = plan_days_instance.plan_days
                        discount_percentage = plan_days_instance.discount_percentage
                        currency_symbol = currency_instance.currency_symbol
                        country_type = country_instance.country

                       
                        #total_price = sum(item['price'] for item in plans_detail['plan_product'])  # Sum of all product prices
                        discount_amount = (total_price * discount_percentage) / 100
                        total_price_after_discount = total_price - discount_amount
                       # total_tax_percentage = 20
                        tax_percentage_instance = TaxPercentageDetail.objects.first()

                        total_tax_percentage = tax_percentage_instance.tax_percentage if tax_percentage_instance else None

                        total_tax_in_currency = total_price_after_discount * (total_tax_percentage / 100)
                        total_price_after_tax = total_price_after_discount + total_tax_in_currency

                        total_minutes = total_days * 24 * 60

                       
                        business_plan_history = {
                            'plan_name': get_plan.plan_name,
                            'price': total_price,
                            'price_after_discount': total_price_after_discount,
                            'price_after_tax': total_price_after_tax,
                            'days_price': total_price / total_days,
                            'days_price_after_discount': total_price_after_discount / total_days,
                            'days_price_after_tax': total_price_after_tax / total_days,
                            'currency_id': currency_detail['id'],
                            'currency_type': request.data.get('currency_type'),
                            'currency_symbol': currency_symbol,
                            'country_category_id': get_plan_pricing.country_type_id.id,
                            'country_type': country_type,
                            'plan_id': get_plan.id,
                            'plan_days_and_discount_id': get_plan_days_and_discount.id,
                            'plan_days': total_days,
                            'discount_in_percentage': discount_percentage,
                            'discount_in_currency': discount_amount,
                            'total_discount': total_price_after_discount,
                            'total_tax_in_percentage': total_tax_percentage,
                            'total_tax_in_currency': total_tax_in_currency,
                            'buy_datetime': timezone.now(),
                            'plan_start_datetime': timezone.now(),
                            'plan_expire_datetime': timezone.now() + timezone.timedelta(days=total_days),
                            'minutes_to_expire': total_minutes,
                            'days_to_expire': total_days,
                            'plan_validity': True,
                            'plan_status': 'pending',
                            'current_active': False,
                            'plan_type': 'Upgrade Plan',
                            #'currency_detail': currency_id,
                            'company_detail_id':company_id
                        }

                      
                        refund_amount = remaining_value
                        # business_plan_history['price'] = max(0, business_plan_history['price'] - refund_amount)
                        # business_plan_history['price_after_discount'] = max(0, business_plan_history['price_after_discount'] - refund_amount)
                        business_plan_history['price_after_tax'] = max(0, business_plan_history['price_after_tax'] - refund_amount)
                        print("refund amount:",refund_amount)

                    except (PlanDaysAndDiscount.DoesNotExist, Currency.DoesNotExist, CountryCategory.DoesNotExist, CompanyDetail.DoesNotExist) as e:
                        return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)

                    # try:
                    #     existing_plan_id = request.data.get('existing_plan_id')
                    #     existing_plan = BusinessPlanHistory.objects.get(id=existing_plan_id)

                    #     remaining_days = self.calculate_remaining_days(existing_plan)
                    #     pro_rated_refund = self.calculate_pro_rated_refund(existing_plan, remaining_days)

                    #     # Subtract the pro-rated refund from the new plan's price
                    #     business_plan_history['price'] -= pro_rated_refund
                    #     business_plan_history['price_after_discount'] -= pro_rated_refund
                    #     business_plan_history['price_after_tax'] -= pro_rated_refund

                    #     # Ensure prices do not go below zero
                    #     business_plan_history['price'] = max(0, business_plan_history['price'])
                    #     business_plan_history['price_after_discount'] = max(0, business_plan_history['price_after_discount'])
                    #     business_plan_history['price_after_tax'] = max(0, business_plan_history['price_after_tax'])

                    # except BusinessPlanHistory.DoesNotExist:
                    #     return Response({'error': 'Invalid existing_plan_id'}, status=status.HTTP_400_BAD_REQUEST)



                    # business_plan_history = {
                    #     'plan_name':get_plan.plan_name,
                    #     'price':total_price,
                    #     'price_after_discount':total_price_after_discount,
                    #     'price_after_tax':total_price_after_tax,
                    #     'days_price':days_total_price,
                    #     'days_price_after_discount': days_total_price_after_discount,
                    #     'days_price_after_tax': days_total_price_after_tax,
                    #     'currency_id':currency_detail['id'],
                    #     'currency_type':currency_detail['currency_type'],
                    #     'currency_symbol':currency_detail['currency_symbol'],
                    #     # 'country_category_id':get_plan_pricing.country_type_id,
                    #     # 'country_type':get_plan_pricing.country_type_id__country,
                    #     'country_category_id':get_plan_pricing.country_type_id.id,
                    #     'country_type':get_plan_pricing.country_type_id.country,
                    #     'plan_id':get_plan.id,
                    #     'plan_days_and_discount_id':get_plan_days_and_discount.id,
                    #     'plan_days':get_plan_days_and_discount.plan_days,
                    #     'discount_in_percentage':get_plan_days_and_discount.discount_percentage,
                    #     'discount_in_currency': discount_amount,
                    #     'total_discount': total_price_after_discount,
                    #     'total_tax_in_percentage':total_tax_percentage,
                    #     'total_tax_in_currency':total_tax_in_currency,
                    #     'buy_datetime':timezone.datetime.now(),
                    #     'plan_start_datetime':timezone.datetime.now(),
                    #     #'plan_expire_datetime': datetime.datetime.now()+get_plan_days_and_discount['plan_days'],
                    #     'plan_expire_datetime': timezone.datetime.now() + timezone.timedelta(days=get_plan_days_and_discount.plan_days),
                    #     'minutes_to_expire':total_minutes,
                    #     'days_to_expire':total_days,
                    #     'plan_validity':True,
                    #     'plan_status':'pending',
                    #     'current_active':False,
                    #     'plan_type':'Upgrade Plan',
                    #     #'business_detail_id':user_detail_page['business_detail']['id']
                    #     'business_detail_id':business_id
                    # }
                    print("business plan history:",business_plan_history)
                    if 'currency_id' in business_plan_history:
                        currency_id = business_plan_history['currency_id']
                        
                        try:
                            
                            currency_instance = Currency.objects.get(id=currency_id)
                        except Currency.DoesNotExist:
                            
                            return Response({'error': 'Invalid currency_id'}, status=status.HTTP_400_BAD_REQUEST)
                    else:
                        
                        return Response({'error': 'currency_id is missing'}, status=status.HTTP_400_BAD_REQUEST)

                    
                    business_plan_history['currency_id'] = currency_instance
                    
                    if 'country_category_id' in business_plan_history:
                        country_category_id = business_plan_history['country_category_id']
                        try:
                            
                            country_category_instance = CountryCategory.objects.get(id=country_category_id)
                        except CountryCategory.DoesNotExist:
                            
                            return Response({'error': 'Invalid country_category_id'}, status=status.HTTP_400_BAD_REQUEST)
                    else:
                        
                        return Response({'error': 'country_category_id is missing'}, status=status.HTTP_400_BAD_REQUEST)

                    
                    business_plan_history['country_category_id'] = country_category_instance

                    if 'plan_id' in business_plan_history:
                        plan_id = business_plan_history['plan_id']
                        try:
                           
                            plan_instance = Plans.objects.get(id=plan_id)
                        except Plans.DoesNotExist:
                            
                            return Response({'error': 'Invalid plan_id'}, status=status.HTTP_400_BAD_REQUEST)
                    else:
                        
                        return Response({'error': 'plan_id is missing'}, status=status.HTTP_400_BAD_REQUEST)

                    
                    business_plan_history['plan_id'] = plan_instance

                    if 'plan_days_and_discount_id' in business_plan_history:
                        plan_days_and_discount_id = business_plan_history['plan_days_and_discount_id']
                        try:
                           
                            plan_days_and_discount_instance = PlanDaysAndDiscount.objects.get(id=plan_days_and_discount_id)
                        except PlanDaysAndDiscount.DoesNotExist:
                           
                            return Response({'error': 'Invalid plan_days_and_discount_id'}, status=status.HTTP_400_BAD_REQUEST)
                    else:
                        
                        return Response({'error': 'plan_days_and_discount_id is missing'}, status=status.HTTP_400_BAD_REQUEST)

                    
                    business_plan_history['plan_days_and_discount_id'] = plan_days_and_discount_instance

                    if 'company_detail_id' in business_plan_history:
                        company_detail_idd = business_plan_history['company_detail_id']
                        print("company id :",company_detail_idd)
                        try:
                            
                            company_detail_instance = CompanyDetail.objects.get(id=company_detail_idd)
                            print("company_detail_instance",company_detail_instance)
                        except CompanyDetail.DoesNotExist:
                            
                            return Response({'error': 'Invalid business_detail_id'}, status=status.HTTP_400_BAD_REQUEST)
                    else:
                       
                        return Response({'error': 'business_detail_id is missing'}, status=status.HTTP_400_BAD_REQUEST)

                    
                    business_plan_history['company_detail_id'] = company_detail_instance


                    try:
                        
                        existing_plan_id = request.data.get('existing_plan_id')
                        print("existing id ", existing_plan_id)
                       
                        #product_data = request.data.get('product_data')
                        print("PLANs DATA:",plans_data)
                        #print(business_plan_history)
                       
                        existing_plan_details = extract_existing_plan_details(existing_plan_id, product_data)
                        updated_plan_details = extract_updated_plan_details(plans_data, product_data,business_plan_history)

                        #print("Product Data:", product_data)
                        
                        with transaction.atomic():
                           
                            if is_valid_upgrade(existing_plan_details, updated_plan_details):
                                existing_plan = BusinessPlanHistory.objects.get(id=existing_plan_id)
                                existing_plan.current_active = False
                                existing_plan.save()
                                print("existing planss", existing_plan)
                                updated_plan = BusinessPlanHistory(**business_plan_history)
                                updated_plan.current_active = True
                                updated_plan.save()
                                #print("business plan history:",business_plan_history)
                                #business_plan_history_id=updated_plan
                                # refund_amount = remaining_value

                                
                                update_related_models(existing_plan_id, updated_plan_details,updated_plan)
                                business_plan_history_instance = BusinessPlanHistory.objects.get(
                                plan_name=business_plan_history['plan_name'],
                                price_after_tax=business_plan_history['price_after_tax'],
                                
                            )

                                try:


                                    #user = User.objects.get(id=user_id)
                                    
                                    email = request.user.email
                                    print(email)
                                    phone_number = request.user.phone_number


                                    autopay_option = request.POST.get('autopay_option', None)

                                    
                                    if autopay_option == 'enable':
                                        
                                        response = create_subscription(request, business_plan_history, email, phone_number)


                                    #logger.info(f"create_subscription response: {response}")
                    
                    
                                    #return response

                                        if not response.get('success', False):

                                            print("Error details:")
                                            # traceback.print_exc()

                                            # # for obj in created_objects:
                                            # #     obj.delete()
                                            
                                            
                                            # logger.info(f"create_subscription response: {response}")
                        
                                            return response
                                        
                                        return JsonResponse({'An ERROR OCCURRED': response.get('message', 'Failed to create subscription')}, status=500)
                                
                                
                                    api_response_data, payment_session_id = process_cashfree_payment_upgrade(request, business_plan_history, email, phone_number)

                                    if api_response_data is None:
                                        
                                        return JsonResponse({'An ERROR OCCURRED': 'No data returned'}, status=500)
                                    
                                    if payment_session_id:
                                    
                                        # return JsonResponse({'payment_session_id': payment_session_id})
                                        # return Response(api_response_data)
                                        # response_data = {
                                        #     'api_response_data': api_response_data,
                                        #     'payment_session_id': payment_session_id
                                        # }
                                        # return Response(response_data)
                                        return render(request, 'checkout.html', {'payment_session_id': payment_session_id})
                                    else:
                                        
                                        return JsonResponse({'An ERROR OCCURRED': 'Payment session ID not found'}, status=500)

                                #         #serialized_data = serializers.serialize('json', [api_response_data])
                                
                                except Exception as e:
                                    # for obj in created_objects:
                                    #     obj.delete()
                                    
                                    return JsonResponse({'AN ERROR OCCURRED': str(e)}, status=500)
                                            
                                    

                                
                            else:
                                return Response({'error': 'Invalid upgrade request'}, status=status.HTTP_400_BAD_REQUEST)

                    # except ObjectDoesNotExist:
                    #     return Response({'error': 'BusinessPlanHistory does not exist'}, status=status.HTTP_400_BAD_REQUEST)

                    except Exception as e:
                        return Response({'error': f'Upgrade and payment failed: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
                                
                    #             return Response({'message': 'Upgrade successful'}, status=status.HTTP_200_OK)
                    #         else:
                    #             return Response({'error': 'Invalid upgrade request'}, status=status.HTTP_400_BAD_REQUEST)
                    # except Exception as e:
                    #     return Response({'error': f'Upgrade failed: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        
                # business_plan_history_serializer = BusinessPlanHistorySerializer(data=business_plan_history)
                # business_plan_history_id = None
                # if business_plan_history_serializer.is_valid():
                #     business_plan_history_obj = business_plan_history_serializer.save()
                #     business_plan_history_id = business_plan_history_obj.id
                # else:
                #     return Response(business_plan_history_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                # business_pricing_tax_ids = []
                # for business_pricing_tax in tax_detail:
                #     business_pricing_tax['business_plan_history_id'] = business_plan_history_id
                #     business_pricing_tax_serializer = BusinessPlanPricingTaxSerializer(data=business_pricing_tax)
                #     business_pricing_tax_id = None
                #     if business_pricing_tax_serializer.is_valid():
                #         business_pricing_tax_obj = business_pricing_tax_serializer.save()
                #         business_pricing_tax_id = business_pricing_tax_obj.id
                #         business_pricing_tax_ids.append(business_pricing_tax_id)
                #     else:
                #         return Response(business_plan_history_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                # business_plan_coupon_id = None
                # if business_coupon != None:
                #     business_coupon['business_plan_history_id'] = business_plan_history_id
                #     business_coupon_serializer = BusinessPlanCoupon(data=business_coupon)
                #     if business_coupon_serializer.is_valid():
                #         business_coupon_obj = business_coupon_serializer.save()
                #         business_plan_coupon_id = business_coupon_obj.id
                #     else:
                #         for business_plan_pricing_tax_id in business_pricing_tax_ids:
                #             BusinessPlanPricingTax.objects.filter(id=business_plan_pricing_tax_id).delete()
                #         for business_pricing_id in business_pricing_tier_ids:
                #             BusinessPricingTier.objects.filter(id=business_pricing_id).delete()
                #         BusinessPlanHistory.objects.filter(id=business_plan_history_id).delete()
                # business_pricing_tier_ids = []
                # for plans in plans_data:
                #     plans['business_plan_history_id'] = business_plan_history_id
                #     business_pricing_tier_serializer = BusinessPricingTierSerializer(data=plans)
                #     business_pricing_tier_id = None
                #     if business_pricing_tier_serializer.is_valid():
                #         business_pricing_tier_obj = business_pricing_tier_serializer.save()
                #         business_pricing_tier_id = business_pricing_tier_obj.id
                #         business_pricing_tier_ids.append(business_pricing_tier_id)
                #     else:
                #         if business_plan_coupon_id != None:
                #             BusinessPlanCoupon.objects.filter(id=business_plan_coupon_id).delete()
                #         for business_plan_pricing_tax_id in business_pricing_tax_ids:
                #             BusinessPlanPricingTax.objects.filter(id=business_plan_pricing_tax_id).delete()
                #         for business_pricing_id in business_pricing_tier_ids:
                #             BusinessPricingTier.objects.filter(id=business_pricing_id).delete()
                #         BusinessPlanHistory.objects.filter(id=business_plan_history_id).delete()
                #         return Response(business_pricing_tier_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                
            
                else:
                    return Response({"detail": "Plans days doesn't exist."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "Plans not exist."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)
        

    def put(self, request,id,format=None):
        user_detail_page = get_user_data_page_plans(request.user.id,'upgrade_plan','view')
        AccessToPage = False
        if user_detail_page['permission'] != None:
            AccessToPage = True
        if AccessToPage == True:
            data = request.data
            print(data)
            plans_data = {}
            plans_detail = data['plans_detail']
            currency_detail = Currency.objects.filter(currency_type=request.data['currency_type']).values('id','currency_type','currency_symbol').first()
            get_plan = Plans.objects.filter(id=plans_detail['id'],plan_name=plans_detail['plan_name']).first()
            #get_plan = Plans.objects.filter(id=id).first()
            #print(get_plan)
            id = get_plan.id
            plan_name = get_plan.plan_name
            get_plan_days_and_discount_all = PlanDaysAndDiscount.objects.filter(plan_id=id).all()
            plans_data['plan_days']= []
            plan_days = 0
            total_price=0
            total_price_after_discount=0
            discount_amount=0
            for plan_days_detail in get_plan_days_and_discount_all:
                selected = False
                if data['plan_days_id'] == plan_days_detail.id:
                    selected = True
                    plan_days = plan_days_detail.plan_days
                    plan_pricing_id = plan_days_detail.plan_pricing_id.id
                plans_data['plan_days'].append({
                   # 'id':plan_days_detail.id,
                    'plan_days':plan_days_detail.plan_days,
                    'discount_percentage':plan_days_detail.discount_percentage,
                    'category':plan_days_detail.category,
                    'default_select':selected,
                    #'plan_pricing_id':plan_days_detail.plan_pricing_id
                   # 'plan_pricing_id': plan_pricing_id
                    
                })
            get_plan_days_and_discount = PlanDaysAndDiscount.objects.filter(plan_id=id,id=data['plan_days_id']).first()
            plans_data['product_data'] = []
            if get_plan_days_and_discount != None:
                plan_days = get_plan_days_and_discount.plan_days
                product_data = plans_detail['plan_product'][0]
                parking_product_data = PlanFeaturePricingTier.objects.filter(plan_id=id,pricing_feature_category_id__category_name="Product",default_product_id__product_name='Visitor management system',id=plans_detail['plan_product'][0]['plan_feature_pricing_tier_id'],show_plan_pricing=True).values('id','uuid','default_product_id','default_product_id__product_name','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                print("parkingpdata",parking_product_data)
                all_product_total_price = 0.0
                if parking_product_data != None:
                    # camera_quantity = product_data['plan_camera_detail']['camera_quantity']
                    product_data_json = {}
                   # product_data_json['id'] = parking_product_data['id']
                    product_data_json['product_name'] = parking_product_data['default_product_id__product_name']

                    plan_feature_days_price_product = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=parking_product_data['id'],currency_id=data['currency_type_id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                    plan_feature_days_price_product_instance = plan_feature_days_price_product.first()

                    if plan_feature_days_price_product_instance:
                           default_product_price = plan_days  * plan_feature_days_price_product_instance['days_price']
                           default_product_price_days =  plan_feature_days_price_product_instance['days_price']
                    else:
                        #print("error in defaultproductprice")
                            default_product_price = 0 
                            default_product_price_days = 0
                    product_selected_exist = True
                    # product_selected_exist = True
                    # default_product_price = plan_days * camera_quantity * plan_feature_days_price_product['days_price']
                    # default_product_price_days = camera_quantity * plan_feature_days_price_product['days_price']

                    product_data_json['plan_product']={
                        # 'id':parking_product_data['id'],
                        # 'uuid':parking_product_data['uuid'],
                        'days_price':default_product_price_days,
                        'price': default_product_price,
                        #'currency_symbol':plan_feature_days_price_product_instance['currency_id__currency_symbol'],
                       # 'currency_id':currency_detail['id'],
                        #'pricing_feature_category_id':parking_product_data['pricing_feature_category_id'],
                        #'category_name':parking_product_data['pricing_feature_category_id__category_name'],
                       # 'default_selected':product_selected_exist,
                        #'plan_id':parking_product_data['plan_id'],
                        'plan_pricing_description':parking_product_data['plan_pricing_description'],
                        #'show_plan_pricing':parking_product_data['show_plan_pricing']
                    }

                    default_parking_product_feature_data = PlanFeaturePricingTier.objects.filter(plan_id=id,pricing_feature_category_id__category_name="Feature",default_product_id__product_name='Visitor management system',is_encluded_plan_feature_id__isnull=False,default_product_feature_id__isnull=False).values('id','uuid','default_product_id','default_product_id__product_name','default_product_feature_id','default_product_feature_id__feature','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').all()
                    product_data_json['plan_product_feature_default'] = []
                    for default_product_feature in default_parking_product_feature_data:
                        product_data_json['plan_product_feature_default'].append({
                            # 'id':default_product_feature['id'],
                            # 'uuid':default_product_feature['uuid'],
                            # 'default_product_feature_id':default_product_feature['default_product_feature_id'],
                            # 'pricing_feature_category_id':default_product_feature['pricing_feature_category_id'],
                            'category_name':default_product_feature['pricing_feature_category_id__category_name'],
                            'feature_name':default_product_feature['default_product_feature_id__feature'],
                            'plan_pricing_description':default_product_feature['plan_pricing_description'],       
                        })
                    parking_product_feature_data = PlanFeaturePricingTier.objects.filter(plan_id=id,pricing_feature_category_id__category_name="Feature",default_product_id__product_name='Visitor management system',is_encluded_plan_feature_id__isnull=False,default_product_feature_id__isnull=False).values('id','uuid','default_product_id','default_product_id__product_name','default_product_feature_id','default_product_feature_id__feature','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').all()
                    product_data_json['plan_product_feature'] = []
                    default_product_feature_price = 0.0
                    for product_feature in parking_product_feature_data:
                        # plan_feature_days_price_product_feature = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=product_feature['id'],currency_id=data['currency_type_id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                        # product_feature_price = plan_days * camera_quantity * plan_feature_days_price_product_feature['days_price']
                        # product_feature_price_days = camera_quantity * plan_feature_days_price_product_feature['days_price']
                        # default_selected = False
                        plan_feature_days_price_product_feature = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=product_feature['id'],currency_id=currency_detail['id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                        plan_feature_days_price_product_feature_instance = plan_feature_days_price_product_feature.first()  
                        if plan_feature_days_price_product_feature_instance:
                            product_feature_price = plan_days * plan_feature_days_price_product_feature_instance['days_price']
                            product_feature_price_days =  plan_feature_days_price_product_feature_instance['days_price']
                        else:
                            
                            product_feature_price = 0  
                        # product_feature_price = plan_days * camera_quantity * plan_feature_days_price_product_feature_instance['days_price']
                        # product_feature_price_days = camera_quantity * plan_feature_days_price_product_feature_instance['days_price']
                        default_selected = False
                        
                        product_feature_price = plan_days * plan_feature_days_price_product_feature_instance['days_price']
                        product_feature_price_days = plan_feature_days_price_product_feature_instance['days_price']
                        default_selected = False
                        feature_plan_selected = [feature_plan for feature_plan in product_data['plan_feature_detail'] if feature_plan['plan_feature_pricing_tier_id']==product_feature['id'] and feature_plan['selected']==True]
                        if len(feature_plan_selected) > 0:
                            default_selected = True
                            default_product_feature_price += product_feature_price
                            product_data_json['plan_product_feature']={
                                'price':product_feature_price,
                                'days_price':product_feature_price_days,
                                'currency_id':currency_detail['id'],
                                # 'default_product_id':parking_product_data['default_product_id'],
                                # 'default_product_feature_id':product_feature['default_product_feature_id'],
                                # 'plan_feature_pricing_category_id':product_feature['pricing_feature_category_id'],
                                'category_name':product_feature['pricing_feature_category_id__category_name'],
                               # 'plan_id':id,
                                #'plan_feature_pricing_tier_id':product_feature['id'],
                                #'business_detail_id':user_detail_page['business_detail']['id'],
                                'plan_pricing_description':product_feature['plan_pricing_description']
                            }
                    existing_plan_id = request.data.get('existing_plan_id')
                    #existing_plan = BusinessPlanHistory.objects.get(id=existing_plan_id)
                    try:
                        existing_plan = BusinessPlanHistory.objects.get(id=existing_plan_id)
                        remaining_value = self.calculate_remaining_value(existing_plan)
                    except BusinessPlanHistory.DoesNotExist:
                        return JsonResponse({'error': 'Invalid existing_plan_id'}, status=status.HTTP_400_BAD_REQUEST)
                    refund_amount = remaining_value
                   
                    
                    total_price = default_product_price+default_product_feature_price
                    all_product_total_price+=total_price
                    print("total_price",total_price)
                    

                    print("total price",total_price)
                    existing_plan_id = data.get('existing_plan_id')
                    try:
                        existing_plan = BusinessPlanHistory.objects.get(id=existing_plan_id)
                        remaining_value = self.calculate_remaining_value(existing_plan)
                    except BusinessPlanHistory.DoesNotExist:
                        return JsonResponse({'error': 'Invalid existing_plan_id'}, status=status.HTTP_400_BAD_REQUEST)

                    
                    refund_amount = remaining_value

                    adjusted_total_price = max(0, total_price - refund_amount)
                   
                   
                    plans_data['product_data'].append(product_data_json)
                    discount_amount = (adjusted_total_price * get_plan_days_and_discount.discount_percentage)/100
                    total_price_after_discount = adjusted_total_price - discount_amount
                    if plans_detail['coupon_code'] != None:
                        get_coupon = Coupon.objects.filter(code=plans_detail['coupon_code'],currency_id=data['currency_type_id'],plan_buy_days__gte=plan_days,coupon_expiry_datetime__gte= timezone.datetime.now(),is_active=True).values('id','uuid','code','description','discount_type','discount_value','currency_id','currency_id__currency_type').first()
                        if get_coupon != None:
                            total_coupon_amount = 0.0
                            if get_coupon['discount_type'] == 'percentage':
                                total_coupon_amount =  (all_product_total_price * get_coupon['discount_value'])/100
                            elif get_coupon['discount_type'] == 'fixed amount':
                                total_coupon_amount = all_product_total_price - get_coupon['discount_value']
                            total_price_after_discount -= total_coupon_amount

                        plans_data['coupon_code'] ={
                            # 'id':get_coupon['id'],
                            # 'uuid':get_coupon['uuid'],
                            'code':get_coupon['code'],
                            'description':get_coupon['description'],
                            'discount_type':get_coupon['discount_type'],
                            'discount_value':get_coupon['discount_value'],
                            # 'currency_id':get_coupon['currency_id'],
                            'total_coupon_amount':total_coupon_amount
                        }

                    else:
                        return Response({'detail':"coupon code is not valid."},status.HTTP_400_BAD_REQUEST)

                plan_pricing_tax_detail = PlanPricingTax.objects.filter(plan_pricing_id = get_plan_days_and_discount.plan_pricing_id).values('id','uuid','plan_pricing_id','tax_percentage_detail_id','tax_percentage_detail_id__tax_percentage','tax_percentage_detail_id__tax_type')
                tax_detail = []
                total_price_after_tax = total_price_after_discount
                for pricing_tax in plan_pricing_tax_detail:
                    tax_amount = (total_price_after_discount*pricing_tax['tax_percentage_detail_id__tax_percentage'])/100
                    total_price_after_tax += tax_amount
                    tax_detail.append({
                        # 'id':pricing_tax['id'],
                        # 'uuid':pricing_tax['uuid'],
                        # 'tax_percentage_detail_id':pricing_tax['tax_percentage_detail_id'],
                        'tax_percentage':pricing_tax['tax_percentage_detail_id__tax_percentage'],
                        'tax_type':pricing_tax['tax_percentage_detail_id__tax_type'],
                        'tax_amount':tax_amount
                    })
                plans_data['plan_pricing'] ={
                    'total_price':total_price,
                    'refund_amount':refund_amount,
                    'adjusted_total_amount': adjusted_total_price,
                    'discount_amount':discount_amount,
                    'total_price_after_discount':total_price_after_discount,
                    'total_price_after_tax':total_price_after_tax,
                    'tax_detail':tax_detail
                }
                    
            return Response(plans_data, status=status.HTTP_200_OK)
        else:
            return Response({"detail": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)


class GetUpgradePlanDetail(APIView):
    permission_classes = (AllowAny,)
    def get(self, request,existing_plan_id):
            currency_type_id = request.GET.get('currency', 1)
            print("currencytypeid:", currency_type_id)
            plans_data = {}
                
            try:
                    existing_plan = BusinessPlanHistory.objects.get(id=existing_plan_id)
                    print(existing_plan)
            except BusinessPlanHistory.DoesNotExist:
                    return Response({'error': 'Existing plan not found'}, status=404)
        # user_detail_page = get_user_data_page_plans(request.user.id,'upgrade_plan','view')  
        # print("udp", user_detail_page)
        # AccessToPage = False
        # if user_detail_page['permission'] != None:
        #     AccessToPage = True
        # if AccessToPage == True:
            # currency_type_id = request.GET.get('currency',4)
            # print("currencytypeid:", currency_type_id)
            # plans_data = {}
            get_plan = existing_plan.plan_id
            print(get_plan)
            plans_data['id'] = get_plan.id
            print(plans_data)
            plans_data['plan_name'] = get_plan.plan_name
            get_plan_days_and_discount_all = PlanDaysAndDiscount.objects.filter(plan_id=get_plan.id).all()
            print(get_plan_days_and_discount_all)
            plans_data['plan_days']= []

            for plan_days_detail in get_plan_days_and_discount_all:
                # plan_days = user_detail_page['business_plan_history_detail'].plan_days
                # default_selected = False
                default_selected = existing_plan.plan_days == plan_days_detail.plan_days
                print(default_selected)
                #if plan_days == plan_days_detail.plan_days:
                    #default_selected = True
                # plan_days_and_discount_id = user_detail_page['business_plan_history_detail']['plan_days_and_discount_id']
                plans_data['plan_days'].append({
                   # 'id':plan_days_detail.id,
                    'plan_days':plan_days_detail.plan_days,
                    'discount_percentage':plan_days_detail.discount_percentage,
                    'category':plan_days_detail.category,
                    #'default_select':default_selected,
                   # 'plan_pricing_id':plan_days_detail.plan_pricing_id
                })
            print(plans_data)
            get_plan_days_and_discount = PlanDaysAndDiscount.objects.filter(plan_id=get_plan.id,default_select=True).first()
            plans_data['product_data'] = []
            if get_plan_days_and_discount != None:
                plan_days = get_plan_days_and_discount.plan_days
                print("PLAN DAYS:", plan_days)
                parking_product_data = PlanFeaturePricingTier.objects.filter(plan_id=get_plan.id,pricing_feature_category_id__category_name="Product",default_product_id__product_name='Visitor management system').values('id','uuid','default_product_id','default_product_id__product_name','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                print("ppd",parking_product_data)
                all_product_total_price = 0.0
                if parking_product_data != None:
                    #plan_features_pricing_tier_camera = PlanFeaturePricingTier.objects.filter(plan_id=get_plan.id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Camera').values('id','uuid','min_quantity','max_quantity','default_quantity','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                    # print("pfptc", plan_features_pricing_tier_camera)
                    # camera_quantity = 1
                    # if plan_features_pricing_tier_camera != None:
                    #     camera_quantity = plan_features_pricing_tier_camera['default_quantity']

                    product_data_json = {}
                    #product_data_json['id'] = parking_product_data['id']
                    product_data_json['product_name'] = 'Visitor management system'

                    plan_feature_days_price_product = PlanFeatureDaysPrice.objects.filter(plans_id=get_plan.id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=parking_product_data['id'],currency_id=currency_type_id).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                   # plan_feature_days_price_product = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=parking_product_data['id'],currency_id=data['currency_type_id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                    plan_feature_days_price_product_instance = plan_feature_days_price_product.first()

                    if plan_feature_days_price_product_instance:
                           default_product_price = plan_days * plan_feature_days_price_product_instance['days_price']
                           default_product_price_days =  plan_feature_days_price_product_instance['days_price']
                    else:
                        #print("error in defaultproductprice")
                            default_product_price = 0 
                            default_product_price_days = 0
                    product_selected_exist = True
                    # product_selected_exist = True
                    # default_product_price = plan_days * camera_quantity * plan_feature_days_price_product['days_price']
                    # default_product_price_days = camera_quantity * plan_feature_days_price_product['days_price']
                    product_data_json['plan_product']={
                        # 'id':parking_product_data['id'],
                        # 'uuid':parking_product_data['uuid'],
                        'days_price':default_product_price_days,
                        'price': default_product_price,
                        'currency_symbol':plan_feature_days_price_product_instance['currency_id__currency_symbol'],
                        # 'pricing_feature_category_id':parking_product_data['pricing_feature_category_id'],
                        # 'category_name':parking_product_data['pricing_feature_category_id__category_name'],
                        # 'default_selected':product_selected_exist,
                        # 'plan_id':parking_product_data['plan_id'],
                        # 'plan_pricing_description':parking_product_data['plan_pricing_description'],
                        # 'show_plan_pricing':parking_product_data['show_plan_pricing']
                    }
                    print("product_data_json",product_data_json)
                    default_parking_product_feature_data = PlanFeaturePricingTier.objects.filter(plan_id=get_plan.id,pricing_feature_category_id__category_name="Feature",default_product_id__product_name='Visitor management system',is_encluded_plan_feature_id__isnull=False,default_product_feature_id__isnull=False).values('id','uuid','default_product_id','default_product_id__product_name','default_product_feature_id','default_product_feature_id__feature','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').all()
                    product_data_json['plan_product_feature_default'] = []
                    for default_product_feature in default_parking_product_feature_data:
                        
                        product_data_json['plan_product_feature_default'].append({
                            # 'id':default_product_feature['id'],
                            # 'uuid':default_product_feature['uuid'],
                            # 'default_product_feature_id':default_product_feature['default_product_feature_id'],
                            # 'pricing_feature_category_id':default_product_feature['pricing_feature_category_id'],
                            'category_name':default_product_feature['pricing_feature_category_id__category_name'],
                            'feature_name':default_product_feature['default_product_feature_id__feature'],
                            'plan_pricing_description':default_product_feature['plan_pricing_description'],

                        })
                    parking_product_feature_data = PlanFeaturePricingTier.objects.filter(plan_id=get_plan.id,pricing_feature_category_id__category_name="Feature",default_product_id__product_name='Visitor management system',is_encluded_plan_feature_id__isnull=False,default_product_feature_id__isnull=False).values('id','uuid','default_product_id','default_product_id__product_name','default_product_feature_id','default_product_feature_id__feature','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').all()
                    print("ppfd",parking_product_feature_data)
                    product_data_json['plan_product_feature'] = []
                    default_product_feature_price = 0.0
                    for product_feature in parking_product_feature_data:
                        plan_feature_days_price_product_feature = list(PlanFeatureDaysPrice.objects.filter(plans_id=get_plan.id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=product_feature['id'],currency_id=currency_type_id).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected'))
                        print("plan_feature_days_price_product_feature:",plan_feature_days_price_product_feature)
                        #product_feature_price = plan_days * camera_quantity * plan_feature_days_price_product_feature['days_price']
                        if plan_feature_days_price_product_feature:
                                for feature in plan_feature_days_price_product_feature:
                                    
                                    product_feature_price = plan_days *  feature['days_price']
                                    print("Product feature price:", product_feature_price)
                                    product_feature_price_days = feature['days_price']
                                    print("product feature price days", product_feature_price_days)
                        else:
                            print("No matching plan feature days price found")
                    
                        plan_feature_days_price_product_feature = PlanFeatureDaysPrice.objects.filter(plans_id=get_plan.id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=product_feature['id'],currency_id=currency_type_id).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                        plan_feature_days_price_product_feature_instance = plan_feature_days_price_product_feature.first()  
                        if plan_feature_days_price_product_feature_instance:
                            product_feature_price = plan_days *  plan_feature_days_price_product_feature_instance['days_price']
                            product_feature_price_days =  plan_feature_days_price_product_feature_instance['days_price']
                            print("product_feature_price", product_feature_price)
                            print("product_feature_price_days",product_feature_price_days)
                        else:
                            
                            product_feature_price = 0  

                        default_selected = False
                        product_feature_price_days = 0
                        
                        default_product_feature_price += product_feature_price
                        default_selected = True
                        product_data_json['plan_product_feature'].append({
                            # 'id':product_feature['id'],
                            # 'uuid':product_feature['uuid'],
                            'days_price':product_feature_price_days,
                            'price': product_feature_price,
                            'currency_symbol':plan_feature_days_price_product_instance['currency_id__currency_symbol'],
                            # 'default_product_feature_id':product_feature['default_product_feature_id'],
                             'feature_name':product_feature['default_product_feature_id__feature'],
                            # 'pricing_feature_category_id':product_feature['pricing_feature_category_id'],
                            # 'category_name':product_feature['pricing_feature_category_id__category_name'],
                            # 'default_selected':default_selected,
                            # 'plan_id':product_feature['plan_id'],
                            'plan_pricing_description':product_feature['plan_pricing_description'],
                            # 'show_plan_pricing':product_feature['show_plan_pricing']
                        })

              
                    
                    total_price =  default_product_price + default_product_feature_price
                    all_product_total_price+=total_price
                    plans_data['product_data'].append(product_data_json)

                discount_amount = (all_product_total_price * get_plan_days_and_discount.discount_percentage)/100
                total_price_after_discount = all_product_total_price - discount_amount
                plans_data['coupon_code'] = None
                plan_pricing_tax_detail = PlanPricingTax.objects.filter(plan_pricing_id = get_plan_days_and_discount.plan_pricing_id).values('id','uuid','plan_pricing_id','tax_percentage_detail_id','tax_percentage_detail_id__tax_percentage','tax_percentage_detail_id__tax_type')
                tax_detail = []
                total_price_after_tax = total_price_after_discount
                for pricing_tax in plan_pricing_tax_detail:
                    tax_amount = (total_price_after_discount*pricing_tax['tax_percentage_detail_id__tax_percentage'])/100
                    total_price_after_tax += tax_amount
                    tax_detail.append({
                        # 'id':pricing_tax['id'],
                        # 'uuid':pricing_tax['uuid'],
                        #'tax_percentage_detail_id':pricing_tax['tax_percentage_detail_id'],
                        'tax_percentage':pricing_tax['tax_percentage_detail_id__tax_percentage'],
                        'tax_type':pricing_tax['tax_percentage_detail_id__tax_type'],
                        'tax_amount':tax_amount
                    })

                
            #     plans_data['plan_pricing'] ={
            #         'total_price':all_product_total_price,
            #         'discount_amount':discount_amount,
            #         'total_price_after_discount':total_price_after_discount,
            #         'total_price_after_tax':total_price_after_tax,
            #         'tax_detail':tax_detail
            #     }

            # return JsonResponse(plans_data, status=status.HTTP_200_OK) 
                plan_pricing = PlanPricingView(
                total_price=all_product_total_price,
                discount_amount=discount_amount,
                total_price_after_discount=total_price_after_discount,
                total_price_after_tax=total_price_after_tax,
                tax_detail=tax_detail
            )

                # plans_data = {
                #     'plan_pricing': plan_pricing.to_dict()
                # }
                response_data = {
                    'refund_amount':0.00,
                    'plan_pricing': plan_pricing.to_dict(),
                    #'plan_offline_dashboard_data_backup': product_data_json.get('plan_offline_dashboard_data_backup', {}),
                    'product_data': product_data_json
                }

                return JsonResponse(response_data, status=status.HTTP_200_OK)  
        # else:
        #     return Response({"detail": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

class RenewPlanView(APIView):
    permission_classes = (IsAuthenticated,)
    def post(self, request):
        user_detail_page = get_user_data_page_plans(request.user.id,'upgrade_plan','create')  
        AccessToPage = False
        if user_detail_page['permission'] != None:
            AccessToPage = True
        if AccessToPage == True:
            #plans_detail =  request.data
            data = request.data
            total_price=0.0
            total_tax_in_currency = 0.0
            total_tax_percentage = 0.0
            all_product_total_price = 0.0
            default_product_feature_price = 0.0
            online_dashboard_price = 0.0
            online_data_backup_price = 0.0
            offline_dashboard_price = 0.0
            offline_data_backup_price = 0.0
            currency_detail = Currency.objects.filter(currency_type=request.data['currency_type']).values('id','currency_type','currency_symbol').first()
            #currency_detail = Currency.objects.filter(currency_type=request.data['currency_type']).values('id','currency_type','currency_symbol').first()
            plans_detail = data['plans_detail']
            get_plan = Plans.objects.filter(id=plans_detail['id'],plan_name=plans_detail['plan_name']).first()
            #get_plan = Plans.objects.filter(id=plans_detail['id'],plan_name=plans_detail['plan_name']).first()
            if get_plan != None:
                id = get_plan.id
                plan_name = get_plan.plan_name
                get_plan_days_and_discount = PlanDaysAndDiscount.objects.filter(plan_id=id,id=plans_detail['plan_days_id'],default_select=True).first()
                if get_plan_days_and_discount != None:
                    plans_data= []
                    plan_days = get_plan_days_and_discount.plan_days
                    
                   # plan_features_pricing_tier_camera = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Camera').values('id','uuid','min_quantity','max_quantity','default_quantity','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                    product_data = plans_detail['plan_product'][0]
                    # camera_quantity = product_data['plan_camera_detail']['camera_quantity']
                    parking_product_data = PlanFeaturePricingTier.objects.filter(plan_id=id,pricing_feature_category_id__category_name="Product",default_product_id__product_name='Visitor management system',id=product_data['plan_feature_pricing_tier_id'],show_plan_pricing=True).values('id','uuid','default_product_id','default_product_id__product_name','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                    
                    if parking_product_data != None:
                        
                        # plan_features_pricing_tier_camera = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Camera').values('id','uuid','min_quantity','max_quantity','default_quantity','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                        plan_feature_days_price_product = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=parking_product_data['id'],currency_id=currency_detail['id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                        plan_feature_days_price_product_instance = plan_feature_days_price_product.first()

                        if plan_feature_days_price_product_instance:
                           default_product_price = plan_days * plan_feature_days_price_product_instance['days_price']
                           default_product_price_days = plan_feature_days_price_product_instance['days_price']
                        else:
                            #print("error in defaultproductprice")
                             default_product_price = 0 
                             default_product_price_days = 0
                        product_selected_exist = True
                        # product_selected_exist = True
                        # default_product_price = plan_days * camera_quantity * plan_feature_days_price_product['days_price']
                        # default_product_price_days = camera_quantity * plan_feature_days_price_product['days_price']
                        plans_data.append({
                            'price':default_product_price,
                            'days_price':default_product_price_days,
                            'currency_id':currency_detail['id'],
                            'default_product_id':parking_product_data['default_product_id'],
                            'plan_feature_pricing_category_id':parking_product_data['pricing_feature_category_id'],
                            'category_name':parking_product_data['pricing_feature_category_id__category_name'],
                            'plan_id':id,
                            'plan_feature_pricing_tier_id':parking_product_data['id'],
                            'company_detail_id':user_detail_page['company_detail']['id'],
                            'plan_pricing_description':parking_product_data['plan_pricing_description']
                        })
                        default_parking_product_feature_data = PlanFeaturePricingTier.objects.filter(plan_id=id,pricing_feature_category_id__category_name="Feature",default_product_id__product_name='Visitor management system',is_encluded_plan_feature_id__isnull=False,default_product_feature_id__isnull=False).values('id','uuid','default_product_id','default_product_id__product_name','default_product_feature_id','default_product_feature_id__feature','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').all()
                        for default_product_feature in default_parking_product_feature_data:
                            plans_data.append({
                                'price':0.0,
                                'days_price':0.0,
                                'currency_id':currency_detail['id'],
                                'default_product_id':parking_product_data['default_product_id'],
                                'default_product_feature_id':default_product_feature['default_product_feature_id'],
                                'plan_feature_pricing_category_id':default_product_feature['pricing_feature_category_id'],
                                'category_name':default_product_feature['pricing_feature_category_id__category_name'],
                                'plan_id':id,
                                'plan_feature_pricing_tier_id':default_product_feature['id'],
                                'company_detail_id':user_detail_page['company_detail']['id'],
                                'plan_pricing_description':default_product_feature['plan_pricing_description']
                            })
                        parking_product_feature_data = PlanFeaturePricingTier.objects.filter(plan_id=id,pricing_feature_category_id__category_name="Feature",default_product_id__product_name='Visitor management system',is_encluded_plan_feature_id__isnull=True,default_product_feature_id__isnull=False).values('id','uuid','default_product_id','default_product_id__product_name','default_product_feature_id','default_product_feature_id__feature','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').all()
                        
                        for product_feature in parking_product_feature_data:
                            # plan_feature_days_price_product_feature = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=product_feature['id'],currency_id=plans_detail['currency_type_id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                            # product_feature_price = plan_days * camera_quantity * plan_feature_days_price_product_feature['days_price']
                            # product_feature_price_days = camera_quantity * plan_feature_days_price_product_feature['days_price']
                            plan_feature_days_price_product_feature = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=product_feature['id'],currency_id=currency_detail['id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                            plan_feature_days_price_product_feature_instance = plan_feature_days_price_product_feature.first()  
                            if plan_feature_days_price_product_feature_instance:
                                product_feature_price = plan_days * plan_feature_days_price_product_feature_instance['days_price']
                                product_feature_price_days =  plan_feature_days_price_product_feature_instance['days_price']
                            else:
                                
                                product_feature_price = 0  
                            default_selected = False
                            feature_plan_selected = [feature_plan for feature_plan in product_data['plan_feature_detail'] if feature_plan['plan_feature_pricing_tier_id']==product_feature['id'] and feature_plan['selected']==True]
                            if len(feature_plan_selected) > 0:
                                default_selected = True
                                default_product_feature_price += product_feature_price
                                plans_data.append({
                                    'price':product_feature_price,
                                    'days_price':product_feature_price_days,
                                    'currency_id':currency_detail['id'],
                                    'default_product_id':parking_product_data['default_product_id'],
                                    'default_product_feature_id':product_feature['default_product_feature_id'],
                                    'plan_feature_pricing_category_id':product_feature['pricing_feature_category_id'],
                                    'category_name':product_feature['pricing_feature_category_id__category_name'],
                                    'plan_id':id,
                                    'plan_feature_pricing_tier_id':product_feature['id'],
                                    'company_detail_id':user_detail_page['company_detail']['id'],
                                    'plan_pricing_description':product_feature['plan_pricing_description']
                                })
                        # plan_feature_days_price_camera = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_camera['id'],currency_id=currency_detail['id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol').first()
                        # camera_price = plan_days * camera_quantity * plan_feature_days_price_camera['days_price']
                        # camera_price_days = camera_quantity * plan_feature_days_price_camera['days_price']
                        # plans_data.append({
                        #     'quantity':camera_quantity,
                        #     'price':camera_price,
                        #     'days_price':camera_price_days,
                        #     'currency_id':currency_detail['id'],
                        #     'plan_feature_pricing_category_id':plan_features_pricing_tier_camera['pricing_feature_category_id'],
                        #     'category_name':plan_features_pricing_tier_camera['pricing_feature_category_id__category_name'],
                        #     'plan_id':id,
                        #     'plan_feature_pricing_tier_id':plan_features_pricing_tier_camera['id'],
                        #     'company_detail_id':user_detail_page['company_detail']['id'],
                        #     'plan_pricing_description':plan_features_pricing_tier_camera['plan_pricing_description']
                        # })
                        # # plan_features_pricing_tier_parking_slot = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Parking Slot').values('id','uuid','min_quantity','max_quantity','default_quantity','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                        # # parking_slot = product_data['plan_parking_slot_detail']['parking_slot']
                        # # if parking_slot < plan_features_pricing_tier_parking_slot['min_quantity'] or parking_slot > plan_features_pricing_tier_parking_slot['max_quantity']:
                        # #     BusinessDetail.objects.filter(id=user_detail_page['business_detail']['id']).delete()
                        # #     return Response({'detail':'please select any one dashboard type.'},status.HTTP_400_BAD_REQUEST)
                        # # # for camera in range(plan_features_pricing_tier_camera['min_quantity'],plan_features_pricing_tier_camera['max_quantity']+1):
                        # # plan_feature_days_price_parking_slot = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_camera['id'],currency_id=currency_detail['id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol').first()
                        # # default_parking_slot_price = plan_days * parking_slot * plan_feature_days_price_parking_slot['days_price']
                        # # praking_slot_days_price = parking_slot * plan_feature_days_price_parking_slot['days_price']
                        # # plans_data.append({
                        # #     'quantity':parking_slot,
                        # #     'price':default_parking_slot_price,
                        # #     'days_price':praking_slot_days_price,
                        # #     'currency_id':currency_detail['id'],
                        # #     'default_product_id':parking_product_data['default_product_id'],
                        # #     'plan_feature_pricing_category_id':plan_features_pricing_tier_parking_slot['pricing_feature_category_id'],
                        # #     'category_name':plan_features_pricing_tier_parking_slot['pricing_feature_category_id__category_name'],
                        # #     'plan_id':id,
                        # #     'plan_feature_pricing_tier_id':plan_features_pricing_tier_parking_slot['id'],
                        # #     'business_detail_id':user_detail_page['business_detail']['id'],
                        # #     'plan_pricing_description':plan_features_pricing_tier_parking_slot['plan_pricing_description']
                        # # })
                        # if product_data['plan_online_dashboard']['selected'] == False and product_data['plan_offline_dashboard']['selected'] == False:
                        #     return Response({'detail':'please select any one dashboard type.'},status.HTTP_400_BAD_REQUEST)
                        
                        # if product_data['plan_online_dashboard']['selected'] == True:
                        #     plan_features_pricing_tier_online_dashboard = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Online Dashboard').values('id','uuid','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                        #     plan_feature_days_price_online_dashboard = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard['id'],currency_id=currency_detail['id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').first()
                        #     online_dashboard_price = plan_days * camera_quantity * plan_feature_days_price_online_dashboard['days_price']
                        #     days_online_dashboard_price = camera_quantity * plan_feature_days_price_online_dashboard['days_price']
                        #     plans_data.append({
                        #         'quantity':camera_quantity,
                        #         'price':online_dashboard_price,
                        #         'days_price':days_online_dashboard_price,
                        #         'currency_id':currency_detail['id'],
                        #         'plan_feature_pricing_category_id':plan_features_pricing_tier_online_dashboard['pricing_feature_category_id'],
                        #         'category_name':plan_features_pricing_tier_online_dashboard['pricing_feature_category_id__category_name'],
                        #         'plan_id':id,
                        #         'plan_feature_pricing_tier_id':plan_features_pricing_tier_online_dashboard['id'],
                        #         'company_detail_id':user_detail_page['company_detail']['id'],
                        #         'plan_pricing_description':plan_features_pricing_tier_online_dashboard['plan_pricing_description']
                        #     })
                        #     plan_features_pricing_tier_online_dashboard_data_backup = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Online Data Backup').values('id','uuid','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                        #     plan_feature_days_price_online_dashboard_data_backup = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard['id'],currency_id=currency_detail['id'],backup_days_id=product_data['plan_online_data_backup']['backup_id']).values('id','uuid','backup_days_id','backup_days_id__days','backup_days_id__category','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').first()
                        #     online_data_backup_price = plan_feature_days_price_online_dashboard_data_backup['backup_days_id__days'] * camera_quantity * plan_feature_days_price_online_dashboard_data_backup['days_price']
                        #     days_online_data_backup_price = camera_quantity * plan_feature_days_price_online_dashboard_data_backup['days_price']
                        #     plans_data.append({
                        #         'backup_days_id':plan_feature_days_price_online_dashboard_data_backup['backup_days_id'],
                        #         'backup_days':plan_feature_days_price_online_dashboard_data_backup['backup_days_id__days'],
                        #         'quantity':camera_quantity,
                        #         'price':online_data_backup_price,
                        #         'days_price':days_online_data_backup_price,
                        #         'currency_id':currency_detail['id'],
                        #         'plan_feature_pricing_category_id':plan_features_pricing_tier_online_dashboard_data_backup['pricing_feature_category_id'],
                        #         'category_name':plan_features_pricing_tier_online_dashboard_data_backup['pricing_feature_category_id__category_name'],
                        #         'plan_id':id,
                        #         'plan_feature_pricing_tier_id':plan_features_pricing_tier_online_dashboard_data_backup['id'],
                        #         'company_detail_id':user_detail_page['company_detail']['id'],
                        #         'plan_pricing_description':plan_features_pricing_tier_online_dashboard_data_backup['plan_pricing_description']
                        #     })
                        
                        # if product_data['plan_offline_dashboard']['selected'] == True:
                        #     plan_features_pricing_tier_offline_dashboard = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Offline Dashboard').values('id','uuid','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                        #     plan_feature_days_price_offline_dashboard = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_offline_dashboard['id'],currency_id=currency_detail['id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').first()
                        #     offline_dashboard_price = plan_days * camera_quantity * plan_feature_days_price_offline_dashboard['days_price']
                        #     days_offline_dashboard_price = camera_quantity * plan_feature_days_price_offline_dashboard['days_price']
                        #     plans_data.append({
                        #         'quantity':camera_quantity,
                        #         'price':offline_dashboard_price,
                        #         'days_price':days_offline_dashboard_price,
                        #         'currency_id':currency_detail['id'],
                        #         'plan_feature_pricing_category_id':plan_features_pricing_tier_offline_dashboard['pricing_feature_category_id'],
                        #         'category_name':plan_features_pricing_tier_offline_dashboard['pricing_feature_category_id__category_name'],
                        #         'plan_id':id,
                        #         'plan_feature_pricing_tier_id':plan_features_pricing_tier_offline_dashboard['id'],
                        #         'company_detail_id':user_detail_page['company_detail']['id'],
                        #         'plan_pricing_description':plan_features_pricing_tier_offline_dashboard['plan_pricing_description']
                        #     })
                        #     plan_features_pricing_tier_offline_dashboard_data_backup = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Offline Data Backup').values('id','uuid','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                        #     plan_feature_days_price_offline_dashboard_data_backup = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_offline_dashboard['id'],currency_id=currency_detail['id'],backup_days_id=product_data['plan_offline_data_backup']['backup_id']).values('id','uuid','backup_days_id','backup_days_id__days','backup_days_id__category','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').first()
                        #     offline_data_backup_price = plan_feature_days_price_offline_dashboard_data_backup['backup_days_id__days'] * camera_quantity * plan_feature_days_price_offline_dashboard_data_backup['days_price']
                        #     days_offline_data_backup_price = camera_quantity * plan_feature_days_price_offline_dashboard_data_backup['days_price']
                        #     plans_data.append({
                        #         'backup_days_id':plan_feature_days_price_offline_dashboard_data_backup['backup_days_id'],
                        #         'backup_days':plan_feature_days_price_offline_dashboard_data_backup['backup_days_id__days'],
                        #         'quantity':camera_quantity,
                        #         'price':offline_data_backup_price,
                        #         'days_price':days_offline_data_backup_price,
                        #         'currency_id':currency_detail['id'],
                        #         'plan_feature_pricing_category_id':plan_features_pricing_tier_offline_dashboard_data_backup['pricing_feature_category_id'],
                        #         'category_name':plan_features_pricing_tier_offline_dashboard_data_backup['pricing_feature_category_id__category_name'],
                        #         'plan_id':id,
                        #         'plan_feature_pricing_tier_id':plan_features_pricing_tier_offline_dashboard_data_backup['id'],
                        #         'company_detail_id':user_detail_page['company_detail']['id'],
                        #         'plan_pricing_description':plan_features_pricing_tier_offline_dashboard_data_backup['plan_pricing_description']
                        #     })
                        # if product_selected_exist == False:
                        #     return Response({'detail':'please select any one dashboard type.'},status.HTTP_400_BAD_REQUEST)
                        total_price =  default_product_price + default_product_feature_price
                        all_product_total_price+=total_price
                    days_total_price = all_product_total_price / plan_days
                    discount_amount = (all_product_total_price * get_plan_days_and_discount.discount_percentage)/100
                    total_price_after_discount = all_product_total_price - discount_amount
                    business_coupon = None
                    if plans_detail['coupon_code'] != None:
                        get_coupon = Coupon.objects.filter(code=plans_detail['coupon_code'],currency_id=currency_detail['id'],plan_buy_days__gte=plan_days,coupon_expiry_datetime__gte= timezone.datetime.now(),is_active=True).values('id','uuid','code','description','discount_type','discount_value','currency_id','currency_id__currency_type').first()
                        if get_coupon != None:
                            total_coupon_amount = 0.0
                            if get_coupon['discount_type'] == 'percentage':
                                total_coupon_amount =  (all_product_total_price * get_coupon['discount_value'])/100
                            elif get_coupon['discount_type'] == 'fixed amount':
                                total_coupon_amount = all_product_total_price - get_coupon['discount_value']
                            total_price_after_discount -= total_coupon_amount
                            business_coupon ={
                                'coupon_code':get_coupon['code'],
                                'description':get_coupon['description'],
                                'discount_type':get_coupon['discount_type'],
                                'discount_value':get_coupon['discount_value'],
                                'coupon_id':get_coupon['id'],
                                'total_coupon_amount':total_coupon_amount,
                                'company_detail_id':user_detail_page['company_detail']['id']
                            }
                        else:
                            return Response({'detail':"coupon code is not valid."},status.HTTP_400_BAD_REQUEST)
                    days_total_price_after_discount = total_price_after_discount / plan_days
                    plan_pricing_tax_detail = PlanPricingTax.objects.filter(plan_pricing_id = get_plan_days_and_discount.plan_pricing_id).values('id','uuid','plan_pricing_id','tax_percentage_detail_id','tax_percentage_detail_id__tax_percentage','tax_percentage_detail_id__tax_type')
                    tax_detail = []
                    total_price_after_tax = total_price_after_discount
                    
                    for pricing_tax in plan_pricing_tax_detail:
                        tax_amount = (total_price_after_discount*pricing_tax['tax_percentage_detail_id__tax_percentage'])/100
                        total_price_after_tax += tax_amount
                        tax_detail.append({
                            'tax_percentage_detail_id':pricing_tax['tax_percentage_detail_id'],
                            'tax_percentage':pricing_tax['tax_percentage_detail_id__tax_percentage'],
                            'tax_type':pricing_tax['tax_percentage_detail_id__tax_type'],
                            'tax_amount':tax_amount,
                            'company_detail_id':user_detail_page['company_detail']['id']
                        })
                        total_tax_percentage+=pricing_tax['tax_percentage_detail_id__tax_percentage']
                        total_tax_in_currency+=tax_amount
                    days_total_price_after_tax = total_price_after_tax / plan_days
                    plan_start_datetime = timezone.datetime.now()
                    plan_expire_datetime = timezone.now() + timedelta(days=get_plan_days_and_discount.plan_days)
                    plan_start_datetime = timezone.make_aware(plan_start_datetime)
                    # plan_start_datetime = timezone.datetime.now()
                    # plan_expire_datetime = timezone.datetime.now()+get_plan_days_and_discount.plan_days
                    time_diff = plan_expire_datetime - plan_start_datetime
                    total_minutes = time_diff.total_seconds()/60
                    total_days = time_diff.days
                    get_plan_pricing = PlanPricing.objects.filter(plan_id=get_plan.id, currency_id=currency_detail['id']).first()
                    business_plan_history = {
                        'plan_name':get_plan.plan_name,
                        'price':total_price,
                        'price_after_discount':total_price_after_discount,
                        'price_after_tax':total_price_after_tax,
                        'days_price':days_total_price,
                        'days_price_after_discount': days_total_price_after_discount,
                        'days_price_after_tax': days_total_price_after_tax,
                        'currency_id':currency_detail['id'],
                        'currency_type':currency_detail['currency_type'],
                        'currency_symbol':currency_detail['currency_symbol'],
                        'country_category_id':get_plan_pricing.country_type_id.id,
                        'country_type':get_plan_pricing.country_type_id.country,
                        'plan_id':get_plan.id,
                        'plan_days_and_discount_id':get_plan_days_and_discount.id,
                        'plan_days':get_plan_days_and_discount.plan_days,
                        'discount_in_percentage':get_plan_days_and_discount.discount_percentage,
                        'discount_in_currency': discount_amount,
                        'total_discount': total_price_after_discount,
                        'total_tax_in_percentage':total_tax_percentage,
                        'total_tax_in_currency':total_tax_in_currency,
                        'buy_datetime':timezone.datetime.now(),
                        'plan_start_datetime':timezone.datetime.now(),
                        #'plan_expire_datetime': datetime.datetime.now()+get_plan_days_and_discount['plan_days'],
                        'plan_expire_datetime': timezone.datetime.now() + timezone.timedelta(days=get_plan_days_and_discount.plan_days),
                        'minutes_to_expire':total_minutes,
                        'days_to_expire':total_days,
                        'plan_validity':False,
                        'plan_status':'pending',
                        'current_active':False,
                        'plan_type':'Renew Plan',
                        'company_detail_id':user_detail_page['company_detail']['id']
                    }

                    print("business plan history:",business_plan_history)
                    if 'currency_id' in business_plan_history:
                        currency_id = business_plan_history['currency_id']
                        
                        try:
                            
                            currency_instance = Currency.objects.get(id=currency_id)
                        except Currency.DoesNotExist:
                            
                            return Response({'error': 'Invalid currency_id'}, status=status.HTTP_400_BAD_REQUEST)
                    else:
                        
                        return Response({'error': 'currency_id is missing'}, status=status.HTTP_400_BAD_REQUEST)

                    
                    business_plan_history['currency_id'] = currency_instance
                    
                    if 'country_category_id' in business_plan_history:
                        country_category_id = business_plan_history['country_category_id']
                        try:
                            
                            country_category_instance = CountryCategory.objects.get(id=country_category_id)
                        except CountryCategory.DoesNotExist:
                            
                            return Response({'error': 'Invalid country_category_id'}, status=status.HTTP_400_BAD_REQUEST)
                    else:
                        
                        return Response({'error': 'country_category_id is missing'}, status=status.HTTP_400_BAD_REQUEST)

                    
                    business_plan_history['country_category_id'] = country_category_instance

                    if 'plan_id' in business_plan_history:
                        plan_id = business_plan_history['plan_id']
                        try:
                           
                            plan_instance = Plans.objects.get(id=plan_id)
                        except Plans.DoesNotExist:
                            
                            return Response({'error': 'Invalid plan_id'}, status=status.HTTP_400_BAD_REQUEST)
                    else:
                        
                        return Response({'error': 'plan_id is missing'}, status=status.HTTP_400_BAD_REQUEST)

                    
                    business_plan_history['plan_id'] = plan_instance

                    if 'plan_days_and_discount_id' in business_plan_history:
                        plan_days_and_discount_id = business_plan_history['plan_days_and_discount_id']
                        try:
                           
                            plan_days_and_discount_instance = PlanDaysAndDiscount.objects.get(id=plan_days_and_discount_id)
                        except PlanDaysAndDiscount.DoesNotExist:
                           
                            return Response({'error': 'Invalid plan_days_and_discount_id'}, status=status.HTTP_400_BAD_REQUEST)
                    else:
                        
                        return Response({'error': 'plan_days_and_discount_id is missing'}, status=status.HTTP_400_BAD_REQUEST)

                    
                    business_plan_history['plan_days_and_discount_id'] = plan_days_and_discount_instance

                    if 'company_detail_id' in business_plan_history:
                        company_detail_id = business_plan_history['company_detail_id']
                        try:
                            
                            company_detail_instance = CompanyDetail.objects.get(id=company_detail_id)
                        except CompanyDetail.DoesNotExist:
                            
                            return Response({'error': 'Invalid business_detail_id'}, status=status.HTTP_400_BAD_REQUEST)
                    else:
                       
                        return Response({'error': 'business_detail_id is missing'}, status=status.HTTP_400_BAD_REQUEST)

                    
                    business_plan_history['company_detail_id'] = company_detail_instance


                    try:
                        
                        existing_plan_id = request.data.get('existing_plan_id')
                       
                        #product_data = request.data.get('product_data')
                        print("PLANs DATA:",plans_data)
                        #print(business_plan_history)


                       
                        existing_plan_details = extract_existing_plan_details(existing_plan_id, product_data)
                        updated_plan_details = extract_updated_plan_details(plans_data, product_data,business_plan_history)

                        #print("Product Data:", product_data)
                        
                        with transaction.atomic():
                           
                            if is_valid_upgrade(existing_plan_details, updated_plan_details):
                                existing_plan = BusinessPlanHistory.objects.get(id=existing_plan_id)
                                existing_plan.current_active = False
                                existing_plan.save()
                                
                                updated_plan = BusinessPlanHistory(**business_plan_history)
                                updated_plan.current_active = True
                                updated_plan.save()
                                print("updated plan:", updated_plan)
                                #print("business plan history:",business_plan_history)
                                #business_plan_history_id=updated_plan
                                
                                update_related_models(existing_plan_id, updated_plan_details,updated_plan)
                                business_plan_history_instance = BusinessPlanHistory.objects.get(
                                plan_name=business_plan_history['plan_name'],
                                price_after_tax=business_plan_history['price_after_tax'],
                                
                            )
                                try:


                            #user = User.objects.get(id=user_id)
                            
                                    email = request.user.email
                                    phone_number = request.user.phone_number


                                    autopay_option = request.POST.get('autopay_option', None)

                                    
                                    if autopay_option == 'enable':
                                        
                                        response = create_subscription(request, business_plan_history, email, phone_number)


                                    #logger.info(f"create_subscription response: {response}")
                    
                    
                                    #return response

                                        if not response.get('success', False):

                                            print("Error details:")
                                            # traceback.print_exc()

                                            # # for obj in created_objects:
                                            # #     obj.delete()
                                            
                                            
                                            # logger.info(f"create_subscription response: {response}")
                        
                                            return response
                                        
                                        return JsonResponse({'An ERROR OCCURRED': response.get('message', 'Failed to create subscription')}, status=500)
                                
                                
                                    api_response_data, payment_session_id = process_cashfree_payment_upgrade(request, business_plan_history, email, phone_number)

                                    if api_response_data is None:
                                        
                                        return JsonResponse({'An ERROR OCCURRED': 'No data returned'}, status=500)
                                    
                                    if payment_session_id:
                                    
                                        # return JsonResponse({'payment_session_id': payment_session_id})
                                        # return Response(api_response_data)
                                        # response_data = {
                                        #     'api_response_data': api_response_data,
                                        #     'payment_session_id': payment_session_id
                                        # }
                                        # return Response(response_data)
                                        return render(request, 'checkout.html', {'payment_session_id': payment_session_id})
                                    else:
                                        
                                        return JsonResponse({'An ERROR OCCURRED': 'Payment session ID not found'}, status=500)

                                #         #serialized_data = serializers.serialize('json', [api_response_data])
                                
                                except Exception as e:
                                    # for obj in created_objects:
                                    #     obj.delete()
                                    
                                    return JsonResponse({'AN ERROR OCCURRED': str(e)}, status=500)

                            
                               # total_price_after_tax = business_plan_history_instance.price_after_tax

                               

                            else:
                                return Response({'error': 'Invalid renew request'}, status=status.HTTP_400_BAD_REQUEST)

                    except ObjectDoesNotExist:
                        return Response({'error': 'BusinessPlanHistory does not exist'}, status=status.HTTP_400_BAD_REQUEST)

                    except Exception as e:
                        return Response({'error': f'Renewal and payment failed: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
                    #             return Response({'message': 'Renew Plan successful'}, status=status.HTTP_200_OK)
                                
                    #         else:
                    #             return Response({'error': 'Invalid renew request'}, status=status.HTTP_400_BAD_REQUEST)
                    # except Exception as e:
                    #     return Response({'error': f'Renew failed: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        
                # business_plan_history_serializer = BusinessPlanHistorySerializer(data=business_plan_history)
                # business_plan_history_id = None
                # if business_plan_history_serializer.is_valid():
                #     business_plan_history_obj = business_plan_history_serializer.save()
                #     business_plan_history_id = business_plan_history_obj.id
                # else:
                #     return Response(business_plan_history_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                # business_pricing_tax_ids = []
                # for business_pricing_tax in tax_detail:
                #     business_pricing_tax['business_plan_history_id'] = business_plan_history_id
                #     business_pricing_tax_serializer = BusinessPlanPricingTaxSerializer(data=business_pricing_tax)
                #     business_pricing_tax_id = None
                #     if business_pricing_tax_serializer.is_valid():
                #         business_pricing_tax_obj = business_pricing_tax_serializer.save()
                #         business_pricing_tax_id = business_pricing_tax_obj.id
                #         business_pricing_tax_ids.append(business_pricing_tax_id)
                #     else:
                #         return Response(business_plan_history_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                # business_plan_coupon_id = None
                # if business_coupon != None:
                #     business_coupon['business_plan_history_id'] = business_plan_history_id
                #     business_coupon_serializer = BusinessPlanCoupon(data=business_coupon)
                #     if business_coupon_serializer.is_valid():
                #         business_coupon_obj = business_coupon_serializer.save()
                #         business_plan_coupon_id = business_coupon_obj.id
                #     else:
                #         for business_plan_pricing_tax_id in business_pricing_tax_ids:
                #             BusinessPlanPricingTax.objects.filter(id=business_plan_pricing_tax_id).delete()
                #         for business_pricing_id in business_pricing_tier_ids:
                #             BusinessPricingTier.objects.filter(id=business_pricing_id).delete()
                #         BusinessPlanHistory.objects.filter(id=business_plan_history_id).delete()
                # business_pricing_tier_ids = []
                # for plans in plans_data:
                #     plans['business_plan_history_id'] = business_plan_history_id
                #     business_pricing_tier_serializer = BusinessPricingTierSerializer(data=plans)
                #     business_pricing_tier_id = None
                #     if business_pricing_tier_serializer.is_valid():
                #         business_pricing_tier_obj = business_pricing_tier_serializer.save()
                #         business_pricing_tier_id = business_pricing_tier_obj.id
                #         business_pricing_tier_ids.append(business_pricing_tier_id)
                #     else:
                #         if business_plan_coupon_id != None:
                #             BusinessPlanCoupon.objects.filter(id=business_plan_coupon_id).delete()
                #         for business_plan_pricing_tax_id in business_pricing_tax_ids:
                #             BusinessPlanPricingTax.objects.filter(id=business_plan_pricing_tax_id).delete()
                #         for business_pricing_id in business_pricing_tier_ids:
                #             BusinessPricingTier.objects.filter(id=business_pricing_id).delete()
                #         BusinessPlanHistory.objects.filter(id=business_plan_history_id).delete()
                #         return Response(business_pricing_tier_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                else:
                    return Response({"detail": "Plans days doesn't exist."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"detail": "Plans not exist."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)
    def put(self, request,id,format=None):
        user_detail_page = get_user_data_page_plans(request.user.id,'upgrade_plan','view')
        AccessToPage = False
        if user_detail_page['permission'] != None:
            AccessToPage = True
        if AccessToPage == True:
            data = request.data
            print(data)
            plans_data = {}
            plans_detail = data['plans_detail']
            currency_detail = Currency.objects.filter(currency_type=request.data['currency_type']).values('id','currency_type','currency_symbol').first()
            get_plan = Plans.objects.filter(id=plans_detail['id'],plan_name=plans_detail['plan_name']).first()
            #get_plan = Plans.objects.filter(id=id).first()
            #print(get_plan)
            id = get_plan.id
            plan_name = get_plan.plan_name
            get_plan_days_and_discount_all = PlanDaysAndDiscount.objects.filter(plan_id=id).all()
            plans_data['plan_days']= []
            plan_days = 0
            for plan_days_detail in get_plan_days_and_discount_all:
                selected = False
                if data['plan_days_id'] == plan_days_detail.id:
                    selected = True
                    plan_days = plan_days_detail.plan_days
                    plan_pricing_id = plan_days_detail.plan_pricing_id.id
                plans_data['plan_days'].append({
                    #'id':plan_days_detail.id,
                    'plan_days':plan_days_detail.plan_days,
                    'discount_percentage':plan_days_detail.discount_percentage,
                    'category':plan_days_detail.category,
                    'default_select':selected,
                    #'plan_pricing_id':plan_days_detail.plan_pricing_id
                    #'plan_pricing_id': plan_pricing_id
                    
                })
            get_plan_days_and_discount = PlanDaysAndDiscount.objects.filter(plan_id=id,id=data['plan_days_id']).first()
            plans_data['product_data'] = []
            if get_plan_days_and_discount != None:
                plan_days = get_plan_days_and_discount.plan_days
                product_data = plans_detail['plan_product'][0]
                parking_product_data = PlanFeaturePricingTier.objects.filter(plan_id=id,pricing_feature_category_id__category_name="Product",default_product_id__product_name='Visitor management system',id=plans_detail['plan_product'][0]['plan_feature_pricing_tier_id'],show_plan_pricing=True).values('id','uuid','default_product_id','default_product_id__product_name','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                all_product_total_price = 0.0
                if parking_product_data != None:
                    # camera_quantity = product_data['plan_camera_detail']['camera_quantity']
                    product_data_json = {}
                    #product_data_json['id'] = parking_product_data['id']
                    product_data_json['product_name'] = parking_product_data['default_product_id__product_name']

                    plan_feature_days_price_product = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=parking_product_data['id'],currency_id=data['currency_type_id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                    plan_feature_days_price_product_instance = plan_feature_days_price_product.first()

                    if plan_feature_days_price_product_instance:
                           default_product_price = plan_days * plan_feature_days_price_product_instance['days_price']
                           default_product_price_days =  plan_feature_days_price_product_instance['days_price']
                    else:
                        #print("error in defaultproductprice")
                            default_product_price = 0 
                            default_product_price_days = 0
                    product_selected_exist = True
                    # product_selected_exist = True
                    # default_product_price = plan_days * camera_quantity * plan_feature_days_price_product['days_price']
                    # default_product_price_days = camera_quantity * plan_feature_days_price_product['days_price']

                    product_data_json['plan_product']={
                        # 'id':parking_product_data['id'],
                        # 'uuid':parking_product_data['uuid'],
                        'days_price':default_product_price_days,
                        'price': default_product_price,
                        #'currency_symbol':plan_feature_days_price_product_instance['currency_id__currency_symbol'],
                        #'currency_id':currency_detail['id'],
                        #'pricing_feature_category_id':parking_product_data['pricing_feature_category_id'],
                        #'category_name':parking_product_data['pricing_feature_category_id__category_name'],
                        #'default_selected':product_selected_exist,
                        #'plan_id':parking_product_data['plan_id'],
                        'plan_pricing_description':parking_product_data['plan_pricing_description'],
                       # 'show_plan_pricing':parking_product_data['show_plan_pricing']
                    }

                    default_parking_product_feature_data = PlanFeaturePricingTier.objects.filter(plan_id=id,pricing_feature_category_id__category_name="Feature",default_product_id__product_name='Visitor management system',is_encluded_plan_feature_id__isnull=False,default_product_feature_id__isnull=False).values('id','uuid','default_product_id','default_product_id__product_name','default_product_feature_id','default_product_feature_id__feature','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').all()
                    product_data_json['plan_product_feature_default'] = []
                    for default_product_feature in default_parking_product_feature_data:
                        product_data_json['plan_product_feature_default'].append({
                            # 'id':default_product_feature['id'],
                            # 'uuid':default_product_feature['uuid'],
                            # 'default_product_feature_id':default_product_feature['default_product_feature_id'],
                            # 'pricing_feature_category_id':default_product_feature['pricing_feature_category_id'],
                            # 'category_name':default_product_feature['pricing_feature_category_id__category_name'],
                            'feature_name':default_product_feature['default_product_feature_id__feature'],
                            'plan_pricing_description':default_product_feature['plan_pricing_description'],       
                        })
                    parking_product_feature_data = PlanFeaturePricingTier.objects.filter(plan_id=id,pricing_feature_category_id__category_name="Feature",default_product_id__product_name='Visitor management system',is_encluded_plan_feature_id__isnull=False,default_product_feature_id__isnull=False).values('id','uuid','default_product_id','default_product_id__product_name','default_product_feature_id','default_product_feature_id__feature','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').all()
                    product_data_json['plan_product_feature'] = []
                    default_product_feature_price = 0.0
                    for product_feature in parking_product_feature_data:
                       plan_feature_days_price_product_feature = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=product_feature['id'],currency_id=currency_detail['id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                    print("plan_feature_days_price_product_feature",plan_feature_days_price_product_feature)
                    plan_feature_days_price_product_feature_instance = plan_feature_days_price_product_feature.first()  
                    if plan_feature_days_price_product_feature_instance:
                        product_feature_price = plan_days* plan_feature_days_price_product_feature_instance['days_price']
                        product_feature_price_days =  plan_feature_days_price_product_feature_instance['days_price']
                    else:
                        
                        product_feature_price = 0  
                    # product_feature_price = plan_days * camera_quantity * plan_feature_days_price_product_feature_instance['days_price']
                    # product_feature_price_days = camera_quantity * plan_feature_days_price_product_feature_instance['days_price']
                    default_selected = False
                    
                    product_feature_price = plan_days *  plan_feature_days_price_product_feature_instance['days_price']
                    product_feature_price_days =  plan_feature_days_price_product_feature_instance['days_price']
                    default_selected = False
                    feature_plan_selected = [feature_plan for feature_plan in product_data['plan_feature_detail'] if feature_plan['plan_feature_pricing_tier_id']==product_feature['id'] and feature_plan['selected']==True]
                    print("feature_plan_selected",feature_plan_selected)
                    if len(feature_plan_selected) > 0:
                        default_selected = True
                        default_product_feature_price += product_feature_price
                        product_data_json['plan_product_feature'].append({
                            'price':product_feature_price,
                            'days_price':product_feature_price_days,
                            'currency_id':currency_detail['id'],
                            # 'default_product_id':parking_product_data['default_product_id'],
                            # 'default_product_feature_id':product_feature['default_product_feature_id'],
                            # 'plan_feature_pricing_category_id':product_feature['pricing_feature_category_id'],
                            'category_name':product_feature['pricing_feature_category_id__category_name'],
                            # 'plan_id':id,
                            #'plan_feature_pricing_tier_id':product_feature['id'],
                            #'business_detail_id':user_detail_page['business_detail']['id'],
                            'plan_pricing_description':product_feature['plan_pricing_description']
                        })

                    existing_plan_id = request.data.get('existing_plan_id')
                    existing_plan = BusinessPlanHistory.objects.get(id=existing_plan_id)
                    # plan_features_pricing_tier_camera = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Camera').values('id','uuid','min_quantity','max_quantity','default_quantity','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                    # default_camera_price = 0.0
                    # product_data_json['plan_camera_detail']= []
                    # for camera in range(plan_features_pricing_tier_camera['min_quantity'],plan_features_pricing_tier_camera['max_quantity']+1):
                    #     plan_feature_days_price_camera = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=data['plan_days_id'],plan_feature_pricing_tier_id=plan_features_pricing_tier_camera['id'],currency_id=data['currency_type_id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol').first()
                    #     camera_price = plan_days * camera * plan_feature_days_price_camera['days_price']
                    #     camera_price_days = camera * plan_feature_days_price_camera['days_price']
                    #     default_selected = False
                    #     if camera_quantity == camera:
                    #         default_camera_price = camera_price
                    #         default_selected = True
                    #         existing_camera_quantity = BusinessPricingTier.objects.filter(
                    #         business_plan_history_id=existing_plan.id,
                    #         category_name='Camera'
                    #         ).first()
                    #         if existing_camera_quantity:
                    #             existing_camera_quantity_value = existing_camera_quantity.quantity
                    #         else:
                    #             # Handle the case where no existing camera quantity data is found
                    #             existing_camera_quantity_value = 0
                    #         if camera < existing_camera_quantity_value:
                    #             return Response({'detail': 'You cannot decrease the camera quantity.'}, status=status.HTTP_400_BAD_REQUEST)

                    #         product_data_json['plan_camera_detail'].append({
                    #         # 'id':plan_features_pricing_tier_camera['id'],
                    #         # 'uuid':plan_features_pricing_tier_camera['uuid'],
                    #         'camera_quantity':camera,
                    #         'days_price':camera_price_days,
                    #         'price': camera_price,
                    #         'currency_symbol':plan_feature_days_price_camera['currency_id__currency_symbol'],
                    #         #'pricing_feature_category_id':plan_features_pricing_tier_camera['pricing_feature_category_id'],
                    #         #'category_name':plan_features_pricing_tier_camera['pricing_feature_category_id__category_name'],
                    #         #'default_selected':default_selected,
                    #         #'plan_id':plan_features_pricing_tier_camera['plan_id'],
                    #         'plan_pricing_description':plan_features_pricing_tier_camera['plan_pricing_description'],
                    #         #'show_plan_pricing':plan_features_pricing_tier_camera['show_plan_pricing']
                    #     })

                    # # plan_features_pricing_tier_parking_slot = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Parking Slot').values('id','uuid','min_quantity','max_quantity','default_quantity','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                    # # parking_slot = product_data['plan_parking_slot_detail']['parking_slot']
                    # # if parking_slot < plan_features_pricing_tier_parking_slot['min_quantity'] or parking_slot > plan_features_pricing_tier_parking_slot['max_quantity']:
                    # #     return Response({'detail':'please select any one dashboard type.'},status.HTTP_400_BAD_REQUEST)
                    # # # for camera in range(plan_features_pricing_tier_camera['min_quantity'],plan_features_pricing_tier_camera['max_quantity']+1):
                    # # plan_feature_days_price_parking_slot = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_camera['id'],currency_id=data['currency_type_id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol').first()
                    # # default_parking_slot_price = plan_days * parking_slot * plan_feature_days_price_parking_slot['days_price']
                    # # praking_days_price = parking_slot * plan_feature_days_price_parking_slot['days_price']
                    # # default_selected = True
                    # # existing_parking_slots = BusinessPricingTier.objects.filter(
                    # #     business_plan_history_id=existing_plan.id,
                    # #     category_name='Parking Slot'
                    # # ).first()
                    # # if existing_parking_slots:
                    # #     existing_parking_slot_quantity = existing_parking_slots.quantity
                    # # else:
                    # #     # Handle the case where no existing parking slot data is found
                    # #     existing_parking_slot_quantity = 0
                    # # if parking_slot < existing_parking_slot_quantity:
                    # #     return Response({'detail': 'You cannot decrease the parking slot quantity.'}, status=status.HTTP_400_BAD_REQUEST)
                    # # product_data_json['plan_parking_slots']={
                    # #     'id':plan_features_pricing_tier_parking_slot['id'],
                    # #     'uuid':plan_features_pricing_tier_parking_slot['uuid'],
                    # #     'parking_slot':parking_slot,
                    # #     'days_price':praking_days_price,
                    # #     'price': default_parking_slot_price,
                    # #     'currency_symbol':plan_feature_days_price_parking_slot['currency_id__currency_symbol'],
                    # #     'pricing_feature_category_id':plan_features_pricing_tier_parking_slot['pricing_feature_category_id'],
                    # #     'category_name':plan_features_pricing_tier_parking_slot['pricing_feature_category_id__category_name'],
                    # #     'default_selected':default_selected,
                    # #     'plan_id':plan_features_pricing_tier_parking_slot['plan_id'],
                    # #     'plan_pricing_description':plan_features_pricing_tier_parking_slot['plan_pricing_description'],
                    # #     'show_plan_pricing':plan_features_pricing_tier_parking_slot['show_plan_pricing']
                    # # }

                    # if product_data['plan_online_dashboard']['selected'] == False and data['plan_offline_dashboard']['selected'] == False: 
                    #     return Response({'detail':'please select any one dashboard type.'},status.HTTP_400_BAD_REQUEST)
                    # product_data_json['plan_online_dashboard'] = []
                    # plan_features_pricing_tier_online_dashboard = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Online Dashboard').values('id','uuid','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                    # plan_feature_days_price_online_dashboard = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard['id'],currency_id=data['currency_type_id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').first()
                    # online_dashboard_price = plan_days * camera_quantity * plan_feature_days_price_online_dashboard['days_price']
                    # online_dashboard_price_days = camera_quantity * plan_feature_days_price_online_dashboard['days_price']
                    # default_online_dashboard_price = 0.0
                    # if product_data['plan_online_dashboard']['selected'] == True:
                    #     default_online_dashboard_price = online_dashboard_price
                    # product_data_json['plan_online_dashboard'].append({
                    #         # 'id':plan_features_pricing_tier_online_dashboard['id'],
                    #         # 'uuid':plan_features_pricing_tier_online_dashboard['uuid'],
                    #         #'camera_quantity':camera_quantity,
                    #         #'plan_days':plan_days,
                    #         'days_price':online_dashboard_price_days,
                    #         'price': online_dashboard_price,
                    #         'currency_symbol':plan_feature_days_price_online_dashboard['currency_id__currency_symbol'],
                    #         #'pricing_feature_category_id':plan_features_pricing_tier_online_dashboard['pricing_feature_category_id'],
                    #         #'category_name':plan_features_pricing_tier_online_dashboard['pricing_feature_category_id__category_name'],
                    #         #'default_selected':product_data['plan_online_dashboard']['selected'],
                    #        # 'plan_id':plan_features_pricing_tier_online_dashboard['plan_id'],
                    #         'plan_pricing_description':plan_features_pricing_tier_online_dashboard['plan_pricing_description'],
                    #         #'show_plan_pricing':plan_features_pricing_tier_online_dashboard['show_plan_pricing']
                    #     })

                    # product_data_json['plan_online_dashboard_data_backup'] = []
                    # plan_features_pricing_tier_online_dashboard_data_backup = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Online Data Backup').values('id','uuid','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                    # plan_feature_days_price_online_dashboard_data_backup = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard['id'],currency_id=data['currency_type_id']).values('id','uuid','backup_days_id','backup_days_id__days','backup_days_id__category','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                    # default_online_dashboard_backup_price = 0.0
                    # for online_data_backup in plan_feature_days_price_online_dashboard_data_backup:
                    #     online_data_backup_price = online_data_backup['backup_days_id__days'] * camera_quantity * online_data_backup['days_price']
                    #     online_data_backup_price_days = camera_quantity * online_data_backup['days_price']

                    #     default_selected = False
                    #     if product_data['plan_online_data_backup']['backup_id'] == online_data_backup['id'] and data['plan_online_dashboard']['selected'] == True:
                    #         default_online_dashboard_backup_price = online_data_backup_price
                    #         default_selected = True
                    #     product_data_json['plan_online_dashboard_data_backup'].append({
                    #         # 'id':plan_features_pricing_tier_online_dashboard_data_backup['id'],
                    #         # 'uuid':plan_features_pricing_tier_online_dashboard_data_backup['uuid'],
                    #         #'camera_quantity':camera_quantity,
                    #         "backup_id":online_data_backup['id'],
                    #         #'backup_days':online_data_backup['backup_days_id__days'],
                    #         #'backup_category':online_data_backup['backup_days_id__category'],
                    #         'days_price':online_data_backup_price_days,
                    #         'price': online_data_backup_price,
                    #         'currency_symbol':online_data_backup['currency_id__currency_symbol'],
                    #         #'pricing_feature_category_id':plan_features_pricing_tier_online_dashboard_data_backup['pricing_feature_category_id'],
                    #         #'category_name':plan_features_pricing_tier_online_dashboard_data_backup['pricing_feature_category_id__category_name'],
                    #         'default_selected':online_data_backup['default_selected'],
                    #         #'plan_id':plan_features_pricing_tier_online_dashboard_data_backup['plan_id'],
                    #         'plan_pricing_description':plan_features_pricing_tier_online_dashboard_data_backup['plan_pricing_description'],
                    #         #'show_plan_pricing':plan_features_pricing_tier_online_dashboard_data_backup['show_plan_pricing']
                    #     })

                    # product_data_json['plan_offline_dashboard'] = []
                    # plan_features_pricing_tier_offline_dashboard = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Offline Dashboard').values('id','uuid','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                    # plan_feature_days_price_offline_dashboard = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_offline_dashboard['id'],currency_id=data['currency_type_id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').first()
                    # offline_dashboard_price = plan_days * camera_quantity * plan_feature_days_price_offline_dashboard['days_price']
                    # offline_dashboard_price_days = camera_quantity * plan_feature_days_price_offline_dashboard['days_price']
                    # default_offline_dashboard_price = 0.0
                    # if product_data['plan_offline_dashboard']['selected'] == True:
                    #     default_offline_dashboard_price = offline_dashboard_price
                    # product_data_json['plan_offline_dashboard'].append({
                    #         # 'id':plan_features_pricing_tier_offline_dashboard['id'],
                    #         # 'uuid':plan_features_pricing_tier_offline_dashboard['uuid'],
                    #         # 'camera_quantity':camera_quantity,
                    #         # 'plan_days':plan_days,
                    #         'days_price':offline_dashboard_price_days,
                    #         'price': offline_dashboard_price,
                    #         'currency_symbol':plan_feature_days_price_offline_dashboard['currency_id__currency_symbol'],
                    #         #'pricing_feature_category_id':plan_features_pricing_tier_offline_dashboard['pricing_feature_category_id'],
                    #         #'category_name':plan_features_pricing_tier_offline_dashboard['pricing_feature_category_id__category_name'],
                    #         'default_selected':product_data['plan_offline_dashboard']['selected'],
                    #         #'plan_id':plan_features_pricing_tier_offline_dashboard['plan_id'],
                    #         'plan_pricing_description':plan_features_pricing_tier_offline_dashboard['plan_pricing_description'],
                    #        # 'show_plan_pricing':plan_features_pricing_tier_offline_dashboard['show_plan_pricing']
                    #     })

                    # product_data_json['plan_offline_dashboard_data_backup'] = []
                    # plan_features_pricing_tier_offline_dashboard_data_backup = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Offline Data Backup').values('id','uuid','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                    # plan_feature_days_price_offline_dashboard_data_backup = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_offline_dashboard['id'],currency_id=data['currency_type_id']).values('id','uuid','backup_days_id','backup_days_id__days','backup_days_id__category','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                    # default_offline_dashboard_backup_price = 0.0
                    # for offline_data_backup in plan_feature_days_price_offline_dashboard_data_backup:
                    #     offline_data_backup_price = offline_data_backup['backup_days_id__days'] * camera_quantity * offline_data_backup['days_price']
                    #     offline_data_backup_price_days = camera_quantity * offline_data_backup['days_price']
                    #     default_selected = False
                    #     if product_data['plan_offline_data_backup']['backup_id'] == offline_data_backup['id'] and data['plan_offline_dashboard']['selected'] == True:
                    #         default_offline_dashboard_backup_price = offline_data_backup_price
                    #         default_selected = True
                    #     product_data_json['plan_offline_dashboard_data_backup'].append({
                    #         # 'id':plan_features_pricing_tier_offline_dashboard_data_backup['id'],
                    #         # 'uuid':plan_features_pricing_tier_offline_dashboard_data_backup['uuid'],
                    #         # 'camera_quantity':camera_quantity,
                    #         # 'backup_days':offline_data_backup['backup_days_id__days'],
                    #         #'backup_category':offline_data_backup['backup_days_id__category'],
                    #         'days_price':offline_data_backup_price_days,
                    #         'price': offline_data_backup_price,
                    #         'currency_symbol':offline_data_backup['currency_id__currency_symbol'],
                    #         #'pricing_feature_category_id':plan_features_pricing_tier_offline_dashboard_data_backup['pricing_feature_category_id'],
                    #         #'category_name':plan_features_pricing_tier_offline_dashboard_data_backup['pricing_feature_category_id__category_name'],
                    #         'default_selected':default_selected,
                    #         #'plan_id':plan_features_pricing_tier_offline_dashboard_data_backup['plan_id'],
                    #         'plan_pricing_description':plan_features_pricing_tier_offline_dashboard_data_backup['plan_pricing_description'],
                    #         #'show_plan_pricing':plan_features_pricing_tier_offline_dashboard_data_backup['show_plan_pricing']
                    #     })

                    total_price =  default_product_price+default_product_feature_price
                    all_product_total_price+=total_price
                    plans_data['product_data'].append(product_data_json)
                discount_amount = (all_product_total_price * get_plan_days_and_discount.discount_percentage)/100
                total_price_after_discount = all_product_total_price - discount_amount
                if plans_detail['coupon_code'] != None:
                    get_coupon = Coupon.objects.filter(code=plans_detail['coupon_code'],currency_id=data['currency_type_id'],plan_buy_days__gte=plan_days,coupon_expiry_datetime__gte= timezone.datetime.now(),is_active=True).values('id','uuid','code','description','discount_type','discount_value','currency_id','currency_id__currency_type').first()
                    if get_coupon != None:
                        total_coupon_amount = 0.0
                        if get_coupon['discount_type'] == 'percentage':
                            total_coupon_amount =  (all_product_total_price * get_coupon['discount_value'])/100
                        elif get_coupon['discount_type'] == 'fixed amount':
                            total_coupon_amount = all_product_total_price - get_coupon['discount_value']
                        total_price_after_discount -= total_coupon_amount

                        plans_data['coupon_code'] ={
                            # 'id':get_coupon['id'],
                            # 'uuid':get_coupon['uuid'],
                            'code':get_coupon['code'],
                            'description':get_coupon['description'],
                            'discount_type':get_coupon['discount_type'],
                            'discount_value':get_coupon['discount_value'],
                           # 'currency_id':get_coupon['currency_id'],
                            'total_coupon_amount':total_coupon_amount
                        }

                    else:
                        return Response({'detail':"coupon code is not valid."},status.HTTP_400_BAD_REQUEST)

                plan_pricing_tax_detail = PlanPricingTax.objects.filter(plan_pricing_id = get_plan_days_and_discount.plan_pricing_id).values('id','uuid','plan_pricing_id','tax_percentage_detail_id','tax_percentage_detail_id__tax_percentage','tax_percentage_detail_id__tax_type')
                tax_detail = []
                total_price_after_tax = total_price_after_discount
                for pricing_tax in plan_pricing_tax_detail:
                    tax_amount = (total_price_after_discount*pricing_tax['tax_percentage_detail_id__tax_percentage'])/100
                    total_price_after_tax += tax_amount
                    tax_detail.append({
                        # 'id':pricing_tax['id'],
                        # 'uuid':pricing_tax['uuid'],
                        # 'tax_percentage_detail_id':pricing_tax['tax_percentage_detail_id'],
                        'tax_percentage':pricing_tax['tax_percentage_detail_id__tax_percentage'],
                        'tax_type':pricing_tax['tax_percentage_detail_id__tax_type'],
                        'tax_amount':tax_amount
                    })
                plans_data['plan_pricing'] ={
                    'total_price':total_price,
                    'discount_amount':discount_amount,
                    'total_price_after_discount':total_price_after_discount,
                    'total_price_after_tax':total_price_after_tax,
                    'tax_detail':tax_detail
                }
                
            return Response(plans_data, status=status.HTTP_200_OK)
        else:
            return Response({"detail": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)
        
class GetPlanDetail(APIView):
    permission_classes = (AllowAny,)
    def get(self, request,id):
        user_detail_page = get_user_data_page_plans(request.user.id,'upgrade_plan','view')  
        print("udp", user_detail_page)
        AccessToPage = False
        if user_detail_page['permission'] != None:
            AccessToPage = True
        if AccessToPage == True:
            currency_type_id = request.GET.get('currency',1)
            print("currencytypeid:", currency_type_id)
            plans_data = {}
            get_plan = Plans.objects.filter(id=id).first()
            plans_data['id'] = get_plan.id
            plans_data['plan_name'] = get_plan.plan_name
            get_plan_days_and_discount_all = PlanDaysAndDiscount.objects.filter(plan_id=id).all()
            plans_data['plan_days']= []

            for plan_days_detail in get_plan_days_and_discount_all:
                plan_days = user_detail_page['business_plan_history_detail'].plan_days
                default_selected = False
                if plan_days == plan_days_detail.plan_days:
                    default_selected = True
                # plan_days_and_discount_id = user_detail_page['business_plan_history_detail']['plan_days_and_discount_id']
                plans_data['plan_days'].append({
                    'id':plan_days_detail.id,
                    'plan_days':plan_days_detail.plan_days,
                    'discount_percentage':plan_days_detail.discount_percentage,
                    'category':plan_days_detail.category,
                    'default_select':default_selected,
                    'plan_pricing_id':plan_days_detail.plan_pricing_id
                })

            get_plan_days_and_discount = PlanDaysAndDiscount.objects.filter(plan_id=id,default_select=True).first()
            plans_data['product_data'] = []
            if get_plan_days_and_discount != None:
                plan_days = get_plan_days_and_discount.plan_days
                print("PLAN DAYS:", plan_days)
                parking_product_data = PlanFeaturePricingTier.objects.filter(plan_id=id,pricing_feature_category_id__category_name="Product",default_product_id__product_name='Visitor management system').values('id','uuid','default_product_id','default_product_id__product_name','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                all_product_total_price = 0.0
                if parking_product_data != None:
                    # plan_features_pricing_tier_camera = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Camera').values('id','uuid','min_quantity','max_quantity','default_quantity','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                    # print("pfptc", plan_features_pricing_tier_camera)
                    # camera_quantity = 1
                    # if plan_features_pricing_tier_camera != None:
                    #     camera_quantity = plan_features_pricing_tier_camera['default_quantity']

                    product_data_json = {}
                    #product_data_json['id'] = parking_product_data['id']
                    product_data_json['product_name'] = 'Visitor management system'

                    plan_feature_days_price_product = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=parking_product_data['id'],currency_id=currency_type_id).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                   # plan_feature_days_price_product = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=parking_product_data['id'],currency_id=data['currency_type_id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                    plan_feature_days_price_product_instance = plan_feature_days_price_product.first()

                    if plan_feature_days_price_product_instance:
                           default_product_price = plan_days * plan_feature_days_price_product_instance['days_price']
                           default_product_price_days =  plan_feature_days_price_product_instance['days_price']
                    else:
                        #print("error in defaultproductprice")
                            default_product_price = 0 
                            default_product_price_days = 0
                    product_selected_exist = True
                    # product_selected_exist = True
                    # default_product_price = plan_days * camera_quantity * plan_feature_days_price_product['days_price']
                    # default_product_price_days = camera_quantity * plan_feature_days_price_product['days_price']
                    product_data_json['plan_product']={
                        # 'id':parking_product_data['id'],
                        # 'uuid':parking_product_data['uuid'],
                        'days_price':default_product_price_days,
                        'price': default_product_price,
                        'currency_symbol':plan_feature_days_price_product_instance['currency_id__currency_symbol'],
                        # 'pricing_feature_category_id':parking_product_data['pricing_feature_category_id'],
                        # 'category_name':parking_product_data['pricing_feature_category_id__category_name'],
                        # 'default_selected':product_selected_exist,
                        # 'plan_id':parking_product_data['plan_id'],
                        # 'plan_pricing_description':parking_product_data['plan_pricing_description'],
                        # 'show_plan_pricing':parking_product_data['show_plan_pricing']
                    }
                    print("product_data_json",product_data_json)
                    default_parking_product_feature_data = PlanFeaturePricingTier.objects.filter(plan_id=id,pricing_feature_category_id__category_name="Feature",default_product_id__product_name='Visitor management system',is_encluded_plan_feature_id__isnull=False,default_product_feature_id__isnull=False).values('id','uuid','default_product_id','default_product_id__product_name','default_product_feature_id','default_product_feature_id__feature','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').all()
                    product_data_json['plan_product_feature_default'] = []
                    for default_product_feature in default_parking_product_feature_data:
                        
                        product_data_json['plan_product_feature_default'].append({
                            # 'id':default_product_feature['id'],
                            # 'uuid':default_product_feature['uuid'],
                            # 'default_product_feature_id':default_product_feature['default_product_feature_id'],
                            # 'pricing_feature_category_id':default_product_feature['pricing_feature_category_id'],
                            'category_name':default_product_feature['pricing_feature_category_id__category_name'],
                            'feature_name':default_product_feature['default_product_feature_id__feature'],
                            'plan_pricing_description':default_product_feature['plan_pricing_description'],

                        })
                    parking_product_feature_data = PlanFeaturePricingTier.objects.filter(plan_id=id,pricing_feature_category_id__category_name="Feature",default_product_id__product_name='Visitor management system',is_encluded_plan_feature_id__isnull=False,default_product_feature_id__isnull=False).values('id','uuid','default_product_id','default_product_id__product_name','default_product_feature_id','default_product_feature_id__feature','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').all()
                    product_data_json['plan_product_feature'] = []
                    default_product_feature_price = 0.0
                    for product_feature in parking_product_feature_data:
                        plan_feature_days_price_product_feature = list(PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=product_feature['id'],currency_id=currency_type_id).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected'))
                        print("plan_feature_days_price_product_feature:",plan_feature_days_price_product_feature)
                        #product_feature_price = plan_days * camera_quantity * plan_feature_days_price_product_feature['days_price']
                        if plan_feature_days_price_product_feature:
                                for feature in plan_feature_days_price_product_feature:
                                    
                                    product_feature_price = plan_days * feature['days_price']
                                    print("Product feature price:", product_feature_price)
                                    product_feature_price_days = feature['days_price']
                                    print("product feature price days", product_feature_price_days)
                        else:
                            print("No matching plan feature days price found")
                        #product_feature_price_days = camera_quantity * plan_feature_days_price_product_feature['days_price']
                        #product_feature_detail = [item[id] for item in user_detail_page['plans_detail']['product_feature_detail'] if product_feature['id'] == item.get('plan_feature_pricing_tier_id')]
                        for plan in user_detail_page['plans_detail']:
                            if plan.get('product_feature_detail') is not None:
                                product_feature_detail = [
                                    item for item in plan['product_feature_detail'] 
                                    if product_feature['id'] == item.get('plan_feature_pricing_tier_id')
                                ]
                                print("Filtered product feature details:", product_feature_detail)
                               

                       
                        print("product_feature_detail", product_feature_detail)
                        print("user_detail_page structure:", user_detail_page)

                        # for plan in user_detail_page['plans_detail']:
    
                        #     if isinstance(plan['product_feature_detail'], QuerySet) or isinstance(plan['product_feature_detail'], list):
                        #         product_feature_detail = [
                        #             item for item in plan['product_feature_detail']
                        #             if product_feature['id'] == item.get('plan_feature_pricing_tier_id')
                        #         ]

                                
                        #         print("Filtered product_feature_detail:", product_feature_detail)
                        #     else:
                        #         print("Error: 'product_feature_detail' is not a QuerySet or list")

                        # print("user_detail_page['plans_detail'][0]['product_feature_detail']:", user_detail_page['plans_detail'][0]['product_feature_detail'])
                        # # if plan_feature_days_price_product_feature['default_selected'] == True:
                        # #     default_product_feature_price += product_feature_price
                        # default_selected = False
                        plan_feature_days_price_product_feature = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=product_feature['id'],currency_id=currency_type_id).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                        plan_feature_days_price_product_feature_instance = plan_feature_days_price_product_feature.first()  
                        if plan_feature_days_price_product_feature_instance:
                            product_feature_price = plan_days  * plan_feature_days_price_product_feature_instance['days_price']
                            product_feature_price_days = plan_feature_days_price_product_feature_instance['days_price']
                            print("product_feature_price", product_feature_price)
                            print("product_feature_price_days",product_feature_price_days)
                        else:
                            
                            product_feature_price = 0  

                        default_selected = False
                        product_feature_price_days = 0
                        if len(product_feature_detail) > 0:
                            default_product_feature_price += product_feature_price
                            default_selected = True
                        product_data_json['plan_product_feature'].append({
                            # 'id':product_feature['id'],
                            # 'uuid':product_feature['uuid'],
                            'days_price':product_feature_price_days,
                            'price': product_feature_price,
                            'currency_symbol':plan_feature_days_price_product_instance['currency_id__currency_symbol'],
                            # 'default_product_feature_id':product_feature['default_product_feature_id'],
                             'feature_name':product_feature['default_product_feature_id__feature'],
                            # 'pricing_feature_category_id':product_feature['pricing_feature_category_id'],
                            # 'category_name':product_feature['pricing_feature_category_id__category_name'],
                            # 'default_selected':default_selected,
                            # 'plan_id':product_feature['plan_id'],
                            'plan_pricing_description':product_feature['plan_pricing_description'],
                            # 'show_plan_pricing':product_feature['show_plan_pricing']
                        })

                #     default_camera_price = 0.0
                #     product_data_json['plan_camera_detail']= []
                #     for camera in range(plan_features_pricing_tier_camera['min_quantity'],plan_features_pricing_tier_camera['max_quantity']+1):
                #         print(f"Allowed quantity of cameras: {camera}")

                #         plan_feature_days_price_camera = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_camera['id'],currency_id=currency_type_id).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol').first()
                        
                #         print("pfdpc", plan_feature_days_price_camera)
                #         camera_price = plan_days * camera * plan_feature_days_price_camera['days_price']
                #         camera_price_days = camera * plan_feature_days_price_camera['days_price']
                #         default_selected = False
                        
                #         #if user_detail_page['plans_detail']['camera_detail']['quantity'] == camera:
                #         for plan in user_detail_page['plans_detail']:
                #             camera_detail = plan.get('camera_detail')
                #             if camera_detail is not None and camera_detail.get('quantity') == camera:
                #                 print("Camera quantity matches:", camera_detail['quantity'])
                        
                #             default_camera_price = camera_price
                #             default_selected = True
                #         total_camera_quantity = sum(plan_detail.get('camera_detail', {}).get('quantity', 0) for plan_detail in user_detail_page['plans_detail'])
                #         product_data_json['plan_camera_detail'].append({
                #             # 'id':plan_features_pricing_tier_camera['id'],
                #             # 'uuid':plan_features_pricing_tier_camera['uuid'],
                #             'quantity':total_camera_quantity,
                #             'days_price':camera_price_days,
                #             'price': camera_price,
                #             'currency_symbol':plan_feature_days_price_camera['currency_id__currency_symbol'],
                #             # 'pricing_feature_category_id':plan_features_pricing_tier_camera['pricing_feature_category_id'],
                #             # 'category_name':plan_features_pricing_tier_camera['pricing_feature_category_id__category_name'],
                #             # 'default_selected':default_selected,
                #             # 'plan_id':plan_features_pricing_tier_camera['plan_id'],
                #              'plan_pricing_description':plan_features_pricing_tier_camera['plan_pricing_description'],
                #             # 'show_plan_pricing':plan_features_pricing_tier_camera['show_plan_pricing']
                #         })
                #         break
                # #     plan_features_pricing_tier_parking_slot = PlanFeaturePricingTier.objects.filter(
                # #     plan_id=id,
                # #     default_product_id=parking_product_data['default_product_id'],
                # #     pricing_feature_category_id__category_name='Parking Slot'
                # # ).values('id', 'uuid', 'min_quantity', 'max_quantity', 'default_quantity', 'pricing_feature_category_id', 'pricing_feature_category_id__category_name', 'plan_id', 'plan_pricing_description', 'show_plan_pricing').first()

                # #     print("plan_features_pricing_tier_parking_slot", plan_features_pricing_tier_parking_slot)
                # #     parking_slot = 1
                # #     if plan_features_pricing_tier_parking_slot is not None:
                # #         parking_slot = user_detail_page['plans_detail'][0]['camera_detail']['quantity']
                # #         print("parking slot", parking_slot)

                # #     for camera in range(plan_features_pricing_tier_camera['min_quantity'], plan_features_pricing_tier_camera['max_quantity'] + 1):
                # #         plan_feature_days_price_parking_slot = PlanFeatureDaysPrice.objects.filter(
                # #             plans_id=id,
                # #             plan_days_and_discount_id=get_plan_days_and_discount.id,
                # #             plan_feature_pricing_tier_id=plan_features_pricing_tier_camera['id'],
                # #             currency_id=currency_type_id
                # #         ).values('id', 'uuid', 'backup_days_id', 'plan_days_and_discount_id', 'days_price', 'currency_id', 'currency_id__currency_symbol').first()

                # #         default_parking_slot_price = plan_days * parking_slot * plan_feature_days_price_parking_slot['days_price']
                # #         praking_days_price = parking_slot * plan_feature_days_price_parking_slot['days_price']

                # #         product_data_json['plan_parking_slots'] = [{
                # #             'quantity': parking_slot,
                # #             'days_price': praking_days_price,
                # #             'price': default_parking_slot_price,
                # #             'currency_symbol': plan_feature_days_price_parking_slot['currency_id__currency_symbol'],
                # #             'plan_pricing_description': plan_features_pricing_tier_parking_slot['plan_pricing_description']
                # #         }]
                # #         break
                # #     plan_features_pricing_tier_parking_slot = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Parking Slot').values('id','uuid','min_quantity','max_quantity','default_quantity','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                # #     print("plan_features_pricing_tier_parking_slot",plan_features_pricing_tier_parking_slot)
                # #     parking_slot = 1
                # #     if plan_features_pricing_tier_parking_slot != None:
                # #         #parking_slot = user_detail_page['plans_detail']['camera_detail']['quantity']
                # #         parking_slot = user_detail_page['plans_detail'][0]['camera_detail']['quantity']
                # #         print("parking slot", parking_slot)
                # # for camera in range(plan_features_pricing_tier_camera['min_quantity'],plan_features_pricing_tier_camera['max_quantity']+1):
                # #     plan_feature_days_price_parking_slot = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_camera['id'],currency_id=currency_type_id).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol').first()
                # #     default_parking_slot_price = plan_days * parking_slot * plan_feature_days_price_parking_slot['days_price']
                # #     praking_days_price = parking_slot * plan_feature_days_price_parking_slot['days_price']
                # #     default_selected = True
                # #     product_data_json['plan_parking_slots']={
                # #         # 'id':plan_features_pricing_tier_parking_slot['id'],
                # #         # 'uuid':plan_features_pricing_tier_parking_slot['uuid'],
                # #         'quantity':parking_slot,
                # #         'days_price':praking_days_price,
                # #         'price': default_parking_slot_price,
                # #         'currency_symbol':plan_feature_days_price_parking_slot['currency_id__currency_symbol'],
                # #         # 'pricing_feature_category_id':plan_features_pricing_tier_parking_slot['pricing_feature_category_id'],
                # #         # 'category_name':plan_features_pricing_tier_parking_slot['pricing_feature_category_id__category_name'],
                # #         # 'default_selected':default_selected,
                # #         # 'plan_id':plan_features_pricing_tier_parking_slot['plan_id'],
                # #          'plan_pricing_description':plan_features_pricing_tier_parking_slot['plan_pricing_description'],
                # #         # 'show_plan_pricing':plan_features_pricing_tier_parking_slot['show_plan_pricing']
                # #     }

                #     product_data_json['plan_online_dashboard'] = []
                #     plan_features_pricing_tier_online_dashboard = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Online Dashboard').values('id','uuid','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                #     plan_feature_days_price_online_dashboard = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard['id'],currency_id=currency_type_id).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').first()
                #     online_dashboard_price = plan_days * camera_quantity * plan_feature_days_price_online_dashboard['days_price']
                #     online_dashboard_price_days = camera_quantity * plan_feature_days_price_online_dashboard['days_price']
                #     default_selected = False
                #     default_online_dashboard_price = 0.0
                #     #if user_detail_page['plans_detail']['online_dashboard_detail'] != None:
                #     online_dashboard_exists = False
                #     for plan_detail in user_detail_page['plans_detail']:
                #         if 'online_dashboard_detail' in plan_detail:
                #             online_dashboard_exists = True
                #             break

                    
                #         default_selected = True
                #         default_online_dashboard_price = online_dashboard_price
                #     product_data_json['plan_online_dashboard'].append({
                #             # 'id':plan_features_pricing_tier_online_dashboard['id'],
                #             # 'uuid':plan_features_pricing_tier_online_dashboard['uuid'],
                #             #'camera_quantity':camera_quantity,
                #             'plan_days':plan_days,
                #             'days_price':online_dashboard_price_days,
                #             'price': online_dashboard_price,
                #             'currency_symbol':plan_feature_days_price_online_dashboard['currency_id__currency_symbol'],
                #             # 'pricing_feature_category_id':plan_features_pricing_tier_online_dashboard['pricing_feature_category_id'],
                #             # 'category_name':plan_features_pricing_tier_online_dashboard['pricing_feature_category_id__category_name'],
                #             'default_selected':default_selected,
                #             # 'plan_id':plan_features_pricing_tier_online_dashboard['plan_id'],
                #              'plan_pricing_description':plan_features_pricing_tier_online_dashboard['plan_pricing_description'],
                #             # 'show_plan_pricing':plan_features_pricing_tier_online_dashboard['show_plan_pricing']
                #         })
                #     product_data_json['plan_online_dashboard_data_backup'] = []
                #     plan_features_pricing_tier_online_dashboard_data_backup = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Online Data Backup').values('id','uuid','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                #     plan_feature_days_price_online_dashboard_data_backup = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard['id'],currency_id=currency_type_id).values('id','uuid','backup_days_id','backup_days_id__days','backup_days_id__category','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                #     print("plan_feature_days_price_online_dashboard_data_backup",plan_feature_days_price_online_dashboard_data_backup)
                #     default_online_dashboard_backup_price = 0.0
                #     for online_data_backup in plan_feature_days_price_online_dashboard_data_backup:
                #         online_data_backup_price = online_data_backup['backup_days_id__days'] * camera_quantity * online_data_backup['days_price']
                #         online_data_backup_price_days = camera_quantity * online_data_backup['days_price']
                #         default_selected = False
                #         #if user_detail_page['plans_detail']['online_dashboard_detail'] != None:
                #         online_dashboard_exists = False
                #         for plan_detail in user_detail_page['plans_detail']:
                #             if 'online_dashboard_detail' in plan_detail:
                #                 online_dashboard_exists = True
                #                 break

                       
                #             if user_detail_page['plans_detail']['online_data_backup_detail']['backup_days'] == online_data_backup['backup_days_id__days']:
                #                 default_selected = True
                #                 default_online_dashboard_backup_price = online_data_backup_price
                #         product_data_json['plan_online_dashboard_data_backup'].append({
                #              'id':plan_features_pricing_tier_online_dashboard_data_backup['id'],
                #             # 'uuid':plan_features_pricing_tier_online_dashboard_data_backup['uuid'],
                #             #'camera_quantity':camera_quantity,
                #             # "backup_id":online_data_backup['id'],
                #              'backup_days':online_data_backup['backup_days_id__days'],
                #             # 'backup_category':online_data_backup['backup_days_id__category'],
                #             'days_price':online_data_backup_price_days,
                #             'price': online_data_backup_price,
                #             'currency_symbol':online_data_backup['currency_id__currency_symbol'],
                #             # 'pricing_feature_category_id':plan_features_pricing_tier_online_dashboard_data_backup['pricing_feature_category_id'],
                #             # 'category_name':plan_features_pricing_tier_online_dashboard_data_backup['pricing_feature_category_id__category_name'],
                #              'default_selected':default_selected,
                #             # 'plan_id':plan_features_pricing_tier_online_dashboard_data_backup['plan_id'],
                #              'plan_pricing_description':plan_features_pricing_tier_online_dashboard_data_backup['plan_pricing_description'],
                #             # 'show_plan_pricing':plan_features_pricing_tier_online_dashboard_data_backup['show_plan_pricing']
                #         })
                #     product_data_json['plan_offline_dashboard'] = []
                #     plan_features_pricing_tier_offline_dashboard = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Offline Dashboard').values('id','uuid','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                #     plan_feature_days_price_offline_dashboard = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_offline_dashboard['id'],currency_id=currency_type_id).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').first()
                #     offline_dashboard_price = plan_days * camera_quantity * plan_feature_days_price_offline_dashboard['days_price']
                #     offline_dashboard_price_days = camera_quantity * plan_feature_days_price_offline_dashboard['days_price']
                #     default_selected = False
                #     default_offline_dashboard_price = 0.0
                #     # if user_detail_page['plans_detail']['offline_dashboard_detail'] != None:
                #     offline_dashboard_exists = False
                #     for plan_detail in user_detail_page['plans_detail']:
                #         if 'offline_dashboard_detail' in plan_detail:
                #             offline_dashboard_exists = True
                #             break

                   
                #         default_selected = True
                #         default_offline_dashboard_price = offline_dashboard_price
                #     product_data_json['plan_offline_dashboard'].append({
                #             # 'id':plan_features_pricing_tier_offline_dashboard['id'],
                #             # 'uuid':plan_features_pricing_tier_offline_dashboard['uuid'],
                #             #'camera_quantity':camera_quantity,
                #             'plan_days':plan_days,
                #             'days_price':offline_dashboard_price_days,
                #             'price': offline_dashboard_price,
                #             'currency_symbol':plan_feature_days_price_offline_dashboard['currency_id__currency_symbol'],
                #             # 'pricing_feature_category_id':plan_features_pricing_tier_offline_dashboard['pricing_feature_category_id'],
                #             # 'category_name':plan_features_pricing_tier_offline_dashboard['pricing_feature_category_id__category_name'],
                #              'default_selected':default_selected,
                #             # 'plan_id':plan_features_pricing_tier_offline_dashboard['plan_id'],
                #              'plan_pricing_description':plan_features_pricing_tier_offline_dashboard['plan_pricing_description'],
                #             # 'show_plan_pricing':plan_features_pricing_tier_offline_dashboard['show_plan_pricing']
                #         })
                #     product_data_json['plan_offline_dashboard_data_backup'] = []
                #     plan_features_pricing_tier_offline_dashboard_data_backup = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Offline Data Backup').values('id','uuid','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                #     plan_feature_days_price_offline_dashboard_data_backup = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_offline_dashboard['id'],currency_id=currency_type_id).values('id','uuid','backup_days_id','backup_days_id__days','backup_days_id__category','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                #     default_offline_dashboard_backup_price = 0.0
                #     for offline_data_backup in plan_feature_days_price_offline_dashboard_data_backup:
                #         offline_data_backup_price = offline_data_backup['backup_days_id__days'] * camera_quantity * offline_data_backup['days_price']
                #         offline_data_backup_price_days = camera_quantity * offline_data_backup['days_price']

                #         # if offline_data_backup['default_selected'] == True:
                #         #     default_offline_dashboard_backup_price = offline_data_backup_price
                #         default_selected = False
                #         #if user_detail_page['plans_detail']['offline_dashboard_detail'] != None:
                #         offline_dashboard_exists = False
                #         for plan_detail in user_detail_page['plans_detail']:
                #             if 'offline_dashboard_detail' in plan_detail:
                #                 offline_dashboard_exists = True
                #                 break

                       
                            
                            
                #             if user_detail_page['plans_detail']['offline_data_backup_detail']['backup_days'] == offline_data_backup['backup_days_id__days']:
                #                 default_selected = True
                #                 default_offline_dashboard_backup_price = offline_data_backup_price
                #         product_data_json['plan_offline_dashboard_data_backup'].append({
                #              'id':plan_features_pricing_tier_offline_dashboard_data_backup['id'],
                #             # 'uuid':plan_features_pricing_tier_offline_dashboard_data_backup['uuid'],
                #             #'camera_quantity':camera_quantity,
                #              'backup_days':offline_data_backup['backup_days_id__days'],
                #             # 'backup_category':offline_data_backup['backup_days_id__category'],
                #             'days_price':offline_data_backup_price_days,
                #             'price': offline_data_backup_price,
                #             'currency_symbol':offline_data_backup['currency_id__currency_symbol'],
                #         #     'pricing_feature_category_id':plan_features_pricing_tier_offline_dashboard_data_backup['pricing_feature_category_id'],
                #         #     'category_name':plan_features_pricing_tier_offline_dashboard_data_backup['pricing_feature_category_id__category_name'],
                #             'default_selected':default_selected,
                #         #     'plan_id':plan_features_pricing_tier_offline_dashboard_data_backup['plan_id'],
                #              'plan_pricing_description':plan_features_pricing_tier_offline_dashboard_data_backup['plan_pricing_description'],
                #         #     'show_plan_pricing':plan_features_pricing_tier_offline_dashboard_data_backup['show_plan_pricing']
                #         })
                    
                    total_price =  default_product_price + default_product_feature_price
                    all_product_total_price+=total_price
                    plans_data['product_data'].append(product_data_json)

                discount_amount = (all_product_total_price * get_plan_days_and_discount.discount_percentage)/100
                total_price_after_discount = all_product_total_price - discount_amount
                plans_data['coupon_code'] = None
                plan_pricing_tax_detail = PlanPricingTax.objects.filter(plan_pricing_id = get_plan_days_and_discount.plan_pricing_id).values('id','uuid','plan_pricing_id','tax_percentage_detail_id','tax_percentage_detail_id__tax_percentage','tax_percentage_detail_id__tax_type')
                tax_detail = []
                total_price_after_tax = total_price_after_discount
                for pricing_tax in plan_pricing_tax_detail:
                    tax_amount = (total_price_after_discount*pricing_tax['tax_percentage_detail_id__tax_percentage'])/100
                    total_price_after_tax += tax_amount
                    tax_detail.append({
                        # 'id':pricing_tax['id'],
                        # 'uuid':pricing_tax['uuid'],
                        #'tax_percentage_detail_id':pricing_tax['tax_percentage_detail_id'],
                        'tax_percentage':pricing_tax['tax_percentage_detail_id__tax_percentage'],
                        'tax_type':pricing_tax['tax_percentage_detail_id__tax_type'],
                        'tax_amount':tax_amount
                    })

                
            #     plans_data['plan_pricing'] ={
            #         'total_price':all_product_total_price,
            #         'discount_amount':discount_amount,
            #         'total_price_after_discount':total_price_after_discount,
            #         'total_price_after_tax':total_price_after_tax,
            #         'tax_detail':tax_detail
            #     }

            # return JsonResponse(plans_data, status=status.HTTP_200_OK) 
                plan_pricing = PlanPricingView(
                total_price=all_product_total_price,
                discount_amount=discount_amount,
                total_price_after_discount=total_price_after_discount,
                total_price_after_tax=total_price_after_tax,
                tax_detail=tax_detail
            )

                # plans_data = {
                #     'plan_pricing': plan_pricing.to_dict()
                # }
                response_data = {
                    'plan_pricing': plan_pricing.to_dict(),
                    #'plan_offline_dashboard_data_backup': product_data_json.get('plan_offline_dashboard_data_backup', {}),
                    'product_data': product_data_json
                }

                return JsonResponse(response_data, status=status.HTTP_200_OK)  
        else:
            return Response({"detail": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)
        
    def put(self, request,id,format=None):
        user_detail_page = get_user_data_page_plans(request.user.id,'upgrade_plan','view')
        AccessToPage = False
        if user_detail_page['permission'] != None:
            AccessToPage = True
        if AccessToPage == True:
            data = request.data
            plans_data = {}
            plans_detail = data['plans_detail']
            get_plan = Plans.objects.filter(id=id).first()
            plans_data['id'] = get_plan.id
            plans_data['plan_name'] = get_plan.plan_name
            get_plan_days_and_discount_all = PlanDaysAndDiscount.objects.filter(plan_id=id).all()
            plans_data['plan_days']= []
            plan_days = 0
            for plan_days_detail in get_plan_days_and_discount_all:
                selected = False
                if data['plan_days_id'] == plan_days_detail.id:
                    selected = True
                    plan_days = plan_days_detail.plan_days
                plans_data['plan_days'].append({
                    #'id':plan_days_detail.id,
                    'plan_days':plan_days_detail.plan_days,
                    'discount_percentage':plan_days_detail.discount_percentage,
                    #'category':plan_days_detail.category,
                    #'default_select':selected,
                    #'plan_pricing_id':plan_days_detail.plan_pricing_id
                })
            get_plan_days_and_discount = PlanDaysAndDiscount.objects.filter(plan_id=id,id=data['plan_days_id']).first()
            plans_data['product_data'] = []
            if get_plan_days_and_discount != None:
                plan_days = get_plan_days_and_discount.plan_days
                product_data = plans_detail['plan_product'][0]
                parking_product_data = PlanFeaturePricingTier.objects.filter(plan_id=id,pricing_feature_category_id__category_name="Product",default_product_id__product_name='Visitor management system',id=plans_detail['plan_product'][0]['plan_feature_pricing_tier_id'],show_plan_pricing=True).values('id','uuid','default_product_id','default_product_id__product_name','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                all_product_total_price = 0.0
                if parking_product_data != None:
                    # camera_quantity = product_data['plan_camera_detail']['camera_quantity']
                    #camera_quantity = data['plan_camera_detail']['camera_quantity']
                    product_data_json = {}
                    product_data_json['id'] = parking_product_data['id']
                    product_data_json['product_name'] = parking_product_data['default_product_id__product_name']

                    # plan_feature_days_price_product = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=parking_product_data['id'],currency_id=data['currency_type_id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                    # product_selected_exist = True
                    # default_product_price = plan_days * camera_quantity * plan_feature_days_price_product['days_price']
                    # default_product_price_days = camera_quantity * plan_feature_days_price_product['days_price']
                    plan_feature_days_price_product = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=parking_product_data['id'],currency_id=data['currency_type_id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                   # plan_feature_days_price_product = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=parking_product_data['id'],currency_id=data['currency_type_id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                    plan_feature_days_price_product_instance = plan_feature_days_price_product.first()

                    if plan_feature_days_price_product_instance:
                           default_product_price = plan_days *  plan_feature_days_price_product_instance['days_price']
                           default_product_price_days =  plan_feature_days_price_product_instance['days_price']
                    else:
                        #print("error in defaultproductprice")
                            default_product_price = 0 
                            default_product_price_days = 0
                    product_selected_exist = True
                    product_data_json['plan_product']={
                        # 'id':parking_product_data['id'],
                        # 'uuid':parking_product_data['uuid'],
                        'days_price':default_product_price_days,
                        'price': default_product_price,
                        'currency_symbol':plan_feature_days_price_product_instance['currency_id__currency_symbol'],
                        #'pricing_feature_category_id':parking_product_data['pricing_feature_category_id'],
                        #'category_name':parking_product_data['pricing_feature_category_id__category_name'],
                        #'default_selected':product_selected_exist,
                        #'plan_id':parking_product_data['plan_id'],
                        'plan_pricing_description':parking_product_data['plan_pricing_description'],
                        #'show_plan_pricing':parking_product_data['show_plan_pricing']
                    }

                    default_parking_product_feature_data = PlanFeaturePricingTier.objects.filter(plan_id=id,pricing_feature_category_id__category_name="Feature",default_product_id__product_name='Visitor management system',is_encluded_plan_feature_id__isnull=False,default_product_feature_id__isnull=False).values('id','uuid','default_product_id','default_product_id__product_name','default_product_feature_id','default_product_feature_id__feature','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').all()
                    product_data_json['plan_product_feature_default'] = []
                    for default_product_feature in default_parking_product_feature_data:
                        product_data_json['plan_product_feature_default'].append({
                            # 'id':default_product_feature['id'],
                            # 'uuid':default_product_feature['uuid'],
                            # 'default_product_feature_id':default_product_feature['default_product_feature_id'],
                            # 'pricing_feature_category_id':default_product_feature['pricing_feature_category_id'],
                            'category_name':default_product_feature['pricing_feature_category_id__category_name'],
                            'feature_name':default_product_feature['default_product_feature_id__feature'],
                            'plan_pricing_description':default_product_feature['plan_pricing_description'],       
                        })
                    parking_product_feature_data = PlanFeaturePricingTier.objects.filter(plan_id=id,pricing_feature_category_id__category_name="Feature",default_product_id__product_name='Visitor management system',is_encluded_plan_feature_id__isnull=True,default_product_feature_id__isnull=False).values('id','uuid','default_product_id','default_product_id__product_name','default_product_feature_id','default_product_feature_id__feature','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').all()
                    product_data_json['plan_product_feature'] = []
                    default_product_feature_price = 0.0
                    for product_feature in parking_product_feature_data:
                        plan_feature_days_price_product_feature = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount['id'],plan_feature_pricing_tier_id=product_feature['id'],currency_id=data['currency_type_id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                        product_feature_price = plan_days * plan_feature_days_price_product_feature['days_price']
                        product_feature_price_days =  plan_feature_days_price_product_feature['days_price']
                        default_selected = False
                        feature_plan_selected = [feature_plan for feature_plan in product_data['plan_feature_detail'] if feature_plan['plan_feature_pricing_tier_id']==product_feature['id'] and feature_plan['selected']==True]
                        if len(feature_plan_selected) > 0:
                            default_selected = True
                            default_product_feature_price += product_feature_price
                        product_data_json['plan_product_feature'].append({
                            # 'id':product_feature['id'],
                            # 'uuid':product_feature['uuid'],
                            'days_price':product_feature_price_days,
                            'price': product_feature_price,
                            'currency_symbol':plan_feature_days_price_product['currency_id__currency_symbol'],
                            #'default_product_feature_id':product_feature['default_product_feature_id'],
                            'feature_name':product_feature['default_product_feature_id__feature'],
                           # 'pricing_feature_category_id':product_feature['pricing_feature_category_id'],
                            'category_name':product_feature['pricing_feature_category_id__category_name'],
                           # 'default_selected':default_selected,
                           # 'plan_id':product_feature['plan_id'],
                            'plan_pricing_description':product_feature['plan_pricing_description'],
                            #'show_plan_pricing':product_feature['show_plan_pricing']
                        })

                    # plan_features_pricing_tier_camera = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Camera').values('id','uuid','min_quantity','max_quantity','default_quantity','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                    # default_camera_price = 0.0
                    # product_data_json['plan_camera_detail']= []
                    # for camera in range(plan_features_pricing_tier_camera['min_quantity'],plan_features_pricing_tier_camera['max_quantity']+1):
                    #     plan_feature_days_price_camera = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=data['plan_days_id'],plan_feature_pricing_tier_id=plan_features_pricing_tier_camera['id'],currency_id=data['currency_type_id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol').first()
                    #     camera_price = plan_days * camera * plan_feature_days_price_camera['days_price']
                    #     camera_price_days = camera * plan_feature_days_price_camera['days_price']
                    #     default_selected = False
                    #     if camera_quantity == camera:
                    #         default_camera_price = camera_price
                    #         default_selected = True
                    #     product_data_json['plan_camera_detail'].append({
                    #         # 'id':plan_features_pricing_tier_camera['id'],
                    #         # 'uuid':plan_features_pricing_tier_camera['uuid'],
                    #         'camera_quantity':camera,
                    #         'days_price':camera_price_days,
                    #         'price': camera_price,
                    #         'currency_symbol':plan_feature_days_price_camera['currency_id__currency_symbol'],
                    #        # 'pricing_feature_category_id':plan_features_pricing_tier_camera['pricing_feature_category_id'],
                    #        # 'category_name':plan_features_pricing_tier_camera['pricing_feature_category_id__category_name'],
                    #        # 'default_selected':default_selected,
                    #        # 'plan_id':plan_features_pricing_tier_camera['plan_id'],
                    #         'plan_pricing_description':plan_features_pricing_tier_camera['plan_pricing_description'],
                    #         #'show_plan_pricing':plan_features_pricing_tier_camera['show_plan_pricing']
                    #     })

                    # # plan_features_pricing_tier_parking_slot = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Parking Slot').values('id','uuid','min_quantity','max_quantity','default_quantity','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                    # # parking_slot = product_data['plan_parking_slot_detail']['parking_slot']
                    # # if parking_slot < plan_features_pricing_tier_parking_slot['min_quantity'] or parking_slot > plan_features_pricing_tier_parking_slot['max_quantity']:
                    # #     return Response({'detail':'please select any one dashboard type.'},status.HTTP_400_BAD_REQUEST)
                    # # # for camera in range(plan_features_pricing_tier_camera['min_quantity'],plan_features_pricing_tier_camera['max_quantity']+1):
                    # # plan_feature_days_price_parking_slot = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_camera['id'],currency_id=data['currency_type_id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol').first()
                    # # default_parking_slot_price = plan_days * parking_slot * plan_feature_days_price_parking_slot['days_price']
                    # # praking_days_price = parking_slot * plan_feature_days_price_parking_slot['days_price']
                    # # default_selected = True
                    # # product_data_json['plan_parking_slots']={
                    # #     'id':plan_features_pricing_tier_parking_slot['id'],
                    # #     'uuid':plan_features_pricing_tier_parking_slot['uuid'],
                    # #     'parking_slot':parking_slot,
                    # #     'days_price':praking_days_price,
                    # #     'price': default_parking_slot_price,
                    # #     'currency_symbol':plan_feature_days_price_parking_slot['currency_id__currency_symbol'],
                    # #     'pricing_feature_category_id':plan_features_pricing_tier_parking_slot['pricing_feature_category_id'],
                    # #     'category_name':plan_features_pricing_tier_parking_slot['pricing_feature_category_id__category_name'],
                    # #     'default_selected':default_selected,
                    # #     'plan_id':plan_features_pricing_tier_parking_slot['plan_id'],
                    # #     'plan_pricing_description':plan_features_pricing_tier_parking_slot['plan_pricing_description'],
                    # #     'show_plan_pricing':plan_features_pricing_tier_parking_slot['show_plan_pricing']
                    # # }

                    # if product_data['plan_online_dashboard']['selected'] == False and data['plan_offline_dashboard']['selected'] == False: 
                    #     return Response({'detail':'please select any one dashboard type.'},status.HTTP_400_BAD_REQUEST)
                    # product_data_json['plan_online_dashboard'] = []
                    # plan_features_pricing_tier_online_dashboard = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Online Dashboard').values('id','uuid','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                    # plan_feature_days_price_online_dashboard = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard['id'],currency_id=data['currency_type_id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').first()
                    # online_dashboard_price = plan_days * camera_quantity * plan_feature_days_price_online_dashboard['days_price']
                    # online_dashboard_price_days = camera_quantity * plan_feature_days_price_online_dashboard['days_price']
                    # default_online_dashboard_price = 0.0
                    # if product_data['plan_online_dashboard']['selected'] == True:
                    #     default_online_dashboard_price = online_dashboard_price
                    # product_data_json['plan_online_dashboard'].append({
                    #         # 'id':plan_features_pricing_tier_online_dashboard['id'],
                    #         # 'uuid':plan_features_pricing_tier_online_dashboard['uuid'],
                    #         # 'camera_quantity':camera_quantity,
                    #         'plan_days':plan_days,
                    #         'days_price':online_dashboard_price_days,
                    #         'price': online_dashboard_price,
                    #         'currency_symbol':plan_feature_days_price_online_dashboard['currency_id__currency_symbol'],
                    #        # 'pricing_feature_category_id':plan_features_pricing_tier_online_dashboard['pricing_feature_category_id'],
                    #       #  'category_name':plan_features_pricing_tier_online_dashboard['pricing_feature_category_id__category_name'],
                    #        # 'default_selected':product_data['plan_online_dashboard']['selected'],
                    #       #  'plan_id':plan_features_pricing_tier_online_dashboard['plan_id'],
                    #         'plan_pricing_description':plan_features_pricing_tier_online_dashboard['plan_pricing_description'],
                    #       #  'show_plan_pricing':plan_features_pricing_tier_online_dashboard['show_plan_pricing']
                    #     })

                    # product_data_json['plan_online_dashboard_data_backup'] = []
                    # plan_features_pricing_tier_online_dashboard_data_backup = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Online Data Backup').values('id','uuid','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                    # plan_feature_days_price_online_dashboard_data_backup = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_online_dashboard['id'],currency_id=data['currency_type_id']).values('id','uuid','backup_days_id','backup_days_id__days','backup_days_id__category','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                    # print("plan_feature_days_price_online_dashboard_data_backup",plan_feature_days_price_online_dashboard_data_backup)
                    # default_online_dashboard_backup_price = 0.0
                    # for online_data_backup in plan_feature_days_price_online_dashboard_data_backup:
                    #     online_data_backup_price = online_data_backup['backup_days_id__days'] * camera_quantity * online_data_backup['days_price']
                    #     online_data_backup_price_days = camera_quantity * online_data_backup['days_price']

                    #     default_selected = False
                    #     if product_data['plan_online_data_backup']['backup_id'] == online_data_backup['id'] and data['plan_online_dashboard']['selected'] == True:
                    #         default_online_dashboard_backup_price = online_data_backup_price
                    #         default_selected = True
                    #     product_data_json['plan_online_dashboard_data_backup'].append({
                    #         # 'id':plan_features_pricing_tier_online_dashboard_data_backup['id'],
                    #         # 'uuid':plan_features_pricing_tier_online_dashboard_data_backup['uuid'],
                    #         # 'camera_quantity':camera_quantity,
                    #         "backup_id":online_data_backup['id'],
                    #         'backup_days':online_data_backup['backup_days_id__days'],
                    #         #'backup_category':online_data_backup['backup_days_id__category'],
                    #         'days_price':online_data_backup_price_days,
                    #         'price': online_data_backup_price,
                    #         'currency_symbol':online_data_backup['currency_id__currency_symbol'],
                    #         #'pricing_feature_category_id':plan_features_pricing_tier_online_dashboard_data_backup['pricing_feature_category_id'],
                    #        # 'category_name':plan_features_pricing_tier_online_dashboard_data_backup['pricing_feature_category_id__category_name'],
                    #         'default_selected':online_data_backup['default_selected'],
                    #         #'plan_id':plan_features_pricing_tier_online_dashboard_data_backup['plan_id'],
                    #         'plan_pricing_description':plan_features_pricing_tier_online_dashboard_data_backup['plan_pricing_description'],
                    #        # 'show_plan_pricing':plan_features_pricing_tier_online_dashboard_data_backup['show_plan_pricing']
                    #     })

                    # product_data_json['plan_offline_dashboard'] = []
                    # plan_features_pricing_tier_offline_dashboard = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Offline Dashboard').values('id','uuid','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                    # plan_feature_days_price_offline_dashboard = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_offline_dashboard['id'],currency_id=data['currency_type_id']).values('id','uuid','backup_days_id','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').first()
                    # offline_dashboard_price = plan_days * camera_quantity * plan_feature_days_price_offline_dashboard['days_price']
                    # offline_dashboard_price_days = camera_quantity * plan_feature_days_price_offline_dashboard['days_price']
                    # default_offline_dashboard_price = 0.0
                    # if product_data['plan_offline_dashboard']['selected'] == True:
                    #     default_offline_dashboard_price = offline_dashboard_price
                    # product_data_json['plan_offline_dashboard'].append({
                    #         # 'id':plan_features_pricing_tier_offline_dashboard['id'],
                    #         # 'uuid':plan_features_pricing_tier_offline_dashboard['uuid'],
                    #         # 'camera_quantity':camera_quantity,
                    #         'plan_days':plan_days,
                    #         'days_price':offline_dashboard_price_days,
                    #         'price': offline_dashboard_price,
                    #         'currency_symbol':plan_feature_days_price_offline_dashboard['currency_id__currency_symbol'],
                    #        # 'pricing_feature_category_id':plan_features_pricing_tier_offline_dashboard['pricing_feature_category_id'],
                    #        # 'category_name':plan_features_pricing_tier_offline_dashboard['pricing_feature_category_id__category_name'],
                    #        # 'default_selected':product_data['plan_offline_dashboard']['selected'],
                    #         #'plan_id':plan_features_pricing_tier_offline_dashboard['plan_id'],
                    #         'plan_pricing_description':plan_features_pricing_tier_offline_dashboard['plan_pricing_description'],
                    #        # 'show_plan_pricing':plan_features_pricing_tier_offline_dashboard['show_plan_pricing']
                    #     })

                    # product_data_json['plan_offline_dashboard_data_backup'] = []
                    # plan_features_pricing_tier_offline_dashboard_data_backup = PlanFeaturePricingTier.objects.filter(plan_id=id,default_product_id=parking_product_data['default_product_id'],pricing_feature_category_id__category_name='Offline Data Backup').values('id','uuid','pricing_feature_category_id','pricing_feature_category_id__category_name','plan_id','plan_pricing_description','show_plan_pricing').first()
                    # plan_feature_days_price_offline_dashboard_data_backup = PlanFeatureDaysPrice.objects.filter(plans_id=id,plan_days_and_discount_id=get_plan_days_and_discount.id,plan_feature_pricing_tier_id=plan_features_pricing_tier_offline_dashboard['id'],currency_id=data['currency_type_id']).values('id','uuid','backup_days_id','backup_days_id__days','backup_days_id__category','plan_days_and_discount_id','days_price','currency_id','currency_id__currency_symbol','default_selected').all()
                    # default_offline_dashboard_backup_price = 0.0
                    # for offline_data_backup in plan_feature_days_price_offline_dashboard_data_backup:
                    #     offline_data_backup_price = offline_data_backup['backup_days_id__days'] * camera_quantity * offline_data_backup['days_price']
                    #     offline_data_backup_price_days = camera_quantity * offline_data_backup['days_price']
                    #     default_selected = False
                    #     if product_data['plan_offline_data_backup']['backup_id'] == offline_data_backup['id'] and data['plan_offline_dashboard']['selected'] == True:
                    #         default_offline_dashboard_backup_price = offline_data_backup_price
                    #         default_selected = True
                    #     product_data_json['plan_offline_dashboard_data_backup'].append({
                    #         'id':plan_features_pricing_tier_offline_dashboard_data_backup['id'],
                    #         # 'uuid':plan_features_pricing_tier_offline_dashboard_data_backup['uuid'],
                    #         # 'camera_quantity':camera_quantity,
                    #         'backup_days':offline_data_backup['backup_days_id__days'],
                    #         #'backup_category':offline_data_backup['backup_days_id__category'],
                    #         'days_price':offline_data_backup_price_days,
                    #         'price': offline_data_backup_price,
                    #         'currency_symbol':offline_data_backup['currency_id__currency_symbol'],
                    #        # 'pricing_feature_category_id':plan_features_pricing_tier_offline_dashboard_data_backup['pricing_feature_category_id'],
                    #        # 'category_name':plan_features_pricing_tier_offline_dashboard_data_backup['pricing_feature_category_id__category_name'],
                    #         'default_selected':default_selected,
                    #         #'plan_id':plan_features_pricing_tier_offline_dashboard_data_backup['plan_id'],
                    #         'plan_pricing_description':plan_features_pricing_tier_offline_dashboard_data_backup['plan_pricing_description'],
                    #        # 'show_plan_pricing':plan_features_pricing_tier_offline_dashboard_data_backup['show_plan_pricing']
                    #     })
                    
                    total_price =  default_product_price+default_product_feature_price
                    all_product_total_price+=total_price
                    plans_data['product_data'].append(product_data_json)
                discount_amount = (all_product_total_price * get_plan_days_and_discount.discount_percentage)/100
                total_price_after_discount = all_product_total_price - discount_amount
                if plans_detail['coupon_code'] != None:
                    get_coupon = Coupon.objects.filter(code=plans_detail['coupon_code'],currency_id=data['currency_type_id'],plan_buy_days__gte=plan_days,coupon_expiry_datetime__gte= timezone.datetime.now(),is_active=True).values('id','uuid','code','description','discount_type','discount_value','currency_id','currency_id__currency_type').first()
                    if get_coupon != None:
                        total_coupon_amount = 0.0
                        if get_coupon['discount_type'] == 'percentage':
                            total_coupon_amount =  (all_product_total_price * get_coupon['discount_value'])/100
                        elif get_coupon['discount_type'] == 'fixed amount':
                            total_coupon_amount = all_product_total_price - get_coupon['discount_value']
                        total_price_after_discount -= total_coupon_amount

                        plans_data['coupon_code'] ={
                            # 'id':get_coupon['id'],
                            # 'uuid':get_coupon['uuid'],
                            'code':get_coupon['code'],
                            'description':get_coupon['description'],
                            'discount_type':get_coupon['discount_type'],
                            'discount_value':get_coupon['discount_value'],
                           # 'currency_id':get_coupon['currency_id'],
                            'total_coupon_amount':total_coupon_amount
                        }

                    else:
                        return Response({'detail':"coupon code is not valid."},status.HTTP_400_BAD_REQUEST)

                #     total_price = default_camera_price + default_online_dashboard_price + default_online_dashboard_backup_price + default_offline_dashboard_price + default_offline_dashboard_backup_price + default_product_price+default_product_feature_price
                #     all_product_total_price+=total_price
                #     plans_data['product_data'].append(product_data_json)
                # discount_amount = (all_product_total_price * get_plan_days_and_discount.discount_percentage)/100
                # total_price_after_discount = all_product_total_price - discount_amount
                # if plans_detail['coupon_code'] != None:
                #     get_coupon = Coupon.objects.filter(code=data['coupon_code'],currency_id=data['currency_type_id'],plan_buy_days__gte=plan_days,coupon_expiry_datetime__gte= datetime.datetime.now(),is_active=True).values('id','uuid','code','description','discount_type','discount_value','currency_id','currency_id__currency_type').first()
                #     if get_coupon != None:
                #         total_coupon_amount = 0.0
                #         if get_coupon['discount_type'] == 'percentage':
                #             total_coupon_amount =  (all_product_total_price * get_coupon['discount_value'])/100
                #         elif get_coupon['discount_type'] == 'fixed amount':
                #             total_coupon_amount = all_product_total_price - get_coupon['discount_value']
                #         total_price_after_discount -= total_coupon_amount

                #         plans_data['coupon_code'] ={
                #             'id':get_coupon['id'],
                #             'uuid':get_coupon['uuid'],
                #             'code':get_coupon['code'],
                #             'description':get_coupon['description'],
                #             'discount_type':get_coupon['discount_type'],
                #             'discount_value':get_coupon['discount_value'],
                #             'currency_id':get_coupon['currency_id'],
                #             'total_coupon_amount':total_coupon_amount
                #         }

                #     else:
                #         return Response({'detail':"coupon code is not valid."},status.HTTP_400_BAD_REQUEST)

                plan_pricing_tax_detail = PlanPricingTax.objects.filter(plan_pricing_id = get_plan_days_and_discount.plan_pricing_id).values('id','uuid','plan_pricing_id','tax_percentage_detail_id','tax_percentage_detail_id__tax_percentage','tax_percentage_detail_id__tax_type')
                tax_detail = []
                total_price_after_tax = total_price_after_discount
                for pricing_tax in plan_pricing_tax_detail:
                    tax_amount = (total_price_after_discount*pricing_tax['tax_percentage_detail_id__tax_percentage'])/100
                    total_price_after_tax += tax_amount
                    tax_detail.append({
                        # 'id':pricing_tax['id'],
                        # 'uuid':pricing_tax['uuid'],
                        # 'tax_percentage_detail_id':pricing_tax['tax_percentage_detail_id'],
                        'tax_percentage':pricing_tax['tax_percentage_detail_id__tax_percentage'],
                        'tax_type':pricing_tax['tax_percentage_detail_id__tax_type'],
                        'tax_amount':tax_amount
                    })
                    plan_pricing = PlanPricingView(
                                total_price=all_product_total_price,
                                discount_amount=discount_amount,
                                total_price_after_discount=total_price_after_discount,
                                total_price_after_tax=total_price_after_tax,
                                tax_detail=tax_detail
                            )

                # plans_data = {
                #     'plan_pricing': plan_pricing.to_dict()
                # }
                response_data = {
                    'plan_pricing': plan_pricing.to_dict(),
                    #'plan_offline_dashboard_data_backup': product_data_json.get('plan_offline_dashboard_data_backup', {}),
                    'product_data': product_data_json
            }
            #     plans_data['plan_pricing'] ={
            #         'total_price':total_price,
            #         'discount_amount':discount_amount,
            #         'total_price_after_discount':total_price_after_discount,
            #         'total_price_after_tax':total_price_after_tax,
            #         'tax_detail':tax_detail
            #     }
            return Response(response_data, status=status.HTTP_200_OK)   
        else:
            return Response({"detail": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)
        

class CashfreeWebhookView(APIView):
    def post(self, request, *args, **kwargs):
        try:


            logger.info("Received webhook POST request")
            body_unicode = request.body.decode('utf-8')
            print(body_unicode)
            logger.debug(f"Request body: {body_unicode}")
            event_data = json.loads(body_unicode)
            print("ed",event_data)
            logger.info("Event data parsed successfully")

            customer_id = event_data.get('data', {}).get('customer_details', {}).get('customer_id')
            print("cid",customer_id)
            
            if not customer_id:
                raise ValueError("customer_id not found in the event data")
            
            logger.debug(f"Extracted customer_id: {customer_id}")
            
            company_detail_obj = CompanyDetail.objects.get(uuid=customer_id)
            business_plan_history_obj = BusinessPlanHistory.objects.filter(company_detail_id=company_detail_obj.id).latest('id')
            print("bpho", business_plan_history_obj)
            
            plan_type = business_plan_history_obj.plan_type

            
            business_plan_history = BusinessPlanHistorySerializer(business_plan_history_obj).data
            print("bph",business_plan_history)
                       
            self.process_webhook_event(request,business_plan_history, event_data)
            print("success")
            logger.info("Webhook event processed successfully")

                
                
            return JsonResponse({'status': 'success'})
        except Exception as e:
            logger.error(f"Error processing webhook: {str(e)}", exc_info=True)
            
            return JsonResponse({'status': 'error', 'message': str(e)}, status=500)


    def process_webhook_event(self,request, business_plan_history, event_data):
        try:
                
                payload = json.loads(request.body)
                event_data = payload['data']


                event_type = payload['type']
                event_time = payload['event_time']
                order_id = event_data['order']['order_id']
                payment_status = event_data['payment']['payment_status']
                customer_id = event_data['customer_details']['customer_id']
                customer_email = event_data['customer_details']['customer_email']
                payment_amount = event_data['payment']['payment_amount']
                payment_time = event_data['payment']['payment_time']

               
                print("Event Type:", event_type)
                print("Event Time:", event_time)
                print("Order ID:", order_id)
                print("Payment Status:", payment_status)
                print("Customer ID:", customer_id)
                print("Customer Email:", customer_email)
                print("Payment Amount:", payment_amount)
                print("Payment Time:", payment_time)
               
                company_detail_obj = CompanyDetail.objects.get(uuid=customer_id)
                business_plan_history_obj = BusinessPlanHistory.objects.filter(company_detail_id=company_detail_obj.id).latest('id')
                print("bpho", business_plan_history_obj)
                
                plan_type = business_plan_history_obj.plan_type
            
                if event_type == 'PAYMENT_SUCCESS_WEBHOOK' and payment_status == 'SUCCESS':
                #if event_type == 'payment' and payment_status == 'success':
                
                    self.update_transaction_history(business_plan_history, payment_amount, customer_email)
                else:
                     if plan_type == 'BuyPlan':
                        
                        self.rollback_transaction(business_plan_history)
                     elif plan_type == 'Upgrade Plan':
                        self.rollback_transaction_for_upgradeplan(business_plan_history)
                        
                        print("failed")

        except Exception as e:
                    print("Error in process_webhook_event")
                    logger.error(f"Error in process_webhook_event: {str(e)}", exc_info=True)
                    raise
      
    def send_payment_confirmation_email(self, customer_email, payment_amount):
        subject = 'Payment Confirmation'
        message = f'Your payment of {payment_amount} was successful.'
        from_email = 'prachipatel200023@gmail.com'
        recipient_list = [customer_email]

        try:
            send_mail(subject, message, from_email, recipient_list)
            logger.info(f"Payment confirmation email sent to {customer_email}")
            print(f"Payment confirmation email sent to {customer_email}")
        except Exception as e:
            logger.info(f"Failed to send payment confirmation email to {customer_email}: {e}")
            print(f"Failed to send payment confirmation email to {customer_email}: {e}")
    @transaction.atomic
    def update_transaction_history(self, business_plan_history, payment_amount, customer_email):
        try:
            currency = Currency.objects.get(id=business_plan_history['currency_id'])
            company_detail = CompanyDetail.objects.get(id=business_plan_history['company_detail_id'])
            business_plan_history_obj = BusinessPlanHistory.objects.get(id=business_plan_history['id'])


            BusinessTransactionHistory.objects.create(
                amout_paid=payment_amount,
                currency_id=currency,
                currency_type=business_plan_history['currency_type'],
                currency_symbol=business_plan_history['currency_symbol'],
                date_and_time=timezone.now(),
                business_detail_id=company_detail,
                business_plan_history_id=business_plan_history_obj,
                #payment_status=True
            )

            business_plan_history_obj.payment_status = True
            business_plan_history_obj.save()
            self.send_payment_confirmation_email(customer_email, payment_amount)
        except Exception as e:
            logger.error(f"Error updating transaction history: {e}", exc_info=True)
            print(f"Error updating transaction history: {e}")
            raise
        
    @transaction.atomic
    def rollback_transaction(self, business_plan_history):
        try:
            company_detail_id = business_plan_history['company_detail_id']

            
            BusinessPlanHistory.objects.filter(id=business_plan_history['id']).delete()

           
            user_role_mappings = UserRoleMapping.objects.filter(company_detail_id=company_detail_id)
            users = User.objects.filter(company_detail_id=company_detail_id)
            add_user_emails = AddUserEmail.objects.filter(company_detail_id=company_detail_id)

            for user_role_map in user_role_mappings:
                UserRoleMapping.objects.filter(id=user_role_map.id).delete()

            for user in users:
                User.objects.filter(id=user.id).delete()

            for add_user_email in add_user_emails:
                AddUserEmail.objects.filter(id=add_user_email.id).delete()

            
            try:
                latest_role = Roles.objects.filter(company_detail_id=company_detail_id).latest('created_datetime')

               
                permissions_to_delete = Permission.objects.filter(role=latest_role)
                for permission in permissions_to_delete:
                    Permission.objects.filter(id=permission.id).delete()

              
                Roles.objects.filter(id=latest_role.id).delete()
            except Roles.DoesNotExist:
                logger.warning(f"No roles found for company_detail_id {company_detail_id}")

            
            CompanyDetail.objects.filter(id=company_detail_id).delete()

            logger.info("Rolled back all related entries for the failed transaction")
        except Exception as e:
            logger.error(f"Error during rollback: {e}", exc_info=True)
            raise

    @transaction.atomic
    def rollback_transaction_for_upgradeplan(self, business_plan_history):
        try:
            company_detail_id = business_plan_history['company_detail_id']

            
            BusinessPlanHistory.objects.filter(id=business_plan_history['id']).delete()
            BusinessPricingTier.objects.filter(business_plan_history_id=company_detail_id).delete()
            #BusinessTransactionHistory.objects.filter(business_plan_history_id=business_detail_id).delete()
            BusinessPlanPricingTax.objects.filter(business_plan_history_id=company_detail_id).delete()
            
           
            BusinessPlanHistory.objects.filter(id=company_detail_id).delete()
            
            logger.info("Rolled back all related entries for the failed upgrade transaction")
        except Exception as e:
            logger.error(f"Error during rollback of upgrade transaction: {e}", exc_info=True)
            raise