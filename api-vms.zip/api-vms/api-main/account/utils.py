from .serializers import *
from datetime import datetime, timedelta
from .views import*
from django.core.exceptions import ObjectDoesNotExist
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.core.mail import send_mail
import requests
from cashfree_pg.models.create_order_request import CreateOrderRequest
from cashfree_pg.api_client import Cashfree
from cashfree_pg.models.customer_details import CustomerDetails
from django.contrib.auth import get_user_model
# from cashfree_sdk.payouts import CashfreePayouts
# from cashfree_sdk.payouts.models import CreateLinkRequest, LinkCustomerDetailsEntity, LinkNotifyEntity

#from cashfree_sdk import Client

# def get_existing_plan(business_id):
        
#         existing_plan= BusinessPlanHistory.objects.filter(
#             business_detail_id=business_id,
#             current_active=True,
#             plan_expire_datetime__gt=timezone.now()  
#         ).order_by('-plan_expire_datetime').first()
       
#         # if existing_plan:
              
#         #         existing_business_pricing_tier = existing_plan.businesspricetier_set.first()
#         #         existing_plan.camera_quantity = existing_business_pricing_tier.quantity
#         #         existing_plan.parking_slots = existing_business_pricing_tier.parking_slots
#         existing_camera_quantity = BusinessPricingTier.objects.filter(
#             plan_id=existing_plan.id,
#             category_name='Camera'
#         ).first()

#         existing_parking_slots = BusinessPricingTier.objects.filter(
#             plan_id=existing_plan.id,
#             category_name='Parking Slot'
#         ).first()
#         return existing_plan

# def get_updated_plan(business_plan_history, plans_data):
    
   
#     #plan_expire_datetime = timezone.now() + timedelta(days=plans_detail['days_to_expire'])

    
#     plan_name = business_plan_history.get('plan_name')
#     price = business_plan_history.get('price')
#     price_after_discount=business_plan_history.get('price_after_discount')
#     price_after_tax=business_plan_history.get('price_after_tax')
#     days_price = business_plan_history.get('days_price')
#     days_price_after_discount= business_plan_history.get('days_price_after_discount')
#     days_price_after_tax= business_plan_history.get('days_price_after_tax')
#     currency_id = business_plan_history.get('currency_id')
#     currency_type = business_plan_history.get('currency_type')
#     currency_symbol = business_plan_history.get('currency_symbol')
#     country_category_id = business_plan_history.get('country_category_id')
#     country_type = business_plan_history.get('country_type')
#     plan_id = business_plan_history.get('plan_id')
#     plan_days_and_discount_id = business_plan_history.get('plan_days_and_discount_id')
#     plan_days = business_plan_history.get('plan_days')
#     discount_in_percentage = business_plan_history.get('discount_in_percentage')
#     discount_in_currency = business_plan_history.get('discount_in_currency')
#     total_discount = business_plan_history.get('total_discount')
#     total_tax_in_percentage = business_plan_history.get('total_tax_in_percentage')
#     total_tax_in_currency = business_plan_history.get('total_tax_in_currency')
#     buy_datetime = business_plan_history.get('buy_datetime')
#     plan_start_datetime = business_plan_history.get('plan_start_datetime')
#     plan_expire_datetime = business_plan_history.get('plan_expire_datetime')
#     minutes_to_expire = business_plan_history.get('minutes_to_expire')
#     days_to_expire = business_plan_history.get('days_to_expire')
#     plan_validity = business_plan_history.get('plan_validity')
#     plan_status = business_plan_history.get('plan_status')
#     current_active = business_plan_history.get('current_active')
#     plan_type = business_plan_history.get('plan_type')
#     business_detail_id = business_plan_history.get('business_detail_id')

#     try:
#         currency_instance = Currency.objects.get(id=currency_id)
#     except ObjectDoesNotExist:
        
#         pass
#     try:
#         country_category_instance = CountryCategory.objects.get(id=country_category_id)
#     except ObjectDoesNotExist:
      
#         pass
#     try:
#         plan_instance = Plans.objects.get(id=plan_id)
#     except ObjectDoesNotExist:
       
#         pass
#     plan_days_and_discount_id = business_plan_history['plan_days_and_discount_id']
#     try:
#         plan_days_and_discount_instance = PlanDaysAndDiscount.objects.get(id=plan_days_and_discount_id)
#     except ObjectDoesNotExist:
        
#         pass
#     business_detail_id = business_plan_history['business_detail_id']
#     try:
#         business_detail_instance = BusinessDetail.objects.get(id=business_detail_id)
#     except ObjectDoesNotExist:
        
#         pass
#     updated_camera_quantity = BusinessPricingTier.objects.filter(
#     plan_id=business_plan_history['plan_id'],  
#     category_name='Camera'
#     ).count()

#     updated_parking_slots = BusinessPricingTier.objects.filter(
#         plan_id=business_plan_history['plan_id'],  
#         category_name='Parking Slot'
#     ).count()
#     # try:
       
#     #     currency_instance = Currency.objects.get(id=business_plan_history.get('currency_id'))
#     #     country_category_instance = CountryCategory.objects.get(id=business_plan_history.get('country_category_id'))
#     #     plan_instance = Plans.objects.get(id=business_plan_history.get('plan_id'))
#     #     plan_days_and_discount_instance = PlanDaysAndDiscount.objects.get(id=business_plan_history.get('plan_days_and_discount_id'))
#     #     business_detail_instance = BusinessDetail.objects.get(id=business_detail_id)

        
#     # except ObjectDoesNotExist:
#     #         return None

#     # camera_quantity = BusinessPricingTier.objects.filter(
#     #         business_plan_history_id=business_plan_history['business_plan_history_id'],
#     #         category_name='Camera'
#     #     ).count()

#     # parking_slot_count = BusinessPricingTier.objects.filter(
#     #     business_plan_history_id=business_plan_history['business_plan_history_id'],
#     #     category_name='Parking Slot'
#     # ).count()


#     updated_plan = BusinessPlanHistory.objects.create(
#         plan_name=plan_name,
#         price=price,
#         price_after_discount=price_after_discount,
#         price_after_tax=price_after_tax,
#         days_price=days_price,
#         days_price_after_discount=days_price_after_discount,
#         days_price_after_tax=days_price_after_tax,
#         currency_id=currency_instance,
#         currency_type=currency_type,
#         currency_symbol=currency_symbol,
#         country_category_id=country_category_instance,
#         country_type=country_type,
#         plan_id=plan_instance,
#         plan_days_and_discount_id=plan_days_and_discount_instance,
#         plan_days=plan_days,
#         discount_in_percentage=discount_in_percentage,
#         discount_in_currency=discount_in_currency,
#         total_discount=total_discount,
#         total_tax_in_percentage=total_tax_in_percentage,
#         total_tax_in_currency=total_tax_in_currency,
#         buy_datetime=buy_datetime,
#         plan_start_datetime=plan_start_datetime,
#         plan_expire_datetime=plan_expire_datetime,
#         minutes_to_expire=minutes_to_expire,
#         days_to_expire=days_to_expire,
#         plan_validity=plan_validity,
#         current_active=current_active,
#         plan_status=plan_status,
#         plan_type=plan_type,
#         business_detail_id=business_detail_instance,
#         upgrade_plan_id=None,
#     )
    
#     return updated_plan

def get_renewed_plan(plans_detail, user, existing_plan):
    plan_expire_datetime = timezone.now() + timedelta(days=plans_detail['days_to_expire'])
    
    business_detail = user.business_detail

    renewed_plan = BusinessPlanHistory.objects.create(
        plan_name=plans_detail['plan_name'],
        price=plans_detail['price'],
        days_price=plans_detail['days_price'],
        currency_id=Currency.objects.get(currency_type=plans_detail['currency_type']),
        plan_expire_datetime=plan_expire_datetime,
        minutes_to_expire=plans_detail['minutes_to_expire'],
        days_to_expire=plans_detail['days_to_expire'],
        plan_validity=True,
        current_active=True,
        total_discount=plans_detail['total_discount'],
        total_tax_in_percentage=plans_detail['total_tax_in_percentage'],
        total_tax_in_currency=plans_detail['total_tax_in_currency'],
        buy_datetime=timezone.now(),
        plan_start_datetime=timezone.now(),
        plan_status=plans_detail['plan_status'],
        plan_type=plans_detail['plan_type'],
        business_detail_id=business_detail.id,
        upgrade_plan_id=None,
    )

    return renewed_plan


# def is_valid_upgrade(existing_plan, updated_plan, business_plan_history):

#     if existing_plan.plan_type != updated_plan.plan_type:
#         return False  

#     if updated_plan.price < existing_plan.price:
#         return False 

#     if updated_plan.days_to_expire < existing_plan.days_to_expire:
#         return False  

    
#     # existing_features = existing_plan.planfeaturepricingtier_set.values_list('id', flat=True)
#     # updated_features = updated_plan.planfeaturepricingtier_set.values_list('id', flat=True)
#     # if not set(existing_features).issubset(set(updated_features)):
#     #     return False  
#     # existing_features = existing_plan.plan_feature_pricing_tier_id.values_list('id', flat=True)
#     # updated_features = updated_plan.plan_feature_pricing_tier_id.values_list('id', flat=True)
#     # if not set(existing_features).issubset(set(updated_features)):
#     #     return False 
   
#     # existing_features = BusinessPricingTier.objects.filter(business_plan_history_id=existing_plan.id).values_list('id', flat=True)
#     # updated_features = BusinessPricingTier.objects.filter(business_plan_history_id=updated_plan.id).values_list('id', flat=True)

    
#     # if not set(existing_features).issubset(set(updated_features)):
#     #     return False  

#     # if updated_plan.discount_in_percentage < existing_plan.discount_in_percentage:
#     #     return False  

#     if updated_plan.discount_in_currency < existing_plan.discount_in_currency:
#         return False 
    
#     if updated_plan.total_tax_in_percentage < existing_plan.total_tax_in_percentage:
#         return False  

#     if updated_plan.total_tax_in_currency < existing_plan.total_tax_in_currency:
#         return False  

#     # existing_camera_quantity = existing_plan.businesspricetier_set.filter(category_name='Camera').first().quantity
#     # updated_camera_quantity = updated_plan.businesspricetier_set.filter(category_name='Camera').first().quantity
    
#     # existing_parking_slots = existing_plan.businesspricetier_set.filter(category_name='Parking Slot').first().quantity
#     # updated_parking_slots = updated_plan.businesspricetier_set.filter(category_name='Parking Slot').first().quantity

   
#     # if updated_camera_quantity > existing_camera_quantity or updated_parking_slots > existing_parking_slots:
#     #     return True 
#     # existing_camera_quantity = existing_plan.plan_feature_pricing_tier_id.filter(category_name='Camera').first().quantity
#     # updated_camera_quantity = updated_plan.plan_feature_pricing_tier_id.filter(category_name='Camera').first().quantity
    
#     # existing_parking_slots = existing_plan.plan_feature_pricing_tier_id.filter(category_name='Parking Slot').first().quantity
#     # updated_parking_slots = updated_plan.plan_feature_pricing_tier_id.filter(category_name='Parking Slot').first().quantity

#     # if updated_camera_quantity < existing_camera_quantity or updated_parking_slots < existing_parking_slots:
#     #     return False 
#     existing_camera_quantity = BusinessPricingTier.objects.filter(business_plan_history_id=existing_plan.id, category_name='Camera').first().quantity
#     updated_camera_quantity = BusinessPricingTier.objects.filter(business_plan_history_id=updated_plan.id, category_name='Camera').first().quantity
    
#     existing_parking_slots = BusinessPricingTier.objects.filter(business_plan_history_id=existing_plan.id, category_name='Parking Slot').first().quantity
#     updated_parking_slots = BusinessPricingTier.objects.filter(business_plan_history_id=updated_plan.id, category_name='Parking Slot').first().quantity

#     if updated_camera_quantity < existing_camera_quantity or updated_parking_slots < existing_parking_slots:
#         return False 
    
#     return True
# def extract_existing_plan_details(plans_data,product_data):
#     existing_plan_details = {}
#     for plan_data in plans_data:
        
#         #existing_plan_details['plan_type'] = plan_data.get('plan_type')
#         existing_plan_details['price'] = plan_data.get('price')
#         existing_plan_details['days_to_expire'] = plan_data.get('days_to_expire')
#         existing_plan_details['discount_in_currency'] = plan_data.get('total_discount', 0)
#         existing_plan_details['total_tax_in_percentage'] = plan_data.get('total_tax_in_percentage')
#         existing_plan_details['total_tax_in_currency'] = plan_data.get('total_tax_in_currency')
#         camera_quantity = product_data['plan_camera_detail'].get('camera_quantity', 0)
#         existing_plan_details['camera_quantity'] = camera_quantity
#         parking_slot = product_data['plan_parking_slot_detail'].get('parking_slot', 0)
#         existing_plan_details['parking_slot_quantity'] = parking_slot
        
#         break  
#     return existing_plan_details
def extract_existing_plan_details(existing_plan_id, product_data):
    existing_plan_details = {}
    
    
    existing_plan = BusinessPlanHistory.objects.filter(id=existing_plan_id).first()
    if existing_plan:
        existing_plan_details['price'] = existing_plan.price
        existing_plan_details['days_to_expire'] = existing_plan.days_to_expire
        existing_plan_details['discount_in_currency'] = existing_plan.total_discount
        existing_plan_details['total_tax_in_percentage'] = existing_plan.total_tax_in_percentage
        existing_plan_details['total_tax_in_currency'] = existing_plan.total_tax_in_currency
        existing_plan_details['plan_type'] = existing_plan.plan_type
        existing_plan_details['plan_status'] = existing_plan.plan_status
       
        # existing_parking_slots = BusinessPricingTier.objects.filter(
        #     business_plan_history_id=existing_plan.id,
        #     category_name='Parking Slot'
        # ).first()
       
        
       
    print("Existing Plan Details:", existing_plan_details) 
    return existing_plan_details

def extract_updated_plan_details(plans_data,product_data,business_plan_history):
    updated_plan_details = {}
    for plan_data in plans_data:
        
        #updated_plan_details['plan_type'] = plan_data.get('plan_type')
        updated_plan_details['price'] = business_plan_history.get('price')
        updated_plan_details['days_to_expire'] = business_plan_history.get('days_to_expire')
        updated_plan_details['discount_in_currency'] = business_plan_history.get('total_discount', 0)
        updated_plan_details['total_tax_in_percentage'] = business_plan_history.get('total_tax_in_percentage')
        updated_plan_details['total_tax_in_currency'] = business_plan_history.get('total_tax_in_currency')
        updated_plan_details['plan_type'] = business_plan_history.get('plan_type')
        updated_plan_details['plan_status'] = business_plan_history.get('plan_status')
        
       # parking_slot = product_data['plan_parking_slot_detail'].get('parking_slot', 0)
       # updated_plan_details['parking_slot_quantity'] =parking_slot
        

    print("Updated Plan Details:", updated_plan_details)
    print("plans data:", plans_data)
    #print("Product Data:", product_data)
         
    return updated_plan_details

def is_valid_upgrade(existing_plan_details, updated_plan_details):
    
    if updated_plan_details.get('plan_type') == 'Upgrade Plan':
        

        if (existing_plan_details['price'] <= updated_plan_details['price'] and
            existing_plan_details['days_to_expire'] < updated_plan_details['days_to_expire']):

                
                # if (existing_plan_details['online_dashboard_quantity'] > 0 and
                #     existing_plan_details['offline_dashboard_quantity'] > 0):

                    
                #     if (not updated_plan_details.get('updated_online_dashboard', False) and
                #         not updated_plan_details.get('updated_offline_dashboard', False)):

                #         if (updated_plan_details['updated_online_backup'] >= existing_plan_details['online_backup_quantity'] and
                #             updated_plan_details['updated_offline_backup'] >= existing_plan_details['offline_backup_quantity']):
                #             return False    
                    #return False
            return True
    elif updated_plan_details.get('plan_type') == 'Renew Plan':
       
        if existing_plan_details['plan_status'] == 'expired':
            
            # if (existing_plan_details['camera_quantity'] <= updated_plan_details['camera_quantity'] and
            #     existing_plan_details['parking_slot_quantity'] <= updated_plan_details['parking_slot_quantity']):
            #     return True
            # if (existing_plan_details['camera_quantity'] <= updated_plan_details['camera_quantity'] ):
            #     return True
    
             return True
# def is_valid_upgrade(existing_plan, updated_plan):
#     if (existing_plan['camera_quantity'] < updated_plan['camera_quantity'] or
#         existing_plan['parking_slot_quantity'] < updated_plan['parking_slot_quantity']):
        
#         if existing_plan['price'] < updated_plan['price']:
            
#             if existing_plan['days_to_expire'] > updated_plan['days_to_expire']:
               
#                 if existing_plan['discount_in_currency'] > updated_plan['discount_in_currency']:
                   
#                     if existing_plan['total_tax_in_percentage'] < updated_plan['total_tax_in_percentage']:
                       
#                         if existing_plan['total_tax_in_currency'] < updated_plan['total_tax_in_currency']:
#                             return True
#     return False
def is_valid_renewal(existing_plan, renewed_plan):

    if existing_plan.plan_type != renewed_plan.plan_type:
        return False


    if renewed_plan.price < existing_plan.price:
        return False
    
    existing_features = existing_plan.planfeaturepricingtier_set.values_list('id', flat=True)
    renewed_features = renewed_plan.planfeaturepricingtier_set.values_list('id', flat=True)
    if not set(renewed_features).issubset(set(existing_features)):
        return False

    if renewed_plan.discount_in_percentage > existing_plan.discount_in_percentage:
        return False

    if renewed_plan.discount_in_currency > existing_plan.discount_in_currency:
        return False

    if renewed_plan.total_tax_in_percentage > existing_plan.total_tax_in_percentage:
        return False

    if renewed_plan.total_tax_in_currency > existing_plan.total_tax_in_currency:
        return False
    
    return True

def update_related_models(existing_plan_id, updated_plan_details, updated_plan):

    BusinessPricingTier.objects.filter(business_plan_history_id=existing_plan_id).update(
        business_plan_history_id=updated_plan.id
    )

    BusinessPlanHistory.objects.filter(id=existing_plan_id).update(
        current_active=False,  
        plan_status='expired'  
    )

    
    BusinessTransactionHistory.objects.filter(business_plan_history_id=existing_plan_id).update(
        business_plan_history_id=updated_plan.id
    )

   
    BusinessPlanPricingTax.objects.filter(business_plan_history_id=existing_plan_id).update(
        business_plan_history_id=updated_plan.id
    )


def update_related_models_renew(existing_plan, renewed_plan):

    
    BusinessPricingTier.objects.filter(business_plan_history_id=existing_plan.id).update(
        business_plan_history_id=renewed_plan.id
    )

    
    BusinessPlanHistory.objects.filter(id=existing_plan.id).update(
        current_active=False,
        plan_status='expired'
    )

    
    BusinessTransactionHistory.objects.filter(business_plan_history_id=existing_plan.id).update(
        business_plan_history_id=renewed_plan.id
    )

    
    BusinessPlanPricingTax.objects.filter(business_plan_history_id=existing_plan.id).update(
        business_plan_history_id=renewed_plan.id
    )

def generate_order_data(request, business_plan_history):
   
        
        return_url = 'http://127.0.0.1:8000/account/payment/success/'  
        notify_url= 'http://127.0.0.1:8000/account/webhook/'
        order_amount = round(float(business_plan_history.get('price_after_tax')), 2)      
        order_id = str(uuid.uuid4())  
        DEFAULT_EXPIRATION_MINUTES = 5
        
        order_data = {
            "order_id": order_id,
            "order_amount": str(order_amount),
            "order_currency": "INR",
            "returnUrl": return_url,
            "notifyUrl": notify_url,
            "minutes_to_expire": DEFAULT_EXPIRATION_MINUTES
        }
        return order_data



def process_cashfree_payment(request, business_plan_history, email, phone_number ):
    try:
        
        company_detail_id = business_plan_history.get('company_detail_id')
        #business_detail_id = business_plan_history['business_detail_id'].id

        print("bdi", company_detail_id)
       
        company_detail = CompanyDetail.objects.get(id=company_detail_id)
        print("bd",company_detail)
    
        business_detail_uuid = str(company_detail.uuid) 
        print("bdu", business_detail_uuid)

        # user_id = request.user.id  
        # data = get_user_data_page_plans(user_id)

        # # Extract business detail UUID from the data
        # business_detail = data.get('business_detail')
        # business_detail_uuid = business_detail.get('uuid')
         
        # User = get_user_model()
        # user = User.objects.get(email=email, phone_number=phone_number)

        # # Get the UUID from the user object
        # user_uuid = str(user.uuid)

     
        app_id = 'TEST10163419a1585185134eae37cb4b91436101'
        secret_key = 'cfsk_ma_test_2f53184655f260ffb469967f5228fc3e_fe6d9072'
        Cashfree.XClientId = app_id
        Cashfree.XClientSecret = secret_key
        Cashfree.XEnvironment = Cashfree.XSandbox

        
        x_api_version = "2023-08-01"

        
        order_data = generate_order_data(request, business_plan_history)

        if phone_number.startswith('+91'):
            phone_number = phone_number[3:]

        customerDetails = CustomerDetails(
            customer_id=business_detail_uuid, 
            customer_email=email,
            customer_phone=phone_number  
        )
        
        order_amount = round(float(order_data.get('order_amount')), 2)
        order_currency = order_data.get('order_currency')
        
        if order_amount is not None and order_currency is not None:
        
                createOrderRequest = CreateOrderRequest(
                    order_amount=order_amount,
                    order_currency=order_currency,
                    customer_details=customerDetails
                )
                
                try:
                    api_response = Cashfree().PGCreateOrder(x_api_version, createOrderRequest, None, None)

                    payment_session_id = api_response.data.payment_session_id
                    print("api-response:",api_response.data)
                    return api_response.data, payment_session_id
                except Exception as e:
                    print(e)
        else:
                
                print("Error: order_amount or order_currency is missing or None")
    except Exception as e:
       
        return None, str(e)    

def process_cashfree_payment_upgrade(request, business_plan_history, email, phone_number ):
    try:
        
        #business_detail_id = business_plan_history.get('business_detail_id')
        business_detail_id = business_plan_history['company_detail_id'].id

        print("bdi", business_detail_id)
       
        company_detail = CompanyDetail.objects.get(id=business_detail_id)
        print("bd", company_detail)
    
        business_detail_uuid = str(company_detail.uuid) 
        print("bdu", business_detail_uuid)

        # user_id = request.user.id  
        # data = get_user_data_page_plans(user_id)

        # # Extract business detail UUID from the data
        # business_detail = data.get('business_detail')
        # business_detail_uuid = business_detail.get('uuid')
         
        # User = get_user_model()
        # user = User.objects.get(email=email, phone_number=phone_number)

        # # Get the UUID from the user object
        # user_uuid = str(user.uuid)

     
        app_id = 'TEST10163419a1585185134eae37cb4b91436101'
        secret_key = 'cfsk_ma_test_2f53184655f260ffb469967f5228fc3e_fe6d9072'
        Cashfree.XClientId = app_id
        Cashfree.XClientSecret = secret_key
        Cashfree.XEnvironment = Cashfree.XSandbox

        
        x_api_version = "2023-08-01"

        
        order_data = generate_order_data(request, business_plan_history)

        if phone_number.startswith('+91'):
            phone_number = phone_number[3:]

        customerDetails = CustomerDetails(
            customer_id=business_detail_uuid, 
            customer_email=email,
            customer_phone=phone_number  
        )
        
        order_amount = round(float(order_data.get('order_amount')), 2)
        order_currency = order_data.get('order_currency')
        
        if order_amount is not None and order_currency is not None:
        
                createOrderRequest = CreateOrderRequest(
                    order_amount=order_amount,
                    order_currency=order_currency,
                    customer_details=customerDetails
                )
                
                try:
                    api_response = Cashfree().PGCreateOrder(x_api_version, createOrderRequest, None, None)

                    payment_session_id = api_response.data.payment_session_id
                    print("api-response:",api_response.data)
                    return api_response.data, payment_session_id
                except Exception as e:
                    print(e)
        else:
                
                print("Error: order_amount or order_currency is missing or None")
    except Exception as e:
       
        return None, str(e)

# @csrf_exempt
# def cashfree_notify(request):
#     if request.method == 'POST':
        
#         payment_status = request.POST.get('txStatus')
#         order_id = request.POST.get('orderId')
#         payment_amount = request.POST.get('orderAmount')

       
#         if payment_status == 'SUCCESS':
            
#             Payment.objects.filter(order_id=order_id).update(status='SUCCESS')

            
#             send_mail(
#                 'Payment Confirmation',
#                 f'Your payment of {payment_amount} was successful.',
#                 'sender@example.com',
#                 ['recipient@example.com'],
#                 fail_silently=False,
#             )

           

#             return JsonResponse({'status': 'success'})
#         elif payment_status == 'CANCELLED':
         
#             Payment.objects.filter(order_id=order_id).update(status='CANCELLED')

         

#             return JsonResponse({'status': 'cancelled'})
#         else:
            
#             return JsonResponse({'status': 'other'})
#     else:
#         return JsonResponse({'error': 'Invalid request method'}, status=405)

def create_plan(business_plan_history):
    url = "https://test.cashfree.com/api/v2/subscription-plans"
    plan_id = str(uuid.uuid4())
    #plan_id=business_plan_history.get('plan_id')

    payload = {
        "planId": plan_id,
        "planName": business_plan_history.get('plan_name'),
        "type": "ON_DEMAND",  # 'PERIODIC' or 'ON_DEMAND'
        "maxAmount": business_plan_history.get('price_after_tax')
    }

    # if business_plan_history.get('plan_type') == 'PERIODIC':
    #     payload.update({
    #         "recurringAmount": business_plan_history.get('recurring_amount'),
    #         "maxCycles": business_plan_history.get('max_cycles'),
    #         "intervals": business_plan_history.get('intervals', 1),
    #         "intervalType": business_plan_history.get('interval_type')  # 'day', 'week', 'month', 'year'
    #     })

    headers = {
        'Content-Type': 'application/json',
        'X-Client-Id': 'TEST10163419a1585185134eae37cb4b91436101',
        'X-Client-Secret': 'cfsk_ma_test_2f53184655f260ffb469967f5228fc3e_fe6d9072'
    }
    
    response = requests.post(url, headers=headers, json=payload)
    response_data = response.json()
    print("PLAN CREATION RESPONSE:", response.json())

    # if response.status_code == 200:
    #     return response.json()
    # else:
    #     return {'success': False, 'message': 'Failed to create plan', 'error': response.json()}
    if response.status_code == 200 and response_data.get('status') == 'OK':
        return {'success': True, 'planId': response_data['data']['planId']}
    else:
        return {'success': False, 'message': 'Failed to create plan', 'error': response_data}





@csrf_exempt
def create_subscription(request, business_plan_history, email, phone_number):
    if request.method == 'POST':
            plan_creation_response = create_plan(business_plan_history)

            
            plan_id = plan_creation_response.get('planId')
           # business_plan_history['plan_id'] = plan_id
            print("Plan ID:", plan_id)

        # plan_creation_response = create_plan(request, business_plan_history)

        # if plan_creation_response.get('success', False):
            
        #     plan_id = plan_creation_response.get('plan_id')
        #     print(plan_id)

            url = "https://test.cashfree.com/api/v2/subscriptions/nonSeamless/subscription"

            subscription_id = str(uuid.uuid4())
            # plan_id = business_plan_history.get('plan_id')
            # print("plan id:",plan_id)
            #expires_on = business_plan_history.get('plan_expire_datetime')
            expires_on = business_plan_history.get('plan_expire_datetime')

            expires_on = expires_on.strftime('%Y-%m-%d %H:%M:%S')

            # expires_on_datetime = datetime.strptime(expires_on, "%Y-%m-%d %H:%M:%S")

            # # Format expires_on_datetime as a string in the required pattern
            # expires_on_formatted = expires_on_datetime.strftime("%Y-%m-%d %H:%M:%S")

            if phone_number.startswith('+91'):
                phone_number = phone_number[3:]

            payload = {
                "subscriptionId": subscription_id,
                "planId": plan_id,
                "customerPhone": phone_number,
                "customerEmail": email,
                "returnUrl": "www.merchant-site.com",
                #"authAmount": 1,
                "expiresOn": expires_on,
                "notificationChannels": [
                    "EMAIL",
                    "SMS"
                ]
            }
            headers = {
                'Content-Type': 'application/json',
                'X-Client-Id': 'TEST10163419a1585185134eae37cb4b91436101',
                'X-Client-Secret': 'cfsk_ma_test_2f53184655f260ffb469967f5228fc3e_fe6d9072'
            }
            response = requests.post(url, headers=headers, json=payload)
            print("SUBSCRIPTION CREATION RESPONSE:", response.json())

        

            if response.status_code == 200:

                return JsonResponse(response.json())

            #     subscription_response = response.json()
            #     print(subscription_response)
            #     auth_response = create_authorization_request(
            #         #sub_reference_id=subscription_id,
            #         sub_reference_id = subscription_response.get('subReferenceId'),
            #         merchant_txn_id=str(uuid.uuid4()),
            #         payment_type="UPI",
            #         vpa="customer@upi",  # Example VPA, replace with actual value
            #         auth_flow="UPI_COLLECT",  # Or other appropriate value for UPI flow
            #         # account_holder_name="John Doe",  # Required for E_MANDATE
            #         # account_number="1234567890",  # Required for E_MANDATE
            #         # bank_id="1234",  # Required for E_MANDATE
            #         # auth_mode="NET_BANKING",  # Required for E_MANDATE
            #         # account_type="SAVINGS",  # Required for E_MANDATE
            #         client_id='TEST10163419a1585185134eae37cb4b91436101',
            #         client_secret='cfsk_ma_test_2f53184655f260ffb469967f5228fc3e_fe6d9072'
            #     )
                
            #     if auth_response.get('status') == 'SUCCESS':
            #         return JsonResponse({'success': True, 'message': 'Subscription and authorization created successfully'})
            #     else:
            #         return JsonResponse({'success': False, 'message': 'Failed to create authorization'}, status=500)

            else:
                return JsonResponse({'success': False, 'message': 'Failed to create subscription'}, status=response.status_code)
                    # else:
                    #     print("SUBSCRIPTION CREATION FAILED:", response.content)
                    #     return JsonResponse({'success': False, 'message': 'Failed to create subscriptionn'})
                
    return JsonResponse({'success': False, 'message': 'Method not allowed'}, status=405)


def create_authorization_request(sub_reference_id, merchant_txn_id, payment_type, vpa, auth_flow,  client_id, client_secret):
    url = "https://test.cashfree.com/api/v2/subscriptions/seamless/authorization"

    payload = {
        "subReferenceId": sub_reference_id,
        "merchantTxnId": merchant_txn_id,
        "paymentType": payment_type,
        "vpa": vpa,
        "authFlow": auth_flow,
        # "accountHolderName": account_holder_name,
        # "accountNumber": account_number,
        # "bankId": bank_id,
        # "authMode": auth_mode,
        # "accountType": account_type
    }

    headers = {
        'Content-Type': 'application/json',
        'X-Client-Id': client_id,
        'X-Client-Secret': client_secret
    }

    response = requests.post(url, headers=headers, json=payload)

    return response.json()



# def create_payment_link(request, business_plan_history, email, phone_number):
#     try:
#         # Extract necessary data from business_plan_history
#         business_detail_id = business_plan_history.get('business_detail_id')
#         business_detail_uuid = str(BusinessDetail.objects.get(id=business_detail_id).uuid)
#         order_data = generate_order_data(request, business_plan_history)
#         order_amount = round(float(order_data.get('order_amount')), 2)
#         order_currency = order_data.get('order_currency')

#         # Initialize Cashfree Payouts instance
#         app_id = 'TEST10163419a1585185134eae37cb4b91436101'
#         secret_key = 'cfsk_ma_test_2f53184655f260ffb469967f5228fc3e_fe6d9072'


#         endpoint = 'https://sandbox.cashfree.com/pg/links'  # Use sandbox URL for testing

#     # Define request headers
#         request_id = str(uuid.uuid4())

# # Generate unique idempotency key
#         idempotency_key = str(uuid.uuid4())
#         # headers = {
#         #     'Content-Type': 'application/json',
#         #     'x-api-version': '2023-08-01',  # Specify API version
#         #     'x-request-id': request_id,  # Unique request ID
#         #     'x-idempotency-key': idempotency_key,  # Unique idempotency key
            
#         # }

#         # Define request body parameters
#         payload = {
#             'appId':app_id,
#             "secretKey":secret_key,
#             'link_id': 'unique_link_id',
#             'link_amount': order_amount,
#             'link_currency': order_currency,
#             'link_purpose': 'Product purchase',
#             'customer_details': {
#                 'customer_phone': phone_number,
#                 'customer_email': email,
#                 'customer_name': business_detail_uuid
#             }
#             # Add other parameters as needed based on the documentation
#         }

#         try:
#             # Make POST request to create the payment link
#             response = requests.post(endpoint, json=payload)
#             print("reponse:",response)
#             data = response.json()

#             if response.status_code == 200:
#                 # Payment link created successfully
#                 return JsonResponse(data)
#             else:
#                 # Error in creating payment link
#                 return JsonResponse({'error': data}, status=response.status_code)
#         except Exception as e:
#             # Exception occurred
#             return JsonResponse({'error': str(e)}, status=500)
#     #     CashfreePayouts.configure(app_id, secret_key, mode='TEST')

#     #     unique_id = uuid.uuid4()
#     # # Convert the UUID to string and remove hyphens
#     #     Link_id = str(unique_id).replace("-", "")

#     #     # Construct request parameters for creating payment link
#     #     link_id = Link_id
#     #     link_amount = order_amount
#     #     link_currency = order_currency
#     #     link_purpose = "Payment for your purchase"
#     #     customer_details = LinkCustomerDetailsEntity(customer_phone=phone_number, customer_email=email, customer_name=business_detail_uuid)
#     #     link_notify = LinkNotifyEntity(send_sms=True)

#     #     # Create payment link request
#     #     create_link_request = CreateLinkRequest(
#     #         link_id=link_id,
#     #         link_amount=link_amount,
#     #         link_currency=link_currency,
#     #         link_purpose=link_purpose,
#     #         customer_details=customer_details,
#     #         link_notify=link_notify
#     #     )

#     #     # Send request to Cashfree to create payment link
#     #     api_response = CashfreePayouts.create_link(create_link_request)
#     #     print("Payment link created:", api_response.data)

#     #     # Return the payment link details
#     #     return api_response.data
#     except Exception as e:
#         print("Error creating payment link:", e)
#         return None