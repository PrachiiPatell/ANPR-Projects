from account.views import *

class ApprovalChangeByNumberOfDaysView(APIView):
    permission_classes = [IsAuthenticated]

    def get_object(self):
        try:
            return ApprovalChangeByNumberOfDays.objects.all()
        except ApprovalChangeByNumberOfDays.DoesNotExist:
            raise Http404
        
    ObjectSerializer = ApprovalChangeByNumberOfDaysSerializer
    model_name = 'ApprovalChangeByNumberOfDays'


    def get(self, request, format=None):
        limit = int(request.GET.get('limit',10))
        offset = int(request.GET.get('offset',0))
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'approval_change_by_number' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['approval_change_by_number']:
                    acess_to_page = True
            if acess_to_page == True:
                sub_company_detail_id = None
                if len(get_user_data['sub_company']) > 0:
                    sub_company_detail_id = get_user_data['sub_company']['id']

                approval_queryset = ApprovalChangeByNumberOfDays.objects.filter(company_detail_id = get_user_data['company_detail']['id'],sub_company_id = sub_company_detail_id).order_by('-id').all()[offset:limit+offset]
                approval_count = ApprovalChangeByNumberOfDays.objects.filter(company_detail_id = get_user_data['company_detail']['id'],sub_company_id = sub_company_detail_id).count()


                serializer = self.ObjectSerializer(approval_queryset, many=True)
                return Response({'count':approval_count, 'results': serializer.data})
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)
                    
    def post(self, request, format=None):

        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'approval_change_by_number' in get_user_data['permission'].keys():
                if 'create' in get_user_data['permission']['approval_change_by_number']:
                    acess_to_page = True
            if acess_to_page == True:
                company_detail_id = get_user_data['company_detail']['id']
                sub_company_detail_id = None
                if len(get_user_data['sub_company']) > 0:
                    sub_company_detail_id = get_user_data['sub_company']['id']

                layer_approval = request.data['layer_of_approval']

                approval_change = {'from_days': request.data['from_days'], 'to_days': request.data['to_days'], 'layer_of_approval':layer_approval,
                                   'company_detail_id':company_detail_id, 'sub_company_id':sub_company_detail_id}
                approval_change_serializer = ApprovalChangeByNumberOfDaysSerializer(data=approval_change)

                approval_change_id = None
                if approval_change_serializer.is_valid():
                    obj = approval_change_serializer.save()
                    approval_change_id = obj.id
                else:
                    #print(approval_change_serializer.errors)
                    return Response(approval_change_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                
                created_approve_steps = 0
                accessory_approval_count = 0

                for step_data in request.data.get('layer_steps', []):
                    accessory_approval = step_data.get('accessory_approval')
                    if accessory_approval == True:
                        accessory_approval_count += 1

                if accessory_approval_count > 1:
                    # Return validation error, as accessory_approval is true for more than one row
                    #validation_error = {'error': 'Accessory approval cannot be true for more than one row.'}
                    ApprovalChangeByNumberOfDays.objects.filter(id=approval_change_id).delete()
                    return Response({"accessory_approval": "Accessory approval cannot be true for more than one row."}, status=status.HTTP_400_BAD_REQUEST)

                if accessory_approval_count == 0:
                    # Return validation error, as accessory_approval is true for more than one row
                    #validation_error = {'error': 'Accessory approval cannot be true for more than one row.'}
                    ApprovalChangeByNumberOfDays.objects.filter(id=approval_change_id).delete()
                    return Response({"accessory_approval": "Accessory approval must be true for any one row."}, status=status.HTTP_400_BAD_REQUEST)


                approve_step_id = []
                for step_data in request.data.get('layer_steps', []):
                    approve_step = {
                        'layer_step': step_data.get('layer_step'),
                        'role_id': step_data.get('role_id'),
                        'approval_change_by_number_of_days_id': approval_change_id, 
                        'accessory_approval': step_data.get('accessory_approval'),
                        'company_detail_id': company_detail_id, 
                        'sub_company_id': sub_company_detail_id
                    }

                    # if step_data.get('accessory_approval') == True:
                    #     accessory_approval_count += 1
                    #     print(accessory_approval_count)

                    # if accessory_approval_count > 1:
                    #     ApproveStepByRole.objects.filter(approval_change_by_number_of_days_id=approval_change_id).delete()
                    #     ApprovalChangeByNumberOfDays.objects.filter(id=approval_change_id).delete()
                    #     return Response({"submit": "Accessory approval cannot be true for more than one row."}, status=status.HTTP_400_BAD_REQUEST)

                    
                    approve_step_serializer = ApproveStepByRoleSerializer(data=approve_step)
                    
                    #print("serializer: ",approve_step_serializer)
                    
                    if approve_step_serializer.is_valid():
                        print("if")
                        obj = approve_step_serializer.save()
                        approve_step_id.append(obj.id)
                        created_approve_steps += 1
                    else:
                        print("else")
                        print("approve_step_id",approve_step_id)
                        for approve_id in approve_step_id:
                            ApproveStepByRole.objects.filter(id=approve_id).delete()
                        ApprovalChangeByNumberOfDays.objects.filter(id=approval_change_id).delete()

                        return Response(approve_step_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

                if created_approve_steps < layer_approval:
                    print("approve_step_id",approve_step_id)
                    for approve_id in approve_step_id:
                        ApproveStepByRole.objects.filter(id=approve_id).delete()
                    ApprovalChangeByNumberOfDays.objects.filter(id=approval_change_id).delete()
                    return Response({"submit": "You have not added all layer steps."}, status=status.HTTP_400_BAD_REQUEST)
                else:
                    return Response({"submit": "All layer has been added."},status=status.HTTP_201_CREATED)

            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


class ApprovalChangeByNumberOfDaysDetailView(APIView):
    permission_classes = [IsAuthenticated]

    def get_object(self, pk):
        try:
            return ApprovalChangeByNumberOfDays.objects.get(pk=pk)
        except ApprovalChangeByNumberOfDays.DoesNotExist:
            raise Http404
        
    ObjectSerializer = ApprovalChangeByNumberOfDaysSerializer

    def get(self, request, id):
        get_user_data = getUserDataLogin(request.user.id)
        
        if get_user_data['company_detail']['account_validity'] == True:
            acess_to_page = False
            if 'approval_change_by_number' in get_user_data['permission'].keys():
                if 'view' in get_user_data['permission']['approval_change_by_number']:
                    acess_to_page = True
            if acess_to_page == True:
                print(r'get details of id: ', id)
                company_detail_id = request.user.company_detail_id
                sub_company_id = request.user.sub_company_id
                #queryset = self.get_object(pk=id)
                queryset = ApprovalChangeByNumberOfDays.objects.filter(pk=id,
                                                                    company_detail_id=company_detail_id, sub_company_id=sub_company_id).first()
                serializer = ApprovalChangeByNumberOfDaysSerializer(queryset)
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)


    def put(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)

        if get_user_data['company_detail']['account_validity'] == True:
            access_to_page = False
            if 'approval_change_by_number' in get_user_data['permission'].keys():
                if 'update' in get_user_data['permission']['approval_change_by_number']:
                    access_to_page = True
            if access_to_page == True:
                try:
                    approval_change = ApprovalChangeByNumberOfDays.objects.get(pk=id)
                except ApprovalChangeByNumberOfDays.DoesNotExist:
                    return Response(
                        {"submit": "Approval Change not found."}, status=status.HTTP_404_NOT_FOUND)

                sub_company_detail_id = None
                if len(get_user_data['sub_company']) > 0:
                    sub_company_detail_id = get_user_data['sub_company']['id']
                    

                data = request.data
                data['company_detail_id'] = get_user_data['company_detail']['id']
                data['sub_company_id'] = sub_company_detail_id

                existed_layer = ApprovalChangeByNumberOfDays.objects.filter(pk=id).first()

                approval_change_serializer = ApprovalChangeByNumberOfDaysSerializer(
                    approval_change, data=data, partial=True
                )

                if approval_change_serializer.is_valid():
                    approval_change_serializer.save()

                    # Delete unused steps
                    layer_of_approval = data.get('layer_of_approval')
                    
                    print(layer_of_approval)
                    print(existed_layer.layer_of_approval)
                    if layer_of_approval < existed_layer.layer_of_approval:
                        unused_step_ids = [step['id'] for step in request.data.get('layer_steps', []) if 'id' in step]
                        deleted_steps = ApproveStepByRole.objects.filter(approval_change_by_number_of_days_id=id).exclude(id__in=unused_step_ids)
                        deleted_steps.delete()

                    created_approve_steps = 0
                    # Update associated ApproveStepByRole instances
                    for step_data in request.data.get('layer_steps', []):
                        step_id = step_data.get('id')  # Get the id of the existing step
                        role_id = step_data.get('role_id')
                        accessory_approval = step_data.get('accessory_approval')
                        
                        
                        print("steo_id", step_id)

                        if step_id:  # If step already exists, update it

                            company_instance = CompanyDetail.objects.get(pk=get_user_data['company_detail']['id'])
                            sub_company_instnace = None
                            if sub_company_detail_id:
                                sub_company_instnace = SubCompany.objects.get(pk=sub_company_detail_id)

                            role_instance = Roles.objects.get(pk=role_id)
                            approve_step = ApproveStepByRole.objects.get(pk=step_id)

                            step_data['approval_change_by_number_of_days_id'] = approval_change.id
                            step_data['company_detail_id'] = company_instance.id

                            step_data['sub_company_id'] = sub_company_instnace


                            approve_step.role_id = role_instance
                            approve_step.accessory_approval = accessory_approval
                            

                            approve_step_serializer = ApproveStepByRoleSerializer(
                                approve_step, data=step_data, partial=True
                            )
                            

                            if approve_step_serializer.is_valid():
                                approve_step_serializer.save()
                                print(approve_step_serializer.data)
                                created_approve_steps += 1
                            else:
                                print(approve_step_serializer.errors)
                                return Response(approve_step_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

                        else:
                             print("step_id", step_id)
                             company_instance = CompanyDetail.objects.get(pk=get_user_data['company_detail']['id'])
                             sub_company_instnace = None
                             if sub_company_detail_id:
                                 sub_company_instnace = SubCompany.objects.get(pk=sub_company_detail_id)
                             approval_chnage_id = ApprovalChangeByNumberOfDays.objects.get(pk=approval_change.id)
                             role_instance = Roles.objects.get(pk=step_data.get('role_id'))

                             print("role", role_instance)
                             print(step_data.get('layer_step'))
                             approve_step_data = {
                                    'layer_step':step_data.get('layer_step'),
                                    'role_id':step_data.get('role_id'),  # Assign the Roles instance
                                    'accessory_approval':accessory_approval,
                                    'approval_change_by_number_of_days_id':approval_chnage_id.id,
                                    'company_detail_id':company_instance.id,
                                    'sub_company_id':sub_company_instnace
                             }
                             print(approve_step_data)
                             
                             approve_step_serializer = ApproveStepByRoleSerializer(data=approve_step_data)
                            
                            
                             if approve_step_serializer.is_valid():
                                approve_step_serializer.save()
                                created_approve_steps += 1
                             else:
                                print(approve_step_serializer.errors)
                                return Response(approve_step_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

                   
                                
                    # Check if layer_of_approval is not equal to the number of layer_steps
                    #layer_steps = request.data.get('layer_steps', [])
                    if layer_of_approval != created_approve_steps:
                        return Response(
                            {"submit": "You have not added all layer steps."}, status=status.HTTP_400_BAD_REQUEST)


                    return Response(
                        {"submit": "All layer has been updated."}, status=status.HTTP_200_OK)
                else:
                    return Response(
                        approval_change_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

            else:
                return Response(
                    {"submit": "You don't have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response(
                {"submit": "Account Validity has expired."}, status=status.HTTP_400_BAD_REQUEST)


        
    def delete(self, request, id, format=None):
        get_user_data = getUserDataLogin(request.user.id)

        if get_user_data['company_detail']['account_validity'] == True:
            access_to_page = False
            if 'approval_change_by_number' in get_user_data['permission'].keys():
                if 'delete' in get_user_data['permission']['approval_change_by_number']:
                    access_to_page = True
            if access_to_page == True:
                company_detail_id = request.user.company_detail_id
                sub_company_id = request.user.sub_company_id
                try:
                    approval_change = ApprovalChangeByNumberOfDays.objects.filter(pk=id,company_detail_id=company_detail_id, sub_company_id=sub_company_id).first()

                    # Delete associated ApproveStepByRole instances
                    ApproveStepByRole.objects.filter(
                        approval_change_by_number_of_days_id=id
                    ).delete()

                    approval_change.delete()
                    return Response(
                        {"submit": "Approval Change deleted successfully."},status=status.HTTP_204_NO_CONTENT)
            
                except Exception as e:
                    return Response({"submit": "Cannot delete. This object is used by Approval."}, status=status.HTTP_400_BAD_REQUEST)
                
            else:
                return Response({"submit": "You don`t have permissions to access."}, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({"submit": "Account Validity are expire."}, status=status.HTTP_400_BAD_REQUEST)

                


