from django.contrib import admin

from visitorapp.models import IdProofType
from .models import ApprovalType, ApprovalLayer, PassExtensionChangeApprovalRole, ApproveStepByRole

from .models import *
from .models import DefaultAccessoryProvidedByCompany, Accessory
from .models import AddUserEmail, OTP


# Register account app models

admin.site.register(OTP)
admin.site.register(Currency)
admin.site.register(CompanyDetail)
admin.site.register(SubCompany)
admin.site.register(User)
admin.site.register(AddUserEmail)

admin.site.register(Roles)
admin.site.register(UserRoleMapping)
admin.site.register(UserType)
admin.site.register(MenuPage)
admin.site.register(Action)
admin.site.register(MenuActionMap)
admin.site.register(Permission)

#
admin.site.register(DefaultAccessoryProvidedByCompany)
admin.site.register(Accessory)


#
admin.site.register(ApprovalType)
admin.site.register(ApprovalLayer)
admin.site.register(PassExtensionChangeApprovalRole)
admin.site.register(ApproveStepByRole)



admin.site.register(SubCompanyMenuActionMap)

admin.site.register(DefaultProduct)
admin.site.register(DefaultProductFeature)
admin.site.register(Days)
admin.site.register(PlanFeaturesPricingCategory)
admin.site.register(Plans)
admin.site.register(CountryCategory)
admin.site.register(PlanPricing)
admin.site.register(TaxPercentageDetail)
admin.site.register(PlanDescription)
admin.site.register(PlanDaysAndDiscount)
admin.site.register(PlanPricingTax)
admin.site.register(PlanFeaturePricingTier)
admin.site.register(PlanFeatureDaysPrice)
admin.site.register(Coupon)
admin.site.register(BusinessPlanHistory)
admin.site.register(BusinessPlanPricingTax)
admin.site.register(BusinessPlanCoupon)
admin.site.register(BusinessPricingTier)
admin.site.register(BusinessTransactionHistory)
admin.site.register(Schedule)
admin.site.register(IdProofType)
admin.site.register(ApprovalChangeByNumberOfDays)













