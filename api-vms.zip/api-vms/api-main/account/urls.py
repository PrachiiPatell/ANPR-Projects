from django.urls import path
from account import views
from rest_framework.urlpatterns import format_suffix_patterns
from account import approve_step

urlpatterns = [
    # path('admin/', admin.site.urls),

    # class base

    path('AddCompany/', views.AddCompany.as_view()),

    path('SubCompanyList/', views.SubCompanyList.as_view()),
    path('SubCompanyDetail/<int:id>', views.SubCompanyDetail.as_view()),

    # path('VisitorList/', views.VisitorList.as_view()),
    # path('VisitorDetail/<int:id>', views.VisitorDetail.as_view()),

    # path('VisitorDetailList/', views.VisitorDetailList.as_view()),
    # path('VisitorDetailDetail/<int:id>', views.VisitorDetailDetail.as_view()),

    path('DefaultAccessoryProvidedByCompanyList/', views.DefaultAccessoryProvidedByCompanyList.as_view()),
    path('DefaultAccessoryProvidedByCompanyDetail/<int:id>', views.DefaultAccessoryProvidedByCompanyDetail.as_view()),

    path('AccessoryList/', views.AccessoryList.as_view()),
    path('AccessoryDetail/<int:id>', views.AccessoryDetail.as_view()),

    path('ApprovalTypeList/', views.ApprovalTypeList.as_view()),
    path('ApprovalTypeDetail/<int:id>', views.ApprovalTypeDetail.as_view()),

    path('ApprovalLayerList/', views.ApprovalLayerList.as_view()),
    path('ApprovalLayerDetail/<int:id>', views.ApprovalLayerDetail.as_view()),

    path('PassExtensionChangeApprovalRoleList/', views.PassExtensionChangeApprovalRoleList.as_view()),
    path('PassExtensionChangeApprovalRoleDetail/<int:id>', views.PassExtensionChangeApprovalRoleDetail.as_view()),

    path('GetUserDetail/', views.GetUserDetail.as_view()),  

    # user specific

    # path('visitor_login_logs/', views.VisitorLoginLogs.as_view()),

    # path('ApprovalPage/', views.ApprovalPage.as_view()),
    #
    # path('ApprovalPageGet/', views.ApprovalPageGet.as_view()),
    # path('ApprovalPageGet/<int:id>', views.ApprovalPageGet.as_view()),

    path('company_dropdown/', views.CompanyListView.as_view()),

    path('roles_dropdown/', views.RoleListView.as_view()),

    # configuration

    path('fine_collected_by/', views.FineCollectedByView.as_view()),
    path('fine_collected_by_detail/<int:id>', views.FineCollectedByDetailView.as_view()),

    path('approval_change_by_number_of_days/', views.ApprovalChangeByNumberOfDaysView.as_view()),
    path('approval_change_by_number_of_days_detail/<int:id>', views.ApprovalChangeByNumberOfDaysDetailView.as_view()),

    path('approve_step_by_role/<int:pk>', views.ApproveStepByRoleView.as_view()),
    path('approve_step_by_role_post/', views.ApproveStepByRolePostView.as_view()),
    path('approve_step_by_role_detail/<int:id>', views.ApproveStepByRoleDetailView.as_view()),

    # path('VisitorRequestDetail/', views.VisitorRequestDetail.as_view()),
    # path('VisitorRequestDetail/<int:id>/', views.VisitorRequestDetail.as_view()),

    # path('VisitorRequestAccessoriesAPIView/', views.VisitorRequestAccessoriesAPIView.as_view()),

    # path('visitor_request_by_self_detail/', views.VisitorRequestWithAccessoriesAPIView.as_view()),

    path('get_user_detail/', views.GetUserDetail.as_view()),

    path('sub_company_dropdown/', views.SubCompanyListView.as_view()),

    path('user_dropdown/', views.UserListView.as_view()),

    path('SubCompanyMenuActionMapView/', views.SubCompanyMenuActionMapView.as_view()),
    path('SubCompanyMenuActionMapDetailView/<int:id>', views.SubCompanyMenuActionMapDetailView.as_view()),

    path('roles_and_permissions/', views.RolesAndPermissionView.as_view()),
    path('roles_and_permissions_detail/<int:id>', views.RolesAndPermissionDetailView.as_view()),

    path('get_roles_and_permissions/', views.GetRolesAndPermissionView.as_view()),

    path('default_accessory_by_company_dropdown/', views.DefaultAccessoryProvidedByCompanyListView.as_view()),

    path('fine_collected_dropdown/', views.FineCollectedByListView.as_view()),

    path('approval_change_by_number_of_days_dropdown/', views.ApprovalChangeByNumberOfDaysListView.as_view()),

    path('approval_change_by_number_of_days_new/', approve_step.ApprovalChangeByNumberOfDaysView.as_view()),
    path('approval_change_by_number_of_days_new_detail/<int:id>', approve_step.ApprovalChangeByNumberOfDaysDetailView.as_view()),

    path('sub_company_dropdown/<int:id>', views.SubCompanyListViewDetail.as_view()),

    path('send_otp/', views.SendOTP.as_view()),

    path('verify_otp/', views.VerifyOTP.as_view()),
    path('free-trial/', views.FreeTrailView.as_view(), name='free_trial_view'),
    path('buy-plan/', views.BuyPlanView.as_view(), name='buy_plan_view'),
    path('buy-plan/<int:id>/', views.BuyPlanView.as_view(), name='update_resource'),
    path('get-buyplan-detail/<int:id>/',views.GetBuyPlanDetail.as_view()),
    path('upgrade-plan/', views.UpgradePlanView.as_view(), name='upgrade_plan_view'),
    path('upgrade-plan/<int:id>/', views.UpgradePlanView.as_view()),
    path('get-upgradeplan-detail/<int:existing_plan_id>/',views.GetUpgradePlanDetail.as_view()),
    path('renew-plan/', views.RenewPlanView.as_view(), name='renew_plan_view'),
    path('renew-plan/<int:id>/', views.RenewPlanView.as_view()),
    path('get-plan-detail/<int:id>/',views.GetPlanDetail.as_view()),
    path('webhook/', views.CashfreeWebhookView.as_view(), name='cashfree_webhook'),
]
#urlpatterns = format_suffix_patterns(urlpatterns)

