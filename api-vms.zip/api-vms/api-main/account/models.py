from django.db import models
import uuid
from django.contrib.auth.models import (
    BaseUserManager, AbstractBaseUser, AbstractUser, PermissionsMixin
)
import django
from django.core.validators import RegexValidator
from django.utils import timezone
timezone.now



class AccountManager(BaseUserManager):
    use_in_migrations = True

    def _create_user(self, email, password, **extra_fields):
        values = [email]
        field_value_map = dict(zip(self.model.REQUIRED_FIELDS, values))
        for field_name, value in field_value_map.items():
            if not value:
                raise ValueError('The {} value must be set'.format(field_name))

        email = self.normalize_email(email)
        user = self.model(
            email=email,
            **extra_fields
        )
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_user(self, email, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', False)
        extra_fields.setdefault('is_superuser', False)
        return self._create_user(email, password, **extra_fields)

    def create_superuser(self, email, password=None, **extra_fields):
        extra_fields.setdefault('is_active', True)
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)

        if extra_fields.get('is_staff') is not True:
            raise ValueError('Superuser must have is_staff=True.')
        if extra_fields.get('is_superuser') is not True:
            raise ValueError('Superuser must have is_superuser=True.')

        return self._create_user(email, password, **extra_fields)


class Currency(models.Model):
    currency_type = models.CharField(max_length=17)
    currency_symbol = models.CharField(max_length=5)


class CompanyDetail(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    company_name = models.CharField(max_length=30)
    company_type = models.CharField(max_length=17)
    # company_logo = models.CharField(max_length=17, blank=True, null=True)
    company_logo = models.TextField(blank=True, null=True)
    country = models.CharField(max_length=17)
    uses_type = models.CharField(max_length=17)
    start_date_time = models.DateTimeField()
    end_date_time = models.DateTimeField()
    account_validity = models.BooleanField()
    accessory_provide = models.BooleanField()
    currency_id = models.ForeignKey(Currency, on_delete=models.PROTECT, related_name="currency",
                                    blank=True, null=True)
    days_to_expire = models.IntegerField()


class SubCompany(models.Model):
    sub_company_name = models.CharField(max_length=17)
    company_email = models.EmailField()
    company_detail_id = models.ForeignKey(CompanyDetail, on_delete=models.PROTECT)


class User(AbstractBaseUser, PermissionsMixin):
    email = models.EmailField(verbose_name='email address', max_length=255, unique=True, )

    company_detail_id = models.ForeignKey(CompanyDetail, on_delete=models.PROTECT, related_name="company_detail",
                                          blank=True, null=True)
    user_login_or_not = models.BooleanField(default=False)
    time_zone = models.CharField(max_length=17)
    is_active = models.BooleanField()
    is_staff = models.BooleanField()
    is_superuser = models.BooleanField()
    sub_company_id = models.ForeignKey(SubCompany, on_delete=models.PROTECT, blank=True, null=True,
                                       related_name="sub_company")
    user_type = models.CharField(max_length=17)
    is_verified = models.BooleanField(default=False)
    phone_regex = RegexValidator(regex=r'^\+?1?\d{11,15}$', message="Phone number must be entered in the format: '+919999999999'. Up to 15 digits allowed.")
    phone_number = models.CharField(validators=[phone_regex], max_length=17, blank=True)
    USERNAME_FIELD = 'email'
    # REQUIRED_FIELDS = ['company_detail_id']  # Email & Password are required by default.
    objects = AccountManager()


class Roles(models.Model):
    role_name = models.CharField(max_length=17)
    company_detail_id = models.ForeignKey(CompanyDetail, on_delete=models.PROTECT)
    sub_company_id = models.ForeignKey(SubCompany, on_delete=models.PROTECT, blank=True, null=True)
    action_perform  = models.BooleanField(default=True)


class AddUserEmail(models.Model):
    email = models.EmailField(verbose_name='email address', max_length=255)
    role_id = models.ForeignKey(Roles, on_delete=models.PROTECT, related_name="role")
    company_detail_id = models.ForeignKey(CompanyDetail, on_delete=models.PROTECT)
    sub_company_id = models.ForeignKey(SubCompany, on_delete=models.PROTECT, blank=True, null=True)


#
class UserRoleMapping(models.Model):
    user_id = models.ForeignKey(User, on_delete=models.PROTECT, related_name="user")
    role_id = models.ForeignKey(Roles, on_delete=models.PROTECT)


class UserType(models.Model):
    is_menu_visible = models.CharField(max_length=17)


class MenuPage(models.Model):
    menu_name = models.CharField(max_length=25)
    is_menu_type_id = models.ForeignKey(UserType, on_delete=models.PROTECT, related_name="is_menu_type")


class Action(models.Model):
    action_name = models.CharField(max_length=17)


class MenuActionMap(models.Model):
    menu_page_id = models.ForeignKey(MenuPage, on_delete=models.PROTECT, related_name="menu_page")
    action_id = models.ForeignKey(Action, on_delete=models.PROTECT, related_name="action")
    role_type = models.CharField(max_length=30, default='Admin')

class MenuActionMapVisitor(models.Model):
    menu_page_id = models.ForeignKey(MenuPage, on_delete=models.PROTECT)
    action_id = models.ForeignKey(Action, on_delete=models.PROTECT)

class Permission(models.Model):
    role_id = models.ForeignKey(Roles, on_delete=models.PROTECT)
    menu_page_id = models.ForeignKey(MenuPage, on_delete=models.PROTECT)
    action_id = models.ForeignKey(Action, on_delete=models.PROTECT)
    allowed = models.BooleanField(default=True)



class DefaultAccessoryProvidedByCompany(models.Model):
    accessory_name = models.CharField(max_length=17)
    company_detail_id = models.ForeignKey(CompanyDetail, on_delete=models.PROTECT)
    sub_company_id = models.ForeignKey(SubCompany, on_delete=models.PROTECT, blank=True, null=True)
    fines_charges = models.IntegerField()
    soft_delete = models.BooleanField(default=False)


# class DefaultAccessoryHave(models.Model):
#     accessory_name = models.CharField(max_length=17)
#     company_detail_id = models.ForeignKey(CompanyDetail, on_delete=models.PROTECT)
#     sub_company_id = models.ForeignKey(SubCompany, on_delete=models.PROTECT, blank=True, null=True)


# configurations
class FineCollectedBy(models.Model):
    role_id = models.ForeignKey(Roles, on_delete=models.PROTECT)
    company_detail_id = models.ForeignKey(CompanyDetail, on_delete=models.PROTECT)
    sub_company_id = models.ForeignKey(SubCompany, on_delete=models.PROTECT, null=True, blank=True)


class ApprovalLayer(models.Model):
    max_layer_of_approval = models.IntegerField()
    company_detail_id = models.ForeignKey(CompanyDetail, on_delete=models.PROTECT)
    sub_company_id = models.ForeignKey(SubCompany, on_delete=models.PROTECT, null=True, blank=True)


class ApprovalChangeByNumberOfDays(models.Model):
    from_days = models.IntegerField()
    to_days = models.IntegerField()
    layer_of_approval = models.IntegerField()
    company_detail_id = models.ForeignKey(CompanyDetail, on_delete=models.PROTECT)
    sub_company_id = models.ForeignKey(SubCompany, on_delete=models.PROTECT, null=True, blank=True)


class ApproveStepByRole(models.Model):
    layer_step = models.IntegerField()
    role_id = models.ForeignKey(Roles, on_delete=models.PROTECT)
    company_detail_id = models.ForeignKey(CompanyDetail, on_delete=models.PROTECT)
    sub_company_id = models.ForeignKey(SubCompany, on_delete=models.PROTECT, null=True, blank=True)
    approval_change_by_number_of_days_id = models.ForeignKey(ApprovalChangeByNumberOfDays, on_delete=models.PROTECT)
    accessory_approval = models.BooleanField(default=False)


class ApprovalType(models.Model):
    approval_name = models.CharField(max_length=50)
    company_detail_id = models.ForeignKey(CompanyDetail, on_delete=models.PROTECT)
    default_approval = models.BooleanField(default=False)


class Accessory(models.Model):
    accessory_name = models.CharField(max_length=50)
    company_detail_id = models.ForeignKey(CompanyDetail, on_delete=models.PROTECT)
    sub_company_id = models.ForeignKey(SubCompany, on_delete=models.PROTECT, blank=True, null=True)




class PassExtensionChangeApprovalRole(models.Model):
    company_detail_id = models.ForeignKey(CompanyDetail, on_delete=models.PROTECT)
    pass_extension_day = models.IntegerField()



class SubCompanyMenuActionMap(models.Model):
    menu_page_id = models.ForeignKey(MenuPage, on_delete=models.PROTECT)
    action_id = models.ForeignKey(Action, on_delete=models.PROTECT)


class OTP(models.Model):
    user =models.ForeignKey(User, on_delete=models.PROTECT)
    email = models.EmailField(verbose_name='email address', max_length=255)
    is_verified = models.BooleanField(default=False)
    otp = models.CharField(max_length=6)
    otp_validity = models.DateTimeField()

class DefaultProduct(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    product_name = models.CharField(max_length=30)

##Dfault Enter Manually
class DefaultProductFeature(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    feature = models.CharField(max_length=50)
    default_product = models.ForeignKey(DefaultProduct,on_delete=models.CASCADE)
    parent_feature = models.ForeignKey('self', on_delete=models.CASCADE, null=True, blank=True, related_name='children')

##Dfault Enter Manually
class Days(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    days = models.IntegerField()
    category = models.CharField(max_length=50)



class PlanFeaturesPricingCategory(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    category_name = models.CharField(max_length=50)

class Plans(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    plan_name = models.CharField(max_length=30)

class CountryCategory(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    country = models.CharField(max_length=30)

class PlanPricing(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    basic_price = models.FloatField()
    basic_price_after_discount = models.FloatField()
    basic_price_after_tax = models.FloatField()
    days_price = models.FloatField()
    days_price_after_discount = models.FloatField()
    days_price_after_tax = models.FloatField()
    currency_id = models.ForeignKey(Currency,on_delete=models.CASCADE)
    country_type_id = models.ForeignKey(CountryCategory,on_delete=models.CASCADE)
    plan_id = models.ForeignKey(Plans,on_delete=models.CASCADE)
    # plan_days_and_discount = models.ForeignKey(PlanDaysAndDiscount,on_delete=models.CASCADE)
    # discount_percentage = models.FloatField()
    # discount_in_currency = models.FloatField()

class TaxPercentageDetail(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    tax_percentage = models.FloatField(default=0.0)
    tax_type = models.CharField(max_length=20)
    country_category = models.ForeignKey(CountryCategory,on_delete=models.CASCADE)

class PlanDescription(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    plan_description = models.TextField()
    plan_id = models.ForeignKey(Plans,on_delete=models.CASCADE)


class PlanDaysAndDiscount(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    plan_days = models.IntegerField()
    discount_percentage = models.FloatField(default=0.0)
    category = models.CharField(max_length=50)
    default_select = models.BooleanField(default=False)
    plan_id = models.ForeignKey(Plans,on_delete=models.CASCADE)
    plan_pricing_id = models.ForeignKey(PlanPricing,on_delete=models.CASCADE)

class PlanPricingTax(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    plan_pricing_id = models.ForeignKey(PlanPricing,on_delete=models.CASCADE)
    tax_percentage_detail_id = models.ForeignKey(TaxPercentageDetail,on_delete=models.CASCADE)
    tax_amount = models.FloatField()
    currency_id = models.ForeignKey(Currency,on_delete=models.CASCADE)


# class PlanDaysPricingBasedOnCurrency(models.Model):
##Dfault Enter Manually
class PlanFeaturePricingTier(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    min_quantity = models.IntegerField(blank=True, null=True)
    max_quantity = models.IntegerField(blank=True, null=True)
    default_quantity = models.IntegerField(blank=True, null=True)
    default_product_id = models.ForeignKey(DefaultProduct,on_delete=models.CASCADE, blank=True, null=True)
    default_product_feature_id = models.ForeignKey(DefaultProductFeature,on_delete=models.CASCADE, blank=True, null=True)
    pricing_feature_category_id = models.ForeignKey(PlanFeaturesPricingCategory,on_delete=models.CASCADE)
    plan_id = models.ForeignKey(Plans,on_delete=models.CASCADE)
    # default_selected = models.BooleanField(default=False)
    plan_pricing_description = models.TextField()
    show_plan_pricing = models.BooleanField(default=False)
    is_encluded_plan_feature_id = models.ForeignKey('self',on_delete=models.CASCADE, blank=True, null=True)

class PlanFeatureDaysPrice(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    backup_days_id = models.ForeignKey(Days,on_delete=models.CASCADE, blank=True, null=True)
    plan_days_and_discount_id = models.ForeignKey(PlanDaysAndDiscount,on_delete=models.CASCADE,blank=True, null=True)
    days_price = models.FloatField()
    currency_id = models.ForeignKey(Currency,on_delete=models.CASCADE)
    plan_feature_pricing_tier_id = models.ForeignKey(PlanFeaturePricingTier,on_delete=models.CASCADE)
    plans_id = models.ForeignKey(Plans,on_delete=models.CASCADE)
    default_selected = models.BooleanField(default=False)

class Coupon(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    code = models.CharField(max_length=100)
    description = models.CharField(max_length=500)
    discount_type = models.CharField(max_length=30)
    discount_value = models.FloatField()
    currency_id = models.ForeignKey(Currency,on_delete=models.CASCADE)
    country_category_id = models.ForeignKey(CountryCategory,on_delete=models.CASCADE)
    plan_buy_days = models.IntegerField(default=30)
    coupon_expiry_datetime = models.DateTimeField()
    is_active = models.BooleanField(default=True)
    user_valid_for_coupon = models.IntegerField(default=10)

class BusinessPlanHistory(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    plan_name = models.CharField(max_length=30)
    price = models.FloatField()
    price_after_discount = models.FloatField()
    price_after_tax = models.FloatField()
    days_price = models.FloatField()
    days_price_after_discount = models.FloatField()
    days_price_after_tax = models.FloatField()
    currency_id = models.ForeignKey(Currency,on_delete=models.CASCADE)
    currency_type = models.CharField(max_length=30)
    currency_symbol = models.CharField(max_length=10)
    country_category_id = models.ForeignKey(CountryCategory,on_delete=models.CASCADE)
    country_type = models.CharField(max_length=30)
    plan_id = models.ForeignKey(Plans,on_delete=models.CASCADE)
    plan_days_and_discount_id = models.ForeignKey(PlanDaysAndDiscount,on_delete=models.CASCADE)
    plan_days = models.IntegerField()
    discount_in_percentage = models.FloatField(default=0.0)
    discount_in_currency = models.FloatField(default=0.0)
    total_discount = models.FloatField()
    total_tax_in_percentage = models.FloatField()
    total_tax_in_currency = models.FloatField()
    # buy_datetime = models.DateTimeField(default=django.utils.timezone.now)
    # plan_start_datetime = models.DateTimeField(default=django.utils.timezone.now)
    # plan_expire_datetime = models.DateTimeField()
    buy_datetime = models.DateTimeField(auto_now_add=True)
    plan_start_datetime = models.DateTimeField(auto_now_add=True)
    plan_expire_datetime = models.DateTimeField()
    minutes_to_expire = models.IntegerField()
    days_to_expire = models.IntegerField()
    plan_validity = models.BooleanField()
    current_active = models.BooleanField()
    plan_status = models.CharField(max_length=30)##active,pending,expire
    plan_type = models.CharField(max_length=30) ##Upgrade,Renew,BuyPlan,Free trail
    company_detail_id = models.ForeignKey(CompanyDetail,on_delete=models.CASCADE)
    upgrade_plan_id = models.ForeignKey('self',on_delete=models.CASCADE, blank=True, null=True)
    payment_status = models.BooleanField(default=False)
   
    def save(self, *args, **kwargs):
        if not self.plan_expire_datetime.tzinfo:
            self.plan_expire_datetime = timezone.make_aware(self.plan_expire_datetime, timezone=timezone.get_current_timezone())
        
        super().save(*args, **kwargs)

class BusinessPlanPricingTax(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    business_plan_history_id = models.ForeignKey(BusinessPlanHistory,on_delete=models.CASCADE)
    tax_percentage_detail_id = models.ForeignKey(TaxPercentageDetail,on_delete=models.CASCADE)
    tax_type = models.CharField(max_length=30)
    tax_percentage = models.FloatField()
    tax_amount = models.FloatField()
    company_detail_id = models.ForeignKey(CompanyDetail,on_delete=models.CASCADE)

class BusinessPlanCoupon(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    coupon_code = models.CharField(max_length=100)
    description = models.CharField(max_length=500)
    discount_type = models.CharField(max_length=30)
    discount_value = models.FloatField()
    coupon_id = models.ForeignKey(Coupon,on_delete=models.CASCADE)
    total_coupon_amount = models.FloatField()
    business_plan_history_id = models.ForeignKey(BusinessPlanHistory,on_delete=models.CASCADE)
    company_detail_id = models.ForeignKey(CompanyDetail,on_delete=models.CASCADE)

class BusinessPricingTier(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    backup_days_id = models.ForeignKey(Days,on_delete=models.CASCADE, blank=True, null=True)
    backup_days = models.IntegerField(blank=True,null=True)
    quantity = models.IntegerField(blank=True,null=True)
    price = models.FloatField()
    days_price = models.FloatField()
    currency_id = models.ForeignKey(Currency,on_delete=models.CASCADE)
    default_product_id = models.ForeignKey(DefaultProduct,on_delete=models.CASCADE, blank=True, null=True)
    default_product_feature_id = models.ForeignKey(DefaultProductFeature,on_delete=models.CASCADE, blank=True, null=True)
    plan_feature_pricing_category_id = models.ForeignKey(PlanFeaturesPricingCategory,on_delete=models.CASCADE)
    category_name = models.CharField(max_length=30)
    plan_id = models.ForeignKey(Plans,on_delete=models.CASCADE)
    business_plan_history_id = models.ForeignKey(BusinessPlanHistory,on_delete=models.CASCADE)
    plan_feature_pricing_tier_id = models.ForeignKey(PlanFeaturePricingTier,on_delete=models.CASCADE)
    company_detail_id= models.ForeignKey(CompanyDetail,on_delete=models.CASCADE)
    plan_pricing_description = models.TextField()

class BusinessTransactionHistory(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    amout_paid = models.FloatField()
    currency_id = models.ForeignKey(Currency,on_delete=models.CASCADE)
    currency_type = models.CharField(max_length=30)
    currency_symbol = models.CharField(max_length=10)
    date_and_time = models.DateTimeField(default=django.utils.timezone.now)
    company_detail_id= models.ForeignKey(CompanyDetail,on_delete=models.CASCADE)
    business_plan_history_id = models.ForeignKey(BusinessPlanHistory,on_delete=models.CASCADE)
    #payment_status = models.BooleanField(default=False)

class Schedule(models.Model):
    uuid = models.UUIDField(default = uuid.uuid4,editable = False)
    days= models.IntegerField()
    type= models.CharField(max_length=30)