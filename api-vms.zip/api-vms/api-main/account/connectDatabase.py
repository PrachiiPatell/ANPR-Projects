import psycopg2


def get_data(model_name, limit, offset):
    print('model name is', model_name)
    con = psycopg2.connect(database="VMS", user="postgres", password="1234", host="127.0.0.1", port="5432")
    cur = con.cursor()
    # cur.execute(f"SELECT * FROM account_companydetail LIMIT {limit} OFFSET {offset}")
    cur.execute(f"SELECT * FROM {model_name} LIMIT {limit} OFFSET {offset}")
    rows = cur.fetchall()
    # print(rows)
    # print(len(rows))
    # cur.execute(f"SELECT column_name FROM information_schema.columns WHERE table_name = 'account_companydetail'")
    # column=cur.fetchall()
    # column_name=[]
    # print(column)
    # for col in column:
    #     if col[0]!='id1':
    #         column_name.append(col[0])
    # print(column_name)

    out = []
    # sql = '''SELECT * FROM account_companydetail'''
    sql = f"SELECT * FROM {model_name} ORDER BY id DESC"
    cur.execute(sql)
    # print(cur.fetchall())
    column_names = [desc[0] for desc in cur.description]
    # for i in column_names:
    #     print(i)
    for row in rows:
        r = {}
        for a in range(len(column_names)):
            r[column_names[a]] = row[a]
        out.append(r)
    # print(out)

    # add count
    # count = CompanyDetail.objects.count()
    cur.execute(f"SELECT COUNT(*) FROM {model_name} ORDER BY id DESC")
    # SELECT COUNT(*) FROM public.account_companydetail
    count = cur.fetchall()
    # print("emp",emp)
    # print("emp1", emp1)
    peg = {}
    peg['count'] = count[0][0]
    peg['results'] = out

    # print(peg)

    return peg


if __name__ == '__main__':
    limit = 2
    offset = 3
    get_data('account_CompanyDetail', limit, offset)
