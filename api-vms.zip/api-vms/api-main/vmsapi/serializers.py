from rest_framework import serializers
from .models import Employee, EmployeeImage,Department, VisitorPass,Accessories,Approval,VisitorAccessories ,Approval,ApprovalType,MobileAllowType,MobileAllow

class DepartmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Department
        fields = ['id', 'DepartmentName','DepartmentEmail' ]

# class EmployeeSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = Employee
#         fields = ['id', 'Name', 'EmailId','MobileNumber','Age','DateOfBirth','Designation',
#         'DateOfJoining',   'DepartmentId__DepartmentName', 'VisitorAllow',  'Roles'    ]

class EmployeeSerializer(serializers.ModelSerializer):
    #DepartmentName1=serializers.PrimaryKeyRelatedField(many=True,read_only=True)
    #DepartmentName1 = DepartmentSerializer(many=True, read_only=True)
    #DepartmentName1 = DepartmentSerializer()
    DepartmentName1 = serializers.CharField(source='DepartmentId.DepartmentName',read_only=True)
    class Meta:
        model = Employee
        fields = ['id', 'Name', 'EmailId','MobileNumber','Age','DateOfBirth','Designation',
        'DateOfJoining','DepartmentId','DepartmentName1', 'VisitorAllow',  'Roles']
        #fields='__all__'
        #depth=1

    def create(self, validated_data):
        print(type(validated_data),"data type of validated_data ")
        print("data in create function",validated_data)

        #profile_data = validated_data.pop('DepartmentName1')
        #profile_data=validated_data
        user = Employee.objects.create(**validated_data)
        #Department.DepartmentName1.objects.create(user=user, **profile_data)
        return user

# class EmployeeSerializer(serializers.ModelSerializer):
#     #DepartmentName1=serializers.PrimaryKeyRelatedField(many=True,read_only=True)
#     Department = DepartmentSerializer(many=True, read_only=True)
#
#     # DepartmentName1 = serializers.CharField(source='DepartmentId.DepartmentName')
#     class Meta:
#         model = Employee
#         # fields = ['id', 'Name', 'EmailId', 'MobileNumber', 'Age', 'DateOfBirth', 'Designation',
#         #           'DateOfJoining', 'DepartmentId', 'VisitorAllow', 'Roles', 'DepartmentName1' ]
#         fields='__all__'
#         # depth=1


    # class DepartmentSerializer(serializers.ModelSerializer):
    #     class Meta:
    #         model = Department
    #         fields = ['id', 'DepartmentName','DepartmentEmail' ]



# class  VisitorPassSerializer(serializers.ModelSerializer):
#     Approval=ApprovalSerializer()
#     class Meta:
#         model = VisitorPass
#         fields = ['id', 'Name','CompanyName','Photo','MobileNo','IDProof','IdProofNumber' ,'IdProofPhoto',
#                   'VehicleNo','TypeofMobile','Address','EmployeeName','DepartmentId','FromDate','ToDate','Duration',
#                  'PurposeOfVisit', 'ScheduledBy','EmployeeId','ApproveStatus','MobileAllow','Approval']


class AccessoriesSerializer(serializers.ModelSerializer):

    class Meta:
        model = Accessories
        #fields = ['id', 'AccessoriesName']
        fields='__all__'

class VisitorAccessoriesSerializer(serializers.ModelSerializer):
    # DepartmentName1=serializers.PrimaryKeyRelatedField(many=True,read_only=True)
    # DepartmentName1 = DepartmentSerializer(many=True, read_only=True)
    # DepartmentName1 = DepartmentSerializer()
    Accessories1 = serializers.CharField(source='Accessories.AccessoriesName', read_only=True)
    VisitorPass2 = serializers.CharField(source='VisitorPass.Name', read_only=True)

    class Meta:
        model = VisitorAccessories
        fields = ['id','Accessories','VisitorPass','Accessories1','VisitorPass2']
        # fields='__all__'
        # depth=1

    # def create(self, validated_data):
    #     print(type(validated_data), "data type of validated_data ")
    #     print("data in create function", validated_data)
    #
    #     # profile_data = validated_data.pop('DepartmentName1')
    #     # profile_data=validated_data
    #     user = Employee.objects.create(**validated_data)
    #     # Department.DepartmentName1.objects.create(user=user, **profile_data)
    #     return user

class ApprovalTypeSerializer(serializers.ModelSerializer):
    # DepartmentName1=serializers.PrimaryKeyRelatedField(many=True,read_only=True)
    # DepartmentName1 = DepartmentSerializer(many=True, read_only=True)
    # DepartmentName1 = DepartmentSerializer()
    #Accessories1 = serializers.CharField(source='Accessories.AccessoriesName', read_only=True)
    #VisitorPass2 = serializers.CharField(source='VisitorPass.Name', read_only=True)

    class Meta:
        model = ApprovalType
        fields = ['id','ApprovalName']

    # def create(self, validated_data):
    #     print(type(validated_data), "data type of validated_data ")
    #     print("data in create function", validated_data)
    #
    #     # profile_data = validated_data.pop('DepartmentName1')
    #     # profile_data=validated_data
    #     user = Employee.objects.create(**validated_data)
    #     # Department.DepartmentName1.objects.create(user=user, **profile_data)
    #     return user

class ApprovalSerializer(serializers.ModelSerializer):
    # DepartmentName1=serializers.PrimaryKeyRelatedField(many=True,read_only=True)
    # DepartmentName1 = DepartmentSerializer(many=True, read_only=True)
    # DepartmentName1 = DepartmentSerializer()
    #VisitorId1 = serializers.IntegerField(source='VisitorId.id', read_only=True)
    Approval1 = serializers.CharField(source='Approval.ApprovalName', read_only=True)
    #MobileAllowName=MobileAllowTypeSerializer()

    class Meta:
        model = Approval
        fields = ['id','Approval','ApprovalBy','VisitorId','Approval1', "MobileAllowName"] #UserId will be added later

    def create(self, validated_data):
        print(type(validated_data), "data type of validated_data ")
        print("data in create function", validated_data)

        # profile_data = validated_data.pop('DepartmentName1')
        # profile_data=validated_data
        #user = Approval.objects.create(**validated_data)
        user = ApprovalType.objects.create(**validated_data)
        # Department.DepartmentName1.objects.create(user=user, **profile_data)
        return user



class  MobileAllowTypeSerializer(serializers.ModelSerializer):
    # VisitorId1=ApprovalSerializer(many=True,read_only=True)
    # VisitorId2 = ApprovalSerializer(many=True, read_only=True)
    class Meta:
        model = MobileAllowType
        # fields = ['id', 'Name','CompanyName','Photo','MobileNo','IDProof','IdProofNumber' ,'IdProofPhoto',
        #           'VehicleNo','TypeofMobile','Address','EmployeeName','DepartmentId','FromDate','ToDate','Duration',
        #          'PurposeOfVisit', 'ScheduledBy','EmployeeId','ApproveStatus','MobileAllow','ApproveStatus1']

        fields = '__all__'

class  MobileAllowSerializer(serializers.ModelSerializer):
    # VisitorId1=ApprovalSerializer(many=True,read_only=True)
    # VisitorId2 = ApprovalSerializer(many=True, read_only=True)
    MobileAllowType1= serializers.CharField(source='MobileAllowType.MobileAllowName', read_only=True)

    class Meta:
        model = MobileAllow
        fields = ['id','MobileAllowType','MobileAllowBy','VisitorId','MobileAllowType1'] #UserId will be added later

    def create(self, validated_data):
        print(type(validated_data), "data type of validated_data ")
        print("data in create function", validated_data)

        # profile_data = validated_data.pop('DepartmentName1')
        # profile_data=validated_data
        user = MobileAllow.objects.create(**validated_data)
        # Department.DepartmentName1.objects.create(user=user, **profile_data)
        return user

class VisitorPassSerializer(serializers.ModelSerializer):
    VisitorId1=ApprovalSerializer(many=True,read_only=True)
    VisitorId2 = MobileAllowSerializer(many=True, read_only=True)
    class Meta:
        model = VisitorPass
        # fields = ['id', 'Name','CompanyName','Photo','MobileNo','IDProof','IdProofNumber' ,'IdProofPhoto',
        #           'VehicleNo','TypeofMobile','Address','EmployeeName','DepartmentId','FromDate','ToDate','Duration',
        #          'PurposeOfVisit', 'ScheduledBy','EmployeeId','ApproveStatus','MobileAllow','ApproveStatus1']

        fields = '__all__'



# class HobbySerializer(serializers.ModelSerializer):
#
#     class Meta:
#         model = Hobby
#         fields = '__all__'
#
# class ProfileSerializer(serializers.ModelSerializer):
#     user_hobby = HobbySerializer(many=True)
#
#     class Meta:
#         model = Profile
#         fields = '__all__'
#
#     def create(self, validated_data):
#         user_hobby = validated_data.pop('user_hobby')
#         profile_instance = Profile.objects.create(**validated_data)
#         for hobby in user_hobby:
#             Hobby.objects.create(user=profile_instance,**hobby)
#         return profile_instance

