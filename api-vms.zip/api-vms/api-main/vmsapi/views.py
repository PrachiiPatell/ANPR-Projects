from django.shortcuts import render

from django.http import JsonResponse

import logging
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from rest_framework.response import Response

from .models import Department ,Employee, VisitorPass,Accessories,Approval,VisitorAccessories,ApprovalType, MobileAllowType,MobileAllow
from .serializers import DepartmentSerializer,EmployeeSerializer, VisitorPassSerializer, AccessoriesSerializer,VisitorAccessoriesSerializer, ApprovalSerializer, ApprovalTypeSerializer, MobileAllowTypeSerializer,MobileAllowSerializer

from rest_framework.generics import ListAPIView
from rest_framework.pagination import LimitOffsetPagination
#
#from rest_framework.genertics import ListAPIView
#from .mypeginations import MyLimitOffSetPagination

from rest_framework import viewsets
from .models import Profile
#from .serializers import ProfileSerializer

#Department api
@api_view(['GET', 'POST'])
def department(request, format=None):
    print(request.data)
    if request.method == 'GET':
        dept = Department.objects.all()
        serializer = DepartmentSerializer(dept, many=True)
        return Response(serializer.data)

    if request.method == 'POST':
        serializer = DepartmentSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()

            return Response(status=status.HTTP_201_CREATED)
    else:
        return Response( status=status.HTTP_400_BAD_REQUEST)

@api_view(['GET', 'PUT', 'DELETE'])
def department_detail(request, id, format=None):
    print("requested details of id: ", id)
    try:
        dept = Department.objects.get(pk=id)
    except:
        return Response(status=status.HTTP_404_NOT_FOUND)

    if request.method == 'GET':
        serializer = DepartmentSerializer(dept)
        return Response(serializer.data)

    elif request.method == 'PUT':
        serializer = DepartmentSerializer(dept, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    elif request.method == 'DELETE':
        #delete Department
        dept_count = Employee.objects.filter(DepartmentId=id).count()
        print(dept_count)
        if dept_count==0:
            dept.delete()
            return Response(status=status.HTTP_200_OK)
        else:
            return Response({"message":"In department Employees are already exist"},status=status.HTTP_400_BAD_REQUEST)

#Emlpoyee api
@api_view(['GET', 'POST'])
def employee(request, format=None):
    print(request.data)
    if request.method == 'GET':
        emp = Employee.objects.all()
        serializer = EmployeeSerializer(emp, many=True)
        return Response(serializer.data)

    if request.method == 'POST':
        serializer = EmployeeSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()

            return Response(status=status.HTTP_201_CREATED)
        else:
            return Response(status=status.HTTP_400_BAD_REQUEST)



@api_view(['GET', 'PUT', 'DELETE'])
def employee_detail(request, id, format=None):
    print("requested details of id: ", id)
    print(request.data)
    try:
        emp = Employee.objects.get(pk=id)
        print("emp",emp)
    except:
        return Response(status=status.HTTP_404_NOT_FOUND)

    if request.method == 'GET':
        serializer = EmployeeSerializer(emp)
        return Response(serializer.data)

    elif request.method == 'PUT':
        serializer = EmployeeSerializer(emp, data=request.data)
        print("PUT request")
        print(request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    elif request.method == 'DELETE':
        emp.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


#VisitorPass api
@api_view(['GET', 'POST'])
def visitor_pass(request, format=None):
    print(request.data)
    if request.method == 'GET':
        emp = VisitorPass.objects.all()
        serializer = VisitorPassSerializer(emp, many=True)
        return Response(serializer.data)

    if request.method == 'POST':
        serializer = VisitorPassSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()

            return Response(status=status.HTTP_201_CREATED)
        else:
            return Response(status=status.HTTP_400_BAD_REQUEST)



@api_view(['GET', 'PUT', 'DELETE'])
def visitor_pass_detail(request, id, format=None):
    print("requested details of id: ", id)
    print(request.data)
    try:
        emp = VisitorPass.objects.get(pk=id)
        print("emp",emp)
    except:
        return Response(status=status.HTTP_404_NOT_FOUND)

    if request.method == 'GET':
        serializer = VisitorPassSerializer(emp)
        return Response(serializer.data)

    elif request.method == 'PUT':
        serializer = VisitorPassSerializer(emp, data=request.data)
        print("PUT request")
        print(request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    elif request.method == 'DELETE':
        emp.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


class EmpListView(ListAPIView):
    queryset=VisitorPass.objects.all()
    serializer_class=VisitorPassSerializer
    pagination_class=LimitOffsetPagination


class EmployeeListView(ListAPIView):
    queryset=Employee.objects.all()
    serializer_class=EmployeeSerializer
    pagination_class=LimitOffsetPagination

# class ProfileViewset(ListAPIView):
#     queryset = Profile.objects.all()
#     serializer_class = ProfileSerializer
#     http_method_names = ['get','post','retrieve','put','patch']

#

#Accessories api
@api_view(['GET', 'POST'])
def accessories(request, format=None):
    print(request.data)
    if request.method == 'GET':
        acc = Accessories.objects.all()
        serializer = AccessoriesSerializer(acc, many=True)
        return Response(serializer.data)

    if request.method == 'POST':
        serializer = AccessoriesSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()

            return Response(status=status.HTTP_201_CREATED)
        else:
            return Response(status=status.HTTP_400_BAD_REQUEST)



@api_view(['GET', 'PUT', 'DELETE'])
def accessories_detail(request, id, format=None):

    print("requested details of id: ", id)
    print(request.data)
    try:
        acc = Accessories.objects.get(pk=id)
        print("emp",acc)
    except:
        return Response(status=status.HTTP_404_NOT_FOUND)

    if request.method == 'GET':
        serializer = AccessoriesSerializer(acc)
        return Response(serializer.data)

    elif request.method == 'PUT':
        serializer = AccessoriesSerializer(acc, data=request.data)
        print("PUT request")
        print(request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    elif request.method == 'DELETE':
        acc.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


#Visitor Accessories  api
@api_view(['GET', 'POST'])
def visitor_accessories(request, format=None):
    print(request.data)
    if request.method == 'GET':
        acc = VisitorAccessories.objects.all()
        serializer = VisitorAccessoriesSerializer(acc, many=True)
        return Response(serializer.data)

    if request.method == 'POST':
        serializer = VisitorAccessoriesSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()

            return Response(status=status.HTTP_201_CREATED)
        else:
            return Response(status=status.HTTP_400_BAD_REQUEST)



@api_view(['GET', 'PUT', 'DELETE'])
def visitor_accessories_detail(request, id, format=None):
    print("requested details of id: ", id)
    print(request.data)
    try:
        acc = VisitorAccessories.objects.get(pk=id)
        print("emp",acc)
    except:
        return Response(status=status.HTTP_404_NOT_FOUND)

    if request.method == 'GET':
        serializer = VisitorAccessoriesSerializer(acc)
        return Response(serializer.data)

    elif request.method == 'PUT':
        serializer = VisitorAccessoriesSerializer(acc, data=request.data)
        print("PUT request")
        print(request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    elif request.method == 'DELETE':
        acc.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


#Approval Type api
@api_view(['GET', 'POST'])
def approval_type(request, format=None):
    print(request.data)
    if request.method == 'GET':
        acc = ApprovalType.objects.all()
        serializer = ApprovalTypeSerializer(acc, many=True)
        return Response(serializer.data)

    if request.method == 'POST':
        serializer = ApprovalTypeSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()

            return Response(status=status.HTTP_201_CREATED)
        else:
            return Response(status=status.HTTP_400_BAD_REQUEST)



@api_view(['GET', 'PUT', 'DELETE'])
def approval_type_detail(request, id, format=None):
    print("requested details of id: ", id)
    print(request.data)
    try:
        acc = ApprovalType.objects.get(pk=id)
        print("emp",acc)
    except:
        return Response(status=status.HTTP_404_NOT_FOUND)

    if request.method == 'GET':
        serializer = ApprovalTypeSerializer(acc)
        return Response(serializer.data)

    elif request.method == 'PUT':
        serializer = ApprovalTypeSerializer(acc, data=request.data)
        print("PUT request")
        print(request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    elif request.method == 'DELETE':
        acc.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)



#Approval api
@api_view(['GET', 'POST'])
def approval(request, format=None):
    print(request.data)
    if request.method == 'GET':
        acc = Approval.objects.all()
        serializer = ApprovalSerializer(acc, many=True)
        return Response(serializer.data)

    if request.method == 'POST':
        serializer = ApprovalSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()

            return Response(status=status.HTTP_201_CREATED)
        else:
            return Response(status=status.HTTP_400_BAD_REQUEST)



@api_view(['GET', 'PUT', 'DELETE'])
def approval_detail(request, id, format=None):
    print("requested details of id: ", id)
    print(request.data)
    try:
        acc = Approval.objects.get(pk=id)
        print("emp",acc)
    except:
        return Response(status=status.HTTP_404_NOT_FOUND)

    if request.method == 'GET':
        serializer = ApprovalSerializer(acc)
        return Response(serializer.data)

    elif request.method == 'PUT':
        serializer = ApprovalSerializer(acc, data=request.data)
        print("PUT request")
        print(request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    elif request.method == 'DELETE':
        acc.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

class ApprovalListView(ListAPIView):
    queryset=Approval.objects.all()
    serializer_class=ApprovalSerializer
    pagination_class=LimitOffsetPagination


#MobileAllowType api
@api_view(['GET', 'POST'])
def mobile_allow_type(request, format=None):
    print(request.data)
    if request.method == 'GET':
        acc = MobileAllowType.objects.all()
        serializer = MobileAllowTypeSerializer(acc, many=True)
        return Response(serializer.data)

    if request.method == 'POST':
        serializer = MobileAllowTypeSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()

            return Response(status=status.HTTP_201_CREATED)
        else:
            return Response(status=status.HTTP_400_BAD_REQUEST)



@api_view(['GET', 'PUT', 'DELETE'])
def mobile_allow_type_detail(request, id, format=None):
    print("requested details of id: ", id)
    print(request.data)
    try:
        acc = MobileAllowType.objects.get(pk=id)
        print("emp",acc)
    except:
        return Response(status=status.HTTP_404_NOT_FOUND)

    if request.method == 'GET':
        serializer = MobileAllowTypeSerializer(acc)
        return Response(serializer.data)

    elif request.method == 'PUT':
        serializer = MobileAllowTypeSerializer(acc, data=request.data)
        print("PUT request")
        print(request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    elif request.method == 'DELETE':
        acc.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

#MobileAllow api
@api_view(['GET', 'POST'])
def mobile_allow(request, format=None):
    print(request.data)
    if request.method == 'GET':
        acc = MobileAllow.objects.all()
        serializer = MobileAllowSerializer(acc, many=True)
        return Response(serializer.data)

    if request.method == 'POST':
        serializer = MobileAllowSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()

            return Response(status=status.HTTP_201_CREATED)
        else:
            return Response(status=status.HTTP_400_BAD_REQUEST)



@api_view(['GET', 'PUT', 'DELETE'])
def mobile_allow_detail(request, id, format=None):
    print("requested details of id: ", id)
    print(request.data)
    try:
        acc = MobileAllow.objects.get(pk=id)
        print("emp",acc)
    except:
        return Response(status=status.HTTP_404_NOT_FOUND)

    if request.method == 'GET':
        serializer = MobileAllowSerializer(acc)
        return Response(serializer.data)

    elif request.method == 'PUT':
        serializer = MobileAllowSerializer(acc, data=request.data)
        print("PUT request")
        print(request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    elif request.method == 'DELETE':
        acc.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)
