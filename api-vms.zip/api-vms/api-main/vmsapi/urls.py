from django.contrib import admin
from django.urls import path
from rest_api_app import views
from rest_framework.urlpatterns import format_suffix_patterns

urlpatterns = [
    path('admin/', admin.site.urls),
    path('face/', views.face_list),
    #path('drinks/', views.drink_list),
    #path('drinks/<int:id>', views.drink_detail)
]

urlpatterns = format_suffix_patterns(urlpatterns)