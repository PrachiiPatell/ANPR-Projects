import requests

response = requests.get(f"http://127.0.0.1:8000/Employee/")
if response.status_code == 200:
    print("sucessfully fetched the data")
    print(response.json())
    data=response.json()
else:
    print(f"Hello person, there's a {response.status_code} error with your request")

print(type(data))


##
dept = Department.objects.all()