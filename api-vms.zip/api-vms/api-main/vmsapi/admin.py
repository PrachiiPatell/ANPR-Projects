from django.contrib import admin
from .models import Employee, Department,Accessories,VisitorAccessories, ApprovalType,Approval,MobileAllow,MobileAllowType,VisitorPass

# Register your models here.

admin.site.register(Employee)
admin.site.register(Department)
admin.site.register(Accessories)
admin.site.register(VisitorAccessories)
admin.site.register(ApprovalType)
admin.site.register(Approval)
admin.site.register(MobileAllow)
admin.site.register(MobileAllowType)
admin.site.register(VisitorPass)


#Register account app models
