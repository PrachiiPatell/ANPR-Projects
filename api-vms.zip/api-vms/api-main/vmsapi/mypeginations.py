from rest_framework.pagination import LimitOffSetPagination


class MyLimitOffSetPagination(LimitOffSetPagination):
    pass