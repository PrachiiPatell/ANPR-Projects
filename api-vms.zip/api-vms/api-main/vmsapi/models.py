from django.db import models
from datetime import datetime

class Department(models.Model):
    DepartmentName = models.TextField()
    DepartmentEmail = models.TextField()
    # from_date = models.DateField(default=datetime.now)
    # to_date = models.DateField(default=datetime.now)

# class Employee(models.Model):
#     Name = models.TextField()
#     EmailId = models.TextField()
#     MobileNumber = models.TextField()
#     Age=models.IntegerField()
#     DateOfBirth=models.DateField(default=datetime.now)
#     Designation=models.TextField()
#     DateOfJoining=models.DateField(default=datetime.now)
#     #DepartmentId=models.IntegerField()
#     DepartmentId = models.ForeignKey(Department, on_delete=models.PROTECT)
#     VisitorAllow=models.TextField()
#     Roles=models.TextField( null=True, blank=True)

class Employee(models.Model):
    Name = models.TextField()
    EmailId = models.EmailField()
    MobileNumber = models.TextField()
    Age=models.IntegerField()
    DateOfBirth=models.DateField(default=datetime.now)
    Designation=models.TextField()
    DateOfJoining=models.DateField(default=datetime.now)
    #DepartmentId=models.IntegerField()
    DepartmentId = models.ForeignKey(Department, on_delete=models.PROTECT,related_name="DepartmentName1")
    #DepartmentId = models.ForeignKey(Department, on_delete=models.CASCADE)
    VisitorAllow=models.TextField()
    Roles=models.TextField( null=True, blank=True)


class EmployeeImage(models.Model):
    EmployeeId  = models.TextField()
    Photo = models.TextField()

class VisitorPass(models.Model):
    Name = models.TextField( null=True, blank=True)
    CompanyName = models.TextField( null=True, blank=True)
    Photo=models.TextField( null=True, blank=True)
    MobileNo=models.TextField( null=True, blank=True)
    IDProof=models.TextField( null=True, blank=True)
    IdProofNumber=models.TextField( null=True, blank=True)
    IdProofPhoto=models.TextField( null=True, blank=True)
    VehicleNo=models.TextField( null=True, blank=True)
    TypeofMobile=models.TextField( null=True, blank=True)
    Address=models.TextField( null=True, blank=True)
    EmployeeName=models.TextField( null=True, blank=True)
    DepartmentId=models.TextField( null=True, blank=True)
    FromDate=models.DateField(default=datetime.now,null=True, blank=True)
    ToDate=models.DateField(default=datetime.now,null=True, blank=True)
    Duration=models.TextField( null=True, blank=True)
    PurposeOfVisit=models.TextField( null=True, blank=True)
    ScheduledBy=models.TextField( null=True, blank=True)
    EmployeeId=models.TextField( null=True, blank=True)

    ApproveStatus=models.TextField( null=True, blank=True)
    MobileAllow=models.TextField( null=True, blank=True)

    # from_date = models.DateField(default=datetime.now)
    # to_date = models.DateField(default=datetime.now)



class Profile(models.Model):
    display_name = models.CharField(max_length=30)
    mobile = models.IntegerField()
    address = models.TextField()
    email = models.EmailField()
    dob = models.DateField()
    photo=models.FileField(upload_to='profile/',null=True,blank=True)
    status = models.IntegerField(default=1)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)


# class Hobby(models.Model):
#     user=models.ForeignKey(Profile,on_delete=models.CASCADE,related_name='user_hobby',null=True,blank=True)
#     name = models.CharField(max_length=30)
#     description = models.TextField()
#     status = models.IntegerField(default=1)
#     created_at = models.DateTimeField(auto_now_add=True)
#     updated_at = models.DateTimeField(auto_now=True)

class Accessories(models.Model):
    AccessoriesName=models.TextField()

class VisitorAccessories(models.Model):
    Accessories=models.ForeignKey(Accessories, on_delete=models.PROTECT,related_name="Accessories1")
    VisitorPass=models.ForeignKey(VisitorPass, on_delete=models.PROTECT,related_name="VisitorPass2")

class ApprovalType(models.Model):
    ApprovalName=models.CharField(max_length=30)
    # CompanyId


class Approval(models.Model):
    Approval=models.ForeignKey(ApprovalType, on_delete=models.CASCADE,related_name="Approval1")
    ApprovalBy=models.CharField(max_length=30)
    #UserId=models.ForeignKey(User, on_delete=models.PROTECT,related_name="User1")
    VisitorId=models.ForeignKey(VisitorPass, on_delete=models.PROTECT,related_name="VisitorId1")
    #XYZ=models.ForeignKey(VisitorPass, on_delete=models.CASCADE, related_name='ApproveStatus1',null=True)


#user model is pending

class MobileAllowType(models.Model):
    MobileAllowName=models.CharField(max_length=30)
    #company model: pending
    #CompanyId=models.ForeignKey(Company, on_delete=models.PROTECT,related_name="CompanyId1")

class MobileAllow(models.Model):
    MobileAllowType=models.ForeignKey(MobileAllowType, on_delete=models.PROTECT,related_name="MobileAllowType1")
    MobileAllowBy=models.CharField(max_length=30)
    #UserId=models.ForeignKey(user, on_delete=models.PROTECT,related_name="UserId1")
    VisitorId=models.ForeignKey(VisitorPass, on_delete=models.PROTECT,related_name="VisitorId2")


