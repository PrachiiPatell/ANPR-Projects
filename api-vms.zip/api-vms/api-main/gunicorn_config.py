import multiprocessing

bind = '0.0.0.0:8005'
workers = 1